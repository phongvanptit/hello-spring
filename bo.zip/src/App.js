import React from 'react';
import PropTypes from 'prop-types';
import Container from 'react-bootstrap/Container';
// import * as Sentry from "@sentry/react";

const App = (props) => <Container>{props.children}</Container>;

App.propTypes = {
  children: PropTypes.node,
};

// export default Sentry.withProfiler(App);
export default App;
