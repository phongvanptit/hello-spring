import React from 'react';
import { makeGetExportFile } from 'lib/reselect/report';
import { connect, useDispatch } from 'react-redux';

import { ReactComponent as IconDownload } from 'assets/img/icon/ic_download.svg';
import Loading from 'assets/img/loading.gif';
import { globalExportFileRequest } from 'containers/report/actions';

function ExportFile(props) {
  const { exportFile, t, dataSearch } = props;

  const dispatch = useDispatch();

  function _handleExportFile() {
    if (!dataSearch || exportFile) return;

    dispatch(globalExportFileRequest(dataSearch));
  }

  return (
    <div style={{ width: '100px' }}>
      <a onClick={_handleExportFile} rel="noreferrer nofollow">
        <IconDownload />{' '}
        {exportFile && <img src={Loading} alt="" style={{ height: '15px' }} />}
        {!exportFile && <span>{t('Export file')}</span>}
      </a>
    </div>
  );
}

const makeMapStateToProps = () => {
  const getExportFile = makeGetExportFile();

  const mapStateToProps = (state) => {
    return {
      exportFile: getExportFile(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(ExportFile);
