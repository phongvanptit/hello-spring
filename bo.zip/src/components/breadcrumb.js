import React, { memo } from 'react';
import styled from 'styled-components';
import * as _ from 'lodash';
import { navItems } from '_nav';
import { Link, useLocation } from 'react-router-dom';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { makeGetPfAccFunc } from 'lib/selector';
import { connect } from 'react-redux';
import { checkHasActByFunc } from 'utils';

const Breadcrumb = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;
  padding: 0 24px 4px 24px;
  background: #ecebea;
  width: 100%;

  .scrollbar-container {
    padding-bottom: 12px;
  }

  ul {
    width: 100%;
    height: 100%;
    padding-left: 0;
    position: relative;
    display: flex;

    li {
      border-left: none;
      display: flex;
      align-items: center;
      border-radius: 8px;

      a {
        white-space: nowrap;
        color: #6f6f6f;
        padding: 6px 24px;
        font-weight: 500;
        font-size: 13px;
        line-height: 16px;
      }

      &.active {
        background: #1c1c1c;

        a {
          color: #ffa31a;
          font-weight: 600;
        }
      }
      &.disabled {
        a {
          color: #b1b1b1;
        }
      }
    }
  }

  div.bg-border {
    width: 100%;
    height: 1px;
    margin-bottom: 16px;
    background: #f0eeea;
  }
`;

function RenderBreadcrumb(props) {
  const { pathUrl, pfAccFunc, t } = props;
  const location = useLocation();
  const { pathname } = location;

  const _group = _.find(navItems, (o) => o.url === pathUrl);

  console.log(_group);

  if (!_group || !_group?.children) return null;

  return (
    <Breadcrumb>
      <PerfectScrollbar>
        <div className="bg-border" />
        <ul>
          {_group?.children.map((item, index) => (
            <li
              className={
                !checkHasActByFunc(item.right, pfAccFunc)
                  ? 'disabled'
                  : pathname === item.url || pathname.startsWith(item.url + '/')
                  ? 'active'
                  : ''
              }
              key={index}
            >
              {checkHasActByFunc(item.right, pfAccFunc) ? (
                <Link to={item.url}>{t(item.lableCode)}</Link>
              ) : (
                <a rel="noreferrer noopener">{t(item.lableCode)}</a>
              )}
            </li>
          ))}
        </ul>
      </PerfectScrollbar>
    </Breadcrumb>
  );
}

const makeMapStateToProps = () => {
  const getPfAccFunc = makeGetPfAccFunc();

  const mapStateToProps = (state) => {
    return {
      pfAccFunc: getPfAccFunc(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(RenderBreadcrumb)
);
