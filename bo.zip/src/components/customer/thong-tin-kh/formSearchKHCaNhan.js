import { makeGetToken } from 'lib/selector';
import React, { useEffect } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';

import FormSearchModal from './formSearchModal';
import FormSearchShort from './formSearchShort';

import {
  custListSearchRequest,
  custListSearchSuccess,
} from 'containers/customer/actions';
import {
  ContainerDropdownShow,
  ContainerSearch,
  ContainerSearchDropdown,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const wrapperRef = React.useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);
  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage, t, statusCode } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(custListSearchSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;
      dispatch(custListSearchRequest(dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }
  function initFormSearch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_TYPE: '',
        NATIONAL_TYPE: '',
        CUSTOMER_CODE: '',
        CUSTOMER_NAME: '',
        CARD_ID: '',
        CUSTOMER_MOBILE: '',
        CUSTOMER_EMAIL: '',
        CHANNEL_CODE: '',
        CREATOR_CODE: '',
        STATUS: statusCode ? statusCode : '',

        PAGE: 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);
  }

  function _handleShow() {
    setShowModal(!showModal);
  }
  return (
    <ContainerSearch>
      <div ref={wrapperRef} style={{ position: 'relative' }}>
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              dataSearch={dataSearch}
              setDataSearch={setDataSearch}
              onClose={() => setShowModal(false)}
            />
          </ContainerDropdownShow>
        )}
      </div>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
          bizCode={'BACK.GET_ALL_CUSTOMER'}
          statusCode={statusCode}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
