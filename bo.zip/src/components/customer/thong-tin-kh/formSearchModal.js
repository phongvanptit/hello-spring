import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { formatDate } from 'utils';
import { translate } from 'react-i18next';

import * as _ from 'lodash';
import { arrSearchKHCaNhan } from 'utils/const';
import { makeGetChannelType } from 'lib/selector';
import { makeGetCustType } from 'lib/selector';
import { custListSearchRequest } from 'containers/customer/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();
  const [arrSel, setArrSel] = React.useState([]);

  const {
    handleSubmit,
    submitting,
    t,
    glChannelType,

    onClose,
    dataSearch,
    setDataSearch,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchKHCaNhan, 'value'));
  }, []);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.NATIONAL_TYPE = values.formNationalType;
    _dataSearch.data.CUSTOMER_NAME = values.formCustName;
    _dataSearch.data.CARD_ID = values.formDKSH;
    _dataSearch.data.CUSTOMER_MOBILE = values.formPhoneNumber;
    _dataSearch.data.CUSTOMER_EMAIL = values.formEmail;
    _dataSearch.data.CHANNEL_CODE = values.formChannel;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    _dataSearch.data.ALL_FLAG = 1;

    dispatch(custListSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchKhachHangModal', 'formNationalType', ''));
    dispatch(change('formSearchKhachHangModal', 'formCustCode', ''));
    dispatch(change('formSearchKhachHangModal', 'formCustName', ''));
    dispatch(change('formSearchKhachHangModal', 'formDKSH', ''));
    dispatch(change('formSearchKhachHangModal', 'formPhoneNumber', ''));
    dispatch(change('formSearchKhachHangModal', 'formEmail', ''));
    dispatch(change('formSearchKhachHangModal', 'formChannel', ''));
    dispatch(change('formSearchKhachHangModal', 'formCreatorCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100 ">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchKHCaNhan,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (_objItem.value === 'formChannel')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    placeholder="-- Tất cả --"
                  />
                </Form.Group>
              );

            if (_objItem.value === 'formNationalType')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name="formNationalType"
                    className="form-control w-100"
                    component={RenderNormalSelect}
                    placeholder="-- Tất cả --"
                    opts={[
                      { value: 'TRONG_NUOC', label: 'Trong nước' },
                      { value: 'NUOC_NGOAI', label: 'Nước ngoài' },
                    ]}
                  />
                </Form.Group>
              );

            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formCustCode' &&
              _objItem.value !== 'formCustName'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'date')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    className="form-control"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                  />
                </Form.Group>
              );
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchKhachHangModal',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchKhachHangModal');

const makeMapStateToProps = () => {
  const getChannelType = makeGetChannelType();
  const getCustType = makeGetCustType();

  const mapStateToProps = (state, props) => {
    const {
      formDKSH,
      formPhoneNumber,
      formEmail,
      formNationalType,
      formChannel,
      formCreatorCode,
    } = selector(
      state,
      'formDKSH',
      'formPhoneNumber',
      'formEmail',
      'formNationalType',
      'formChannel',
      'formCreatorCode'
    );

    const { dataSearch } = props;

    return {
      glCustType: getCustType(state),
      glChannelType: getChannelType(state),
      formDKSH,
      formPhoneNumber,
      formEmail,
      formNationalType,
      formChannel,
      formCreatorCode,

      initialValues: {
        formDKSH: dataSearch?.data?.CARD_ID,
        formPhoneNumber: dataSearch?.data?.CUSTOMER_MOBILE,
        formEmail: dataSearch?.data?.CUSTOMER_EMAIL,
        formNationalType: dataSearch?.data?.NATIONAL_TYPE,
        formChannel: dataSearch?.data?.CHANNEL_CODE,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
