import React, { memo } from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { numberFormat } from 'utils';

import * as _ from 'lodash';

function TabAccountLMV({ accountLMV }) {
  const totalLMV0 = _.sumBy(accountLMV, (o) => o.lmv_0);
  const totalLMV = _.sumBy(accountLMV, (o) => o.lmv);
  const totalMR = _.sumBy(accountLMV, (o) => o.mr);

  return (
    <PerfectScrollbar
      style={{ height: 'calc(100vh - 550px)' }}
      className="mb-2"
    >
      <table className="table table-bordered">
        <thead>
          <tr>
            <th className="high-light">Stock</th>
            <th className="high-light">Type</th>
            <th className="high-light">Rate</th>
            <th className="high-light">Wait</th>
            <th className="high-light">Actual Vol</th>
            <th className="high-light">MKT Price</th>
            <th className="high-light">Limit Price</th>
            <th className="high-light">LMV_0</th>
            <th className="high-light">LMV</th>
            <th className="high-light">MR</th>
            <th className="high-light">PLG</th>
            <th className="high-light">%P</th>
            <th className="high-light">Note</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className=" font-weight-bold high-light-2" colSpan="7">
              TOTAL
            </td>
            <td className="text-right font-weight-bold high-light-2">
              {numberFormat(totalLMV0)}
            </td>
            <td className="text-right font-weight-bold high-light-2">
              {numberFormat(totalLMV)}
            </td>
            <td className="text-right font-weight-bold high-light-2">
              {numberFormat(totalMR)}
            </td>
            <td className=" high-light-2"></td>
            <td className=" high-light-2"></td>
            <td className=" high-light-2"></td>
          </tr>
          {accountLMV &&
            !!accountLMV.length &&
            accountLMV.map((item, i) => (
              <tr key={i}>
                <td className={'text-center '}>{item.s}</td>
                <td className="text-center">{item.t}</td>
                <td className="text-center">{numberFormat(item.p * 100)}%</td>
                <td className="text-right">{numberFormat(item.temp)}</td>
                <td className="text-right">{numberFormat(item.at)}</td>
                <td className={'text-right '}>{numberFormat(item.mp)}</td>
                <td className="text-right">{numberFormat(item.lp)}</td>
                <td className="text-right">{numberFormat(item.lmv_0)}</td>
                <td className="text-right">{numberFormat(item.lmv)}</td>
                <td className="text-right">{numberFormat(item.mr)}</td>
                <td className="text-center">{item.plg}</td>
                <td className="text-center">{item.pc}</td>
                <td>{item.sector}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </PerfectScrollbar>
  );
}

export default memo(TabAccountLMV);
