import React, { useEffect, useRef } from 'react';

import Avatar from 'assets/img/account/avatar.png';
import BadgeCheck from 'assets/img/icon/badgeCheck.png';
import {
  custMasterDetailRequest,
  custMasterDetailSuccess,
} from 'containers/customer/actions';
import { makeGetToken, makeGtCustMasterDetail } from 'lib/selector';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import styled from 'styled-components';
import TabThongTinChung from './TabThongTinChung';
import TabTKThuong from './TabTKThuong';
import TabTKMargin from './TabTKMargin';

//#region
const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-top: 16px;
`;

const PanelHead = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f5f5f5;
  border-radius: 12px;
  padding: 6px;

  .account-info {
    display: flex;

    img.avatar {
      height: 46px;
      width: 46px;
      margin-right: 16px;
      align-self: center;
    }

    .account-name {
      display: flex;
      flex-direction: column;

      span:first-of-type {
        font-weight: bold;
        font-size: 16px;
        color: #3c3c3c;
      }
      span:last-of-type {
        font-weight: 500;
        font-size: 13px;
        line-height: 24px;
        color: #979797;
      }
    }
  }
`;

const SubBreadcrumb = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;

  ul {
    width: 100%;
    height: 100%;
    padding-left: 0;
    position: relative;
    display: flex;

    li {
      border-left: none;
      display: flex;
      align-items: center;
      padding: 6px 12px;
      border-bottom: 1.5px solid transparent;
      white-space: nowrap;
      font-size: 13px;
      line-height: 16px;
      color: #6f6f6f;
      cursor: pointer;

      &.active {
        border-bottom-color: #ffa31a;
        font-weight: 600;
        color: #ffa31a;
      }
    }
  }
`;

//#endregion

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function IndividualEditComponent(props) {
  const dispatch = useDispatch();
  const [tabActive, setTabActive] = React.useState('THONG_TIN_CHUNG');

  const { token, custCode, custDetail, t, accRight } = props;

  useEffect(() => {
    // get customer detail
    if (custCode) {
      handleGetSingleCustomer();
    }
    return () => {
      dispatch(custMasterDetailSuccess(null));
    };
  }, []);

  function handleGetSingleCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custCode,
      },
    };

    dispatch(custMasterDetailRequest(params));
  }

  return (
    <Container>
      <div className="d-flex flex-column">
        <PanelHead>
          <div className="account-info">
            <img src={Avatar} className={'avatar'} alt="" />
            <div className="account-name">
              <span>{custDetail?.C_CUSTOMER_NAME}</span>
              <span>
                {t('txt-acc')}
                {':'} {custDetail?.C_CUSTOMER_CODE}{' '}
                <img src={BadgeCheck} alt="" />
              </span>
            </div>
          </div>
        </PanelHead>
      </div>
      <SubBreadcrumb>
        <ul>
          <li
            onClick={() => setTabActive('THONG_TIN_CHUNG')}
            className={tabActive === 'THONG_TIN_CHUNG' ? 'active ' : ''}
          >
            {t('txt-general-info')}
          </li>
          {/*<li*/}
          {/*  onClick={() => setTabActive('TK_THUONG')}*/}
          {/*  className={tabActive === 'TK_THUONG' ? 'active ' : ''}*/}
          {/*>*/}
          {/*  {t('txt-acc-regular')}*/}
          {/*</li>*/}
          {/*<li*/}
          {/*  onClick={() => setTabActive('TK_MARGIN')}*/}
          {/*  className={tabActive === 'TK_MARGIN' ? 'active ' : ''}*/}
          {/*>*/}
          {/*  {t('txt-acc-margin')}*/}
          {/*</li>*/}
        </ul>
      </SubBreadcrumb>
      {tabActive === 'THONG_TIN_CHUNG' && (
        <TabThongTinChung
          custDetail={custDetail}
          custCode={custCode}
          accRight={accRight}
        />
      )}

      {/*{tabActive === 'TK_THUONG' && (*/}
      {/*  <TabTKThuong custCode={custCode} accRight={accRight} />*/}
      {/*)}*/}
      {/*{tabActive === 'TK_MARGIN' && (*/}
      {/*  <TabTKMargin custCode={custCode} accRight={accRight} />*/}
      {/*)}*/}
    </Container>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCustomerDetail = makeGtCustMasterDetail();

  return {
    token: getToken(state),
    custDetail: getCustomerDetail(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(IndividualEditComponent)
);
