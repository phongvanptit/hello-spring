import React, { useEffect, Fragment, useState } from 'react';
import { StringToInt, numberFormat } from 'utils';
import { connect, useDispatch } from 'react-redux';
import {
  cashBdAccStatusRequest,
  cashBdAccStatusSuccess,
  cashBdaccountPortfolioRequest,
  cashBdaccountPortfolioSuccess,
} from 'containers/cash/actions';
import {
  makeGetToken,
  makeGetBdAccStatus,
  makeGetBdAccPortStatus,
} from 'lib/selector';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import Paging from 'components/paging';

function TabTkThuong(props) {
  const { token, custCode, accountStatus, accountPortfolio, tabActive } = props;
  const dispatch = useDispatch();
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);

  function _handleNextPage(step) {
    setPage(step);
  }
  const [singleTaiSanFetched, setSingleTaiSanFetched] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      // get customer detail
      if (custCode && !singleTaiSanFetched) {
        await getSingleTaiSan();
        setSingleTaiSanFetched(true);
      }
    };

    fetchData();

    return () => {
      dispatch(cashBdAccStatusSuccess(null));
      dispatch(cashBdaccountPortfolioSuccess(null));
    };
  }, [custCode, singleTaiSanFetched]);

  useEffect(() => {
    if (singleTaiSanFetched) {
      setTimeout(() => {
        getAccountPortfolio();
      }, 200);
    }
  }, [singleTaiSanFetched]);

  async function getSingleTaiSan() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        type: 'string',
        cmd: 'BD.accountStatus',
        p1: custCode + '1',
      },
    };

    await dispatch(cashBdAccStatusRequest(params));
  }

  function getAccountPortfolio() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        cmd: 'BD.accountPortfolio',
        type: 'string',
        p2: '1',
        p3: '30',
        p1: custCode + '1',
      },
    };

    dispatch(cashBdaccountPortfolioRequest(params));
  }

  const marketValues = Array.isArray(accountPortfolio)
    ? accountPortfolio?.find((item) => item.symbol === 'TOTAL')
    : null;

  const totalMarketValue = marketValues ? marketValues.market_value : 0;

  return (
    <div style={{ display: 'flex' }}>
      <div style={{ width: '300px' }}>
        <div className="custom-tabs-content my-2">
          <div>
            <p className="text-center ">Thông tin chung</p>
          </div>
          <table className="table table-bordered">
            <tbody>
              <tr>
                <td className="text-left">Sản phẩm</td>
                <td className="text-right">NORMAL</td>
              </tr>
              <tr>
                <td className="text-left">Phí max</td>
                <td className="text-right">
                  {accountStatus?.max_rate &&
                    (accountStatus?.max_rate.startsWith('.')
                      ? '0' + accountStatus?.max_rate
                      : accountStatus?.max_rate)}
                  %
                </td>
              </tr>
              <tr>
                <td className="text-left"></td>
                <td className="text-right">-</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="custom-tabs-content my-2">
          <div>
            <p className="text-center  ">Tiền</p>
          </div>
          <table className="table table-bordered">
            <tbody>
              <tr>
                <td className="text-left">Tài sản ròng</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.assets, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Số dư tiền</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.cash_balance, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Số tiền phong toả</td>
                <td className="text-right d">
                  {numberFormat(accountStatus?.cash_block, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Cổ tức tiền</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.collateral, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Phí lưu ký</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.deposit_fee, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Tiền có thể rút</td>
                <td className="text-right i">
                  {numberFormat(accountStatus?.withdrawal_cash, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Tiền rút chờ duyệt</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.cash_temp_day_out, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Tiền có thể ứng</td>
                <td className="text-right i">
                  {numberFormat(accountStatus?.cash_advance_avai, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Hạn mức ứng</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.temp_ee, 0)}
                </td>
              </tr>
              <tr>
                <td className="text-left">Hạn mức đã dùng</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.tempee_used, 0)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div style={{ width: '100%', marginLeft: 10 }}>
        <div className="custom-tabs-content my-2">
          <div>
            <p className="text-center mt-1 mb-1">
              Giá trị thanh toán Mua/Bán CK
            </p>
          </div>
          <table className="table table-bordered">
            <thead>
              <tr>
                <th colSpan="2">T2</th>
                <th colSpan="2">T1</th>
                <th colSpan="2">T0</th>
                <th rowSpan="2">Mua CK chưa khớp</th>
                <th rowSpan="2">Bán CK chưa khớp</th>
                <th rowSpan="2">Tiền có thể ứng</th>
              </tr>
              <tr>
                <th>Tiền mua CK</th>
                <th>Tiền bán CK</th>
                <th>Tiền mua CK</th>
                <th>Tiền bán CK</th>
                <th>Tiền mua CK</th>
                <th>Tiền bán CK</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="text-right">-</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.ap_t2, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.ar_t1, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.ap_t1, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.ar_t0, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.ap_t0, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.buy_unmatch, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.sell_unmatch, 0)}
                </td>
                <td className="text-right">
                  {numberFormat(accountStatus?.cash_advance_avai, 0)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="custom-tabs-content my-2">
          <div>
            <p className="text-center mt-1 mb-1">Trạng thái danh mục</p>
          </div>
          <PerfectScrollbar style={{ height: 'calc(100vh - 575px)' }}>
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Mã CK</th>
                  <th>Khả dụng</th>
                  <th>T2 Mua</th>
                  <th>T2 Bán</th>
                  <th>T1 Mua</th>
                  <th>T1 Bán</th>
                  <th>T0 Mua</th>
                  <th>T0 Bán</th>
                  <th>Giá TB</th>
                  <th>Giá TT</th>
                  <th>Giá trị TT</th>
                  <th>%P</th>
                  <th>Chú ý</th>
                </tr>
              </thead>
              <tbody>
                {accountPortfolio &&
                  accountPortfolio.length > 0 &&
                  accountPortfolio.map((idata, i) => (
                    <tr key={i}>
                      <td className="text-center">{idata.symbol}</td>
                      {idata.symbol === 'TOTAL' && (
                        <Fragment>
                          <td colSpan="9"></td>
                          <td className="text-right">
                            {numberFormat(idata.market_value, 0)}
                          </td>
                          <td className="text-center">100%</td>
                          <td></td>
                        </Fragment>
                      )}
                      {idata.symbol !== 'TOTAL' && (
                        <Fragment>
                          <td
                            className={
                              'text-right  ' +
                              (idata.gain_loss_value > 0 ? 'i' : 'd')
                            }
                          >
                            {numberFormat(idata.avaiable_vol, 0)}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.buy_t2, 0)}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.sell_t2, 0)}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.buy_t1, 0)}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.sell_t1, 0)}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.buy_t0, 0)}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.sell_t0, 0)}
                          </td>
                          <td className="text-right">{idata.avg_price}</td>
                          <td
                            className={
                              'text-right ' +
                              (idata.gain_loss_value > 0 ? 'i' : 'd')
                            }
                          >
                            {idata.market_price}
                          </td>
                          <td className="text-right">
                            {numberFormat(idata.market_value, 0)}
                          </td>
                          <td className="text-center">
                            {numberFormat(
                              (StringToInt(idata.market_value) /
                                StringToInt(totalMarketValue)) *
                                100,
                              2
                            )}
                            %
                          </td>
                          <td></td>
                        </Fragment>
                      )}
                    </tr>
                  ))}
              </tbody>
            </table>
          </PerfectScrollbar>
          <div className="mt-3 d-flex justify-content-end">
            <Paging
              page={page}
              nextPage={_handleNextPage}
              recordPerPage={recordPerPage}
              setRecordPerPage={setRecordPerPage}
              total={
                accountPortfolio && !!accountPortfolio.length
                  ? accountPortfolio[0].C_TOTAL_RECORD
                  : 0
              }
            />
          </div>
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getBdAccStatus = makeGetBdAccStatus();
  const getBdAccPortPortfolio = makeGetBdAccPortStatus();

  return {
    token: getToken(state),
    accountStatus: getBdAccStatus(state),
    accountPortfolio: getBdAccPortPortfolio(state),
  };
};
export default connect(mapStateToProps)(translate('translations')(TabTkThuong));
