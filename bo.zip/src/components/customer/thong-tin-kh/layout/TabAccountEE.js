import React, { memo } from 'react';

import PerfectScrollbar from 'react-perfect-scrollbar';
import * as _ from 'lodash';
import { numberFormat } from 'utils';

function TabAccountEE({ detailLMVEE }) {
  return (
    <PerfectScrollbar style={{ height: 'calc(100vh - 550px)' }}>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th className="high-light">Mã CK</th>
            <th className="high-light">Tỷ lệ</th>
            <th className="high-light">KL thực tế</th>
            <th className="high-light">KL uỷ ban</th>
            <th className="high-light">KL ba bên</th>
            <th className="high-light">KL nợ</th>
            <th className="high-light">Giá tính</th>
            <th className="high-light">Giá chặn trần</th>
            <th className="high-light">LMV</th>
            <th className="high-light">MR</th>
            <th className="high-light">Note</th>
          </tr>
        </thead>
        <tbody>
          {detailLMVEE && !!detailLMVEE.length && (
            <tr>
              <td className=" font-weight-bold high-light-2" colSpan="3">
                TOTAL
              </td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(
                  _.sumBy(detailLMVEE, (o) => o.debt_vol_ub * o.mp),
                  0
                )}
              </td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(
                  _.sumBy(detailLMVEE, (o) => o.debt_vol_bb * o.mp)
                )}
              </td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(_.sumBy(detailLMVEE, (o) => o.debt_vol * o.mp))}
              </td>
              <td className=" high-light-2" colSpan="2"></td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(_.sumBy(detailLMVEE, (o) => o.lmv))}
              </td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(_.sumBy(detailLMVEE, (o) => o.mr))}
              </td>
              <td className=" high-light-2"></td>
            </tr>
          )}
          {detailLMVEE &&
            !!detailLMVEE.length &&
            detailLMVEE.map((item, i) => (
              <tr key={'lmvee_' + i}>
                <td className={'text-center '}>{item.s}</td>
                <td className="text-center">{numberFormat(item.p * 100)}%</td>
                <td className="text-right">{numberFormat(item.at)}</td>
                <td className="text-right">{numberFormat(item.debt_vol_ub)}</td>
                <td className="text-right">{numberFormat(item.debt_vol_bb)}</td>
                <td className="text-right">{numberFormat(item.debt_vol)}</td>
                <td className={'text-right '}>{numberFormat(item.mp)}</td>
                <td className="text-right">{numberFormat(item.lp)}</td>
                <td className="text-right">{numberFormat(item.lmv)}</td>
                <td className="text-right">{numberFormat(item.mr)}</td>
                <td>{item.sector}</td>
              </tr>
            ))}
        </tbody>
      </table>
      {(!detailLMVEE || !detailLMVEE.length) && (
        <p className="text-center fz-12 text-white-50">Không có dữ liệu!</p>
      )}
    </PerfectScrollbar>
  );
}

export default memo(TabAccountEE);
