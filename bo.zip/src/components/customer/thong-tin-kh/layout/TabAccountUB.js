import React, { memo } from 'react';

import PerfectScrollbar from 'react-perfect-scrollbar';
import { numberFormat } from 'utils';
import * as _ from 'lodash';

function TabAccountUB({ detailLMVUB }) {
  return (
    <PerfectScrollbar
      className="mb-2"
      style={{ height: 'calc(100vh - 550px)' }}
    >
      <table className="table table-bordered">
        <thead>
          <tr>
            <th className="high-light">Mã CK</th>
            <th className="high-light">Loại</th>
            <th className="high-light">UB</th>
            <th className="high-light">TL ký quỹ</th>
            <th className="high-light">KL đã có</th>
            <th className="high-light">KL chờ khớp</th>
            <th className="high-light">KL tổng</th>
            <th className="high-light">Giá tính</th>
            <th className="high-light">Giá chặn</th>
            <th className="high-light">LMV UB</th>
            <th className="high-light">EE UB</th>
          </tr>
        </thead>
        <tbody>
          {detailLMVUB && !!detailLMVUB.length && (
            <tr>
              <td
                className="text-left font-weight-bold high-light-2"
                colSpan="9"
              >
                TOTAL
              </td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(_.sumBy(detailLMVUB, (o) => o.lmv))}
              </td>
              <td className="text-right font-weight-bold high-light-2">
                {numberFormat(_.sumBy(detailLMVUB, (o) => o.eeub))}
              </td>
            </tr>
          )}
          {detailLMVUB &&
            !!detailLMVUB.length &&
            detailLMVUB.map((item, i) => (
              <tr key={'lmvee_' + i}>
                <td className="text-center ">{item.s}</td>
                <td className="text-center">{item.t}</td>
                <td className="text-center">{item.ub}</td>
                <td className="text-center">{item.p}</td>
                <td className="text-right">{numberFormat(item.at)}</td>
                <td className="text-right">{numberFormat(item.inday)}</td>
                <td className="text-right ">{numberFormat(item.total)}</td>
                <td className="text-right">{numberFormat(item.mp)}</td>
                <td className="text-right">{numberFormat(item.lp)}</td>
                <td className="text-right">{numberFormat(item.lmv)}</td>
                <td className="text-right">{numberFormat(item.eeub)}</td>
              </tr>
            ))}
        </tbody>
      </table>
      {(!detailLMVUB || !detailLMVUB.length) && (
        <p className="text-center fz-12 text-white-50">Không có dữ liệu!</p>
      )}
    </PerfectScrollbar>
  );
}

export default memo(TabAccountUB);
