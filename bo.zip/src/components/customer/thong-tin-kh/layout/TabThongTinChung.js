import { makeCustGetTotalAsset, makeGetToken } from 'lib/selector';
import React, { Fragment, useEffect, useState } from 'react';
import { Card, Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';

import IcClock from 'assets/img/icon/ic-clock.svg';
import Paging from 'components/paging';
import {
  accountLimitAcc6SingleRequest,
  accountLimitAcc6SingleSuccess,
  accountLimitSingleRequest,
  accountLimitSingleSuccess,
} from 'containers/account/actions';
import {
  sysDataLogRequest,
  sysDataLogSuccess,
} from 'containers/system/actions';
import {
  makeGetAccountLimitAcc6Single,
  makeGetAccountLimitSingle,
  makeGetDataLog,
  makeGetLimitedService,
} from 'lib/selector';
import * as _ from 'lodash';
import styled from 'styled-components';
import { accountAuthorSearchRequest } from 'containers/account/actions';
import { accountAuthorSearchSuccess } from 'containers/account/actions';
import { makeGetAccountAuthorList } from 'lib/selector';
import PerfectScrollbar from 'react-perfect-scrollbar';
import DetailTTUyQuyenModal from 'components/modal/account/tai-khoan/thong-tin-uy-quyen/DetailTTUyQuyenModal';
import { accHolderSearchRequest } from 'containers/account/actions';
import { accHolderSearchSuccess } from 'containers/account/actions';
import { makeAccHolderListSearch } from 'lib/selector';
import { accBenListSuccess } from 'containers/account/actions';
import { makeGetAccBenAll } from 'lib/selector';
import { accBenListRequest } from 'containers/account/actions';
import IcNoData from 'assets/img/icon/no-data.png';
import { makeGetGlBusinessLog } from 'lib/selector';
import { custGetTotalAssetRequesting } from '../../../../containers/customer/actions';
import { numberFormat, numberFormatDecimal } from '../../../../utils';
import { Field } from 'redux-form';
import RenderNormalSelect from '../../../input/renderNormalSelect';
//#region

const GridContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  grid-template-rows: repeat(3, minmax(0, 1fr));
  gap: 20px;
  margin: 16px 0;
  height: calc(100vh - 251px);
  & > div {
    border-radius: 12px;
    background: #f5f5f5;
     { 
      table {
        margin: 0;
        tr:first-of-type {
          td:first-of-type {
            border-top-left-radius: 12px;
          }
          td:last-of-type {
            border-top-right-radius: 12px;
          }
        }
        tr:last-of-type {
          td:first-of-type {
            border-bottom-left-radius: 12px;
          }
          td:last-of-type {
            border-bottom-right-radius: 12px;
          }
        }
        th,
        td {
          text-align: left;
          padding: 12px 10px;
        }
        .text-date {
          color: #6f6f6f;
        }
        .text-blue {
          color: #3790fb;
        }
      }
    }
    span {
      font-size: 13px;
    }
    p {
      font-weight: bold;
      padding-bottom: 5px;
      margin: 0;
    }
    a {
      font-size: 13px;
      &:hover {
        text-decoration: underline;
      }
    }

    .text-content {
      font-size: 11px;
    }

    img {
      margin-right: 4px;
    }
    .text-disable {
      margin-right: 4px;
      font-size: 10px !important;
      color: #666;
    }
    .text-header {
      color: #ffa31a;
    }
  }
`;
//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const arrNghiepVu = [
  { value: '', lable: '-- Tất cả --' },
  { value: 'INSERT', lable: 'Thêm mới' },
  { value: 'UPDATE', lable: 'Cập nhập' },
  { value: 'UN_APPROVE', lable: 'Hủy Duyệt' },
  { value: 'DELETE', lable: 'Xóa' },
  { value: 'REJECT', lable: 'Từ chối' },
  { value: 'LOGIN', lable: 'Thêm mới' },
];

function TabThongTinChung(props) {
  const dispatch = useDispatch();
  const {
    token,
    t,
    custDetail,
    dataLog,
    custCode,
    accLimitSingle,
    glLimitFunc,
    accLimitAccSingle,
    listAccAuthor,
    accRight,
    listAccHolder,
    listAccBen,
    glBusinessLog,
  } = props;
  const [page, setPage] = useState(1);
  const [pkAuthor, setPkAuthor] = useState(null);

  const prePage = usePrevious(page);
  const listLimit = accLimitSingle?.FUNC.split(',');
  const listLimitAcc6 = accLimitAccSingle?.FUNC.split(',');

  useEffect(() => {
    // get customer detail
    if (custCode) {
      handleGetListLog('');
      handleGetSingleLimited();
      handleGetSingleLimitedAcc6();
      handleGetListAccAuthor();
      // handleGetListAccHolder();
      handleGetListAccBen();
      handleGetTotalAsset();
    }

    return () => {
      dispatch(sysDataLogSuccess(null));
      dispatch(accountLimitSingleSuccess(null));
      dispatch(accountLimitAcc6SingleSuccess(null));
      dispatch(accountAuthorSearchSuccess(null));
      dispatch(accHolderSearchSuccess(null));
      dispatch(accBenListSuccess(null));
    };
  }, []);

  useEffect(() => {
    if (page && prePage && !_.isEqual(page, prePage)) {
      handleGetListLog('');
    }
  }, [page]);

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleGetListLog(actionCode) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_CASH_TRANSACTION_REPORT',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: props.custCode + '1',
        PAGE: page || 1,
        RECORD_PER_PAGE: 10,
      },
    };
    dispatch(sysDataLogRequest(params));
  }

  function handleClose() {
    setPkAuthor(null);
  }

  function handleOnChange(e) {
    handleGetListLog(e.target.value || '');
  }

  function handleGetSingleLimited() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: custCode + '1',
      },
    };

    dispatch(accountLimitSingleRequest(params));
  }

  function handleGetSingleLimitedAcc6() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: custCode + '6',
      },
    };

    dispatch(accountLimitAcc6SingleRequest(params));
  }

  function handleGetListAccAuthor() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: custCode + '1',
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };
    dispatch(accountAuthorSearchRequest(params));
  }

  function handleGetListAccHolder() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_HOLDER',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: custCode,
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };
    dispatch(accHolderSearchRequest(params));
  }

  function handleGetListAccBen() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACC_BEN',
      group: 'LIST',
      data: {
        ITEM_ID: custCode,
      },
    };
    dispatch(accBenListRequest(params));
  }

  const handleGetTotalAsset = () => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'MM_APPENDIX.GET_TOTAL_ASSET',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: custCode,
      },
    };
    dispatch(custGetTotalAssetRequesting(params));
  }

  return (
    <>
      <GridContainer>
        <Card>
          <Card.Body>
            <div
              style={{
                padding: '10px'
              }}
            >
              <PerfectScrollbar
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, minmax(0, 1fr)',
                  paddingRight: '10px',
                  columnGap: '10px',
                  rowGap: '10px'
                }}
              >
                <span>{t('txt-mobile')}</span>
                <span style={{ gridColumn: '2/4' }}>
                  {custDetail?.C_CUST_MOBILE}
                </span>
                <span>{t('txt-email')}</span>
                <span style={{ gridColumn: '2/4' }}>
                  {custDetail?.C_CUST_EMAIL}
                </span>
                <span>{t('txt-address')}</span>
                <span style={{ gridColumn: '2/4' }}>
                  {custDetail?.C_CUST_ADDRESS}
                </span>
              </PerfectScrollbar>
            </div>
          </Card.Body>
        </Card>
        <Card style={{ gridColumn: '2/5', gridRow: '1/4' }}>
          <Card.Header className="d-flex d-flex justify-content-between">
            Lịch sử giao dịch
          </Card.Header>
          <Card.Body>
            <PerfectScrollbar
              className="w-100"
              style={{ height: 'calc(100% - 50px)', paddingRight: '10px' }}
            >
              <Table className="table-list">
                <thead>
                <tr>
                  <th className="text-center">#</th>
                  <th className="text-center">{t('txt-bus')}</th>
                  <th className="text-center">{t('lab-detail-business')}</th>
                  <th className="text-center">{t('txt-trans-from-date1')}</th>
                  <th className="text-center">{t('txt-trans-due-date')}</th>
                  <th className="text-center">{t('txt-in')}</th>
                  <th className="text-center">{t('txt-out')}</th>
                  <th className="text-center">{t('txt-content')}</th>
                </tr>
                </thead>
                <tbody className="w-100">
                {dataLog &&
                  dataLog.map((item) => (
                    <tr key={item?.PK_REQUEST_INFO} className="mb-1">
                      <td className="text-center">{item?.ROW_NUM}</td>
                      <td className="">{item?.C_BUSINESS_NAME}</td>
                      <td className="">{item?.C_BUSINESS_DETAIL_NAME}</td>
                      <td className="text-center">{item?.C_TRANSACTION_DATE}</td>
                      <td className="text-center">{item?.C_DUE_DATE}</td>
                      <td className="text-right">
                        {numberFormat(item?.C_CASH_IN, 0, '0')}
                      </td>
                      <td className="text-right">
                        {numberFormat(item?.C_CASH_OUT, 0, '0')}
                      </td>
                      <td className="">{item?.C_CONTENT}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
              {(!dataLog || !dataLog.length) && (
                <img src={IcNoData} className="m-auto w-100 h-80" />
              )}
            </PerfectScrollbar>
            <div className="mt-3 d-flex justify-content-end">
              <Paging
                page={page}
                nextPage={_handleNextPage}
                recordPerPage={10}
                total={
                  dataLog && !!dataLog.length ? dataLog[0].C_TOTAL_RECORD : 0
                }
                isElement
              />
            </div>
          </Card.Body>
        </Card>
        <Card>
          <Card.Header>Thông tin tổng tài sản</Card.Header>
          <Card.Body>
            <PerfectScrollbar
              style={{
                paddingRight: '10px'
              }}
            >
              <table
                style={{
                 width: '100%'
               }}
              >
                <tr>
                  <td className={'font-weight-bold'} colSpan={2}>
                    <div
                      style={{
                        borderLeft: '3px darkgray solid',
                        paddingLeft: '2px'
                      }}
                    >Tiền mặt</div>
                  </td>
                  {props.totalAsset && props.totalAsset[0] && (
                    <td className={'font-weight-bold text-right'}>{numberFormatDecimal(props.totalAsset[0].C_CASH_BALANCE)}đ</td>
                  )}
                  {!(props.totalAsset && props.totalAsset[0]) && (
                    <td className={'font-weight-bold text-right'}>{numberFormatDecimal('0')}đ</td>
                  )}
                </tr>
                {props.totalAsset && props.totalAsset[1] && (
                  <Fragment>
                    <tr>
                      <td className={'font-weight-bold'} colSpan={2}>
                        <div
                          style={{
                            borderLeft: '3px #e7e700 solid',
                            paddingLeft: '2px'
                          }}
                        >Tích luỹ</div>
                      </td>
                      <td className={'font-weight-bold text-right'}>{numberFormatDecimal(props.totalAsset[1].C_MM_CASH_VALUE_TOTAL)}đ</td>
                    </tr>
                    {props.totalAsset.slice(1).map((item) =>
                      <tr>
                        <td style={{ width: '5%' }}></td>
                        <td>{item.C_WEB_PRODUCT_NAME}</td>
                        <td className={'text-right'}>{numberFormatDecimal(item.C_MM_CASH_VALUE)}đ</td>
                      </tr>
                    )}
                  </Fragment>
                )}
              </table>
            </PerfectScrollbar>
          </Card.Body>
        </Card>
        <Card>
          <Card.Header>{t('txt-acc-bank')}</Card.Header>
          <Card.Body>
            <PerfectScrollbar>
              {listAccBen &&
                listAccBen.map((item, index) => (
                  <Card key={index} className="mb-1 fz-13"

                        style={{
                          marginRight: '10px',
                        }}>
                    <Card.Body>
                      <div className="text-header">
                        {item?.C_BANK_ACCOUNT_NAME} -{' '}
                        {item?.C_BANK_ACCOUNT_CODE}
                      </div>
                      <div className="text-disable">{item?.C_BANK_NAME}</div>
                    </Card.Body>
                  </Card>
                ))}
              {(!listAccBen || !listAccBen.length) && (
                <img src={IcNoData} className="m-auto w-100 h-100" />
              )}
            </PerfectScrollbar>
          </Card.Body>
        </Card>
      </GridContainer>
      {pkAuthor && accRight?.C_VIEW === 1 && (
        <DetailTTUyQuyenModal
          id={pkAuthor}
          onClose={handleClose}
          accRight={accRight}
        />
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getDataLog = makeGetDataLog();
  const getAccountLimitSingle = makeGetAccountLimitSingle();
  const getAccountLimitAcc6Single = makeGetAccountLimitAcc6Single();
  const getLimitFunction = makeGetLimitedService();
  const getAccountAuthorList = makeGetAccountAuthorList();
  const getAccHolderListSearch = makeAccHolderListSearch();
  const getAccBenAll = makeGetAccBenAll();
  const getGlBusinessLog = makeGetGlBusinessLog();
  return {
    token: getToken(state),
    dataLog: getDataLog(state),
    accLimitSingle: getAccountLimitSingle(state),
    accLimitAcc6Single: getAccountLimitAcc6Single(state),
    listAccAuthor: getAccountAuthorList(state),
    glLimitFunc: getLimitFunction(state),
    listAccHolder: getAccHolderListSearch(state),
    listAccBen: getAccBenAll(state),
    glBusinessLog: getGlBusinessLog(state),
    totalAsset: makeCustGetTotalAsset()(state)
  };
};

export default connect(mapStateToProps)(
  translate('translations')(TabThongTinChung)
);
