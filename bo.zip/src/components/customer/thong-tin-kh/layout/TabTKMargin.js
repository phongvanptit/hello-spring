import React, { useEffect, useState } from 'react';
import { StringToInt, numberFormat, formatDate } from 'utils';
import { connect, useDispatch } from 'react-redux';
import {
  cashBdAccStatusRequest,
  cashBdAccStatusSuccess,
  cashBdAccLMVRequest,
  cashBdAccLMVSuccess,
  cashBdAccEERequest,
  cashBdAccEESuccess,
  cashBdAccUBRequest,
  cashBdAccUBSuccess,
} from 'containers/cash/actions';
import {
  makeGetToken,
  makeGetBdAccStatus,
  makeGetBdAccLMV,
  makeGetBdAccEE,
  makeGetBdAccUB,
} from 'lib/selector';
import { translate } from 'react-i18next';
import TabAccountLMV from './TabAccountLMV';
import TabAccountUB from './TabAccountUB';
import TabAccountEE from './TabAccountEE';
import styled from 'styled-components';

const SubBreadcrumb = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;

  ul {
    width: 100%;
    height: 100%;
    padding-left: 0;
    position: relative;
    display: flex;

    li {
      border-left: none;
      display: flex;
      align-items: center;
      padding: 6px 12px;
      border-bottom: 1.5px solid transparent;
      white-space: nowrap;
      font-size: 13px;
      line-height: 16px;
      color: #6f6f6f;
      cursor: pointer;

      &.active {
        border-bottom-color: #ffa31a;
        font-weight: 600;
        color: #ffa31a;
      }
    }
  }
`;

function TabTKMargin(props) {
  const {
    token,
    custCode,
    accountStatus,
    t,
    accountLMV,
    detailLMVEE,
    detailLMVUB,
  } = props;
  const dispatch = useDispatch();
  const [tabActive, setTabActive] = useState('ChiTietKiQuy');
  const [singleTaiSanFetched, setSingleTaiSanFetched] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      // get customer detail
      if (custCode && !singleTaiSanFetched) {
        await getSingleTaiSan();
        setSingleTaiSanFetched(true);
      }
    };

    fetchData();

    return () => {
      dispatch(cashBdAccStatusSuccess(null));
    };
  }, [custCode, singleTaiSanFetched]);

  useEffect(() => {
    // get customer detail
    if (singleTaiSanFetched && tabActive) {
      if (tabActive === 'ChiTietKiQuy') {
        setTimeout(() => {
          getSingleLMV();
        }, 200);
      } else if (tabActive === 'ChiTietSucMua') {
        setTimeout(() => {
          getSingleEE();
        }, 200);
      } else if (tabActive === 'TaiSanUB') {
        setTimeout(() => {
          getSingleUB();
        }, 200);
      }
    }
    return () => {
      dispatch(cashBdAccLMVSuccess(null));
      dispatch(cashBdAccEESuccess(null));
      dispatch(cashBdAccUBSuccess(null));
    };
  }, [tabActive, singleTaiSanFetched]);

  async function getSingleTaiSan() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        type: 'string',
        cmd: 'BD.accountStatus',
        p1: custCode + '6',
      },
    };

    dispatch(cashBdAccStatusRequest(params));
  }

  function getSingleLMV() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        p1: custCode + '6',
        cmd: 'BD.accountLMV',
        type: 'string',
      },
    };

    dispatch(cashBdAccLMVRequest(params));
  }

  function getSingleEE() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        p1: custCode + '6',
        cmd: 'BD.accountLMVEE',
        type: 'string',
        p2: '1',
        p3: '30',
      },
    };

    dispatch(cashBdAccEERequest(params));
  }

  function getSingleUB() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        p1: custCode + '6',
        cmd: 'BD.accountLMVUB',
        type: 'string',
        p2: '1',
        p3: '30',
      },
    };

    dispatch(cashBdAccUBRequest(params));
  }

  return (
    <div className="scroll_30">
      <div className="custom-tabs-content">
        <table className="table table-bordered ">
          <tbody>
            <tr>
              <td className="high-light">{t('txt-group-code')}</td>
              <td className="text-center">{accountStatus?.group}</td>
              <td className="high-light">Imkh</td>
              <td className="text-center">{accountStatus?.imKH}</td>
              <td className="high-light">Call Rate</td>
              <td className="text-center ">
                {accountStatus?.call_lmv &&
                accountStatus?.call_lmv.startsWith('.')
                  ? '0' + accountStatus?.call_lmv
                  : accountStatus?.call_lmv}
              </td>
              <td className="high-light">Datetime</td>
              <td className="text-center">
                {formatDate(new Date(), '/', 'dmy')}
              </td>
            </tr>
            <tr>
              <td className="high-light">Phí max</td>
              <td className="text-center">
                {accountStatus?.max_rate &&
                  (accountStatus?.max_rate.startsWith('.')
                    ? '0' + accountStatus?.max_rate
                    : accountStatus?.max_rate)}
                %
              </td>
              <td className="high-light">H</td>
              <td className="text-center">
                {(accountStatus?.h * 100).toFixed(0)}%
              </td>
              <td className="high-light">Sell Rate</td>
              <td className="text-center">
                {accountStatus?.call_lmv &&
                accountStatus?.sell_lmv.startsWith('.')
                  ? '0' + accountStatus?.sell_lmv
                  : accountStatus?.sell_lmv}
              </td>
              <td className="high-light">NAV</td>
              <td className="text-center i">
                {numberFormat(accountStatus?.total_equity, 0)}
              </td>
            </tr>
            <tr>
              <td className="high-light">Ba bên</td>
              <td className="text-center">{accountStatus?.tdck}</td>
              <td className="high-light">Rút EE</td>
              <td className="text-center">
                {accountStatus?.overDraft === '1' ? 'YES' : 'NO'}
              </td>
              <td className="high-light">Hạn mức bảo lãnh</td>
              <td className="text-center i">
                {numberFormat(accountStatus?.temp_ee, 0)}
              </td>
              <td className="high-light">Số tiền cần nộp</td>
              <td className="text-center i">
                {numberFormat(accountStatus?.payment, 0)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="custom-tabs-content  mt-2">
        <table className="table table-bordered ">
          <tbody>
            <tr>
              <td className="high-light ">Tổng tài sản</td>
              <td className="text-right">
                {numberFormat(accountStatus?.assets, 0)}
              </td>
              <td className="high-light">Tiền bán chờ về</td>
              <td className="text-right">
                {numberFormat(accountStatus?.sum_ap, 0)}
              </td>
              <td className="high-light">EE có thể rút</td>
              <td className="text-right i">
                {numberFormat(accountStatus?.withdrawal_ee, 0)}
              </td>
              <td className="high-light">Tỷ lệ tài khoản</td>
              <td
                className={
                  'text-center text-white ' +
                  (accountStatus?.action === 'CALL_FORCE'
                    ? 'bg-primary-dbl'
                    : accountStatus?.action === 'CALL_MARGIN'
                    ? 'bg-primary'
                    : '')
                }
              >
                {accountStatus?.margin_ratio}
              </td>
            </tr>
            <tr>
              <td className="high-light">Tổng nợ</td>
              <td
                className={
                  'text-right ' + (accountStatus?.debt !== '0' ? 'd' : '')
                }
              >
                {numberFormat(accountStatus?.debt, 0)}
              </td>
              <td className="high-light">&nbsp;&nbsp;&nbsp;&nbsp;AP T0</td>
              <td className="text-right">
                {numberFormat(accountStatus?.ap_t0, 0)}
              </td>
              <td className="high-light">Mua đã khớp</td>
              <td className="text-right i mw_85">
                {numberFormat(StringToInt(accountStatus?.ar_t0), 0)}
              </td>
              <td className="high-light">Tỷ lệ uỷ ban</td>
              <td className="text-center mw_85">
                {accountStatus?.margin_ratio_ub}
              </td>
              {/* *
            <td
              className={
                'text-center text-white ' +
                (accountStatus?.action ? 'bg-primary' : '')
              }
            >
              {accountStatus?.action}
            </td> */}
            </tr>
            <tr>
              <td className="high-light">Tài sản ròng</td>
              <td
                //   className={
                //     'text-right ' +
                //     (stringToInt( accountStatus?.equity) < '0' ? 'd' : 'i')
                //   }
                className="text-right"
              >
                {numberFormat(accountStatus?.equity, 0)}
              </td>
              <td className="high-light">&nbsp;&nbsp;&nbsp;&nbsp;AP T1</td>
              <td className="text-right">
                {numberFormat(accountStatus?.ap_t1, 0)}
              </td>
              <td className="high-light">Mua chờ khớp</td>
              <td className="text-right">
                {numberFormat(accountStatus?.buy_unmatch, 0)}
              </td>
              <td className="high-light">TSR giảm về callmargin</td>
              <td className="text-right mw_85">
                {numberFormat(accountStatus?.a1, 0)}
              </td>
            </tr>
            <tr>
              <td className="high-light">Tiền mặt</td>
              <td className="text-right">
                {numberFormat(accountStatus?.cash_balance, 0)}
              </td>
              <td className="high-light">&nbsp;&nbsp;&nbsp;&nbsp;AP T2</td>
              <td className="text-right">
                {numberFormat(accountStatus?.ap_t2, 0)}
              </td>
              <td className="high-light">Ký quỹ chờ khớp</td>
              <td className="text-right">
                {numberFormat(accountStatus?.buy_mr, 0)}
              </td>
              <td className="high-light">Số tiền cần nộp call</td>
              <td className="text-right">
                {numberFormat(accountStatus?.a2, 0)}
              </td>
            </tr>
            <tr>
              <td className="high-light">Cổ tức</td>
              <td className="text-right">
                {numberFormat(accountStatus?.collateral, 0)}
              </td>
              <td className="high-light">Tiền đã ứng</td>
              <td className="text-right">
                {numberFormat(accountStatus?.withdraw, 0)}
              </td>
              <td className="high-light">EE + Hạn mức bảo lãnh</td>
              <td
                className={
                  'text-right ' + (accountStatus?.ee_inc_app > 0 ? 'i' : 'd')
                }
              >
                {numberFormat(accountStatus?.ee_inc_app, 0)}
              </td>
              <td className="high-light">TSR giảm về call forcesell</td>
              <td className="text-right">
                {numberFormat(accountStatus?.a3, 0)}
              </td>
            </tr>
            <tr>
              <td className="high-light">CK cho vay</td>
              <td className="text-right i">
                {numberFormat(accountStatus?.lmv, 0)}
              </td>
              <td className="high-light">Có thể ứng</td>
              <td className="text-right">
                {numberFormat(accountStatus?.cash_advance_avai, 0)}
              </td>
              <td className="high-light">Lãi tạm tính</td>
              <td className="text-right">
                {numberFormat(accountStatus?.loan_fee, 0)}
              </td>
              <td className="high-light">Số tiền cần nộp force</td>
              <td className="text-right">
                {numberFormat(accountStatus?.a4, 0)}
              </td>
            </tr>
            <tr>
              <td className="high-light">Ký quỹ</td>
              <td className="text-right">
                {numberFormat(accountStatus?.mr, 0)}
              </td>
              <td className="high-light">Tiền mặt có thể rút</td>
              <td className="text-right">
                {numberFormat(accountStatus?.withdrawal_cash, 0)}
              </td>
              <td className="high-light">Phí lưu ký</td>
              <td className="text-right">
                {numberFormat(accountStatus?.deposit_fee, 0)}
              </td>
              <td className="high-light">GT CK cho vay cần bán</td>
              <td className="text-right">
                {numberFormat(accountStatus?.a5, 0)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <SubBreadcrumb>
        <ul>
          <li
            onClick={() => setTabActive('ChiTietKiQuy')}
            className={tabActive === 'ChiTietKiQuy' ? 'active' : ''}
          >
            Chi tiết giá trị kí quỹ
          </li>
          <li
            onClick={() => setTabActive('ChiTietSucMua')}
            className={tabActive === 'ChiTietSucMua' ? 'active' : ''}
          >
            Chi tiết sức mua
          </li>
          <li
            onClick={() => setTabActive('TaiSanUB')}
            className={tabActive === 'TaiSanUB' ? 'active' : ''}
          >
            Tài sản ủy ban
          </li>
        </ul>
      </SubBreadcrumb>
      {tabActive === 'ChiTietKiQuy' && (
        <TabAccountLMV accountLMV={accountLMV} />
      )}
      {tabActive === 'ChiTietSucMua' && (
        <TabAccountEE detailLMVEE={detailLMVEE} />
      )}
      {tabActive === 'TaiSanUB' && <TabAccountUB detailLMVUB={detailLMVUB} />}
    </div>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getBdAccStatus = makeGetBdAccStatus();
  const getBdAccLMV = makeGetBdAccLMV();
  const getBdAccEE = makeGetBdAccEE();
  const getBdAccUB = makeGetBdAccUB();

  return {
    token: getToken(state),
    accountStatus: getBdAccStatus(state),
    accountLMV: getBdAccLMV(state),
    detailLMVEE: getBdAccEE(state),
    detailLMVUB: getBdAccUB(state),
  };
};
export default connect(mapStateToProps)(translate('translations')(TabTKMargin));
