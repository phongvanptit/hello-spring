import React, { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { Form } from 'react-bootstrap';
import * as _ from 'lodash';

import IconConfig from 'assets/img/icon/cog.png';
import RenderSearchShort from 'components/input/inputSearchShort';
import ConfigHeaderTblModal from 'components/modal/ConfigHeaderTblModal';
import { setToast } from 'containers/client/actions';
import {
  custApproveSuccess,
  custDeleteSuccess,
  custRejectSuccess,
  custUpdateSuccess,
} from 'containers/customer/actions';
import {
  makeGetCustomerApprove,
  makeGetCustomerDelete,
  makeGetCustomerReject,
  makeGetCustomerUpdate,
} from 'lib/selector';
import { arrHeaderTblCustomer } from 'utils/const';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';
import { custListSearchRequest } from 'containers/customer/actions';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetGlobalCustStatus } from 'lib/selector';
import { makeGetCustType } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);

  const {
    t,
    bizCode,
    handleSubmit,
    submitting,

    dataSearch,
    setDataSearch,
    custUpd,
    custDel,
    custAppr,
    custReject,
    formCustCode,
    glCustStatus,
    glCustType,
    formCustomerType,
    formStatus,
    statusCode,
  } = props;

  const preCustUpdate = usePrevious(custUpd);
  const preCustDel = usePrevious(custDel);
  const preCustAppr = usePrevious(custAppr);
  const preCustReject = usePrevious(custReject);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(custListSearchRequest(dataSearch));
    }, 200);
  }, []);

  React.useEffect(() => {
    if (
      (custUpd && !_.isEqual(custUpd, preCustUpdate)) ||
      (custDel && !_.isEqual(custDel, preCustDel)) ||
      (custAppr && !_.isEqual(custAppr, preCustAppr)) ||
      (custReject && !_.isEqual(custReject, preCustReject))
    ) {
      dispatch(custListSearchRequest(dataSearch));
    }
  }, [custUpd, custDel, custAppr, custReject]);

  React.useEffect(() => {
    if (custUpd && !_.isEqual(custUpd, preCustUpdate)) {
      _handleToast(`${t('txt-upd-cust-success1')}`, 'success');
      dispatch(custUpdateSuccess(null));
    }
  }, [custUpd]);

  React.useEffect(() => {
    if (custDel && !_.isEqual(custDel, preCustDel)) {
      _handleToast(`${t('txt-del-cust-success')}`, 'success');
      dispatch(custDeleteSuccess(null));
    }
  }, [custDel]);

  React.useEffect(() => {
    if (custAppr && !_.isEqual(custAppr, preCustAppr)) {
      _handleToast(`${t('txt-appr-cust-success')}`, 'success');
      dispatch(custApproveSuccess(null));
    }
  }, [custAppr]);

  React.useEffect(() => {
    if (custReject && !_.isEqual(custReject, preCustReject)) {
      _handleToast(`${t('txt-reject-cust-success')}`, 'success');
      dispatch(custRejectSuccess(null));
    }
  }, [custReject]);

  function initForm() {
    if (statusCode) {
      dispatch(change('formSearchShortKhachHang', 'formStatus', statusCode));
    }
  }

  const submit = (values) => {
    let _params = _.cloneDeep(dataSearch);
    _params.data.CUSTOMER_CODE = formCustCode;
    _params.data.CUSTOMER_TYPE = formCustomerType;
    _params.data.STATUS = formStatus;
    _params.data.ALL_FLAG = 0;
    setDataSearch && setDataSearch(_params);
  };

  function _handleSetDataSearch() {
    let _params = _.cloneDeep(dataSearch);
    _params.data.CUSTOMER_CODE = formCustCode;
    _params.data.CUSTOMER_TYPE = formCustomerType;
    _params.data.STATUS = formStatus;
    _params.data.ALL_FLAG = 0;
    dispatch(custListSearchRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  function _handleShowConfigTable() {
    setShowModal(true);
  }

  function handleCloseModal() {
    setShowModal(false);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <>
      <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
        <div className="d-flex align-items-center mr-auto">
          <Form.Label className="fz-13 w-fix">{t('txt-cust-type')}</Form.Label>
          <Field
            name="formCustomerType"
            className="form-control w_100 mx-2"
            component={RenderNormalSelect}
            opts={glCustType}
            placeholder="-- Tất cả --"
            onBlur={_handleSetDataSearch}
          />
          <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
          <Field
            name="formStatus"
            className="form-control w_120 mx-2"
            component={RenderNormalSelect}
            opts={glCustStatus}
            placeholder="-- Tất cả --"
            onBlur={_handleSetDataSearch}
          />
        </div>
        <Field
          name="formCustCode"
          type="text"
          className="form-control"
          placeholder={t('txt-search')}
          component={RenderSearchShort}
          onBlur={_handleSetDataSearch}
          clickSearch={_handleSetDataSearch}
        />
        {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
          <img src={IconReset} alt="" />
        </ButtonSearch>
        <ExportExcel>
          <img src={IconExcel} alt="" />
        </ExportExcel> */}
        <ExportExcel
          onClick={() => _handleShowConfigTable()}
          title={t('txt-field-manage')}
        >
          <img src={IconConfig} />
        </ExportExcel>
      </FormFlexCenter>
      {showModal && (
        <ConfigHeaderTblModal
          onClose={handleCloseModal}
          bizCode={bizCode}
          tblDef={arrHeaderTblCustomer}
        />
      )}
    </>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortKhachHang',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortKhachHang');

const makeMapStateToProps = () => {
  const getCustomerUpdate = makeGetCustomerUpdate();
  const getCustomerDel = makeGetCustomerDelete();
  const getCustomerApprove = makeGetCustomerApprove();
  const getCustomerReject = makeGetCustomerReject();
  const getGlobalCustStatus = makeGetGlobalCustStatus();
  const getCustType = makeGetCustType();

  const mapStateToProps = (state) => {
    const { formCustCode, formCustomerType, formStatus } = selector(
      state,
      'formCustCode',
      'formCustomerType',
      'formStatus'
    );

    return {
      custUpd: getCustomerUpdate(state),
      custDel: getCustomerDel(state),
      custAppr: getCustomerApprove(state),
      custReject: getCustomerReject(state),
      glCustType: getCustType(state),
      glCustStatus: getGlobalCustStatus(state),
      formCustomerType,
      formStatus,
      formCustCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
