import React, { useState } from 'react';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconEdit } from 'assets/img/icon/ic_edit.svg';
import DetailCustomerChangeInfoModal from 'components/modal/customer/thong-tin-kh/DetailAccountChangeInfo';
import DetailKhachHangModal from 'components/modal/customer/thong-tin-kh/DetailKhachHangModal';
import ProfileAccountModal from 'components/modal/customer/thong-tin-kh/ProfileCustomerModal';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import {
  custDeleteRequest,
  custApproveRequest,
} from 'containers/customer/actions';
import {
  sysSingleListCfgRequest,
  sysSingleUserCfgRequest,
} from 'containers/system/actions';
import {
  makeGetCustomerSearch,
  makeGetListCfg,
  makeGetToken,
  makeGetUserCfg,
  makeGetAccountRight,
  makeGetCustomerDelete,
} from 'lib/selector';
import * as _ from 'lodash';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { BsThreeDots } from 'react-icons/bs';
import { connect, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './formSearchKHCaNhan';
import PerfectScrollbar from 'react-perfect-scrollbar';
import styled from 'styled-components';
import { globalIssuePlaceSuccess } from 'containers/global/actions';
import { globalIssuePlaceRequest } from 'containers/global/actions';
import { sysSingleListCfgSuccess } from 'containers/system/actions';
import { sysSingleUserCfgSuccess } from 'containers/system/actions';
import { makeGetUpdListInType } from 'lib/selector';

const FormShow = styled.div`
  min-width: 100px;
  min-height: 50px;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  right: 0;
  top: 100%;
  z-index: 1;

  ul {
    padding: 5px;

    li {
      text-align: left;
      padding: 5px;
      cursor: pointer;
      color: #212529;

      &:hover {
        background-color: #ffa31a;
      }

      &:not(:last-child) {
        border: 1px solid #e8eaeb;
        border-width: 0 0 1px 0;
      }

      &.li_no-active {
        background: #e0e0e0;
        cursor: default;
      }
    }
  }
`;

function GroupAction(props) {
  const wrapperRef = React.useRef(null);
  const [showModal, setShowModal] = React.useState(false);
  const { record, fnCallback, rightFunc, t } = props;

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  React.useState();

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    setShowModal(true);
  }

  function _handleClickItem(fnName) {
    fnCallback &&
      fnCallback[fnName] &&
      fnCallback[fnName](
        fnName === 'onDelete' ? record.PK_CUST_CUSTOMER : record
      );
    setShowModal(false);
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW ? (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      ) : null}
      {/* {rightFunc?.C_UPDATE ? (
        <a
          title={t('txt-edit')}
          onClick={() => _handleClickItem('onEdit')}
          rel="noreferrer noopener"
        >
          <IconEdit style={{ height: '13px' }} />
        </a>
      ) : null} */}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={t('txt-appr')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onApprove')
              : null
          }
        >
          <IconApprove />
        </a>
      )}
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={(record.C_STATUS !== 'CHUA_DUYET' || record.C_APPROVER_CODE !== '') ? 'disabled' : ''}
          onClick={() =>
            (record.C_STATUS === 'CHUA_DUYET' && record.C_APPROVER_CODE === '') 
              ? _handleClickItem('onDelete')
              : null
          }
        >
          <IconTrash />
        </a>
      )}
      {/* {rightFunc?.C_APPROVE || rightFunc?.C_UPDATE ? (
        <a
          title={t('txt-add')}
          onClick={_handleShow}
          ref={wrapperRef}
          style={{ position: 'relative' }}
          rel="noreferrer noopener"
        >
          <BsThreeDots />
          {showModal && (
            <FormShow>
              <ul>
                {rightFunc?.C_APPROVE === 1 && (
                  <li
                    className={
                      'li_' +
                      (record?.C_STATUS === 'CHUA_DUYET' ||
                      record?.C_STATUS === 'DANG_SUA_DOI'
                        ? ''
                        : 'no-active')
                    }
                    onClick={() =>
                      record?.C_STATUS === 'CHUA_DUYET' ||
                      record?.C_STATUS === 'DANG_SUA_DOI'
                        ? _handleClickItem('onApprove')
                        : null
                    }
                  >
                    {t('txt-appr')}
                  </li>
                )}
                {rightFunc?.C_UPDATE === 1 && (
                  <li
                    className={
                      'li_' +
                      (record?.C_STATUS === 'CHUA_DUYET' ? '' : 'no-active')
                    }
                    onClick={() =>
                      record?.C_STATUS === 'CHUA_DUYET'
                        ? _handleClickItem('onDelete')
                        : null
                    }
                  >
                    {t('txt-del')}
                  </li>
                )}
              </ul>
            </FormShow>
          )}
        </a>
      ) : null} */}
    </GroupButton>
  );
}

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function TabKHCaNhan(props) {
  const dispatch = useDispatch();
  const [checkAll, setCheckAll] = useState(false);
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [accountDetail, setAccountDetail] = useState(null);
  const [accountProfile, setAccountProfile] = useState(null);
  const [accountApprove, setAccountApprove] = useState(null);
  const [modalReadonly, setModalReadonly] = React.useState(false);
  const [action, setAction] = React.useState(null);

  const [bizCode] = useState('BACK.GET_ALL_CUSTOMER');

  const {
    custList,
    token,
    t,
    userCfg,
    listCfg,
    accRight,
    statusCode,
    updListInType,
  } = props;

  const preUpdListInType = usePrevious(updListInType);

  React.useEffect(() => {
    getListConfig();
    getUserConfig();
    getGlobalIssuePlace();
    return () => {
      dispatch(sysSingleListCfgSuccess(null));
      dispatch(sysSingleUserCfgSuccess(null));
      dispatch(globalIssuePlaceSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (updListInType && !_.isEqual(updListInType, preUpdListInType)) {
      getGlobalIssuePlace();
    }
  }, [updListInType]);

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(custList, (o) => o.C_STATUS === 'CHUA_DUYET');
      setOrderCheck(_.map(allFunc, 'PK_CUST_CUSTOMER'));
    }
  }

  function handleDelCustomer(_custCode) {
    console.log(_custCode, orderCheck);
    if (!_custCode && !orderCheck.length) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-cust')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(_custCode);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleApprCustomer(_custCode) {
    if (!_custCode && !orderCheck.length) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-cust')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(_custCode);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(_custCode) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CUSTOMER',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: _custCode || orderCheck.join(','),
      },
    };

    setOrderCheck([]);
    dispatch(custDeleteRequest(params));
  }

  function handleActionApprove(_custCode) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CUSTOMER',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: _custCode || orderCheck.join(','),
      },
    };

    setOrderCheck([]);
    dispatch(custApproveRequest(params));
  }

  function handleApproveCustomer(_custCode) {
    if (!_custCode) return;
    if (_custCode?.PK_REQUEST_INFO === '') {
      handleApprCustomer(_custCode);
    } else {
      setAccountApprove(_custCode);
      setAction('Approve');
    }
  }

  function getListConfig() {
    if (!token) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_CONFIG',
      group: 'LIST',
      data: {
        BUSINESS_CODE: bizCode,
      },
    };

    dispatch(sysSingleListCfgRequest(params));
  }

  function getUserConfig() {
    if (!token) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_CONFIG',
      group: 'LIST',
      data: {
        BUSINESS_CODE: bizCode,
      },
    };

    dispatch(sysSingleUserCfgRequest(params));
  }

  function getGlobalIssuePlace() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE: 'ISSUE_PLACE',
      },
    };
    dispatch(globalIssuePlaceRequest(params));
  }

  function handleEditCustomer(custCode) {
    setAccountDetail(custCode);
  }

  function handleDetailCustomer(custCode) {
    setAccountApprove(custCode);
    setModalReadonly(true);
  }

  function onClose() {
    setAccountDetail(null);
    setAccountProfile(null);
    setAccountApprove(null);
    setAction(null);
    setModalReadonly(false);
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content my-3">
      <FormSearch
        page={page}
        recordPerPage={recordPerPage}
        statusCode={statusCode}
      />
      <PerfectScrollbar className="w-100">
        <Table bordered>
          <thead>
            <tr>
              <th>
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              </th>
              {userCfg &&
                !!userCfg.length &&
                userCfg.map((item, index) => {
                  if (item.status === '0') return null;

                  return (
                    <th key={index}>
                      <div className={'headerSticky_' + index}>
                        {_.find(listCfg, (o) => o.code === item.code)?.name}
                      </div>
                    </th>
                  );
                })}
              {(!userCfg || !userCfg.length) && (
                <>
                  <th>{t('txt-cust-code')}</th>
                  <th>{t('txt-cust-name')}</th>
                  <th>{t('txt-cust-type')}</th>
                  <th>{t('txt-card-id-1')}</th>
                  <th>{t('txt-open-date')}</th>
                  <th>{t('txt-marketing-id')}</th>
                  <th>{t('txt-marketing-name')}</th>
                </>
              )}
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {(!userCfg || !userCfg.length) &&
              custList &&
              custList.map((item) => (
                <tr
                  key={item.ROW_NUM}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_CUST_CUSTOMER)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td className="text-center">
                    {item.C_STATUS === 'CHUA_DUYET' && (
                      <input
                        type={'checkbox'}
                        name={item.PK_CUST_CUSTOMER}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_CUST_CUSTOMER
                        )}
                      />
                    )}
                  </td>
                  <td className="text-center">
                    <Link
                      title="Chi tiết"
                      to={
                        '/account/khach-hang/thong-tin-kh/' +
                        item.C_CUSTOMER_CODE
                      }
                    >
                      {item.C_CUSTOMER_CODE}
                    </Link>
                  </td>
                  <td className="">{item.C_CUSTOMER_NAME}</td>
                  <td className="">{item.C_CUSTOMER_TYPE}</td>
                  <td className="text-center">{item.C_CARD_ID}</td>
                  <td className="text-center">
                    {item.C_CREATE_TIME ? item.C_CREATE_TIME.split(' ')[0] : ''}
                  </td>
                  <td className="text-center">{item.C_MARKETING_ID}</td>
                  <td className="text-center">{item.C_MARKETING_NAME}</td>
                  <td className="text-center p-0 w_85">
                    <GroupAction
                      t={t}
                      record={item}
                      rightFunc={accRight}
                      fnCallback={{
                        onEdit: handleEditCustomer,
                        onApprove: handleApproveCustomer,
                        onDetail: handleDetailCustomer,
                        onDelete: handleDelCustomer,
                      }}
                    />
                  </td>
                </tr>
              ))}

            {custList &&
              userCfg &&
              !!userCfg.length &&
              custList.map((item) => (
                <tr
                  key={item.ROW_NUM}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_CUST_CUSTOMER)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td>
                    {item.C_STATUS === 'CHUA_DUYET' && (
                      <input
                        type={'checkbox'}
                        name={item.PK_CUST_CUSTOMER}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_CUST_CUSTOMER
                        )}
                      />
                    )}
                  </td>
                  {userCfg.map((it, index) => {
                    if (it.status === '0') return null;

                    if (it.code === 'C_CUSTOMER_CODE')
                      return (
                        <td className="text-center" key={index}>
                          <Link
                            title="Chi tiết"
                            to={
                              '/account/khach-hang/thong-tin-kh/' +
                              item.C_CUSTOMER_CODE
                            }
                          >
                            {item.C_CUSTOMER_CODE}
                          </Link>
                        </td>
                      );
                    if (it.code === 'C_CUSTOMER_NAME')
                      return <td key={index}>{item[it.code]}</td>;
                    if (
                      it.code === 'C_CREATE_TIME' ||
                      it.code === 'C_OPEN_DATE'
                    )
                      return (
                        <td className="text-center" key={index}>
                          {item[it.code] ? item[it.code].split(' ')[0] : ''}
                        </td>
                      );
                    return (
                      <td
                        className={
                          it.code === 'C_MARKETING_NAME' ||
                          it.code === 'C_CARD_ID_TYPE' ||
                          it.code === 'C_CUST_EMAIL'
                            ? ''
                            : 'text-center'
                        }
                        key={index}
                      >
                        {item[it.code]}
                      </td>
                    );
                  })}

                  <td className="text-center p-0">
                    <GroupAction
                      t={t}
                      record={item}
                      rightFunc={accRight}
                      fnCallback={{
                        onEdit: handleEditCustomer,
                        onApprove: handleApproveCustomer,
                        onDetail: handleDetailCustomer,
                        onDelete: handleDelCustomer,
                      }}
                    />
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
      {(!custList || !custList.length) && <NodataSearch name={t('txt-cust')} />}
      <div className="mt-3 d-flex justify-content-end">
        {orderCheck && !!orderCheck.length && (
          <div className="mr-auto">
            <Button
              variant="danger"
              className="mr-2"
              onClick={() => handleDelCustomer()}
            >
              {t('bnt-del-entry')}
            </Button>
            <Button
              variant="success"
              className="mr-auto"
              onClick={() => handleApprCustomer()}
            >
              {t('bnt-appr-entry')}
            </Button>
          </div>
        )}
        <Paging
          page={page}
          recordPerPage={recordPerPage}
          total={custList && !!custList.length ? custList[0].C_TOTAL_RECORD : 0}
          nextPage={_handleNextPage}
          setRecordPerPage={setRecordPerPage}
        />
      </div>
      {accountDetail && (
        <DetailKhachHangModal
          id={accountDetail}
          onClose={onClose}
          accRight={accRight}
        />
      )}
      {accountProfile && (
        <ProfileAccountModal accountCode={accountProfile} onClose={onClose} />
      )}
      {accountApprove && (
        <DetailCustomerChangeInfoModal
          record={accountApprove}
          onClose={onClose}
          accRight={accRight}
          readonly={modalReadonly}
          action={action}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCustomerSearch = makeGetCustomerSearch();
  const getCustomerDel = makeGetCustomerDelete();
  const getUserCfg = makeGetUserCfg();
  const getListCfg = makeGetListCfg();
  const getAccountRight = makeGetAccountRight();
  const getUpdListInType = makeGetUpdListInType();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      custList: getCustomerSearch(state),
      custDel: getCustomerDel(state),
      userCfg: getUserCfg(state),
      listCfg: getListCfg(state),
      accRight: getAccountRight(state),
      updListInType: getUpdListInType(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(TabKHCaNhan)
);
