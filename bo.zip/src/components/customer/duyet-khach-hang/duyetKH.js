/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from 'react';
import { Table } from 'react-bootstrap';
import { connect } from 'react-redux';
import Paging from 'components/paging';
import FormSearch from './formSearchDuyetTTTK';
import { translate } from 'react-i18next';
import { GroupButton } from 'utils/styledComponent';
import NodataSearch from 'components/noDataSearch';
import { makeGetToken } from 'lib/selector';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { BsThreeDots } from 'react-icons/bs';

import { makeGetAccountChangeAll } from 'lib/selector';
import DetailAccountChangeInfoModal from 'components/modal/customer/thong-tin-kh/DetailAccountChangeInfo';

function TabDuyetTTTK(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [recordDetail, setRecordDetail] = useState(null);

  const { t, accChangeAll } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetailRecord(pk) {
    setRecordDetail(pk);
  }

  return (
    <div className="custom-tabs-content my-3">
      <div className="w-100 d-flex flex-column">
        <FormSearch page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th>{t('Account')}</th>
              <th>{t('Type')}</th>
              <th>Ngày tạo</th>
              <th>Ngày duyệt</th>
              <th>Người tạo</th>
              <th>Người duyệt</th>
              <th>{t('Note')}</th>
              <th>Trạng thái</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {accChangeAll &&
              accChangeAll.map((item) => (
                <tr key={item.ROW_NUM}>
                  <td className="text-center">{item.C_CUS_CODE}</td>
                  <td className="text-center">{item.C_TYPE}</td>
                  <td className="text-center">{item.C_CREATED_DATE}</td>
                  <td className="text-center">{item.C_UPDATED_DATE}</td>
                  <td className="text-center">{item.C_CREATOR}</td>
                  <td className="text-center">{item.C_UPDATER}</td>
                  <td className="text-center">{item.C_CHANGE_INFO}</td>
                  <td className={'text-center orderStt_' + item.C_STATUS}>
                    {item.C_STATUS}
                  </td>
                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      <a
                        title="Chi tiết"
                        onClick={() =>
                          handleDetailRecord(item.PK_CUS_REQUEST_CHANGE)
                        }
                      >
                        <IconCopy />
                      </a>
                      <a title="Xóa">
                        <IconTrash />
                      </a>
                      <a title={t('txt-add')}>
                        <BsThreeDots />
                      </a>
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>

        {(!accChangeAll || !accChangeAll.length) && (
          <NodataSearch name={'tài khoản'} />
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              accChangeAll && !!accChangeAll.length
                ? accChangeAll[0].C_TOTAL_RECORD
                : 0
            }
          />
        </div>
      </div>
      {recordDetail && (
        <DetailAccountChangeInfoModal
          id={recordDetail}
          onClose={() => setRecordDetail(null)}
        />
      )}
    </div>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountChangeAll = makeGetAccountChangeAll();

  return {
    token: getToken(state),
    accChangeAll: getAccountChangeAll(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(TabDuyetTTTK)
);
