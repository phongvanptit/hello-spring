import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { makeGetToken } from 'lib/selector';
import { translate } from 'react-i18next';

import * as _ from 'lodash';

import FormSearchShort from './formSearchShortDuyetTTTK';

import { makeGetSystemInfo } from 'lib/selector';
import { stringToDate } from 'utils';
import { ContainerSearch } from 'utils/styledComponent';
import { accChangeAllRequest } from 'containers/account/actions';
import { accChangeAllSuccess } from 'containers/account/actions';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();

  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage, sysSystemInfo } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(accChangeAllSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(accChangeAllRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  function initFormSearch() {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'CUSTOMER.GET_ALL_REQUEST_CHANGE',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: '',
        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    setDataSearch(params);
  }

  return (
    <ContainerSearch>
      <div className="mr-auto"></div>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
