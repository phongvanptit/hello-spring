import React from 'react';
import TabKHCaNhan from './tabTKThuHuong';

function TKThuHuongComponent(props) {
  return (
    <>
      <div className="custom-tabs-content my-3">
        <TabKHCaNhan />
      </div>
    </>
  );
}

export default TKThuHuongComponent;
