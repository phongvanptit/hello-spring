import React, { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import { makeGetToken } from 'lib/selector';
import { translate } from 'react-i18next';

import * as _ from 'lodash';

import FormSearchShort from './formSearchShortTKTH';
import FormSearchModal from './formSearchModalTKTH';

import {
  ContainerSearch,
  ContainerSearchDropdown,
  ContainerDropdownShow,
} from 'utils/styledComponent';
import { accBenListSuccess } from 'containers/account/actions';
import { accBenListRequest } from 'containers/account/actions';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const wrapperRef = React.useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);
  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage, t } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(accBenListSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(accBenListRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function initFormSearch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACC_BEN',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: '',
        ACCOUNT_NAME: '',
        CARD_ID: '',
        ACCOUNT_TYPE: '',
        BANK_CODE: '',
        BANK_ACCOUNT_CODE: '',
        BANK_ACCOUNT_NAME: '',
        STATUS: '',

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    setDataSearch(params);
  }

  function _handleShow() {
    setShowModal(!showModal);
  }
  return (
    <ContainerSearch>
      <div
        ref={wrapperRef}
        style={{ position: 'relative' }}
        className="mr-auto"
      >
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              dataSearch={dataSearch}
              setDataSearch={setDataSearch}
              onClose={() => setShowModal(false)}
            />
          </ContainerDropdownShow>
        )}
      </div>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
