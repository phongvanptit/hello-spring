import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetCustType } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import { accBenListRequest } from 'containers/account/actions';
import { makeGetAccBenType, makeGetChannelType } from 'lib/selector';
import * as _ from 'lodash';
import { arrSearchTKThuHuong } from 'utils/const';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);

  const {
    handleSubmit,
    submitting,
    t,
    glBenType,
    glPublicStt,
    glChannelType,

    dataSearch,
    setDataSearch,
    onClose,
    reset,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchTKThuHuong, 'value'));
  }, []);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formCustCode;
    _dataSearch.data.ACCOUNT_NAME = values.formCustName;
    _dataSearch.data.CARD_ID = values.formDKSH;
    _dataSearch.data.ACCOUNT_TYPE = values.formAccountType;
    _dataSearch.data.BANK_ACCOUNT_CODE = values.formBankAccount;
    _dataSearch.data.BANK_CODE = values.formBank;
    dispatch(accBenListRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalTkth', 'formDKSH', ''));
    dispatch(change('formSearchModalTkth', 'formAccountType', ''));
    dispatch(change('formSearchModalTkth', 'formBankAccount', ''));
    dispatch(change('formSearchModalTkth', 'formBank', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchTKThuHuong,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formCustCode' &&
              _objItem.value !== 'formCustName'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'select') {
              if (_objItem.value === 'formAccountType')
                return (
                  <Form.Group
                    key={_objItem.value}
                    style={{ gridColumn: '2/4' }}
                  >
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={glBenType}
                      index={2}
                    />
                  </Form.Group>
                );
            }
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalTkth',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalTkth');

const makeMapStateToProps = () => {
  const getCustType = makeGetCustType();
  const getAccBenType = makeGetAccBenType();
  const getChannelType = makeGetChannelType();

  const mapStateToProps = (state, props) => {
    const {
      formCustCode,
      formCustName,
      formDKSH,
      formChannel,
      formAccountType,
      formBankAccount,
      formBank,
    } = selector(
      state,
      'formCustCode',
      'formCustName',
      'formDKSH',
      'formChannel',
      'formAccountType',
      'formBankAccount',
      'formBank'
    );

    const { dataSearch } = props;

    return {
      glCustType: getCustType(state),
      glBenType: getAccBenType(state),
      glChannelType: getChannelType(state),

      formCustCode,
      formCustName,
      formDKSH,
      formChannel,
      formAccountType,
      formBankAccount,
      formBank,

      initialValues: {
        formDKSH: dataSearch?.data?.CARD_ID,
        formAccountType: dataSearch?.data?.ACCOUNT_TYPE,
        formBankAccount: dataSearch?.data?.BANK_ACCOUNT_CODE,
        formBank: dataSearch?.data?.BANK_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
