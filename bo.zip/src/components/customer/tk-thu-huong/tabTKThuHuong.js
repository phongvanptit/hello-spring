import React, { memo, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';

import FormSearch from './formSearchTKThuHuong';
import Paging from 'components/paging';
import * as _ from 'lodash';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import { confirmAlert } from 'react-confirm-alert';
import { makeGetToken } from 'lib/selector';
import { translate } from 'react-i18next';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailBeneficaryModal from 'components/modal/customer/tk-thu-huong/DetailAccBenModal';
import { GroupButton } from 'utils/styledComponent';
import NodataSearch from 'components/noDataSearch';
import { makeGetAccBenAll } from 'lib/selector';
import { accBenDelRequest,accBenApprRequest } from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';

function TabTKThuHuong(props) {
  const [checkAll, setCheckAll] = useState(false);
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [accountDetail, setAccountDetail] = useState(null);

  const { accBenAll, token, t, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      //setOrderCheck(_.map(accBenAll, 'PK_ACCOUNT_BEN'));
      const allFunc = _.filter(accBenAll, (o) => o.C_STATUS === 'CHUA_DUYET');
      setOrderCheck(_.map(allFunc, 'PK_ACCOUNT_BEN'));
    }
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACC_BEN',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk ? pk : orderCheck.join(','),
      },
    };

    dispatch(accBenDelRequest(params));
  }

  function handleActionAppr(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACC_BEN',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(accBenApprRequest(params));
  }

  function handleDetailCustomer(custCode) {
    setAccountDetail(custCode);
  }

  function onClose() {
    setAccountDetail(null);
  }

  function handleDelAccountBeneficary(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-acc-beneficiary')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleApprAccountBeneficary(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-acc-beneficiary')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionAppr(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            <th style={{ width: '26px' }}>
              {accRight?.C_APPROVE === 1 && (
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              )}
            </th>
            <th>{t('txt-cust-code')}</th>
            <th>{t('txt-cust-name')}</th>
            <th>{t('txt-register-date')}</th>
            <th>{t('txt-acc-type')}</th>
            <th>{t('txt-ben-acc')}</th>
            <th>{t('txt-ben-acc-name')}</th>
            <th>{t('txt-open-at')}</th>
            <th>{t('txt-branch')}</th>
            <th>{t('txt-active')}</th>
            <th>{t('txt-status')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {accBenAll &&
            accBenAll.map((item) => (
              <tr
                key={item.ROW_NUM}
                className={
                  _.some(orderCheck, (o) => o === item.PK_ACCOUNT_BEN)
                    ? 'row-checked'
                    : ''
                }
              >
                <td className="text-center">
                  {item.C_STATUS === 'CHUA_DUYET' && accRight?.C_APPROVE === 1 && (
                    <input
                      type="checkbox"
                      name={item.PK_ACCOUNT_BEN}
                      onChange={_handleChange}
                      checked={_.some(
                        orderCheck,
                        (o) => o === item.PK_ACCOUNT_BEN
                      )}
                    />
                  )}
                </td>
                <td className="text-center">
                  <a
                    rel="noreferrer noopener"
                    onClick={() => handleDetailCustomer(item.C_CUSTOMER_CODE)}
                  >
                    {item.C_CUSTOMER_CODE}
                  </a>
                </td>
                <td className="">
                  <a
                    rel="noreferrer noopener"
                    onClick={() => handleDetailCustomer(item.C_CUSTOMER_CODE)}
                  >
                    {item.C_CUSTOMER_NAME}
                  </a>
                </td>
                <td className="text-center">
                  {item.C_CREATE_TIME ? item.C_CREATE_TIME.split(' ')[0] : ''}
                </td>
                <td className="text-center">{item.C_ACCOUNT_TYPE_NAME}</td>
                <td className="text-center">
                  <a
                    rel="noreferrer noopener"
                    onClick={() => handleDetailCustomer(item.C_CUSTOMER_CODE)}
                  >
                    {item.C_BANK_ACCOUNT_CODE}
                  </a>
                </td>
                <td className="text-center">
                  <a
                    rel="noreferrer noopener"
                    onClick={() => handleDetailCustomer(item.C_CUSTOMER_CODE)}
                  >
                    {item.C_BANK_ACCOUNT_NAME}
                  </a>
                </td>
                <td className="text-center">{item.C_BANK_NAME}</td>
                <td className="text-center">{item.C_BANK_BRANCH_NAME}</td>
                <td className="text-center">
                  {item.C_ACTIVE === 1 ? 'Hoạt động' : 'Không hoạt động'}
                </td>
                <td className="text-center">
                  {item.C_STATUS === 'DA_DUYET' ? 'Đã duyệt' : 'Chưa duyệt'}
                </td>
                <td className="text-center p-0 w_85">
                  <GroupButton>
                    <a
                      title={t('txt-detail')}
                      onClick={() => handleDetailCustomer(item.C_CUSTOMER_CODE)}
                    >
                      <IconCopy />
                    </a>
                    {accRight?.C_UPDATE === 1 &&
                      item.C_STATUS === 'CHUA_DUYET' && (
                        <a
                          title={t('txt-appr')}
                          onClick={() =>
                            handleApprAccountBeneficary(item.PK_ACCOUNT_BEN)
                          }
                        >
                          <IconApprove />
                        </a>
                      )}
                    {accRight?.C_UPDATE === 1 &&
                      item.C_STATUS === 'CHUA_DUYET' && item.C_APPROVER_CODE === '' && (
                        <a
                          title={t('txt-del')}
                          onClick={() =>
                            handleDelAccountBeneficary(item.PK_ACCOUNT_BEN)
                          }
                        >
                          <IconTrash />
                        </a>
                      )}
                  </GroupButton>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>
      {(!accBenAll || !accBenAll.length) && (
        <NodataSearch name={t('txt-ben-acc')} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        {orderCheck && !!orderCheck.length && (
          <Button
            variant="danger"
            className="mr-auto"
            onClick={() => handleDelAccountBeneficary()}
          >
            {t('bnt-del-entry')}
          </Button>
        )}
        <Paging
          page={page}
          recordPerPage={recordPerPage}
          total={
            accBenAll && !!accBenAll.length ? accBenAll[0].C_TOTAL_RECORD : 0
          }
          nextPage={_handleNextPage}
          setRecordPerPage={setRecordPerPage}
        />
      </div>
      {accountDetail && (
        <DetailBeneficaryModal
          id={accountDetail}
          onClose={onClose}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccBenAll = makeGetAccBenAll();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accBenAll: getAccBenAll(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};
export default connect(makeMapStateToProps)(
  memo(translate('translations')(TabTKThuHuong))
);
