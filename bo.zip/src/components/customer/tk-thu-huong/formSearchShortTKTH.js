import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { Form } from 'react-bootstrap';
import {
  FormFlexCenter,
  ButtonSearch,
  ExportExcel,
} from 'utils/styledComponent';
import ConfigHeaderTblModal from 'components/modal/ConfigHeaderTblModal';
import { arrHeaderTblCustomer } from 'utils/const';
import { accBenListRequest } from 'containers/account/actions';
import { makeGetAccBenUpdate } from 'lib/selector';
import { makeGetAccBenDel } from 'lib/selector';
import { makeGetAccBenApprove } from 'lib/selector';
import { accBenDelSuccess } from 'containers/account/actions';
import { accBenApprSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetPublicStt } from 'lib/selector';
import { makeGetAccBenChangeActive } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);

  const {
    t,
    bizCode,
    handleSubmit,
    submitting,
    glPublicStt,

    dataSearch,
    setDataSearch,
    custUpd,
    accBenDel,
    accBenAppr,
    accBenChangeActive,
    formAccountCode,
    formStatus,
  } = props;

  const preCustUpdate = usePrevious(custUpd);
  const preAccBenDel = usePrevious(accBenDel);
  const preAccBenAppr = usePrevious(accBenAppr);
  const preAccBenChangeActive = usePrevious(accBenChangeActive);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accBenListRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (custUpd && !_.isEqual(custUpd, preCustUpdate)) ||
      (accBenDel && !_.isEqual(accBenDel, preAccBenDel)) ||
      (accBenAppr && !_.isEqual(accBenAppr, preAccBenAppr)) ||
      (accBenChangeActive &&
        !_.isEqual(accBenChangeActive, preAccBenChangeActive))
    ) {
      dispatch(accBenListRequest(dataSearch));
    }
  }, [custUpd, accBenDel, accBenAppr, accBenChangeActive]);

  useEffect(() => {
    if (accBenDel && !_.isEqual(accBenDel, preAccBenDel)) {
      _handleToast(`${t('txt-del-acc-beneficiary-success')}`);
      dispatch(accBenDelSuccess(null));
    }
  }, [accBenDel]);

  useEffect(() => {
    if (accBenAppr && !_.isEqual(accBenAppr, preAccBenAppr)) {
      _handleToast(`${t('txt-appr-acc-beneficiary-success')}`);
      dispatch(accBenApprSuccess(null));
    }
  }, [accBenAppr]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.STATUS = values.formStatus;

    dispatch(accBenListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.STATUS = formStatus;

    dispatch(accBenListRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  function handleCloseModal() {
    setShowModal(false);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <>
      <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
        <div className="d-flex align-items-center mr-auto">
          <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
          <Field
            name="formStatus"
            className="form-control w_120 mx-2"
            component={RenderNormalSelect}
            opts={glPublicStt}
            onBlur={_handleBlur}
            placeholder="-- Tất cả --"
          />
        </div>
        <Field
          name={'formAccountCode'}
          type="text"
          className="form-control"
          placeholder={t('txt-search')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
        {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
          <img src={IconReset} alt="" />
        </ButtonSearch>
        <ExportExcel>
          <img src={IconExcel} alt="" />
        </ExportExcel> */}
      </FormFlexCenter>
      {showModal && (
        <ConfigHeaderTblModal
          onClose={handleCloseModal}
          bizCode={bizCode}
          tblDef={arrHeaderTblCustomer}
        />
      )}
    </>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortTKTH',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortTKTH');

const makeMapStateToProps = () => {
  const getPublicStt = makeGetPublicStt();
  const getAccBenUpdate = makeGetAccBenUpdate();
  const getAccBenDel = makeGetAccBenDel();
  const getAccBenApprove = makeGetAccBenApprove();
  const getAccBenChangeActive = makeGetAccBenChangeActive();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStatus } = selector(
      state,
      'formAccountCode',
      'formStatus'
    );

    return {
      glPublicStt: getPublicStt(state),
      custUpd: getAccBenUpdate(state),
      accBenDel: getAccBenDel(state),
      accBenAppr: getAccBenApprove(state),
      accBenChangeActive: getAccBenChangeActive(state),
      formAccountCode,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
