import React, { useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { makeGetToken } from 'lib/selector';
import { formatDate } from 'utils';
import { custBlackListSearchSuccess } from 'containers/customer/actions';
import { makeGetSystemInfo } from 'lib/selector';
import { stringToDate } from 'utils';
import { ContainerSearch } from 'utils/styledComponent';
import { ContainerSearchDropdown } from 'utils/styledComponent';
import { ContainerDropdownShow } from 'utils/styledComponent';
import FormSearchShort from './formSearchShort';
import FormSearchModal from './formSearchModal';
import { custBlackListSearchRequest } from 'containers/customer/actions';
import * as _ from 'lodash';
import { translate } from 'react-i18next';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const wrapperRef = useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);
  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage, sysSystemInfo, t } = props;
  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      dispatch(custBlackListSearchSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(custBlackListSearchRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function initFormSearch() {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_CUST_BLACK',
      group: 'LIST',
      data: {
        CARD_ID: '',
        TAX_CODE: '',
        CUST_NAME: '',
        CUST_MOBILE: '',
        CUST_EMAIL: '',

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    setDataSearch(params);
  }

  function _handleShow() {
    setShowModal(!showModal);
  }

  return (
    <ContainerSearch>
      <div
        ref={wrapperRef}
        style={{ position: 'relative' }}
        className="mr-auto"
      >
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              dataSearch={dataSearch}
              setDataSearch={setDataSearch}
              onClose={() => setShowModal(false)}
            />
          </ContainerDropdownShow>
        )}
      </div>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      getSystemInfo: getSystemInfo(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
