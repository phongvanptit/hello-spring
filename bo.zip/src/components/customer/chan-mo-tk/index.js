import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import FormSearch from './formSearch';
import {
  makeGetToken,
  makeGetCustBlackSearch,
  makeGetAuthenType,
} from 'lib/selector';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import NodataSearch from 'components/noDataSearch';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import DetailModal from 'components/modal/customer/chan-mo-tk/detail';
//import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
import { confirmAlert } from 'react-confirm-alert';
import { custBlackDeleteRequest } from 'containers/customer/actions';
import { makeGetAccountRight } from 'lib/selector';
import { numberFormat } from 'utils';
function CustBlackComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);
  const [accountDetail, setAccountDetail] = useState(null);
  const { custBlackList, t, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
    setAccountDetail(null);
  }

  function handleConfirm(actionName, record) {
    if (record.C_STATUS === 'DA_DUYET' && actionName === 'approve') return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'close'
                ? t('txt-del-service')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'close':
                    handleActionClose(record);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CUST_BLACK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_CUST_BLACK,
      },
    };

    dispatch(custBlackDeleteRequest(params));
  }

  return (
    <>
      <div className="w-100 d-flex flex-column custom-tabs-content my-3">
        <FormSearch page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th>Ngày thực hiện</th>
              <th>Họ và tên</th>
              <th>Số giấy tờ</th>
              <th>Mã số thuế</th>
              <th>Điện thoại</th>
              <th>Từ ngày</th>
              <th>Đến ngày</th>
              <th>Nội dung</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {custBlackList &&
              custBlackList.map((item) => (
                <tr key={item.PK_CUST_BLACK}>
                  <td className="text-center">{item.C_CREATE_TIME}</td>
                  <td className="text-left">                  
                      {item.C_CUSTOMER_NAME}
                  </td>

                  <td className="">{item.C_CARD_ID}</td>
                  <td className="">{item.C_TAX_CODE}</td>
                  <td className="">{item.C_CUST_MOBILE}</td>
                  
                  <td className="text-center">
                    {item.C_FROM_DATE ? item.C_FROM_DATE.split(' ')[0] : ''}
                  </td>
                  <td className="text-center">
                    {item.C_TO_DATE ? item.C_TO_DATE.split(' ')[0] : ''}
                  </td>
                  <td className="">{item.C_CONTENT}</td>
                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      <a
                        title={t('txt-detail')}
                        onClick={() => handleDetail(item.PK_CUST_BLACK)}
                      >
                        <IconCopy />
                      </a>
                      {/* {accRight?.C_UPDATE === 1 && (
                        <a
                          title={t('txt-del')}
                          onClick={() => handleConfirm('close', item)}
                        >
                          <IconTrash />
                        </a>
                      )} */}
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!custBlackList || !custBlackList.length) && (
          <NodataSearch name={t('txt-acc-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (custBlackList &&
                !!custBlackList.length &&
                custBlackList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {/* {accountDetail && (
          <DetailAccountModal
            accountCode={accountDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )} */}
        {detailAccInt && (
          <DetailModal
            onClose={onClose}
            id={detailAccInt}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCustBlackSearch = makeGetCustBlackSearch();
  const getAccountRight = makeGetAccountRight();
  const getAuthenType = makeGetAuthenType();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      custBlackList: getCustBlackSearch(state),
      glAuthenType: getAuthenType(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(CustBlackComponent)
);
