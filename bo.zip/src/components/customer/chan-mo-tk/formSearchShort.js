import RenderSearchShort from 'components/input/inputSearchShort';
import React, { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import * as _ from 'lodash';
import IconConfig from 'assets/img/icon/cog.png';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';

import {
  custBlackListSearchRequest,
  custBlackUpdateSuccess,
  custBlackDeleteSuccess,
} from 'containers/customer/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetCustBlackUpdate,
  makeGetCustBlackDelete,
} from 'lib/selector';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    custBlackUpd,
    custBlackDel,
  } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preCustBlackUpd = usePrevious(custBlackUpd);
  const preCustBlackDel = usePrevious(custBlackDel);

  React.useEffect(() => {
    if (custBlackUpd && !_.isEqual(custBlackUpd, preCustBlackUpd)) {
      dispatch(custBlackUpdateSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [custBlackUpd]);

  React.useEffect(() => {
    if (custBlackDel && !_.isEqual(custBlackDel, preCustBlackDel)) {
      _handleToast('Xóa bút toán thành công');
      dispatch(custBlackDeleteSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [custBlackDel]);

  useEffect(() => {
    setTimeout(() => {
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
  }, []);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.CARD_ID = values.formCardId;

    dispatch(custBlackListSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    if (refSubmit.current) refSubmit.current.click();
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)}>
      <Field
        name="formCardId"
        type="text"
        className="form-control"
        //placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
      <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShort',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShort');

const makeMapStateToProps = () => {
  const getCustBlackUpdate = makeGetCustBlackUpdate();
  const getCustBlackDelete = makeGetCustBlackDelete();

  const mapStateToProps = (state) => {
    const { formCardId, formAccountName } = selector(
      state,
      'formCardId',
      'formAccountName'
    );

    return {
      custBlackUpd: getCustBlackUpdate(state),
      custBlackDel: getCustBlackDelete(state),
      formCardId,
      formAccountName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
