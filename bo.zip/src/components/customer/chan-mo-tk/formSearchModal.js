import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import RenderSelectDate from 'components/input/renderDatePicker';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { custBlackListSearchRequest } from 'containers/customer/actions';
import { formatDate, stringToDate } from 'utils';
import { makeGetSystemInfo } from 'lib/selector';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
  } = props;

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.CARD_ID = values.formCardId;
    _dataSearch.data.TAX_CODE = values.formTaxCode;
    _dataSearch.data.CUST_NAME = values.formName;
    _dataSearch.data.CUST_MOBILE = values.formPhone;
    _dataSearch.data.CUST_EMAIL = values.formEmail;
    

    dispatch(custBlackListSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModal', 'formCardId', ''));
    dispatch(change('formSearchModal', 'formTaxCode', ''));
    dispatch(change('formSearchModal', 'formName', ''));
    dispatch(change('formSearchModal', 'formPhone', ''));
    dispatch(change('formSearchModal', 'formEmail', ''));
    

  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        <Form.Group>
          <Form.Label className="fz-13">Số giấy tờ</Form.Label>
          <Field
            name="formCardId"
            type="text"
            className="form-control"
            placeholder={'Số giấy tờ'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Mã số thuế</Form.Label>
          <Field
            name="formTaxCode"
            type="text"
            className="form-control"
            placeholder={'Mã số thuế'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Tên</Form.Label>
          <Field
            name="formName"
            type="text"
            className="form-control"
            placeholder={t('txt-creator')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Điện thoại</Form.Label>
          <Field
            name="formPhone"
            type="text"
            className="form-control"
            placeholder={'Điện thoại'}
            component={RenderInput}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label className="fz-13">Email</Form.Label>
          <Field
            name="formEmail"
            type="text"
            className="form-control"
            placeholder={'Email'}
            component={RenderInput}
          />
        </Form.Group>
     
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModal',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModal');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      formCardId,
      formTaxCode,
      formName,
      formPhone,
      formEmail,
    } = selector(
      state,
      'formCardId',
      'formTaxCode',
      'formName',
      'formPhone',
      'formEmail',
    );

    const { dataSearch } = props;

    return {
      getSystemInfo: getSystemInfo(state),
      formCardId,
      formTaxCode,
      formName,
      formPhone,
      formEmail,

      initialValues: {
        formCardId: dataSearch?.data?.CARD_ID,
        formTaxCode: dataSearch?.data?.TAX_CODE,
        formName: dataSearch?.data?.CUST_NAME,
        formPhone: dataSearch?.data?.CUST_MOBILE,
        formEmail: dataSearch?.data?.CUST_EMAIL,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
