import React, { useRef, useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import { translate } from 'react-i18next';
import { stringToDate, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { sysDataLogRequest } from 'containers/system/actions';
import { makeGetSystemInfo } from 'lib/selector';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();
  const [calendarOpen, setCalendarOpen] = useState(false);
  const {
    handleSubmit,
    submitting,
    t,

    onClose,
    dataSearch,
    setDataSearch,
    sysSystemInfo,
    onTriggerPopover,
  } = props;

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);

    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    _dataSearch.data.BUSINESS_CODE = values.formBusinessCode;
    _dataSearch.data.ACTION_CODE = values.formActionCode;
    _dataSearch.data.CUSTOMER_CODE = values.formCustomerCode;
    _dataSearch.data.ACCOUNT_CODE = values.formAccountCode;
    _dataSearch.data.FROM_DATE = values.formFromDate;
    _dataSearch.data.TO_DATE = values.formToDate;

    dispatch(sysDataLogRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchLogModal', 'formCreatorCode', ''));
    dispatch(change('formSearchLogModal', 'formBusinessCode', ''));
    dispatch(change('formSearchLogModal', 'formActionCode', ''));
    dispatch(change('formSearchLogModal', 'formCustomerCode', ''));
    dispatch(change('formSearchLogModal', 'formAccountCode', ''));
    dispatch(
      change(
        'formSearchLogModal',
        'formFromDate',
        formatDate(_date, '/', 'dmy')
      )
    );
    dispatch(
      change(
        'formSearchLogModal',
        'formToDate',
        formatDate(
          sysSystemInfo
            ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
            : new Date(),
          '/',
          'dmy'
        )
      )
    );
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100 ">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-creator')}</Form.Label>
          <Field
            name={'formCreatorCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-creator')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-action')}</Form.Label>
          <Field
            name="formActionCode"
            className="form-control w-100"
            component="select"
          >
            <option value="">-- Tất cả --</option>
            <option value="INSERT">Thêm mới</option>
            <option value="UPDATE">Cập nhập</option>
            <option value="APPROVE">Duyệt</option>
            <option value="UN_APPROVE">Hủy Duyệt</option>
            <option value="DELETE">Xóa</option>
            <option value="REJECT">Từ chối</option>
            <option value="LOGIN">Login</option>
          </Field>
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-cust')}</Form.Label>
          <Field
            name={'formCustomerCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-acc')}</Form.Label>
          <Field
            name={'formAccountCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-acc')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
          <Field
            name={'formFromDate'}
            className="form-control"
            classParentName="w-100"
            component={RenderSelectDate}
            onCalendarOpen={() => setCalendarOpen(true)}
            onCalendarClose={() => setCalendarOpen(false)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
          <Field
            name={'formToDate'}
            className="form-control"
            classParentName="w-100"
            component={RenderSelectDate}
            onCalendarOpen={() => setCalendarOpen(true)}
            onCalendarClose={() => setCalendarOpen(false)}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchLogModal',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchLogModal');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      formCreatorCode,
      formBusinessCode,
      formActionCode,
      formCustomerCode,
      formAccountCode,
      formFromDate,
      formToDate,
    } = selector(
      state,
      'formCreatorCode',
      'formBusinessCode',
      'formActionCode',
      'formCustomerCode',
      'formAccountCode',
      'formFromDate',
      'formToDate'
    );

    const { dataSearch } = props;

    return {
      sysSystemInfo: getSystemInfo(state),
      formCreatorCode,
      formBusinessCode,
      formActionCode,
      formCustomerCode,
      formAccountCode,
      formFromDate,
      formToDate,

      initialValues: {
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formBusinessCode: dataSearch?.data?.BUSINESS_CODE,
        formActionCode: dataSearch?.data?.ACTION_CODE,
        formCustomerCode: dataSearch?.data?.CUSTOMER_CODE,
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formFromDate: dataSearch?.data?.FROM_DATE,
        formToDate: dataSearch?.data?.TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
