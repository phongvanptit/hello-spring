import React, { useState } from 'react';
import { Table } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import Paging from 'components/paging';
import * as _ from 'lodash';

import FormSearch from './formSearchLog';
import { makeGetToken } from 'lib/selector';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import NodataSearch from 'components/noDataSearch';
import DetailDataLogModal from 'components/modal/customer/log-khach-hang/DetailDataLogModal';
import { makeGetDataLog } from 'lib/selector';
import { GroupButton } from 'utils/styledComponent';
import { translate } from 'react-i18next';

function TabLogKhachHang(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);

  const [accountDetail, setAccountDetail] = useState(null);

  const { dataLog, token, t } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetailRecord(custCode) {
    setAccountDetail(custCode);
  }

  function onClose() {
    setAccountDetail(null);
  }

  return (
    <div className="custom-tabs-content my-3">
      <div className="w-100 d-flex flex-column">
        <FormSearch page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-stt')}</th>
              <th>{t('txt-date-trading')}</th>
              <th>{t('txt-cust-code')}</th>
              <th>{t('txt-acc')}</th>
              <th>{t('txt-bus')}</th>
              <th>{t('txt-note')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-creator')}</th>
              <th>{t('txt-create-time')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {dataLog &&
              dataLog.map((item) => (
                <tr key={item.PK_REQUEST_INFO}>
                  <td className="text-center">{item.ROW_NUM}</td>
                  <td className="text-center">{item.C_TRADING_DATE}</td>
                  <td className="text-center">{item.C_CUSTOMER_CODE}</td>
                  <td className="text-center">{item.C_ACCOUNT_CODE}</td>
                  <td className="text-center">{item.C_ACTION_TYPE}</td>
                  <td className="">{item.C_CONTENT}</td>
                  <td className={'text-center orderStt_' + item.C_STATUS}>
                    {item.C_STATUS}
                  </td>
                  <td className="text-center">{item.C_CREATOR_CODE}</td>
                  <td className="text-center">{item.C_CREATE_TIME}</td>
                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      <a
                        title={t('txt-detail')}
                        onClick={() => handleDetailRecord(item.PK_REQUEST_INFO)}
                      >
                        <IconCopy />
                      </a>
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!dataLog || !dataLog.length) && (
          <NodataSearch name={t('txt-cus-log')} />
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={dataLog && !!dataLog.length ? dataLog[0].C_TOTAL_RECORD : 0}
          />
        </div>
      </div>
      {accountDetail && (
        <DetailDataLogModal id={accountDetail} onClose={onClose} />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getDataLog = makeGetDataLog();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      dataLog: getDataLog(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(TabLogKhachHang)
);
