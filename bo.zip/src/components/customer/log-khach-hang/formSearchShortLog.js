import { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { sysDataLogRequest } from 'containers/system/actions';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';
import RenderSearchShort from 'components/input/inputSearchShort';
function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    t,
    handleSubmit,
    submitting,
    dataSearch,
    setDataSearch,
    formCustCode,
  } = props;

  useEffect(() => {
    setTimeout(() => {
      dispatch(sysDataLogRequest(dataSearch));
    }, 200);
  }, []);

  const submit = (values) => {
    let _params = _.cloneDeep(dataSearch);
    _params.data.CUSTOMER_CODE = values.formCustCode;

    dispatch(sysDataLogRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = _.cloneDeep(dataSearch);
    _params.data.CUSTOMER_CODE = formCustCode;

    dispatch(sysDataLogRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  return (
    <>
      <FormFlexCenter onSubmit={handleSubmit(submit)}>
        {
          <Field
            name={'formCustCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-search')}
            component={RenderSearchShort}
            onBlur={_handleBlur}
            clickSearch={_handleBlur}
          />
        }
        {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
          <img src={IconReset} alt="" />
        </ButtonSearch>
        <ExportExcel>
          <img src={IconExcel} alt="" />
        </ExportExcel> */}
      </FormFlexCenter>
    </>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortLog',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortLog');

const makeMapStateToProps = () => {
  const mapStateToProps = (state) => {
    const { formCustCode, formAccountName } = selector(
      state,
      'formCustCode',
      'formAccountName'
    );

    return {
      formCustCode,
      formAccountName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
