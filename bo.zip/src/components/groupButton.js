import React from 'react';
import styled from 'styled-components';

import { ReactComponent as IconDown } from 'assets/img/_ic-down.svg';
import { ReactComponent as IconPlus } from 'assets/img/icon/plus.svg';

const GroupButton = styled.div`
  position: relative;
  display: flex;
  margin-left: auto;
`;

const ButtonDropDown = styled.div`
  width: 46px;
  background-color: #ffa31a;
  border-radius: 0 12px 12px 0;
  display: flex;
  align-items: center;
  cursor: pointer;

  &:hover {
    background-color: #ffd34b;
  }

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #1c1c1c;
  }

  .line {
    margin: 5px 0 5px 5px;
    width: 1px;
    height: 25px;
    background: #1c1c1c;
  }
`;

const ButtonNormal = styled.div`
  color: #1c1c1c;
  background-color: #ffa31a;
  border-radius: ${(props) => (props.type === '2' ? '12px' : '12px 0 0 12px')};
  font-size: 13px;
  line-height: 24px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px 16px 8px 16px;
  cursor: pointer;
  width: 150px;

  &:hover {
    background-color: #ffd34b;
  }
`;

const FormShow = styled.div`
  min-width: 250px;
  min-height: 100px;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  right: 0;
  top: 100%;
`;

function GroupAddButton(props) {
  const wrapperRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);

  const { actDef, opts, fnCallback, labelName } = props;

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    if (opts && opts.length) setShowModal(true);
  }

  function _handleClickItem(record) {
    fnCallback && fnCallback(record?.value);
  }

  return (
    <GroupButton>
      <ButtonNormal
        onClick={() => fnCallback && fnCallback(actDef)}
        type={opts && !!opts.length ? '1' : '2'}
      >
        <IconPlus className="mr-3" /> {labelName}
      </ButtonNormal>
      <div ref={wrapperRef} style={{ position: 'relative' }}>
        {opts && !!opts.length && (
          <ButtonDropDown onClick={_handleShow}>
            <div className="line"></div>
            <IconDown />
          </ButtonDropDown>
        )}
        {showModal && (
          <FormShow>
            <ul>
              {opts &&
                opts.map((item, index) => (
                  <li key={index} onClick={() => _handleClickItem(item)}>
                    {item.label}
                  </li>
                ))}
            </ul>
          </FormShow>
        )}
      </div>
    </GroupButton>
  );
}

export default GroupAddButton;
