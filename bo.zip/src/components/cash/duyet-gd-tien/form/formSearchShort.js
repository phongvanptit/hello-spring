import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  cashManagementApproveSuccess,
  cashManagementListRequest,
  cashDelOtherSuccess,
} from 'containers/cash/actions';
import { makeGetCashManagementApprove } from 'lib/selector';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import { cashManagementDelSuccess } from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetCashInUpdate,
  makeGetCashManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementUnApprove,
  makeGetCashStatus,
  makeGetCashTypeEntry,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';
import { makeGetCashOutUpdate } from 'lib/selector';
import { makeGetCashTransferUpdate } from 'lib/selector';
import { ExportExcel } from 'utils/styledComponent';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    dataSearch,
    setDataSearch,
    cashStatus,
    glCashTypeEntry,
    formStartDate,
    formEndDate,

    cashInUpd,
    cashOutUpd,
    cashTransferUpd,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    cashUpdOther,
    cashDelOther,
    otherCashApprove,
    OtherCashUnApprove,
    otherCashMngReject
  } = props;

  const preCashInUpd = usePrevious(cashInUpd);
  const preCashOutUpd = usePrevious(cashOutUpd);
  const preTransferUpd = usePrevious(cashTransferUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preCashUpdOther = usePrevious(cashUpdOther);
  const preCashDelOther = usePrevious(cashDelOther);
  const preOtherCashMngApprove = usePrevious(otherCashApprove);
  const preOtherCashMngUnApprove = usePrevious(OtherCashUnApprove);
  const preOtherCashMngReject = usePrevious(otherCashMngReject);

  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(cashManagementListRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (cashInUpd && !_.isEqual(cashInUpd, preCashInUpd)) ||
      (cashOutUpd && !_.isEqual(cashOutUpd, preCashOutUpd)) ||
      (cashTransferUpd && !_.isEqual(cashTransferUpd, preTransferUpd)) ||
      (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) ||
      (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) ||
      (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) ||
      (cashManagementDel && !_.isEqual(cashManagementDel, preCashManagementDel)) ||
      (cashUpdOther && !_.isEqual(cashUpdOther, preCashUpdOther)) ||
      (cashDelOther && !_.isEqual(cashDelOther, preCashDelOther)) ||
      (otherCashApprove && !_.isEqual(otherCashApprove, preOtherCashMngApprove)) ||
      (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preOtherCashMngUnApprove)) ||
      (cashMngReject && !_.isEqual(cashMngReject, preOtherCashMngReject))
    ) {
      dispatch(cashManagementListRequest(dataSearch));
    }
  }, [
    cashInUpd,
    cashOutUpd,
    cashTransferUpd,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    cashUpdOther,
    cashDelOther,
    otherCashApprove,
    cashMngUnApprove,
    cashMngReject,
  ]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove))
      _handleToast(t('txt-appr-entry-success'), 'success');
    dispatch(cashManagementApproveSuccess(null));
    dispatch(cashManagementListRequest(dataSearch));
  }, [cashMngApprove]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    )
      _handleToast(t('txt-del-entry-success'), 'success');
    dispatch(cashManagementDelSuccess(null));
  }, [cashManagementDel]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (cashDelOther && !_.isEqual(cashDelOther, preCashDelOther)) {
      _handleToast('Xóa bút toán thành công', 'success');
      dispatch(cashDelOtherSuccess(null));
    }
  }, [cashDelOther]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove))
      _handleToast('Duyệt bút toán thành công', 'success');
    dispatch(cashManagementApproveSuccess(null));
  }, [cashMngApprove]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;
    _params.data.BUSINESS_DETAIL_CODE = values.formType;
    dispatch(cashManagementListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = props.formAccountCode;
    _params.data.FROM_DATE = props.formStartDate;
    _params.data.TO_DATE = props.formEndDate;
    _params.data.STATUS = props.formStatus;
    _params.data.BUSINESS_DETAIL_CODE = props.formType;

    dispatch(cashManagementListRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'GD_EXPORT_06';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_CASH_MANAGEMENT_APPROVE";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-entry-type')}</Form.Label>
        <Field
          name="formType"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glCashTypeEntry}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_110 mx-2"
          component={RenderNormalSelect}
          opts={cashStatus}
          placeholder="-- Tất cả --"
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />

      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
      <ExportExcel >
        <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDuyetGDTien',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDuyetGDTien');

const makeMapStateToProps = () => {
  const getCashInUpdate = makeGetCashInUpdate();
  const getCashOutUpdate = makeGetCashOutUpdate();
  const getCashTransferUpdate = makeGetCashTransferUpdate();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
 
  const getCashStatus = makeGetCashStatus();
  const getCashTypeEntry = makeGetCashTypeEntry();

  const mapStateToProps = (state) => {
    const {
      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
      formType,
    } = selector(
      state,
      'formAccountCode',
      'formStatus',
      'formStartDate',
      'formEndDate',
      'formType'
    );

    return {
      cashInUpd: getCashInUpdate(state),
      cashOutUpd: getCashOutUpdate(state),
      cashTransferUpd: getCashTransferUpdate(state),
      cashMngApprove: getCashManagementApprove(state),
      cashMngUnApprove: getCashManagementUnApprove(state),
      cashMngReject: getCashManagementReject(state),
      cashManagementDel: getCashManagementDel(state),
      cashMngApprove: getCashManagementApprove(state),

      cashStatus: getCashStatus(state),
      glCashTypeEntry: getCashTypeEntry(state),

      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
      formType,

      initialValues: {
        formStatus: 'CHUA_DUYET',
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
