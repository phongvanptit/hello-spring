import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { cashOtherListRequest } from 'containers/cash/actions';
import {
  makeGetAllBranch,
  makeGetBNTransaction,
  makeGetGlobalCashBusiness,
  makeGetGlobalCashBusinessDetail,
  makeGetPublicStt,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

import { globalCashBusinessDetailRequest } from 'containers/global/actions';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    token,
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    setDataSearch,
    onClose,
    onTriggerPopover,
    glAllBranch,
    glCashBusiness,
    glCashBusinessDetail,
    formBusiness,
    sysSystemInfo,
  } = props;

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  React.useEffect(() => {
    if (formBusiness) {
      _handleGetBusinessDetail();
    } else dispatch(globalCashBusinessDetailRequest(null));
  }, [formBusiness]);

  function _handleGetBusinessDetail() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BUSINESS_DETAIL',
      group: 'LIST',
      data: {
        BUSINESS_TRANSACTION_CODE: formBusiness,
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalCashBusinessDetailRequest(params));
  }

  const submit = (values) => {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_OTHER_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        BRANCH_CODE: values?.formBranchCode,
        BUSINESS_CODE: values?.formBusiness,
        BUSSINESS_DETAIL_CODE: values?.formBusinessDetail,
        CREATOR_CODE: values?.formCreatorCode,
        ACCOUNT_CODE: values?.formAccountCode,

        FROM_DATE: values?.formStartDate,
        TO_DATE: values?.formEndDate,
        STATUS: values?.formStatus,
        OTHER_FLAG: 1,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    dispatch(cashOtherListRequest(params));
    setDataSearch && setDataSearch(params);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalOther', 'formBranchCode', ''));
    dispatch(change('formSearchModalOther', 'formBusiness', ''));
    dispatch(change('formSearchModalOther', 'formBusinessDetail', ''));
    dispatch(change('formSearchModalOther', 'formCreatorCode', ''));
    dispatch(change('formSearchModalOther', 'formAccountCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-branch')}</Form.Label>
          <Field
            name="formBranchCode"
            type="text"
            className="form-control"
            component={RenderNormalSelect}
            opts={glAllBranch}
            index={3}
            placeholder="-- Tất cả --"
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-creator')}</Form.Label>
          <Field
            name="formCreatorCode"
            type="text"
            className="form-control"
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group style={{ gridColumn: '3/5' }}>
          <Form.Label className="fz-13">{t('txt-bus')}</Form.Label>
          <Field
            name="formBusiness"
            type="text"
            className="form-control"
            placeholder="-- Tất cả --"
            component={RenderNormalSelect}
            opts={glCashBusiness}
            index={2}
          />
        </Form.Group>
        <Form.Group style={{ gridColumn: '1/3' }}>
          <Form.Label className="fz-13">{t('txt-detail-business')}</Form.Label>
          <Field
            name="formBusinessDetail"
            type="text"
            className="form-control"
            component={RenderNormalSelect}
            opts={glCashBusinessDetail}
            placeholder="-- Tất cả --"
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalOther',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalOther');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getPublicStt = makeGetPublicStt();
  const getBNTransaction = makeGetBNTransaction();
  const getAllBranch = makeGetAllBranch();
  const getGlobalCashBusiness = makeGetGlobalCashBusiness();
  const getGlobalCashBusinessDetail = makeGetGlobalCashBusinessDetail();
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      formBranchCode,
      formCreatorCode,
      formStartDate,
      formEndDate,
      formBusiness,
      formBusinessDetail,
      formStatus,
      formAccountCode,
    } = selector(
      state,
      'formBranchCode',
      'formCreatorCode',
      'formStartDate',
      'formEndDate',
      'formBusiness',
      'formBusinessDetail',
      'formStatus',
      'formAccountCode'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      glPublicStt: getPublicStt(state),
      glBnTransaction: getBNTransaction(state),
      glAllBranch: getAllBranch(state),
      glCashBusiness: getGlobalCashBusiness(state),
      glCashBusinessDetail: getGlobalCashBusinessDetail(state),
      sysSystemInfo: getSystemInfo(state),
      formBranchCode,
      formCreatorCode,
      formStartDate,
      formEndDate,
      formBusiness,
      formBusinessDetail,
      formStatus,
      formAccountCode,
      initialValues: {
        formBranchCode: dataSearch?.data?.BRANCH_CODE,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
        formBusiness: dataSearch?.data?.BUSINESS_CODE,
        formBusinessDetail: dataSearch?.data?.BUSSINESS_DETAIL_CODE,
        formStatus: dataSearch?.data?.STATUS,
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
