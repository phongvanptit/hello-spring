import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import {
  cashDelOtherSuccess,
  cashManagementApproveSuccess,
  cashOtherListRequest,
} from 'containers/cash/actions';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { change } from 'redux-form';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  makeCashDelOther,
  makeCashUpdOther,
  makeGetCashManagementApprove,
  makeGetCashManagementReject,
  makeGetCashManagementUnApprove,
} from 'lib/selector';

import { setToast } from 'containers/client/actions';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    cashUpdOther,
    cashDelOther,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,

    formAccountCode,
    formStatus,
    formStartDate,
    formEndDate,
    statusCode
  } = props;

  const preCashUpdOther = usePrevious(cashUpdOther);
  const preCashDelOther = usePrevious(cashDelOther);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    if (cashDelOther && !_.isEqual(cashDelOther, preCashDelOther)) {
      _handleToast('Xóa bút toán thành công', 'success');
      dispatch(cashDelOtherSuccess(null));
    }
  }, [cashDelOther]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove))
      _handleToast('Duyệt bút toán thành công', 'success');
    dispatch(cashManagementApproveSuccess(null));
  }, [cashMngApprove]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  useEffect(() => {
    if (
      (cashUpdOther && !_.isEqual(cashUpdOther, preCashUpdOther)) ||
      (cashDelOther && !_.isEqual(cashDelOther, preCashDelOther)) ||
      (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) ||
      (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) ||
      (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject))
    ) {
      dispatch(cashOtherListRequest(dataSearch));
    }
  }, [
    cashUpdOther,
    cashDelOther,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
  ]);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(cashOtherListRequest(dataSearch));
    }, 200);
  }, []);

  function initForm() {
    if (statusCode) {
      dispatch(change('formSearchShortOther', 'formStatus', statusCode));
      
    }
  }

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;
    dispatch(cashOtherListRequest(_params));
    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;
    dispatch(cashOtherListRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'GD_EXPORT_05';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_CASH_MANAGEMENT_OTHER";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component="select"
          onBlur={_handleBlur}
        >
          <option value="">-- Tất cả --</option>
          <option value="CHUA_DUYET">Chưa duyệt</option>
          <option value="DA_DUYET">Đã duyệt</option>
          <option value="DA_HUY">Đã hủy</option>
        </Field>
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        className="form-control"
        name="formAccountCode"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel >
        <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortOther',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortOther');

const makeMapStateToProps = () => {
  const getCashUpdOther = makeCashUpdOther();
  const getCashDelOther = makeCashDelOther();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const mapStateToProps = (state) => {
    const { formAccountCode, formStatus, formStartDate, formEndDate } =
      selector(
        state,
        'formAccountCode',
        'formStatus',
        'formStartDate',
        'formEndDate'
      );

    return {
      cashUpdOther: getCashUpdOther(state),
      cashDelOther: getCashDelOther(state),
      cashMngApprove: getCashManagementApprove(state),
      cashMngUnApprove: getCashManagementUnApprove(state),
      cashMngReject: getCashManagementReject(state),
      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
