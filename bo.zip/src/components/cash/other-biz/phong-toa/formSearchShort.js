import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import {
  cashApprBlockSuccess,
  cashBlockListRequest,
  cashDelBlockSuccess,
} from 'containers/cash/actions';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { change } from 'redux-form';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  makeCashApprBlock,
  makeCashDelBlock,
  makeCashRejectBlock,
  makeCashUnApprBlock,
  makeCashUpdBlock,
  makeCashUpdUnBlock,
} from 'lib/selector';

import { setToast } from 'containers/client/actions';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    cashUpdBlock,
    cashUpdUnBlock,
    cashDelBlock,
    cashApprBlock,
    cashRejectBlock,
    cashUnApprBlock,

    formAccountCode,
    formStatus,
    formStartDate,
    formEndDate,
    statusCode,
  } = props;

  const preCashUpdBlock = usePrevious(cashUpdUnBlock);
  const preCashUpdUnBlock = usePrevious(cashUpdUnBlock);
  const preCashDelBlock = usePrevious(cashDelBlock);
  const preCashApprBlock = usePrevious(cashApprBlock);
  const preCashUnApprBlock = usePrevious(cashUnApprBlock);
  const preCashRejectBlock = usePrevious(cashRejectBlock);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(cashBlockListRequest(dataSearch));
    }, 200);
  }, []);

  function initForm() {
    if (statusCode) {
      dispatch(change('formSearchShortPhongToa', 'formStatus', statusCode));
      
    }
  }

  useEffect(() => {
    if (cashDelBlock && !_.isEqual(cashDelBlock, preCashDelBlock)) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashDelBlockSuccess(null));
    }
  }, [cashDelBlock]);

  useEffect(() => {
    if (cashApprBlock && !_.isEqual(cashApprBlock, preCashApprBlock)) {
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      dispatch(cashApprBlockSuccess(null));
    }
  }, [cashApprBlock]);

  useEffect(() => {
    if (
      (cashUpdBlock && !_.isEqual(cashUpdBlock, preCashUpdBlock)) ||
      (cashUpdUnBlock && !_.isEqual(cashUpdUnBlock, preCashUpdUnBlock)) ||
      (cashDelBlock && !_.isEqual(cashDelBlock, preCashDelBlock)) ||
      (cashRejectBlock && !_.isEqual(cashRejectBlock, preCashRejectBlock)) ||
      (cashApprBlock && !_.isEqual(cashApprBlock, preCashApprBlock)) ||
      (cashUnApprBlock && !_.isEqual(cashUnApprBlock, preCashUnApprBlock))
    ) {
      dispatch(cashBlockListRequest(dataSearch));
    }
  }, [
    cashUpdBlock,
    cashUpdUnBlock,
    cashDelBlock,
    cashRejectBlock,
    cashApprBlock,
    cashUnApprBlock,
  ]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.APPROVE_STATUS = values.formStatus;
    dispatch(cashBlockListRequest(_params));
    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.APPROVE_STATUS = formStatus;
    dispatch(cashBlockListRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'GD_EXPORT_07';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_BLOCK_UNBLOCK";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component="select"
          onBlur={_handleBlur}
        >
          <option value="">-- Tất cả --</option>
          <option value="CHUA_DUYET">Chưa duyệt</option>
          <option value="DA_DUYET">Đã duyệt</option>
          <option value="TU_CHOI">Từ chối</option>
        </Field>
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        className="form-control"
        name="formAccountCode"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel >
        <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortPhongToa',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortPhongToa');

const makeMapStateToProps = () => {
  const getCashUpdBlock = makeCashUpdBlock();
  const getCashUpdUnBlock = makeCashUpdUnBlock();
  const getCashDelBlock = makeCashDelBlock();
  const getCashUnApprBlock = makeCashUnApprBlock();
  const getCashRejectBlock = makeCashRejectBlock();
  const getCashApprBlock = makeCashApprBlock();
  const mapStateToProps = (state) => {
    const { formAccountCode, formStatus, formStartDate, formEndDate } =
      selector(
        state,
        'formAccountCode',
        'formStatus',
        'formStartDate',
        'formEndDate'
      );

    return {
      cashUpdBlock: getCashUpdBlock(state),
      cashUpdUnBlock: getCashUpdUnBlock(state),
      cashDelBlock: getCashDelBlock(state),
      cashApprBlock: getCashApprBlock(state),
      cashUnApprBlock: getCashUnApprBlock(state),
      cashRejectBlock: getCashRejectBlock(state),
      cashApprBlock: getCashApprBlock(state),

      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
