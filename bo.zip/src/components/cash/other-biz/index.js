import TabGiaiToa from './giai-toa';
import TabNghiepVuKhac from './nghiep-vu-khac';
import TabPhongToa from './phong-toa';

function IndividualComponent(props) {
  const { subType, accRight, statusCode } = props;
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'phong-toa' && <TabPhongToa accRight={accRight} statusCode={statusCode}/>}
        {subType === 'giai-toa' && <TabGiaiToa accRight={accRight} />}
        {subType === 'other' && <TabNghiepVuKhac accRight={accRight} statusCode={statusCode}/>}
      </div>
    </>
  );
}

export default IndividualComponent;
