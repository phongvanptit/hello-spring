import { cashUnBlockListRequest } from 'containers/cash/actions';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import RenderSelectDate from 'components/input/renderDatePicker';
import {
  makeGetPublicStt,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import { formatDate, stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    token,
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    setDataSearch,
    onClose,
    onTriggerPopover,
    sysSystemInfo,
  } = props;

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        BUSSINESS_CODE: values?.businessCode,
        ACCOUNT_CODE: values?.formAccountCode,
        FROM_DATE: values?.formStartDate,
        TO_DATE: values?.formEndDate,
        APPROVE_STATUS: values?.formApproveStatus,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    dispatch(cashUnBlockListRequest(params));
    setDataSearch && setDataSearch(params);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(
      change(
        'formSearchModalCoTucGiaiToa',
        'formStartDate',
        formatDate(_date, '/', 'dmy')
      )
    );
    dispatch(
      change(
        'formSearchModalCoTucGiaiToa',
        'formEndDate',
        formatDate(
          sysSystemInfo
            ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
            : new Date(),
          '/',
          'dmy'
        )
      )
    );
    dispatch(change('formSearchModalCoTucGiaiToa', 'formApproveStatus', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
          <Field
            className="form-control"
            name="formStartDate"
            type="start"
            component={RenderSelectDate}
            onCalendarOpen={() => setCalendarOpen(true)}
            onCalendarClose={() => setCalendarOpen(false)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
          <Field
            className="form-control"
            name="formEndDate"
            type="end"
            component={RenderSelectDate}
            onCalendarOpen={() => setCalendarOpen(true)}
            onCalendarClose={() => setCalendarOpen(false)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
          <Field
            name="formApproveStatus"
            className="form-control w-100"
            component="select"
          >
            <option value="">-- Tất cả --</option>
            <option value="CHUA_DUYET">Chưa duyệt</option>
            <option value="DA_DUYET">Đã duyệt</option>
          </Field>
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalCoTucGiaiToa',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalCoTucGiaiToa');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getPublicStt = makeGetPublicStt();
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      businessCode,
      formAccountCode,
      formStartDate,
      formEndDate,
      formApproveStatus,
    } = selector(
      state,
      'businessCode',
      'formAccountCode',
      'formStartDate',
      'formEndDate',
      'formApproveStatus'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      glPublicStt: getPublicStt(state),
      sysSystemInfo: getSystemInfo(state),

      businessCode,
      formAccountCode,
      formStartDate,
      formEndDate,
      formApproveStatus,
      initialValues: {
        businessCode: dataSearch?.data?.BUSSINESS_CODE,
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
        formApproveStatus: dataSearch?.data?.APPROVE_STATUS,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
