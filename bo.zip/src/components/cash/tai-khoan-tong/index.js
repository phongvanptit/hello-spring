import { translate } from 'react-i18next';
import Tab from './danh-sach-tk-tong';
import TabNopTien from './nop-tien';
import TabRutTien from './rut-tien';
import TabChuyenKhoan from './chuyen-khoan';
import TabDuyetChuyenKhoan from './duyet-chuyen-khoan';

function IndividualComponent(props) {
  const { subType, accRight } = props;
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'danh-sach-tk-tong' && <Tab accRight={accRight} />}
        {subType === 'nop-tien' && <TabNopTien accRight={accRight} />}
        {subType === 'rut-tien' && <TabRutTien accRight={accRight} />}
        {subType === 'chuyen-khoan' && <TabChuyenKhoan accRight={accRight} />}
        {subType === 'duyet-chuyen-khoan' && <TabDuyetChuyenKhoan accRight={accRight} />}
      </div>
    </>
  );
}

export default translate('translations')(IndividualComponent);
