import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  bankManagementListRequest,
  bankManagementDelSuccess
} from 'containers/cash/actions';
import {
  makeGetBankTransferUpdate,
  makeGetCashManagementApprove,
  makeGetBankManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementUnApprove,
} from 'lib/selector';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import { setToast } from 'containers/client/actions';
import { makeGetCashStatus } from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    bankTransferUpd,
    cashMngApprove,
    bankManagementDel,
    cashStatus,

    formAccountCode,
    formStatus,
    formStartDate,
    formEndDate,
  } = props;

  const preBankTransferUpd = usePrevious(bankTransferUpd);
  const preBankManagementDel = usePrevious(bankManagementDel);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(bankManagementListRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (bankTransferUpd && !_.isEqual(bankTransferUpd, preBankTransferUpd)) ||
      (bankManagementDel && !_.isEqual(bankManagementDel, preBankManagementDel))
    ) {
      dispatch(bankManagementListRequest(dataSearch));
    }
  }, [
    bankTransferUpd,
    bankManagementDel,
  ]);

  useEffect(() => {
    if (
      bankManagementDel &&
      !_.isEqual(bankManagementDel, preBankManagementDel)
    )
      _handleToast(t('txt-del-entry-success'), 'success');
    dispatch(bankManagementDelSuccess(null));
  }, [bankManagementDel]);

  // useEffect(() => {
  //   if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove))
  //     _handleToast(t('txt-appr-entry-success'), 'success');
  //   dispatch(cashManagementApproveSuccess(null));
  // }, [cashMngApprove]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;

    dispatch(bankManagementListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;

    dispatch(bankManagementListRequest(_params));
    console.log('actions');
    setDataSearch && setDataSearch(_params);
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={cashStatus}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />

      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortNopTien',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortNopTien');

const makeMapStateToProps = () => {
  const getBankTransferUpdate = makeGetBankTransferUpdate();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getBankManagementDel = makeGetBankManagementDel();
  const getCashStatus = makeGetCashStatus();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStatus, formStartDate, formEndDate } =
      selector(
        state,
        'formAccountCode',
        'formStatus',
        'formStartDate',
        'formEndDate'
      );

    return {
      bankTransferUpd: getBankTransferUpdate(state),
      cashMngApprove: getCashManagementApprove(state),
      cashMngUnApprove: getCashManagementUnApprove(state),
      cashMngReject: getCashManagementReject(state),
      bankManagementDel: getBankManagementDel(state),
      cashStatus: getCashStatus(state),

      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
