import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailNopTienModal from 'components/modal/cash/tai-khoan-tong/nop-tien/DetailNopTienModal';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  cashManagementApproveRequest,
  bankManagementDelRequest,
} from 'containers/cash/actions';
import { makeGetBankManagementList, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import { useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { numberFormat } from 'utils';
import { GroupButton } from 'utils/styledComponent';
import FormSearchNopTien from './formSearchNopTien';

function GroupAction(props) {
  const { record, fnCallback, rightFunc, t } = props;

  function _handleClickItem(fnName) {
    fnCallback[fnName](record?.PK_BANK_MANAGEMENT);
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW === 1 && (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      )}

      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() => _handleClickItem('onDelete')}
        >
          <IconTrash />
        </a>
      )}
    </GroupButton>
  );
}

function NopTienComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [idDetail, setIdDetail] = useState(null);
  const [checkAll, setCheckAll] = useState(false);

  const dispatch = useDispatch();
  const { bankManagementList, token, t, accRight } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(
        bankManagementList,
        (o) => o.C_STATUS === 'CHUA_DUYET'
      );
      setOrderCheck(_.map(allFunc, 'PK_BANK_MANAGEMENT'));
    }
  }

  function handleDetail(value) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(value);
  }

  function onClose() {
    setIdDetail(null);
  }

  // function handleApprove(value) {
  //   if (!value) return;
  //   confirmAlert({
  //     customUI: ({ onClose }) => {
  //       return (
  //         <div className="custom-ui-confirm">
  //           <h1>{t('txt-confirm')}</h1>
  //           <p>{t('txt-appr-entry')}</p>
  //           <button onClick={onClose}>{t('txt-cancel')}</button>
  //           <button
  //             onClick={() => {
  //               handleActionApprove(value);
  //               onClose();
  //             }}
  //           >
  //             {t('txt-accept')}
  //           </button>
  //         </div>
  //       );
  //     },
  //     closeOnEscape: true,
  //     closeOnClickOutside: true,
  //     keyCodeForClose: [8, 32],
  //   });
  // }

  // function handleActionApprove(value) {
  //   const params = {
  //     user: token?.USER_NAME,
  //     session: token?.SESSION_ID,
  //     cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
  //     group: 'LIST',
  //     data: {
  //       LIST_ITEM_ID: value,
  //     },
  //   };

  //   dispatch(cashManagementApproveRequest(params));
  // }

  function handleDel(value) {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_BANK_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(bankManagementDelRequest(params));
    setOrderCheck([]);
    setCheckAll(false);
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearchNopTien page={page} recordPerPage={recordPerPage} />
        <Table bordered className="mt-2">
          <thead>
            <tr>
              <th style={{ width: '26px' }}>
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              </th>
              <th>Tài khoản nhận</th>
              <th>Số tiền</th>
              <th>Ngày giao dịch</th>
              <th>{t('txt-content')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-creator')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {bankManagementList &&
              bankManagementList.map((item) => (
                <tr
                  key={item.PK_BANK_MANAGEMENT}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_BANK_MANAGEMENT)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td className="text-center">
                    {item.C_STATUS === 'CHUA_DUYET' && (
                      <input
                        type={'checkbox'}
                        name={item.PK_BANK_MANAGEMENT}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_BANK_MANAGEMENT
                        )}
                      />
                    )}
                  </td>

                  <td className="text-center">
                    {`${item.C_ACCOUNT_IN} - ${item.C_ACCOUNT_IN_NAME}`}
                  </td>
                  <td className="text-right">
                    {numberFormat(item.C_CASH_VALUE)}
                  </td>
                  <td className="text-center">{item.C_TRANSACTION_DATE}</td>

                  <td className="">{item.C_CONTENT}</td>
                  <td className={'orderStt_' + item.C_STATUS + ' text-center'}>
                    {item.C_STATUS_NAME}
                  </td>
                  <td className="text-center">{item.C_CREATOR_CODE}</td>
                  <td className="text-center p-0 w_85">
                    {accRight?.C_VIEW ||
                    accRight?.C_APPROVE ||
                    accRight?.C_UPDATE ? (
                      <GroupAction
                        record={item}
                        rightFunc={accRight}
                        t={t}
                        fnCallback={{
                          // onApprove: handleApprove,
                          onDetail: handleDetail,
                          onDelete: handleDel,
                        }}
                      />
                    ) : null}
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!bankManagementList || !bankManagementList.length) && (
          <NodataSearch name={t('txt-deposit-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          {orderCheck && !!orderCheck.length && (
            <Button
              variant="danger"
              className="mr-auto"
              onClick={() => handleDel(orderCheck.join(','))}
              disabled={accRight?.C_UPDATE !== 1}
            >
              {t('bnt-del-entry')}
            </Button>
          )}
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (bankManagementList &&
                !!bankManagementList.length &&
                bankManagementList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailNopTienModal
            id={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getBankManagementList = makeGetBankManagementList();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      bankManagementList: getBankManagementList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(NopTienComponent)
);
