import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { bankManagementListRequest } from 'containers/cash/actions';
import { makeGetToken } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';
import { arrSearchNopRutTien } from 'utils/const';

import {
  makeGetChannelType,
  makeGetGlobalCashDeposit,
  makeGetSystemInfo,
} from 'lib/selector';
import * as _ from 'lodash';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    token,
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    glChannelType,
    setDataSearch,
    onClose,
    onTriggerPopover,
    sysSystemInfo,
    glCashDeposit,
    cashStatus,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchNopRutTien, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BANK_MANAGEMENT',
      group: 'LIST',
      data: {
        BUSINESS_CODE: '',
        ACCOUNT_CODE: values.formAccountCode,
        ACCOUNT_NAME: values.formAccountName,
        FROM_DATE: _.some(arrSel, (o) => o === 'formStartDate')
          ? values.formStartDate
          : null,
        TO_DATE: _.some(arrSel, (o) => o === 'formEndDate')
          ? values.formEndDate
          : null,
        STATUS: values.formStatus,
        CREATOR_CODE: values.formCreatorCode,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    dispatch(bankManagementListRequest(params));
    setDataSearch && setDataSearch(params);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalNopTien', 'formCreatorCode', ''));
    dispatch(change('formSearchModalNopTien', 'formAccountCode', ''));
    dispatch(change('formSearchModalNopTien', 'formAccountName', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100">
        <Form.Group>
          <Form.Label className="fz-13">Người tạo</Form.Label>
          <Field
            name="formCreatorCode"
            type="text"
            className="form-control"
            placeholder={'Người tạo'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Số tài khoản</Form.Label>
          <Field
            name="formAccountCode"
            type="text"
            className="form-control"
            placeholder={'Số tài khoản'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Tên tài khoản</Form.Label>
          <Field
            name="formAccountName"
            type="text"
            className="form-control"
            placeholder={t('Tên tài khoản')}
            component={RenderInput}
          />
        </Form.Group>

     
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalNopTien',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalNopTien');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getChannelType = makeGetChannelType();
  const getSystemInfo = makeGetSystemInfo();
  const getGlobalCashDeposit = makeGetGlobalCashDeposit();
  const mapStateToProps = (state, props) => {
    const {
      formBusinessCode,
      formAccountCode,
      formAccountName,
      formStatus,
      formCreatorCode,
      formStartDate,
      formEndDate,
    } = selector(
      state,
      'formBusinessCode',
      'formAccountCode',
      'formAccountName',
      'formStatus',
      'formCreatorCode',
      'formStartDate',
      'formEndDate'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      glChannelType: getChannelType(state),
      sysSystemInfo: getSystemInfo(state),
      glCashDeposit: getGlobalCashDeposit(state),
      formBusinessCode,
      formAccountCode,
      formAccountName,
      formStatus,
      formCreatorCode,
      formStartDate,
      formEndDate,

      initialValues: {
        formBusinessCode: dataSearch?.data?.BUSINESS_CODE,
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formAccountName: dataSearch?.data?.ACCOUNT_NAME,
        formStatus: dataSearch?.data?.STATUS,
       
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
