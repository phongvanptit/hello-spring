/* eslint-disable jsx-a11y/anchor-is-valid */
import { memo, useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { typeDelBankRequest } from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import { makeGetToken, makeGetTypeListBankSearch } from 'lib/selector';
import * as _ from 'lodash';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './formSearch';
import DetailBranchBankModal from 'components/modal/cash/tai-khoan-tong/detail';
import Paging from 'components/paging';
import { numberFormat } from 'utils';

function GroupAction(props) {
  const { record, fnCallback, rightFunc, t } = props;

  function _handleClickItem(fnName) {
    fnCallback &&
      fnCallback[fnName] &&
      fnCallback[fnName](record?.PK_BRANCH_BANK);
  }

  return (
    <GroupButton>
      <a
        title={t('txt-detail')}
        rel="noreferrer noopener"
        onClick={() => _handleClickItem('onDetail')}
      >
        <IconCopy />
      </a>
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS === 0 ? '' : 'disabled'}
          onClick={() =>
            record.C_STATUS === 0 ? _handleClickItem('onDelete') : null
          }
        >
          <IconTrash />
        </a>
      )}
    </GroupButton>
  );
}

function BranchBankComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [isOpen, setIsOpen] = useState(false);
  const [isOpenDetail, setIsOpenDetail] = useState(false);
  const [isID, setIsID] = useState(null);
  const [orderCheck, setOrderCheck] = useState([]);
  const [checkAll, setCheckAll] = useState(false);

  const { typeListBank, token, t, accRight } = props;
  const dispatch = useDispatch();

  function _onClose() {
    setIsOpen(false);
    setIsOpenDetail(false);
  }

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const find = _.filter(typeListBank, (o) => o.C_STATUS === 0);
      const allFunc = _.map(find, 'PK_BRANCH_BANK');
      setOrderCheck(allFunc);
    }
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeDetail(id) {
    setIsOpenDetail(true);
    setIsID(id);
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleDel(value) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-acc-total')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_BRANCH_BANK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };
    dispatch(typeDelBankRequest(params));
    setOrderCheck([]);
  }

  return (
    <>
      <div className="custom-tabs-content mb-4 mt-2">
        <div className="w-100 d-flex flex-column">
          <FormSearch
            page={page}
            recordPerPage={recordPerPage}
            handleToast={_handleToast}
          />
          <Table bordered>
            <thead>
              <tr>
                <th style={{ width: '26px' }}>
                  <input
                    type="checkbox"
                    value={checkAll}
                    onChange={_handleChangeCheckAll}
                    checked={checkAll}
                  />
                </th>
                <th>{t('txt-bank')}</th>
                <th>{t('txt-total-acc-code')}</th>
                <th>{t('txt-total-acc-name')}</th>
                <th>{t('txt-acc-bank-number')}</th>
                <th>{t('txt-balance')}</th>
                <th>{t('txt-status')}</th>
                <th>{t('txt-action')}</th>
              </tr>
            </thead>
            <tbody>
              {typeListBank &&
                typeListBank.map((item) => (
                  <tr
                    key={item.ROW_NUM}
                    className={
                      _.some(orderCheck, (o) => o === item.PK_BRANCH_BANK)
                        ? 'row-checked'
                        : ''
                    }
                  >
                    <td className="text-center">
                      {item?.C_STATUS === 0 && (
                        <input
                          type={'checkbox'}
                          name={item.PK_BRANCH_BANK}
                          onChange={_handleChange}
                          checked={_.some(
                            orderCheck,
                            (o) => o === item.PK_BRANCH_BANK
                          )}
                        />
                      )}
                    </td>
                    <td>
                      <a
                        onClick={() => _handleChangeDetail(item.PK_BRANCH_BANK)}
                      >
                        {item.C_BANK_NAME}
                      </a>
                    </td>
                    <td className="text-center">
                      <a
                        onClick={() => _handleChangeDetail(item.PK_BRANCH_BANK)}
                      >
                        {item.C_BRANCH_BANK_CODE}
                      </a>
                    </td>
                    <td>
                      <a
                        onClick={() => _handleChangeDetail(item.PK_BRANCH_BANK)}
                      >
                        {item.C_BRANCH_BANK_NAME}
                      </a>
                    </td>
                    <td className="text-center">{item.C_BANK_ACCOUNT_CODE}</td>
                    <td className="text-right">{numberFormat(item?.C_CASH_BALANCE, 0, '0')}</td>
                    <td className="text-center">
                      {item.C_STATUS === 1 ? 'Hoạt động' : 'Không hoạt động'}
                    </td>
                    <td className="text-center p-0 w_85">
                      {accRight?.C_VIEW ||
                      accRight?.C_APPROVE ||
                      accRight?.C_UPDATE ? (
                        <GroupAction
                          record={item}
                          rightFunc={accRight}
                          t={t}
                          fnCallback={{
                            onDetail: _handleChangeDetail,
                            onDelete: handleDel,
                          }}
                        />
                      ) : null}
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>

          <div className="mt-3 d-flex justify-content-end">
            {orderCheck && !!orderCheck.length && (
              <Button
                variant="danger"
                className="mr-auto"
                onClick={() => handleDel(orderCheck.join(','))}
              >
                Xóa tài khoản tổng đã chọn
              </Button>
            )}
            <Paging
              page={page}
              recordPerPage={recordPerPage}
              nextPage={_handleNextPage}
              setRecordPerPage={setRecordPerPage}
              total={
                (typeListBank &&
                  !!typeListBank.length &&
                  typeListBank[0].C_TOTAL_RECORD) ||
                0
              }
            />
          </div>
        </div>
      </div>
      {isOpenDetail && (
        <DetailBranchBankModal
          onClose={_onClose}
          id={isID}
          accRight={accRight}
        />
      )}
    </>
  );
}
const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getTypeListBankSearch = makeGetTypeListBankSearch();
  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      typeListBank: getTypeListBankSearch(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(memo(BranchBankComponent))
);
