import RenderSearchShort from 'components/input/inputSearchShort';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import RenderInput from 'components/input/renderInput';
import {
  typeBankSearchRequest,
  typeDelBankSuccess,
} from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAllBank,
  makeGetTypeDelBank,
  makeGetTypeUpdBank,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,

    typeDelBank,
    typeUpdBank,
  } = props;

  const preTypeDelBank = usePrevious(typeDelBank);
  const preTypeUpdBank = usePrevious(typeUpdBank);

  useEffect(() => {
    setTimeout(() => {
      _handleBlur();
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (typeUpdBank && !_.isEqual(typeUpdBank, preTypeUpdBank)) ||
      (typeDelBank && !_.isEqual(typeDelBank, preTypeDelBank))
    ) {
      _handleBlur();
    }
  }, [typeUpdBank, typeDelBank]);

  useEffect(() => {
    if (typeDelBank && !_.isEqual(typeDelBank, preTypeDelBank)) {
      handleToast(t('txt-del-acc-total-success'), 'success');
      dispatch(typeDelBankSuccess(null));
    }
  }, [typeDelBank]);

  const handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.BANK_CODE = values?.formBankCode;
    _params.data.BRANCH_BANK_CODE = values?.formCode;
    _params.data.BRANCH_BANK_NAME = values?.formName;
    _params.data.BANK_ACCOUNT_CODE = values?.formAccountCode;

    dispatch(typeBankSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.BANK_CODE = props?.formBankCode;
    _params.data.BRANCH_BANK_CODE = props?.formCode;
    _params.data.BRANCH_BANK_NAME = props?.formName;
    _params.data.BANK_ACCOUNT_CODE = props?.formAccountCode;

    dispatch(typeBankSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="w-fix">{t('txt-bank')}</Form.Label>
        <Field
          name="formBankCode"
          type="text"
          className="form-control mx-2 w_100"
          component={RenderInput}
          placeholder={t('txt-bank')}
        />
        <Form.Label className="w-fix">{t('txt-total-acc-name')}</Form.Label>
        <Field
          name="formName"
          type="text"
          className="form-control mx-2 w_100"
          placeholder={t('txt-total-acc-name')}
          component={RenderInput}
        />
        <Form.Label className="w-fix">{t('txt-acc-bank-number')}</Form.Label>
        <Field
          name="formAccountCode"
          type="text"
          className="form-control mx-2 w_100"
          placeholder={t('txt-acc-bank-number')}
          component={RenderInput}
        />
      </div>
      <Form.Group>
        <Field
          name="formCode"
          className="form-control"
          placeholder={t('txt-total-acc-code')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch> */}
      {/* <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortTKTong',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortTKTong');

const makeMapStateToProps = () => {
  const getAllBank = makeGetAllBank();
  const getTypeUpdBank = makeGetTypeUpdBank();
  const getTypeDelBank = makeGetTypeDelBank();

  const mapStateToProps = (state) => {
    const { formBankCode, formName, formCode, formAccountCode } = selector(
      state,
      'formBankCode',
      'formCode',
      'formName',
      'formAccountCode'
    );

    return {
      glAllBank: getAllBank(state),
      typeUpdBank: getTypeUpdBank(state),
      typeDelBank: getTypeDelBank(state),

      formBankCode,
      formCode,
      formName,
      formAccountCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
