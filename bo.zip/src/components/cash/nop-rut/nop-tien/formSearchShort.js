import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  cashManagementApproveSuccess,
  cashManagementDelSuccess,
  cashManagementListRequest,
} from 'containers/cash/actions';
import {
  makeGetCashInUpdate,
  makeGetCashManagementApprove,
  makeGetCashManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementUnApprove,
} from 'lib/selector';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import { setToast } from 'containers/client/actions';
import { makeGetPublicStt } from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';
import { change } from 'redux-form';
import { globalExportFileVer2Request } from 'containers/report/actions';
import { ExportExcel } from 'utils/styledComponent';
import IconExcel from 'assets/img/icon/ms-excel.png';
import RenderInput from '../../../input/renderInput';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    cashInUpd,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    glStatusList,

    formAccountCode,
    formStatus,
    formStartDate,
    formEndDate,
    statusCode,
    bizCode,
  } = props;

  const preCashInUpd = usePrevious(cashInUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(cashManagementListRequest(dataSearch));
    }, 200);
  }, []);

  function initForm() {
 
    if (statusCode) {
      dispatch(change('formSearchShortNopTien', 'formStatus', statusCode));
      
    }
  }

  useEffect(() => {
    if (
      (cashInUpd && !_.isEqual(cashInUpd, preCashInUpd)) ||
      (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) ||
      (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) ||
      (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) ||
      (cashManagementDel && !_.isEqual(cashManagementDel, preCashManagementDel))
    ) {
      dispatch(cashManagementListRequest(dataSearch));
    }
  }, [
    cashInUpd,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
  ]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    )
      _handleToast(t('txt-del-entry-success'), 'success');
    dispatch(cashManagementDelSuccess(null));
  }, [cashManagementDel]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove))
      _handleToast(t('txt-appr-entry-success'), 'success');
    dispatch(cashManagementApproveSuccess(null));
  }, [cashMngApprove]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;
    _params.data.FILE_NO = values.formFileNo;

    dispatch(cashManagementListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;
    _params.data.FILE_NO = props.formFileNo;

    dispatch(cashManagementListRequest(_params));
    console.log('actions');
    setDataSearch && setDataSearch(_params);
  }

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'GD_01';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_CASH_DEPOSIT";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glStatusList}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 w-fix mx-2">Số hồ sơ</Form.Label>
        <Field
          name="formFileNo"
          className="form-control w_150"
          classParentName="w-100"
          onBlur={_handleBlur}
          component={RenderInput}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />

      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
      <ExportExcel >
        <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortNopTien',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortNopTien');

const makeMapStateToProps = () => {
  const getCashInUpdate = makeGetCashInUpdate();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
  const getGlStatusList = makeGetPublicStt();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStatus, formStartDate, formEndDate, formFileNo } =
      selector(
        state,
        'formAccountCode',
        'formStatus',
        'formStartDate',
        'formEndDate',
        'formFileNo'
      );

    return {
      cashInUpd: getCashInUpdate(state),
      cashMngApprove: getCashManagementApprove(state),
      cashMngUnApprove: getCashManagementUnApprove(state),
      cashMngReject: getCashManagementReject(state),
      cashManagementDel: getCashManagementDel(state),
      glStatusList: getGlStatusList(state),

      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
      formFileNo,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
