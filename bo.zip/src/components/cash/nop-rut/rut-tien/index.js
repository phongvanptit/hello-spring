import { useState } from 'react';

import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailRutTienModal from 'components/modal/cash/nop-rut-tien/rut-tien/DetailRutTienModal';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  cashManagementApproveRequest,
  cashManagementDelRequest,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import { makeGetCashManagementList, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { numberFormat } from 'utils';
import { GroupButton } from 'utils/styledComponent';
import FormSearchRutTien from './formSearchRutTien';

function GroupAction(props) {
  const { record, fnCallback, rightFunc, t } = props;

  function _handleClickItem(fnName) {
    fnCallback[fnName](record?.PK_CASH_MANAGEMENT);
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW === 1 && (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      )}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={t('txt-appr')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onApprove')
              : null
          }
        >
          <IconApprove />
        </a>
      )}
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onDelete')
              : null
          }
        >
          <IconTrash />
        </a>
      )}
    </GroupButton>
  );
}

function RutTienComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [idDetail, setIdDetail] = useState(null);
  const [checkAll, setCheckAll] = useState(false);

  const dispatch = useDispatch();
  const { cashManagementList, token, t, accRight, statusCode } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(
        cashManagementList,
        (o) => o.C_STATUS === 'CHUA_DUYET'
      );

      setOrderCheck(_.map(allFunc, 'PK_CASH_MANAGEMENT'));
    }
  }

  function handleApprove(value) {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleDel(value) {
    if (!value) return;
    console.log(value);
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashManagementDelRequest(params));
    setOrderCheck([]);
    setCheckAll(false);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleDetail(id) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(id);
  }

  function onClose() {
    setIdDetail(null);
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearchRutTien
          handleToast={_handleToast}
          page={page}
          recordPerPage={recordPerPage}
          statusCode={statusCode}
        />
        <Table bordered>
          <thead>
            <tr>
              <th style={{ width: '26px' }}>
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              </th>
              <th>{t('txt-acc')}</th>
              <th>{t('txt-acc-name')}</th>
              <th>{t('txt-cash-vol')}</th>
              <th>{t('txt-date-trading')}</th>
              <th>{t('txt-trans-no')}</th>
              <th>{t('txt-content')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {cashManagementList &&
              cashManagementList.map((item) => (
                <tr
                  key={item.PK_CASH_MANAGEMENT}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_CASH_MANAGEMENT)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td className="text-center">
                    {item.C_STATUS === 'CHUA_DUYET' && (
                      <input
                        type={'checkbox'}
                        name={item.PK_CASH_MANAGEMENT}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_CASH_MANAGEMENT
                        )}
                      />
                    )}
                  </td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item.PK_CASH_MANAGEMENT)}
                    >
                      {item.C_ACCOUNT_OUT}
                    </a>
                  </td>
                  <td className="">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item.PK_CASH_MANAGEMENT)}
                    >
                      {item.C_ACCOUNT_OUT_NAME}
                    </a>
                  </td>
                  <td className="text-right">
                    {numberFormat(item.C_CASH_VOLUME)}
                  </td>
                  <td className="text-center">{item.C_TRANSACTION_DATE}</td>
                  <td className="text-center">{item.C_TRANSACTION_NO}</td>
                  <td className="">{item.C_CONTENT}</td>
                  <td className={'orderStt_' + item.C_STATUS + ' text-center'}>
                    {item.C_STATUS_NAME}
                  </td>
                  <td className="text-center p-0 w_85">
                    {accRight?.C_VIEW ||
                    accRight?.C_APPROVE ||
                    accRight?.C_UPDATE ? (
                      <GroupAction
                        record={item}
                        rightFunc={accRight}
                        t={t}
                        fnCallback={{
                          onApprove: handleApprove,
                          onDetail: handleDetail,
                          onDelete: handleDel,
                        }}
                      />
                    ) : null}
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!cashManagementList || !cashManagementList.length) && (
          <NodataSearch name={t('txt-withdrawal-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          {orderCheck && !!orderCheck.length && (
            <div className="mr-auto">
              <Button
                className="mr-2"
                onClick={() => handleDel(orderCheck.join(','))}
                variant="danger"
                disabled={accRight?.C_UPDATE !== 1}
              >
                {t('bnt-del-entry')}
              </Button>
              <Button
                //variant="danger"
                className="mr-auto"
                onClick={() => handleApprove(orderCheck.join(','))}
                disabled={accRight?.C_APPROVE !== 1}
              >
                {t('bnt-appr-entry')}
              </Button>
            </div>
          )}
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (cashManagementList &&
                !!cashManagementList.length &&
                cashManagementList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailRutTienModal
            id={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCashManagementList = makeGetCashManagementList();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      cashManagementList: getCashManagementList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(RutTienComponent)
);
