import { translate } from 'react-i18next';
import TabNopTien from './nop-tien';
import TabRutTien from './rut-tien';
import TabChuyenKhoanONL from 'components/cash/chuyen-khoan/chuyen-khoan-ONL';
import TabChuyenKhoanUNC from 'components/cash/chuyen-khoan/chuyen-khoan-UNC';
import TabChuyenKhoanNoiBo from 'components/cash/chuyen-khoan/chuyen-khoan-noi-bo';
import TabNghiepVuKhac from 'components/cash/other-biz/nghiep-vu-khac';
import DuyetGDTienComponent from 'components/cash/duyet-gd-tien';
function IndividualComponent(props) {
  const { subType, accRight,statusCode } = props;
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'nop-tien' && <TabNopTien accRight={accRight} statusCode={statusCode}/>}
        {subType === 'rut-tien' && <TabRutTien accRight={accRight} statusCode={statusCode}/>}
        {subType === 'noi-bo' && <TabChuyenKhoanNoiBo accRight={accRight} />}
        {subType === 'unc' && <TabChuyenKhoanUNC accRight={accRight} />}
        {subType === 'online' && <TabChuyenKhoanONL accRight={accRight} />}
        {subType === 'other' && <TabNghiepVuKhac accRight={accRight} statusCode={statusCode}/>}
        {subType === 'appr-cash' && <DuyetGDTienComponent accRight={accRight} />}
      </div>
    </>
  );
}

export default translate('translations')(IndividualComponent);
