import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { cashManagementListRequest } from 'containers/cash/actions';
import { makeGetToken } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';
import { arrSearchChuyenKhoanTien } from 'utils/const';

import {
  makeGetCashBankStatus,
  makeGetChannelType,
  makeGetSystemInfo,
} from 'lib/selector';
import * as _ from 'lodash';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    token,
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    glChannelType,
    setDataSearch,
    onClose,
    onTriggerPopover,
    sysSystemInfo,
    cashBankStatus,
    cashStatus,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchChuyenKhoanTien, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        BUSINESS_CODE: props.formBusinessCode,
        ACCOUNT_CODE: values.formAccountCode,
        ACCOUNT_NAME: values.formAccountName,
        FROM_DATE: _.some(arrSel, (o) => o === 'formStartDate')
          ? values.formStartDate
          : null,
        TO_DATE: _.some(arrSel, (o) => o === 'formEndDate')
          ? values.formEndDate
          : null,
        STATUS: values.formStatus,
        BANK_STATUS: values.formBankStatus,
        CHANNEL_CODE: values.formChannel,
        ONLINE_FLAG: values.formType,
        CREATOR_CODE: values.formCreatorCode,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    dispatch(cashManagementListRequest(params));
    setDataSearch && setDataSearch(params);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalCTONL', 'formStatus', ''));
    dispatch(change('formSearchModalCTONL', 'formBankStatus', ''));
    dispatch(change('formSearchModalCTONL', 'formChannel', ''));
    dispatch(change('formSearchModalCTONL', 'formType', ''));
    dispatch(change('formSearchModalCTONL', 'formCreatorCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchChuyenKhoanTien,
              (o) => o?.value === item
            );
            if (!_objItem) return null;

            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formAccountCode' &&
              _objItem.value !== 'formAccountName'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'select') {
              if (_objItem.value === 'formBankStatus')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={cashBankStatus}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formChannel')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={glChannelType}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );
            }
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalCTONL',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalCTONL');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getChannelType = makeGetChannelType();
  const getSystemInfo = makeGetSystemInfo();
  const getCashBankStatus = makeGetCashBankStatus();
  const mapStateToProps = (state, props) => {
    const {
      formBusinessCode,
      formAccountCode,
      formAccountName,
      formStatus,
      formBankStatus,
      formChannel,
      formType,
      formCreatorCode,
      formStartDate,
      formEndDate,
    } = selector(
      state,
      'formBusinessCode',
      'formAccountCode',
      'formAccountName',
      'formStatus',
      'formBankStatus',
      'formChannel',
      'formType',
      'formCreatorCode',
      'formStartDate',
      'formEndDate'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      glChannelType: getChannelType(state),
      sysSystemInfo: getSystemInfo(state),
      cashBankStatus: getCashBankStatus(state),
      formBusinessCode,
      formAccountCode,
      formAccountName,
      formStatus,
      formBankStatus,
      formChannel,
      formType,
      formCreatorCode,
      formStartDate,
      formEndDate,

      initialValues: {
        formBusinessCode: dataSearch?.data?.BUSINESS_CODE,
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formAccountName: dataSearch?.data?.ACCOUNT_NAME,
        formStatus: dataSearch?.data?.STATUS,
        formBankStatus: dataSearch?.data?.BANK_STATUS,
        formChannel: dataSearch?.data?.CHANNEL_CODE,
        formType: dataSearch?.data?.ONLINE_FLAG,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
