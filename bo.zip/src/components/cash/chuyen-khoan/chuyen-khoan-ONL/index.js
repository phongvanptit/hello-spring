import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconSend } from 'assets/img/icon/send.svg';
import DetailCKOnlModal from 'components/modal/cash/chuyen-khoan/online/DetailCKOnlModal';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  cashManagementApproveRequest,
  cashManagementDelRequest, cashManagementSendMessageRequest
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import { makeGetCashManagementList, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import { useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { numberFormat } from 'utils';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './formSearchChuyenKhoanONL';
import PerfectScrollbar from 'react-perfect-scrollbar';

function GroupAction(props) {
  const { record, fnCallback, rightFunc, t } = props;

  function _handleClickItem(fnName) {
    fnCallback[fnName](record?.PK_CASH_MANAGEMENT);
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW === 1 && (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      )}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={t('txt-appr')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onApprove')
              : null
          }
        >
          <IconApprove />
        </a>
      )}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={'Gửi điện'}
          className={!['CHUA_DUYET', 'DANG_XU_LY'].includes(record.C_BANK_STATUS) ? 'disabled' : ''}
          onClick={() =>
            ['CHUA_DUYET', 'DANG_XU_LY'].includes(record.C_BANK_STATUS)
              ? _handleClickItem('onSendMessage')
              : null
          }
        >
          <IconSend />
        </a>
      )}
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onDelete')
              : null
          }
        >
          <IconTrash />
        </a>
      )}
    </GroupButton>
  );
}

function CKNoiBoComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [idDetail, setIdDetail] = useState(null);
  const [checkAll, setCheckAll] = useState(false);

  const dispatch = useDispatch();
  const { cashManagementList, token, t, accRight } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(
        cashManagementList,
        (o) => o.C_STATUS === 'CHUA_DUYET'
      );

      setOrderCheck(_.map(allFunc, 'PK_CASH_MANAGEMENT'));
    }
  }

  function handleApprove(value) {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDel(value) {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashManagementDelRequest(params));
    setOrderCheck([]);
    setCheckAll(false);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleDetail(id) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(id);
  }

  function onClose() {
    setIdDetail(null);
  }

  const handleSendMessage = (value) => {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Gửi điện?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                const params = {
                  user: token?.USER_NAME,
                  session: token?.SESSION_ID,
                  cmd: 'BACK.SEND_MESSAGE_CASH_MANAGEMENT',
                  group: 'LIST',
                  data: {
                    ITEM_ID: value,
                  },
                };

                dispatch(cashManagementSendMessageRequest(params));
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearch
          handleToast={_handleToast}
          page={page}
          recordPerPage={recordPerPage}
        />
        <PerfectScrollbar className="w-100 mt-2">
          <Table bordered>
            <thead>
              <tr>
                <th style={{ width: '26px' }}>
                  <input
                    type={'checkbox'}
                    value={checkAll}
                    onChange={_handleChangeCheckAll}
                    checked={checkAll}
                  />
                </th>

                <th>{t('txt-sender-acc')}</th>
                <th>{t('txt-sender-name')}</th>
                <th>{t('txt-target-acc')}</th>
                <th>{t('txt-target-name')}</th>
                <th>{t('txt-cash-vol')}</th>
                <th>{t('txt-transfer-fee')}</th>
                <th>{t('txt-date-trading')}</th>
                <th>{t('txt-trans-no')}</th>
                <th>{t('txt-content')}</th>
                <th>{t('txt-status')}</th>
                <th>{t('txt-bank-status')}</th>
                <th>{t('txt-bank-response')}</th>
                <th>{t('txt-creator')}</th>
                <th>{t('txt-action')}</th>
              </tr>
            </thead>
            <tbody>
              {cashManagementList &&
                cashManagementList.map((item) => (
                  <tr
                    key={item.PK_CASH_MANAGEMENT}
                    className={
                      _.some(orderCheck, (o) => o === item.PK_CASH_MANAGEMENT)
                        ? 'row-checked'
                        : ''
                    }
                  >
                    <td className="text-center">
                      {item.C_STATUS === 'CHUA_DUYET' && (
                        <input
                          type={'checkbox'}
                          name={item.PK_CASH_MANAGEMENT}
                          onChange={_handleChange}
                          checked={_.some(
                            orderCheck,
                            (o) => o === item.PK_CASH_MANAGEMENT
                          )}
                        />
                      )}
                    </td>

                    <td className="text-center">
                      <a
                        rel="noreferrer noopener"
                        onClick={() => handleDetail(item.PK_CASH_MANAGEMENT)}
                      >
                        {item.C_ACCOUNT_OUT}
                      </a>
                    </td>
                    <td className="">
                      <a
                        rel="noreferrer noopener"
                        onClick={() => handleDetail(item.PK_CASH_MANAGEMENT)}
                      >
                        {item.C_ACCOUNT_OUT_NAME}
                      </a>
                    </td>
                    <td className="text-center">
                      <a
                        rel="noreferrer noopener"
                        onClick={() => handleDetail(item.PK_CASH_MANAGEMENT)}
                      >
                        {item.C_ACCOUNT_IN}
                      </a>
                    </td>
                    <td className="">
                      <a
                        rel="noreferrer noopener"
                        onClick={() => handleDetail(item.PK_CASH_MANAGEMENT)}
                      >
                        {item.C_ACCOUNT_IN_NAME}
                      </a>
                    </td>
                    <td className="text-right">
                      {numberFormat(item.C_CASH_VOLUME)}
                    </td>
                    <td className="text-right">
                      {numberFormat(item.C_FEE_TRANSFER_OUT)}
                    </td>
                    <td className="text-center">{item.C_TRANSACTION_DATE}</td>
                    <td className="text-center">{item.C_TRANSACTION_NO}</td>
                    <td className="">{item.C_CONTENT}</td>
                    <td className={'orderStt_' + item.C_STATUS + ' text-center'}>
                      {item.C_STATUS_NAME}
                    </td>
                    <td className="text-center">{item.C_BANK_STATUS}</td>
                    <td className="">{item.C_BANK_RESPONSE}</td>
                    <td className="text-center">{item.C_CREATOR_CODE}</td>
                    <td className="text-center p-0 w_85">
                      {accRight?.C_VIEW ||
                        accRight?.C_APPROVE ||
                        accRight?.C_UPDATE ? (
                        <GroupAction
                          record={item}
                          rightFunc={accRight}
                          t={t}
                          fnCallback={{
                            onApprove: handleApprove,
                            onDetail: handleDetail,
                            onDelete: handleDel,
                            onSendMessage: handleSendMessage,
                          }}
                        />
                      ) : null}
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </PerfectScrollbar>

        {(!cashManagementList || !cashManagementList.length) && (
          <NodataSearch name={t('txt-ol-transfer')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          {orderCheck && !!orderCheck.length && (
            <div className="mr-auto">
              <Button
                variant="danger"
                className="mr-auto"
                onClick={() => handleDel(orderCheck.join(','))}
                disabled={accRight?.C_UPDATE !== 1}
              >
                {t('bnt-del-entry')}
              </Button>
              <Button
                //variant="danger"
                className="mr-auto"
                onClick={() => handleApprove(orderCheck.join(','))}
                disabled={accRight?.C_APPROVE !== 1}
              >
                {t('bnt-appr-entry')}
              </Button>
            </div>
          )}
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (cashManagementList &&
                !!cashManagementList.length &&
                cashManagementList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailCKOnlModal
            id={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCashManagementList = makeGetCashManagementList();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      cashManagementList: getCashManagementList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(CKNoiBoComponent)
);
