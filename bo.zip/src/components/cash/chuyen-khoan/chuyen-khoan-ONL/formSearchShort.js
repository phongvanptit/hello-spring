import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  cashManagementApproveSuccess,
  cashManagementListRequest, cashManagementSendMessageSuccess
} from 'containers/cash/actions';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';

import { cashManagementDelSuccess } from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetCashManagementApprove,
  makeGetCashManagementDel,
  makeGetCashManagementReject, makeGetCashManagementSendMessage,
  makeGetCashManagementUnApprove,
  makeGetCashTransferUpdate
} from 'lib/selector';

import { makeGetCashStatus } from 'lib/selector';
import {
  FormFlexCenter
} from 'utils/styledComponent';
import { ExportExcel } from 'utils/styledComponent';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { globalExportFileVer2Request } from 'containers/report/actions';


function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    cashTransferUpd,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    cashStatus,

    formAccountCode,
    formStatus,
    formStartDate,
    formEndDate,
  } = props;

  const preTransferUpd = usePrevious(cashTransferUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preCashMngSendMessage = usePrevious(props.cashMngSendMessage);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(cashManagementListRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (cashTransferUpd && !_.isEqual(cashTransferUpd, preTransferUpd)) ||
      (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) ||
      (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) ||
      (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) ||
      (cashManagementDel && !_.isEqual(cashManagementDel, preCashManagementDel)) ||
      (props.cashMngSendMessage && !_.isEqual(props.cashMngSendMessage, preCashMngSendMessage))
    ) {
      dispatch(cashManagementListRequest(dataSearch));
    }
  }, [
    cashTransferUpd,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    props.cashMngSendMessage
  ]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    )
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
    dispatch(cashManagementDelSuccess(null));
  }, [cashManagementDel]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove))
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
    dispatch(cashManagementApproveSuccess(null));
  }, [cashMngApprove]);

  useEffect(() => {
    if (props.cashMngSendMessage && !_.isEqual(props.cashMngSendMessage, preCashMngSendMessage))
      _handleToast(`Gửi điện thành công`, 'success');
    dispatch(cashManagementSendMessageSuccess(null));
  }, [props.cashMngSendMessage]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;
    dispatch(cashManagementListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;

    dispatch(cashManagementListRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'GD_EXPORT_04';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_CASH_MANAGEMENT_GATEWAY";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={cashStatus}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
      <ExportExcel >
        <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortCTONL',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortCTONL');

const makeMapStateToProps = () => {
  const getCashTransferUpdate = makeGetCashTransferUpdate();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
  const getCashStatus = makeGetCashStatus();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStatus, formStartDate, formEndDate } =
      selector(
        state,
        'formAccountCode',
        'formStatus',
        'formStartDate',
        'formEndDate'
      );

    return {
      cashTransferUpd: getCashTransferUpdate(state),
      cashMngApprove: getCashManagementApprove(state),
      cashMngUnApprove: getCashManagementUnApprove(state),
      cashMngReject: getCashManagementReject(state),
      cashManagementDel: getCashManagementDel(state),
      cashMngSendMessage: makeGetCashManagementSendMessage()(state),
      cashStatus: getCashStatus(state),

      formAccountCode,
      formStatus,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
