import { makeGetToken } from 'lib/selector';
import React from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';

import { makeGetSystemInfo } from 'lib/selector';
import { stringToDate } from 'utils';
import FormSearchModal from './formSearchModal';
import FormSearchShort from './formSearchShort';

import {
  cashManagementListRequest,
  cashManagementListSuccess,
} from 'containers/cash/actions';
import {
  ContainerDropdownShow,
  ContainerSearch,
  ContainerSearchDropdown,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const wrapperRef = React.useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);
  const [dataSearch, setDataSearch] = React.useState(null);
  const [triggerPopover, setTriggerPopover] = React.useState(false);

  const { token, page, recordPerPage, sysSystemInfo, t } = props;
  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(cashManagementListSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(cashManagementListRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target) &&
      !triggerPopover
    ) {
      setShowModal(false);
    }
  }

  function initFormSearch() {
    const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
    _date?.setMonth(_date.getMonth() - 1);

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        BUSINESS_CODE: 'CASH_TRANSFER_OUT',
        ACCOUNT_CODE: '',
        ACCOUNT_NAME: '',
        FROM_DATE: '',
        TO_DATE: '',
        STATUS: '',
        BANK_STATUS: '',
        CHANNEL_CODE: '',
        ONLINE_FLAG: 1,
        CREATOR_CODE: '',

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);
  }

  function _handleShow() {
    setShowModal(!showModal);
  }

  function onTriggerPopover(param) {
    setTriggerPopover(param);
  }

  return (
    <ContainerSearch>
      <div
        ref={wrapperRef}
        style={{ position: 'relative' }}
        className="mr-auto"
      >
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              dataSearch={dataSearch}
              setDataSearch={setDataSearch}
              onClose={() => setShowModal(false)}
              onTriggerPopover={onTriggerPopover}
            />
          </ContainerDropdownShow>
        )}
      </div>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
