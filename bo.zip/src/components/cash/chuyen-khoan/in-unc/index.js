import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import {
  typeSingleBankRequest,
  typeSingleBankSuccess,
} from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import { handleApiErrors } from 'lib/api-errors';
import { makeGetToken, makeGetTypeSingleBank } from 'lib/selector';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnSubmit } from 'utils/styledComponent';

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.form`
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 5px 10px;

  input.form-control,
  label {
    font-size: 13px;
  }
`;

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function InUncComponent(props) {
  const dispatch = useDispatch();
  const { token, t, formSendBank, formReceiveBank } = props;
  const { handleSubmit, submitting, typeSingleBank } = props;
  const [singleReceiveBank, setSingleReceiveBank] = React.useState(null);

  useEffect(() => {
    return () => {
      // clear
      dispatch(typeSingleBankSuccess(null));
    };
  }, []);

  useEffect(() => {
    if (formSendBank) {
      if (formSendBank) {
        _handleCheckBankBranch();
      } else dispatch(typeSingleBankSuccess(null));
    }
  }, [formSendBank]);

  useEffect(() => {
    if (formReceiveBank) {
      const params = {
        user: token?.USER_NAME,
        session: token?.SESSION_ID,
        cmd: 'BACK.GET_SINGLE_BRANCH_BANK',
        group: 'LIST',
        data: {
          BRANCH_BANK_ID: formReceiveBank,
        },
      };

          const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


      fetch(appUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
        },
        body: JSON.stringify(params),
      })
        .then(handleApiErrors)
        .then((response) => response.json())
        .then((json) => {
          console.log(json);
          if (json.code === '1') {
            setSingleReceiveBank(json.data[0]);
          } else {
            setSingleReceiveBank(null);
            _handleToast(json.re, 'error');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else setSingleReceiveBank(null);
  }, [formReceiveBank]);

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BRANCH_BANK',
      group: 'LIST',
      data: {
        BRANCH_BANK_ID: formSendBank,
      },
    };

    dispatch(typeSingleBankRequest(params));
  }

  function submit(values) {
    console.log(values);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <>
      <div className="w-100 d-flex justify-content-center">
        <div
          className="w-100 p-0 rounded"
          style={{ maxHeight: 'calc(100vh - 120px)' }}
        >
          <StyleContainer>
            <FormAdd onSubmit={handleSubmit(submit)}>
              <p style={{ gridColumn: '1/6' }} className="color-thm mb-0 fz-13">
                {t('txt-sender-info')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-sender-bank')}</Form.Label>
                <Field
                  name="formSendBank"
                  className="form-control input-order fz-13"
                  component={RenderSuggestBranchBank}
                  index="2"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-payer-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={typeSingleBank?.C_BRANCH_BANK_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-number')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={typeSingleBank?.C_BANK_ACCOUNT_CODE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-at-bank')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={typeSingleBank?.C_BANK_CODE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-province-city')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={typeSingleBank?.C_PROVINCE_NAME || ''}
                  disabled
                />
              </Form.Group>
              <p style={{ gridColumn: '1/6' }} className="color-thm mb-0 fz-13">
                {t('txt-target-info')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-target-bank')}</Form.Label>
                <Field
                  name="formReceiveBank"
                  className="form-control input-order fz-13"
                  component={RenderSuggestBranchBank}
                  index="1"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-receiver-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={singleReceiveBank?.C_BRANCH_BANK_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-number')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={singleReceiveBank?.C_BANK_ACCOUNT_CODE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-bank')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={singleReceiveBank?.C_BANK_CODE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-province-city')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control"
                  value={singleReceiveBank?.C_PROVINCE_NAME || ''}
                  disabled
                />
              </Form.Group>
              <p style={{ gridColumn: '1/6' }} className="color-thm mb-0 fz-13">
                {t('txt-cash-transfer-info')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-cash-vol')}</Form.Label>
                <Field
                  name="formMoney"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/6' }}>
                <Form.Label>{t('txt-content')}</Form.Label>
                <Field
                  name="formContent"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows={2}
                />
              </Form.Group>
              <hr style={{ gridColumn: '1/6' }} />
              <div
                className="d-flex justify-content-center"
                style={{
                  height: '30px',
                  whiteSpace: 'nowrap',
                  gridColumn: '1/6',
                }}
              >
                <div className="d-flex">
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-print')}
                  </BtnSubmit>
                </div>
              </div>
            </FormAdd>
          </StyleContainer>
        </div>
      </div>
    </>
  );
}

InUncComponent = reduxForm({
  form: 'inUncform',
  enableReinitialize: true,
})(InUncComponent);

const selector = formValueSelector('inUncform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getTypeSingleBank = makeGetTypeSingleBank();
  const { formSendBank, formReceiveBank, formMoney, formContent } = selector(
    state,
    'formSendBank',
    'formReceiveBank',
    'formMoney',
    'formContent'
  );
  return {
    token: getToken(state),
    typeSingleBank: getTypeSingleBank(state),
    formSendBank,
    formReceiveBank,
    formMoney,
    formContent,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(InUncComponent)
);
