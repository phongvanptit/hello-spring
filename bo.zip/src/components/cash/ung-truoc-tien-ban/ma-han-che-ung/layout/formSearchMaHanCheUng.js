import { cashMHCUListSuccess } from 'containers/cash/actions';
import { makeGetToken } from 'lib/selector';
import React from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';

import { cashMHCUListRequest } from 'containers/cash/actions';
import {
  ContainerSearch
} from 'utils/styledComponent';
import FormSearchShort from './formSearchShort';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const wrapperRef = React.useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);
  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage, t } = props;
  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(cashMHCUListSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(cashMHCUListRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function initFormSearch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ADVANCE_SHARE_LIMIT',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: '',
        SHARE_CODE: '',
        STATUS: '',
        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    setDataSearch(params);
  }

  function _handleShow() {
    setShowModal(!showModal);
  }

  return (
    <ContainerSearch>
      {/* <div
        ref={wrapperRef}
        style={{ position: 'relative' }}
        className="mr-auto"
      >
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              dataSearch={dataSearch}
              setDataSearch={setDataSearch}
              onClose={() => setShowModal(false)}
            />
          </ContainerDropdownShow>
        )}
      </div> */}
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
