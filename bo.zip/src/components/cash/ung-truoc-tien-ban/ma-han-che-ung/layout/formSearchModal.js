import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { cashMHCUListRequest } from 'containers/cash/actions';
import { makeGetPublicStt, makeGetToken } from 'lib/selector';
import { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    token,
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    setDataSearch,
    onClose,
    reset,
    glPublicStt,
  } = props;

  const submit = (values) => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ADVANCE_SHARE_LIMIT',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: values.formCustomerCode,
        SHARE_CODE: values.formShareCode,
        STATUS: values.formStatus,
        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    dispatch(cashMHCUListRequest(params));
    setDataSearch && setDataSearch(params);
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalHanCheUng', 'formShareCode', ''));
    dispatch(change('formSearchModalHanCheUng', 'formStatus', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-share-code')}</Form.Label>
          <Field
            name="formShareCode"
            className="form-control"
            placeholder={t('txt-share-code')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
          <Field
            name="formStatus"
            className="form-control w-100"
            component={RenderNormalSelect}
            opts={glPublicStt}
            placeholder="-- Tất cả --"
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalHanCheUng',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalHanCheUng');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getPublicStt = makeGetPublicStt();
  const mapStateToProps = (state, props) => {
    const { formCustomerCode, formShareCode, formStatus } = selector(
      state,
      'formCustomerCode',
      'formShareCode',
      'formStatus'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      glPublicStt: getPublicStt(state),
      formCustomerCode,
      formShareCode,
      formStatus,
      initialValues: {
        formCustomerCode: dataSearch?.data?.CUSTOMER_CODE,
        formShareCode: dataSearch?.data?.SHARE_CODE,
        formStatus: dataSearch?.data?.STATUS,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
