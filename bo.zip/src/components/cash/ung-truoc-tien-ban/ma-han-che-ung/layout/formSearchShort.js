import RenderSearchShort from 'components/input/inputSearchShort';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';

import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { cashMHCUListRequest } from 'containers/cash/actions';
import {
  makeGetCashMHCUApprove,
  makeGetCashMHCUDel,
  makeGetCashMHCUUpdate,
} from 'lib/selector';

import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { cashMHCUApproveSuccess, cashMHCUDelSuccess } from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import { makeGetPublicStt } from 'lib/selector';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    t,
    handleSubmit,
    submitting,

    dataSearch,
    setDataSearch,
    cashDelHMU,
    cashUpdateHMU,
    cashApproveHMU,
    glPublicStt,

    formCustomerCode,
    formShareCode,
    formStatus,
  } = props;

  const preCashDelHMU = usePrevious(cashDelHMU);
  const preCashUpdateHMU = usePrevious(cashUpdateHMU);
  const preCashApproveHMU = usePrevious(cashApproveHMU);

  useEffect(() => {
    setTimeout(() => {
      dispatch(cashMHCUListRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (cashDelHMU && !_.isEqual(cashDelHMU, preCashDelHMU)) ||
      (cashApproveHMU && !_.isEqual(cashApproveHMU, preCashApproveHMU)) ||
      (cashUpdateHMU && !_.isEqual(cashUpdateHMU, preCashUpdateHMU))
    ) {
      dispatch(cashMHCUListRequest(dataSearch));
    }
  }, [cashDelHMU, cashApproveHMU, cashUpdateHMU]);

  useEffect(() => {
    if (cashDelHMU && !_.isEqual(cashDelHMU, preCashDelHMU))
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
    dispatch(cashMHCUDelSuccess(null));
  }, [cashDelHMU]);

  useEffect(() => {
    if (cashApproveHMU && !_.isEqual(cashApproveHMU, preCashApproveHMU))
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
    dispatch(cashMHCUApproveSuccess(null));
  }, [cashApproveHMU]);

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.CUSTOMER_CODE = values.formCustomerCode || '';
    _params.data.SHARE_CODE = values.formShareCode;
    _params.data.STATUS = values.formStatus;
    dispatch(cashMHCUListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.CUSTOMER_CODE = formCustomerCode || '';
    _params.data.SHARE_CODE = formShareCode;
    _params.data.STATUS = formStatus;
    dispatch(cashMHCUListRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-share-code')}</Form.Label>
        <Field
          name="formShareCode"
          className="form-control w_120 mx-2"
          placeholder={t('txt-share-code')}
          component={RenderInput}
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_120 mx-2"
          component={RenderNormalSelect}
          opts={glPublicStt}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
      </div>
      <Form.Group>
        <Field
          name="formCustomerCode"
          className="form-control"
          placeholder={t('txt-search')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortHanCheUng',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortHanCheUng');

const makeMapStateToProps = () => {
  const getCashUpdateHMU = makeGetCashMHCUUpdate();
  const getCashDelHMU = makeGetCashMHCUDel();
  const getCashApproveHMU = makeGetCashMHCUApprove();
  const getPublicStt = makeGetPublicStt();
  const mapStateToProps = (state) => {
    const { formCustomerCode, formShareCode, formStatus } = selector(
      state,
      'formCustomerCode',
      'formShareCode',
      'formStatus'
    );

    return {
      cashDelHMU: getCashDelHMU(state),
      cashUpdateHMU: getCashUpdateHMU(state),
      cashApproveHMU: getCashApproveHMU(state),
      glPublicStt: getPublicStt(state),
      formCustomerCode,
      formShareCode,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
