import { useState } from 'react';
import FormSearch from './layout/formSearchMaHanCheUng';

import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailHanCheUngModal from 'components/modal/cash/uttb/han-che-ung-theo-ma/DetailHanCheUngModal';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  cashMHCUApproveRequest,
  cashMHCUDelRequest,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import { makeGetCashMHCUList, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';

function GroupAction(props) {
  const { record, fnCallback, rightFunc, t } = props;

  function _handleClickItem(fnName) {
    fnCallback &&
      fnCallback[fnName] &&
      fnCallback[fnName](
        fnName === 'onDetail' ? record : record?.PK_ADVANCE_SHARE_LIMIT
      );
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW === 1 && (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      )}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={t('txt-appr')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onApprove')
              : null
          }
        >
          <IconApprove />
        </a>
      )}
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onDelete')
              : null
          }
        >
          <IconTrash />
        </a>
      )}
    </GroupButton>
  );
}

function HanCheUngComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [idDetail, setIdDetail] = useState(null);
  const [checkAll, setCheckAll] = useState(false);

  const dispatch = useDispatch();
  const { cashMHCUList, token, t, accRight } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(
        cashMHCUList,
        (o) => o.C_STATUS === 'CHUA_DUYET'
      );

      setOrderCheck(_.map(allFunc, 'PK_ADVANCE_SHARE_LIMIT'));
    }
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleDetail(id) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(id);
  }

  function onClose() {
    setIdDetail(null);
  }

  function handleApprove(value) {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDel(item) {
    if (!item) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(item);
                onClose();
              }}
            >
              Tiếp tục
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ADV_SHARE_LIMIT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashMHCUApproveRequest(params));
  }

  function handleActionDel(item) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ADV_SHARE_LIMIT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: item,
      },
    };

    dispatch(cashMHCUDelRequest(params));
    setOrderCheck([]);
    setCheckAll(false);
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearch
          handleToast={_handleToast}
          page={page}
          recordPerPage={recordPerPage}
        />
        <Table bordered>
          <thead>
            <tr>
              <th style={{ width: '26px' }}>
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              </th>
              <th>{t('txt-share-code')}</th>
              <th>{t('txt-cust')}</th>
              <th>{t('txt-from-date')}</th>
              <th>{t('txt-to-date')}</th>
              <th>{t('txt-note')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {cashMHCUList &&
              cashMHCUList.map((item, index) => (
                <tr key={index}>
                  <td className="text-center">
                    {item.C_STATUS === 'CHUA_DUYET' && (
                      <input
                        type={'checkbox'}
                        name={item.PK_ADVANCE_SHARE_LIMIT}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_ADVANCE_SHARE_LIMIT
                        )}
                      />
                    )}
                  </td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item)}
                    >
                      {item.C_SHARE_CODE}
                    </a>
                  </td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item)}
                    >
                      {item.C_CUSTOMER_CODE}
                    </a>
                  </td>
                  <td className="text-center">{item.C_FROM_DATE}</td>
                  <td className="text-center">{item.C_TO_DATE}</td>
                  <td className="">{item.C_CONTENT}</td>
                  <td className="text-center">{item.C_STATUS}</td>
                  <td className="text-center p-0 w_85">
                    {accRight?.C_VIEW ||
                      accRight?.C_APPROVE ||
                      accRight?.C_UPDATE ? (
                      <GroupAction
                        record={item}
                        rightFunc={accRight}
                        t={t}
                        fnCallback={{
                          onApprove: handleApprove,
                          onDetail: handleDetail,
                          onDelete: handleDel,
                        }}
                      />
                    ) : null}
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!cashMHCUList || !cashMHCUList.length) && (
          <NodataSearch name={t('txt-advance-limit-code-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          {orderCheck && !!orderCheck.length && (
            <Button
              variant="danger"
              className="mr-auto"
              onClick={() => handleDel(orderCheck.join(','))}
              disabled={accRight?.C_UPDATE !== 1}
            >
              {t('bnt-del-entry')}
            </Button>
          )}
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (cashMHCUList &&
                !!cashMHCUList.length &&
                cashMHCUList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailHanCheUngModal
            record={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCashMHCUList = makeGetCashMHCUList();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      cashMHCUList: getCashMHCUList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(HanCheUngComponent)
);
