import { useState } from 'react';
import FormSearch from './layout/formSearchHoSoUng';

import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailUngTruocModal from 'components/modal/cash/uttb/ung-truoc/DetailUngTruocModal';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  cashHSUApproveRequest,
  cashHSUDelRequest,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import { makeGetCashHSUList, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { numberFormat } from 'utils';
import { GroupButton } from 'utils/styledComponent';

function GroupAction(props) {
  const { record, fnCallback, rightFunc, t } = props;

  function _handleClickItem(fnName) {
    fnCallback &&
      fnCallback[fnName] &&
      fnCallback[fnName](
        fnName === 'onDetail' ? record : record?.PK_ADVANCE_WITHDRAW
      );
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW === 1 && (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      )}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={t('txt-appr')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onApprove')
              : null
          }
        >
          <IconApprove />
        </a>
      )}
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onDelete')
              : null
          }
        >
          <IconTrash />
        </a>
      )}
    </GroupButton>
  );
}

function UngTruocComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [idDetail, setIdDetail] = useState(null);
  const [checkAll, setCheckAll] = useState(false);

  const dispatch = useDispatch();
  const { cashMHCUList, token, t, accRight, statusCode } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(
        cashMHCUList,
        (o) => o.C_STATUS === 'CHUA_DUYET'
      );

      setOrderCheck(_.map(allFunc, 'PK_ADVANCE_WITHDRAW'));
    }
  }

  function handleApprove(value) {
    if (!value) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDel(item) {
    if (!item) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(item);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ADVANCE_WITHDRAW',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashHSUApproveRequest(params));
  }

  function handleActionDel(item) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ADVANCE_WITHDRAW',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: item,
      },
    };

    dispatch(cashHSUDelRequest(params));
    setOrderCheck([]);
    setCheckAll(false);
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleDetail(id) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(id);
  }

  function onClose() {
    setIdDetail(null);
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearch
          handleToast={_handleToast}
          page={page}
          recordPerPage={recordPerPage}
          statusCode={statusCode}
        />
        <Table bordered>
          <thead>
            <tr>
              <th style={{ width: '26px' }}>
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              </th>
              <th>{t('txt-branch')}</th>
              <th>{t('txt-acc')}</th>
              <th>{t('txt-acc-name')}</th>
              <th>{t('txt-pay-date')}</th>
              <th>{t('txt-due-date')}</th>
              <th>{t('txt-advance-cash')}</th>
              <th>{t('txt-advance-fee')}</th>
              <th>{t('txt-channel')}</th>
              <th>{t('txt-status')}</th>
              {/* <th>{t('txt-ksrr-status')}</th> */}
              <th>{t('txt-creator')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {cashMHCUList &&
              cashMHCUList.map((item, index) => (
                <tr key={index}>
                  <td className="text-center">
                    {item.C_STATUS === 'CHUA_DUYET' && (
                      <input
                        type={'checkbox'}
                        name={item.PK_ADVANCE_WITHDRAW}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_ADVANCE_WITHDRAW
                        )}
                      />
                    )}
                  </td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item)}
                    >
                      {`${item.C_BRANCH_CODE} - ${item.C_BRANCH_NAME}`}
                    </a>
                  </td>

                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item)}
                    >
                      {item.C_ACCOUNT_CODE}
                    </a>
                  </td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetail(item)}
                    >
                      {item.C_ACCOUNT_NAME}
                    </a>
                  </td>
                  <td className="text-center">{item.C_WITHDRAW_DATE}</td>
                  <td className="text-center">{item.C_DUE_DATE}</td>
                  <td className="text-right">
                    {numberFormat(item.C_CASH_VALUE, 0, '0')}
                  </td>
                  <td className="text-right">
                    {numberFormat(item.C_FEE_VALUE, 0, '0')}
                  </td>
                  <td className="text-center">{item.C_CHANNEL_NAME}</td>
                  <td className="text-center">{item.C_STATUS_NAME}</td>
                  {/* <td className="text-center">{item.C_RISK_STATUS_NAME}</td> */}
                  <td className="text-center">{item.C_CREATOR_CODE}</td>
                  <td className="text-center p-0 w_85">
                    {accRight?.C_VIEW ||
                    accRight?.C_APPROVE ||
                    accRight?.C_UPDATE ? (
                      <GroupAction
                        record={item}
                        rightFunc={accRight}
                        t={t}
                        fnCallback={{
                          onApprove: handleApprove,
                          onDetail: handleDetail,
                          onDelete: handleDel,
                        }}
                      />
                    ) : null}
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!cashMHCUList || !cashMHCUList.length) && (
          <NodataSearch name={t('txt-advance-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          {orderCheck && !!orderCheck.length && (
            <Button
              variant="danger"
              className="mr-auto"
              onClick={() => handleDel(orderCheck.join(','))}
              disabled={accRight?.C_UPDATE !== 1}
            >
              {t('bnt-del-entry')}
            </Button>
          )}
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (cashMHCUList &&
                !!cashMHCUList.length &&
                cashMHCUList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailUngTruocModal
            record={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCashMHCUList = makeGetCashHSUList();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      cashMHCUList: getCashMHCUList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(UngTruocComponent)
);
