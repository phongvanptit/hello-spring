import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { cashHSUListRequest } from 'containers/cash/actions';
import {
  makeGetAllBranch,
  makeGetChannelType,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    token,
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    setDataSearch,
    onClose,
    onTriggerPopover,
    sysSystemInfo,
    glAllBranch,
  } = props;

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ADVANCE_WITHDRAW',
      group: 'LIST',
      data: {
        ACCOUNT_BRANCH_CODE: values.formBranchCode,
        ACCOUNT_SUB_BRANCH_CODE: '',
        FROM_DATE: values.formFromDate,
        TO_DATE: values.formToDate,
        BANK_CODE: '',
        CHANNEL_CODE: '',
        RISK_STATUS: values?.formRiskStatus,
        CREATOR_CODE: values.formCreateCode,
        STATUS: values.formStatus,
        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    dispatch(cashHSUListRequest(params));
    setDataSearch && setDataSearch(params);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalUngTruoc', 'formBranchCode', ''));
    dispatch(change('formSearchModalUngTruoc', 'formCreateCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-branch')}</Form.Label>
          <Field
            name="formBranchCode"
            className="form-control input-order fz-13"
            component={RenderNormalSelect}
            opts={glAllBranch}
            index={2}
            placeholder="-- Tất cả --"
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-creator')}</Form.Label>
          <Field
            name="formCreateCode"
            className="form-control"
            placeholder={'Nhập người lập'}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalUngTruoc',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalUngTruoc');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getChannelType = makeGetChannelType();
  const getSystemInfo = makeGetSystemInfo();
  const getAllBranch = makeGetAllBranch();
  const mapStateToProps = (state, props) => {
    const {
      formBranchCode,
      formCreateCode,
      formFromDate,
      formToDate,
      formStatus,
      formRiskStatus,
    } = selector(
      state,
      'formBranchCode',
      'formCreateCode',
      'formFromDate',
      'formToDate',
      'formStatus',
      'formRiskStatus'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      glChannelType: getChannelType(state),
      sysSystemInfo: getSystemInfo(state),
      glAllBranch: getAllBranch(state),
      formBranchCode,
      formCreateCode,
      formFromDate,
      formToDate,
      formStatus,
      formRiskStatus,
      initialValues: {
        formBranchCode: dataSearch?.data?.ACCOUNT_BRANCH_CODE,
        formCreateCode: dataSearch?.data?.CREATOR_CODE,
        formFromDate: dataSearch?.data?.FROM_DATE,
        formToDate: dataSearch?.data?.TO_DATE,
        formStatus: dataSearch?.data?.STATUS,
        formRiskStatus: dataSearch?.data?.RISK_STATUS,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
