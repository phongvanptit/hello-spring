import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { cashHSUListRequest } from 'containers/cash/actions';
import {
  makeGetCashHSUApprove,
  makeGetCashHSUDel,
  makeGetCashHSUURiskReject,
  makeGetCashHSUURiskUpdStt,
  makeGetCashHSUUpdate,
} from 'lib/selector';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { change } from 'redux-form';
import {
  cashHSUApproveSuccess,
  cashHSUDelSuccess,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import { makeGetAdvRiskStatus, makeGetCashStatus } from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    cashDelHMU,
    cashUpdateHMU,
    cashApproveHMU,
    riskUpdStt,
    riskReject,
    glAdvRiskStt,
    cashStatus,

    formCustomerCode,
    formRiskStatus,
    formStatus,
    formFromDate,
    formToDate,
    statusCode,
  } = props;

  const preCashDelHMU = usePrevious(cashDelHMU);
  const preCashUpdateHMU = usePrevious(cashUpdateHMU);
  const preCashApproveHMU = usePrevious(cashApproveHMU);
  const preRiskUpdStt = usePrevious(riskUpdStt);
  const preRiskReject = usePrevious(riskReject);
  const preStartDate = usePrevious(formFromDate);
  const preEndDate = usePrevious(formToDate);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(cashHSUListRequest(dataSearch));
    }, 200);
  }, []);

  function initForm() {
    if (statusCode) {
      dispatch(change('formSearchShortUngTruoc', 'formStatus', statusCode));
      
    }
  }

  useEffect(() => {
    if (
      (cashApproveHMU && !_.isEqual(cashApproveHMU, preCashApproveHMU)) ||
      (cashUpdateHMU && !_.isEqual(cashUpdateHMU, preCashUpdateHMU)) ||
      (cashDelHMU && !_.isEqual(cashDelHMU, preCashDelHMU)) ||
      (riskUpdStt && !_.isEqual(riskUpdStt, preRiskUpdStt)) ||
      (riskReject && !_.isEqual(riskReject, preRiskReject))
    ) {
      dispatch(cashHSUListRequest(dataSearch));
    }
  }, [cashApproveHMU, cashUpdateHMU, cashDelHMU, riskUpdStt, riskReject]);

  useEffect(() => {
    if (cashDelHMU && !_.isEqual(cashDelHMU, preCashDelHMU))
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
    dispatch(cashHSUDelSuccess(null));
  }, [cashDelHMU]);

  useEffect(() => {
    if (cashApproveHMU && !_.isEqual(cashApproveHMU, preCashApproveHMU))
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
    dispatch(cashHSUApproveSuccess(null));
  }, [cashApproveHMU]);

  useEffect(() => {
    if (formFromDate && !_.isEqual(formFromDate, preStartDate)) {
      if (!formFromDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formFromDate]);

  useEffect(() => {
    if (formToDate && !_.isEqual(formToDate, preEndDate)) {
      if (!formToDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formToDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    //_params.data.RISK_STATUS = values.formCustomerCode;
    _params.data.STATUS = values.formStatus;
    _params.data.ACCOUNT_CODE = values.formCustomerCode;
    _params.data.FROM_DATE = values.formFromDate;
    _params.data.TO_DATE = values.formToDate;

    dispatch(cashHSUListRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    //_params.data.RISK_STATUS = formCustomerCode;
    _params.data.STATUS = formStatus;
    _params.data.ACCOUNT_CODE = formCustomerCode;
    _params.data.FROM_DATE = formFromDate;
    _params.data.TO_DATE = formToDate;

    dispatch(cashHSUListRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={cashStatus}
          placeholder="-- Tất cả --"
        />
        {/* <Form.Label className="fz-13 w-fix">{t('txt-ksrr-status')}</Form.Label>
        <Field
          name="formRiskStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glAdvRiskStt}
          placeholder="-- Tất cả --"
        /> */}
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formFromDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formToDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Form.Group>
        <Field
          name="formCustomerCode"
          className="form-control"
          placeholder={t('txt-search')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortUngTruoc',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortUngTruoc');

const makeMapStateToProps = () => {
  const getCashHSUUpdate = makeGetCashHSUUpdate();
  const getCashDelHMU = makeGetCashHSUDel();
  const getCashApproveHMU = makeGetCashHSUApprove();
  const getCashHSUURiskUpdStt = makeGetCashHSUURiskUpdStt();
  const getCashHSUURiskReject = makeGetCashHSUURiskReject();
  const getAdvRiskStatus = makeGetAdvRiskStatus();
  const getCashStatus = makeGetCashStatus();
  const mapStateToProps = (state) => {
    const {
      formCustomerCode,
      formRiskStatus,
      formStatus,
      formFromDate,
      formToDate,
    } = selector(
      state,
      'formCustomerCode',
      'formRiskStatus',
      'formStatus',
      'formFromDate',
      'formToDate'
    );

    return {
      cashDelHMU: getCashDelHMU(state),
      cashUpdateHMU: getCashHSUUpdate(state),
      cashApproveHMU: getCashApproveHMU(state),
      riskUpdStt: getCashHSUURiskUpdStt(state),
      riskReject: getCashHSUURiskReject(state),
      glAdvRiskStt: getAdvRiskStatus(state),
      cashStatus: getCashStatus(state),

      formCustomerCode,
      formRiskStatus,
      formStatus,
      formFromDate,
      formToDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
