import TabHanCheUng from 'components/cash/ung-truoc-tien-ban/ma-han-che-ung';
import TabUngTruoc from 'components/cash/ung-truoc-tien-ban/ung-truoc';
import { translate } from 'react-i18next';

import { useDispatch } from 'react-redux';
function IndividualComponent(props) {
  const { subType, accRight, statusCode } = props;
  const dispatch = useDispatch();
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'ung-truoc' && <TabUngTruoc accRight={accRight} statusCode={statusCode}/>}
        {subType === 'han-che-ung' && <TabHanCheUng accRight={accRight} />}
      </div>
    </>
  );
}

export default translate('translations')(IndividualComponent);
