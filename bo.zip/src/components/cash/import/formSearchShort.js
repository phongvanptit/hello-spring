import RenderSearchShort from 'components/input/inputSearchShort';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderSelect';
import { typeBankSearchRequest } from 'containers/category/actions';
import {
  impUpdateSuccess,
  ipmApproveSuccess,
  ipmDeleteSuccess,
  ipmUnApproveSuccess,
} from 'containers/import/actions';
import {
  makeGetGLImportType,
  makeGetGlobalCashBusinessDetail,
  makeGetIpmApprove,
  makeGetIpmDelete,
  makeGetIpmUnApprove,
  makeGetIpmUpdate,
  makeGetTypeBizList,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,

    typeBizList,
    ipmDel,
    ipmAppr,
    ipmUnAppr,
    ipmUpd,
  } = props;

  const preDelIpm = usePrevious(ipmDel);
  const preApprIpm = usePrevious(ipmAppr);
  const preUnApprIpm = usePrevious(ipmUnAppr);
  const preUpdIpm = usePrevious(ipmUpd);

  useEffect(() => {
    setTimeout(() => {
      _handleBlur();
    }, 200);
  }, []);

  useEffect(() => {
    if (ipmDel && !_.isEqual(ipmDel, preDelIpm)) {
      dispatch(ipmDeleteSuccess(null));
      _handleBlur();
    }
  }, [ipmDel]);

  useEffect(() => {
    if (ipmAppr && !_.isEqual(ipmAppr, preApprIpm)) {
      dispatch(ipmApproveSuccess(null));
      _handleBlur();
    }
  }, [ipmAppr]);

  useEffect(() => {
    if (ipmUpd && !_.isEqual(ipmUpd, preUpdIpm)) {
      dispatch(impUpdateSuccess(null));
      _handleBlur();
    }
  }, [ipmUpd]);

  useEffect(() => {
    if (ipmUnAppr && !_.isEqual(ipmUnAppr, preUnApprIpm)) {
      dispatch(ipmUnApproveSuccess(null));
      _handleBlur();
    }
  }, [ipmUnAppr]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.BUSINESS_CODE = values?.formBizCode;
    _params.data.SHARE_CODE = values?.formShareCode;

    dispatch(typeBankSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.BUSINESS_CODE = props?.formBizCode;
    _params.data.SHARE_CODE = props?.formShareCode;

    dispatch(typeBankSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }
  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="w-fix">{t('txt-bus')}</Form.Label>
        <Field
          name="formBizCode"
          type="text"
          className="form-control mx-2 w_200"
          component={RenderNormalSelect}
          opts={typeBizList}
          onBlur={_handleBlur}
        />
      </div>
      <Form.Group>
        <Field
          name="formShareCode"
          className="form-control"
          placeholder={t('txt-share-code')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch> */}
      {/* <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortImportCash',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortImportCash');

const makeMapStateToProps = () => {
  const getGLImportType = makeGetGLImportType();
  const getTypeBizList = makeGetTypeBizList();
  const getGlCashBizDetail = makeGetGlobalCashBusinessDetail();
  const getIpmDelete = makeGetIpmDelete();
  const getIpmArrove = makeGetIpmApprove();
  const getIpmUnApprove = makeGetIpmUnApprove();
  const getIpmUpdate = makeGetIpmUpdate();

  const mapStateToProps = (state) => {
    const { formImportType, formBizCode, formBizDetail, formShareCode } =
      selector(
        state,
        'formImportType',
        'formBizCode',
        'formBizDetail',
        'formShareCode'
      );

    return {
      glImportType: getGLImportType(state),
      typeBizList: getTypeBizList(state),
      glCashBizDetail: getGlCashBizDetail(state),
      ipmDel: getIpmDelete(state),
      ipmAppr: getIpmArrove(state),
      ipmUnAppr: getIpmUnApprove(state),
      ipmUpd: getIpmUpdate(state),

      formImportType,
      formBizCode,
      formBizDetail,
      formShareCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
