import RenderSearchShort from 'components/input/inputSearchShort';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import RenderInput from 'components/input/renderInput';
import {
  typeBankSearchRequest,
  typeDelBankSuccess,
} from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import {
  ipmDeleteSuccess,
  ipmApproveSuccess,
  ipmUnApproveSuccess,
  impUpdateSuccess,
} from 'containers/import/actions';
import {
  makeGetGLImportType,
  makeGetGlobalCashBusinessDetail,
  makeGetTypeBizList,
  makeGetTypeDelBank,
  makeGetIpmDelete,
  makeGetIpmApprove,
  makeGetIpmUnApprove,
  makeGetIpmUpdate,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';
import RenderNormalSelect from 'components/input/renderSelect';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,

    typeBizList,
    glImportType,
    glCashBizDetail,
    typeDelBank,
    ipmDel,
    ipmAppr,
    ipmUnAppr,
    ipmUpd,
  } = props;

  const preDelIpm = usePrevious(ipmDel);
  const preApprIpm = usePrevious(ipmAppr);
  const preUnApprIpm = usePrevious(ipmUnAppr);
  const preUpdIpm = usePrevious(ipmUpd);

  useEffect(() => {
    setTimeout(() => {
      _handleBlur();
    }, 200);
  }, []);

  // useEffect(() => {
  //   if (ipmDel && !_.isEqual(ipmDel, preDelIpm)) {
  //     dispatch(ipmDeleteSuccess(null));
  //     _handleBlur();
  //   }
  // }, [ipmDel]);

  useEffect(() => {
    if (
      ipmDel &&
      !_.isEqual(ipmDel, preDelIpm)
    )
      _handleToast('Xóa bút toán thành công', 'success');
    dispatch(ipmDeleteSuccess(null));
    _handleBlur();
  }, [ipmDel]);

  useEffect(() => {
    if (ipmAppr && !_.isEqual(ipmAppr, preApprIpm)) {
      dispatch(ipmApproveSuccess(null));
      _handleBlur();
    }
  }, [ipmAppr]);

  useEffect(() => {
    if (ipmUpd && !_.isEqual(ipmUpd, preUpdIpm)) {
      dispatch(impUpdateSuccess(null));
      _handleBlur();
    }
  }, [ipmUpd]);

  useEffect(() => {
    if (ipmUnAppr && !_.isEqual(ipmUnAppr, preUnApprIpm)) {
      dispatch(ipmUnApproveSuccess(null));
      _handleBlur();
    }
  }, [ipmUnAppr]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    // formImportType, formBizCode, formBizDetail, formShareCode
    let _params = Object.assign({}, dataSearch);
    //_params.data.IMPORT_TYPE = values?.formImportType;
    //_params.data.BUSINESS_CODE = values?.formBizCode;
    _params.data.SHARE_CODE = values?.formShareCode;
    // _params.data.BANK_ACCOUNT_CODE = values?.formAccountCode;

    dispatch(typeBankSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    //_params.data.IMPORT_TYPE = props?.formImportType;
    //_params.data.BUSINESS_CODE = props?.formBizCode;
    _params.data.SHARE_CODE = props?.formShareCode;

    dispatch(typeBankSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }
  // formImportType, formBizCode, formBizDetail, formShareCode
  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        {/* <Form.Label className="w-fix">Loại Import</Form.Label>
        <Field
          name="formImportType"
          type="text"
          className="form-control mx-2 w_100"
          component={RenderNormalSelect}
          opts={glImportType}
        /> */}
        {/* <Form.Label className="w-fix">Nghiệp vụ</Form.Label>
        <Field
          name="formBizCode"
          type="text"
          className="form-control mx-2 w_200"
          component={RenderNormalSelect}
          opts={typeBizList}
        /> */}
        {/* <Form.Label className="w-fix">NV chi tiết</Form.Label>
        <Field
          name="formBizDetail"
          type="text"
          className="form-control mx-2 w_200"
          component={RenderNormalSelect}
          opts={glCashBizDetail}
        /> */}
        <Form.Label className="w-fix">Mã CK</Form.Label>
        <Field
          name="formShareCode"
          type="text"
          className="form-control mx-2 w_100"
          placeholder="Mã CK"
          component={RenderInput}
          onBlur={_handleBlur}
        />
      </div>
      <Form.Group>
        <Field
          name="formCode"
          className="form-control"
          placeholder={t('txt-total-acc-code')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch> */}
      {/* <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortTKTong',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortTKTong');

const makeMapStateToProps = () => {
  const getGLImportType = makeGetGLImportType();
  const getTypeBizList = makeGetTypeBizList();
  const getGlCashBizDetail = makeGetGlobalCashBusinessDetail();
  const getIpmDelete = makeGetIpmDelete();
  const getIpmArrove = makeGetIpmApprove();
  const getIpmUnApprove = makeGetIpmUnApprove();
  const getIpmUpdate = makeGetIpmUpdate();

  const mapStateToProps = (state) => {
    const { formImportType, formBizCode, formBizDetail, formShareCode } =
      selector(
        state,
        'formImportType',
        'formBizCode',
        'formBizDetail',
        'formShareCode'
      );

    return {
      glImportType: getGLImportType(state),
      typeBizList: getTypeBizList(state),
      glCashBizDetail: getGlCashBizDetail(state),
      ipmDel: getIpmDelete(state),
      ipmAppr: getIpmArrove(state),
      ipmUnAppr: getIpmUnApprove(state),
      ipmUpd: getIpmUpdate(state),

      formImportType,
      formBizCode,
      formBizDetail,
      formShareCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
