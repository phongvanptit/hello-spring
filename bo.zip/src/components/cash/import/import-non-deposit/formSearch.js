import { typeBankSearchRequest } from 'containers/category/actions';
import { makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { ContainerSearch } from 'utils/styledComponent';
import FormSearchShort from './formSearchShort';
import { typeBankSearchSuccess } from 'containers/category/actions';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();

  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage, t } = props;
  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(typeBankSearchSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(typeBankSearchRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  function initFormSearch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_IMPORT_INFO',
      group: 'LIST',
      data: {
        IMPORT_TYPE: 'NON_DEPOSIT',
        BUSINESS_CODE: 'CASH_DEPOSIT',
        BIZ_DETAIL_CODE: '',
        SHARE_CODE: '',
        STATUS: '',
        FROM_DATE: '',
        TO_DATE: '',

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    dispatch(typeBankSearchRequest(params));
    setDataSearch(params);
  }

  return (
    <ContainerSearch>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
