import TabImportCash from 'components/cash/import/import-cash';
import TabImportNonDeposit from 'components/cash/import/import-non-deposit';
import { translate } from 'react-i18next';

import { useDispatch } from 'react-redux';
function ImportComponent(props) {
  const { subType, accRight } = props;
  const dispatch = useDispatch();
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'import-cash' && <TabImportCash accRight={accRight} />}
        {subType === 'import-non-deposit' && <TabImportNonDeposit accRight={accRight} />}
      </div>
    </>
  );
}

export default translate('translations')(ImportComponent);


