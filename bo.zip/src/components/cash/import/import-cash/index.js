/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { memo, useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { setToast } from 'containers/client/actions';
import { makeGetToken, makeGetTypeListBankSearch } from 'lib/selector';
import * as _ from 'lodash';
import { Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import FormSearch from './formSearch';
import DetailImportDataModal from 'components/modal/cash/import/import-cash/detail';
import Paging from 'components/paging';
import {
  typeBusinessSearchRequest,
  typeBusinessSearchSuccess,
} from 'containers/category/actions';
import { ipmDeleteRequest,ipmApproveRequest } from 'containers/import/actions';
import { confirmAlert } from 'react-confirm-alert';
import { GroupButton } from 'utils/styledComponent';

function BranchBankComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [isOpenDetail, setIsOpenDetail] = useState(false);
  const [isID, setIsID] = useState(null);

  const { typeListBank, token, t, accRight } = props;
  const dispatch = useDispatch();

  React.useEffect(() => {
    getAllBiz();

    return () => {
      dispatch(typeBusinessSearchSuccess(null));
    };
  }, []);

  function _onClose() {
    setIsOpenDetail(false);
  }

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChangeDetail(id) {
    setIsOpenDetail(true);
    setIsID(id);
  }

  function getAllBiz() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BUSINESS',
      group: 'LIST',
      data: {
        BUSINESS_TRANSACTION_CODE: '',
        BUSINESS_TRANSACTION_NAME: '',
        TYPE: '',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };
    dispatch(typeBusinessSearchRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleConfirm(actionName, record) {
    if (record.C_STATUS === 'DA_DUYET' && actionName === 'approve') return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'close'
                ? t('txt-del-service')
                : actionName === 'approve'
                ? t('txt-appr-service')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'close':
                    handleActionClose(record);
                    break;
                  case 'approve':
                    handleActionApprove(record);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_IMPORT_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_IMPORT_INFO,
      },
    };

    dispatch(ipmDeleteRequest(params));
  }

  function handleActionApprove(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_IMPORT_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_IMPORT_INFO,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(ipmApproveRequest(params));
  }


  return (
    <>
      <div className="w-100 d-flex flex-column">
          <FormSearch
            page={page}
            recordPerPage={recordPerPage}
            handleToast={_handleToast}
          />
          <Table bordered>
            <thead>
              <tr>
                <th>STT</th>
                <th>Ngày thực hiện</th>
                <th>Nghiệp vụ</th>
                <th>Nghiệp vụ chi tiết</th>
                <th>Mã CK</th>
                <th>Nội dung</th>
                <th>Trạng thái</th>
                <th>Người tạo</th>
                <th>Thời gian tạo</th>
                <th>Người duyệt</th>
                <th>Thời gian duyệt</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {typeListBank &&
                typeListBank.map((item) => (
                  <tr key={item.ROW_NUM}>
                    <td className="text-center">{item.ROW_NUM}</td>
                    <td className="text-center">
                      <a
                        onClick={() => _handleChangeDetail(item.PK_IMPORT_INFO)}
                      >
                        {item.C_TRADING_DATE}
                      </a>
                    </td>
                    <td>
                      <a
                        onClick={() => _handleChangeDetail(item.PK_IMPORT_INFO)}
                      >
                        {item.C_BUSINESS_NAME}
                      </a>
                    </td>
                    <td>
                      <a
                        onClick={() => _handleChangeDetail(item.PK_IMPORT_INFO)}
                      >
                        {item.C_BUSINESS_DETAIL_NAME}
                      </a>
                    </td>
                    <td className="text-center">{item.C_SHARE_CODE}</td>
                    <td>{item.C_CONTENT}</td>
                    <td className="text-center">{item.C_STATUS_NAME}</td>
                    <td className="text-center">{item.C_CREATOR_CODE}</td>
                    <td className="text-center">{item.C_CREATE_TIME}</td>
                    <td className="text-center">{item.C_APPROVER_CODE}</td>
                    <td className="text-center">{item.C_APPROVE_TIME}</td>
                    <td className="text-center p-0 w_85">
                    <GroupButton>
                      
                      {accRight?.C_VIEW === 1 &&
                        item?.C_STATUS === 'CHUA_DUYET' && (
                          <a
                            title={t('txt-appr')}
                            onClick={() => handleConfirm('approve', item)}
                          >
                            <IconAppr />
                          </a>
                        )}
                      {accRight?.C_UPDATE === 1 &&
                        item?.C_STATUS === 'CHUA_DUYET' && (
                          <a
                            title={t('txt-del')}
                            onClick={() => handleConfirm('close', item)}
                          >
                            <IconTrash />
                          </a>
                        )}
                    </GroupButton>
                  </td>
                  </tr>
                ))}
            </tbody>
          </Table>

          <div className="mt-3 d-flex justify-content-end">
            <Paging
              page={page}
              recordPerPage={recordPerPage}
              nextPage={_handleNextPage}
              setRecordPerPage={setRecordPerPage}
              total={
                (typeListBank &&
                  !!typeListBank.length &&
                  typeListBank[0].C_TOTAL_RECORD) ||
                0
              }
            />
          </div>
      </div>
      {isOpenDetail && (
        <DetailImportDataModal
          onClose={_onClose}
          id={isID}
          accRight={accRight}
        />
      )}
    </>
  );
}
const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getTypeListBankSearch = makeGetTypeListBankSearch();
  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      typeListBank: getTypeListBankSearch(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(memo(BranchBankComponent))
);
