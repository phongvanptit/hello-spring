import React, { useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import Paging from 'components/paging';

import FormSearch from './formSearchDuyetTKVSD';
import { translate } from 'react-i18next';
import { makeGetToken } from 'lib/selector';
import { makeGetAccountListSearch } from 'lib/selector';
import NodataSearch from 'components/noDataSearch';
import * as _ from 'lodash';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_approve.svg';
import { confirmAlert } from 'react-confirm-alert';
import { accountApproveVSDRequest } from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';
import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
function TabDuyetTTTKVSD(props) {
  const [checkAll, setCheckAll] = useState(false);
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [accountDetail, setAccountDetail] = useState(null);

  const { t, accountList, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetailAccount(accountCode) {
    if (accRight?.C_VIEW !== 1) return;
    setAccountDetail(accountCode);
  }

  function onClose() {
    setAccountDetail(null);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(accountList, 'PK_BACK_ACCOUNT');
      setOrderCheck(allFunc);
    }
  }

  function handleActionApprove(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_VSD',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record ? record.PK_BACK_ACCOUNT : orderCheck.join(','),
        TYPE: '1', // 1 - duyệt mở C_STATUS = 'CHUA_DUYET', 0 - duyệt đóng C_STATUS = 'CHO_DONG'
      },
    };

    dispatch(accountApproveVSDRequest(params));
  }

  function handleApproveSelected(record) {
    if (!record && !orderCheck.length) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-acc')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(record);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  return (
    <div className="custom-tabs-content my-3">
      <div className="w-100 d-flex flex-column">
        <FormSearch page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th style={{ width: '26px' }}>
                {accRight?.C_APPROVE === 1 && (
                  <input
                    type="checkbox"
                    value={checkAll}
                    onChange={_handleChangeCheckAll}
                    checked={checkAll}
                  />
                )}
              </th>
              <th>{t('txt-creator')}</th>
              <th>{t('txt-acc')}</th>
              <th>{t('txt-acc-name')}</th>
              <th>{t('txt-open-date')}</th>
              <th>{t('txt-close-date')}</th>
              <th>{t('txt-vsd-status')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {accountList &&
              accountList.map((item, index) => (
                <tr
                  key={item.PK_BACK_ACCOUNT}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_BACK_ACCOUNT)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td className="text-center">
                    {accRight?.C_APPROVE === 1 && (
                      <input
                        type="checkbox"
                        name={item.PK_BACK_ACCOUNT}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_BACK_ACCOUNT
                        )}
                      />
                    )}
                  </td>
                  <td className="text-center">{item.C_CREATOR_CODE}</td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetailAccount(item.C_ACCOUNT_CODE)}
                    >
                      {item.C_ACCOUNT_CODE}
                    </a>
                  </td>
                  <td className="">{item.C_ACCOUNT_NAME}</td>
                  <td className="text-center">{item.C_OPEN_DATE}</td>
                  <td className="text-center">{item.C_CLOSE_DATE}</td>
                  <td className="text-center">{item.C_VSD_STATUS_NAME}</td>
                  <td className="text-center">{item.C_STATUS_NAME}</td>
                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      {accRight?.C_APPROVE === 1 && (
                        <a
                          title={t('txt-appr')}
                          onClick={() => handleApproveSelected(item)}
                        >
                          <IconCopy />
                        </a>
                      )}
                      {/* <a title="Xóa">
                        <IconTrash />
                      </a> */}
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!accountList || !accountList.length) && (
          <NodataSearch name={t('txt-acc-1')} />
        )}

        <div className="my-2 d-flex justify-content-end">
          {orderCheck && !!orderCheck.length && (
            <Button className="mr-auto" onClick={() => handleApproveSelected()}>
              {t('txt-appr-acc')}
            </Button>
          )}
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              accountList && !!accountList.length
                ? accountList[0].C_TOTAL_RECORD
                : 0
            }
          />
        </div>
      </div>
      {accountDetail && (
        <DetailAccountModal
          accountCode={accountDetail}
          onClose={onClose}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountListSearch = makeGetAccountListSearch();
  const getAccountRight = makeGetAccountRight();

  return {
    token: getToken(state),
    accountList: getAccountListSearch(state),
    accRight: getAccountRight(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(TabDuyetTTTKVSD)
);
