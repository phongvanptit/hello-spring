import RenderSearchShort from 'components/input/inputSearchShort';
import { accListSearchRequest } from 'containers/account/actions';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import IconConfig from 'assets/img/icon/cog.png';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import ConfigHeaderTblModal from 'components/modal/ConfigHeaderTblModal';
import { accountApproveSuccess, accountApproveVSDSuccess, accountDeleteSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetAccountApprove, makeGetAccountApproveVsd, makeGetAccountClose, makeGetAccountDelete, makeGetAccountRevert, makeGetAccountUpdate, makeGetGlobalAccVsdStatus } from 'lib/selector';
import { arrHeaderTblAccount } from 'utils/const';
import {
  ExportExcel,
  FormFlexCenter
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);

  const {
    bizCode,
    handleSubmit,
    submitting,
    t,
    glVsdStatus,

    dataSearch,
    setDataSearch,
    accountDelete,
    accountApprove,
    accountAprVsd,
    accountClose,
    accountRevert,
    accountUpdate,

    formAccountCode,
    formVSDStatus,
    formStatus,
    formStartDate,
    formEndDate,
  } = props;

  const preAccountDelete = usePrevious(accountDelete);
  const preAccountApprove = usePrevious(accountApprove);
  const preAccountClose = usePrevious(accountClose);
  const preAccountRevert = usePrevious(accountRevert);
  const preAccountUpdate = usePrevious(accountUpdate);
  const preAccountApprVsd = usePrevious(accountAprVsd);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(accListSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accountUpdate && !_.isEqual(accountUpdate, preAccountUpdate)) ||
      (accountClose && !_.isEqual(accountClose, preAccountClose)) ||
      (accountRevert && !_.isEqual(accountRevert, preAccountRevert)) ||
      (accountDelete && !_.isEqual(accountDelete, preAccountDelete)) ||
      (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) ||
      (accountAprVsd && !_.isEqual(accountAprVsd, preAccountApprVsd))
    ) {
      dispatch(accListSearchRequest(dataSearch));
    }
  }, [
    accountUpdate,
    accountClose,
    accountRevert,
    accountDelete,
    accountApprove,
    accountAprVsd,
  ]);

  useEffect(() => {
    if (accountDelete && !_.isEqual(accountDelete, preAccountDelete)) {
      _handleToast(t('txt-del-acc-success'), 'success');
      // clear update
      dispatch(accountDeleteSuccess(null));
    }
  }, [accountDelete]);

  useEffect(() => {
    if (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) {
      _handleToast(t('txt-appr-acc-success'), 'success');
      // clear update
      dispatch(accountApproveSuccess(null));
    }
  }, [accountApprove]);

  useEffect(() => {
    if (accountAprVsd && !_.isEqual(accountAprVsd, preAccountApprVsd)) {
      _handleToast(t('txt-appr-acc-success'));
      dispatch(accountApproveVSDSuccess(null));
    }
  }, [accountAprVsd]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  function initForm() {
    dispatch(change('formSearchShortDuyetVSD', 'formStatus', 'CHUA_DUYET'));
  }

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.ALL_FLAG = 0; // tìm kiếm nhanh
    _params.data.VSD_STATUS = values.formVSDStatus;
    _params.data.STATUS = values.formStatus;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;

    dispatch(accListSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.ALL_FLAG = 0; // tìm kiếm nhanh
    _params.data.VSD_STATUS = formVSDStatus;
    _params.data.STATUS = formStatus;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;

    dispatch(accListSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  function _handleShowConfigTable() {
    setShowModal(true);
  }

  function handleCloseModal() {
    setShowModal(false);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <>
      <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
        <div className="d-flex align-items-center mr-auto">
          <Form.Label className="fz-13 w-fix">{t('txt-vsd-status')}</Form.Label>
          <Field
            name="formVSDStatus"
            className="form-control w_100 mx-2"
            component={RenderNormalSelect}
            opts={glVsdStatus}
            onBlur={_handleBlur}
            placeholder="-- Tất cả --"
          />
          <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
          <Field
            name="formStatus"
            className="form-control w_100 mx-2"
            component="select"
            onBlur={_handleBlur}
          >
            <option value="">-- Tất cả --</option>
            <option value="CHUA_DUYET">Chưa duyệt</option>
            <option value="DA_DUYET">Đã duyệt</option>
            <option value="TU_CHOI">Từ chối</option>
            <option value="DA_DONG">Đã đóng</option>
          </Field>
          <Form.Label className="fz-13 w-fix mr-2">
            {t('txt-from-date')}
          </Form.Label>
          <Field
            name="formStartDate"
            className="w_90"
            component={RenderSelectDate}
            classParentName="w-100"
          />
          <Form.Label className="fz-13 w-fix mx-2">
            {t('txt-to-date')}
          </Form.Label>
          <Field
            name="formEndDate"
            className="w_90"
            classParentName="w-100"
            component={RenderSelectDate}
          />
        </div>
        <Field
          name="formAccountCode"
          type="text"
          className="form-control"
          placeholder={t('txt-search')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
        {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
          <img src={IconReset} alt="" />
        </ButtonSearch>
        <ExportExcel>
          <img src={IconExcel} alt="" />
        </ExportExcel> */}
        {bizCode && (
          <ExportExcel
            onClick={() => _handleShowConfigTable()}
            title={t('txt-field-manage')}
          >
            <img src={IconConfig} alt="" />
          </ExportExcel>
        )}
      </FormFlexCenter>
      {showModal && (
        <ConfigHeaderTblModal
          onClose={handleCloseModal}
          bizCode={bizCode}
          tblDef={arrHeaderTblAccount}
        />
      )}
    </>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDuyetVSD',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDuyetVSD');

const makeMapStateToProps = () => {
  const getAccountUpdate = makeGetAccountUpdate();
  const getAccountApprove = makeGetAccountApprove();
  const getAccountApproveVsd = makeGetAccountApproveVsd();
  const getAccountClose = makeGetAccountClose();
  const getAccountRevert = makeGetAccountRevert();
  const getAccountDelete = makeGetAccountDelete();
  const getVsdStatus = makeGetGlobalAccVsdStatus();

  const mapStateToProps = (state) => {
    const {
      formAccountCode,
      formVSDStatus,
      formStatus,
      formStartDate,
      formEndDate,
    } = selector(
      state,
      'formAccountCode',
      'formAccountName',
      'formVSDStatus',
      'formStatus',
      'formStartDate',
      'formEndDate'
    );

    return {
      accountUpdate: getAccountUpdate(state),
      accountDelete: getAccountDelete(state),
      accountApprove: getAccountApprove(state),
      accountAprVsd: getAccountApproveVsd(state),
      accountClose: getAccountClose(state),
      accountRevert: getAccountRevert(state),
      glVsdStatus: getVsdStatus(state),

      formAccountCode,
      formVSDStatus,
      formStatus,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
