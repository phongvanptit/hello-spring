import RenderSearchShort from 'components/input/inputSearchShort';
import { accListSearchRequest } from 'containers/account/actions';
import React, { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import IconExcel from 'assets/img/icon/ms-excel.png';
import * as _ from 'lodash';

import IconConfig from 'assets/img/icon/cog.png';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import ConfigHeaderTblModal from 'components/modal/ConfigHeaderTblModal';
import {
  accountApproveSuccess,
  accountApproveVSDSuccess,
  accountDeleteSuccess,
  accountUpdateSuccess,
} from 'containers/account/actions';
import { globalExportFileRequest } from 'containers/report/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountApprove,
  makeGetAccountApproveClose,
  makeGetAccountApproveVsd,
  makeGetAccountDelete,
  makeGetAccountRevert,
  makeGetAccountUpdate,
  makeGetAccountUnClose
} from 'lib/selector';
import { arrHeaderTblAccount } from 'utils/const';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';

import {
  makeGetAccountFrontType,
  makeGetGlobalAccStatus,
  makeGetSystemInfo,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import { formatDate, stringToDate } from 'utils';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);

  const {
    bizCode,
    handleSubmit,
    submitting,

    dataSearch,
    setDataSearch,
    accountDelete,
    accountApprove,
    accountAprVsd,
    accountRevert,
    accountUpdate,
    t,
    accountApproveClose,
    accountUnClose,
    glAccStatus,
    glAccFrontType,

    formAccountCode,
    formAccountType,
    formStartDate,
    formEndDate,
    formStatus,
    statusCode,
    sysSystemInfo,
  } = props;

  const preAccountDelete = usePrevious(accountDelete);
  const preAccountApprove = usePrevious(accountApprove);
  const preAccountRevert = usePrevious(accountRevert);
  const preAccountUpdate = usePrevious(accountUpdate);
  const preAccountApprVsd = usePrevious(accountAprVsd);
  const preAccountApproveClose = usePrevious(accountApproveClose);
  const preAccountUnClose = usePrevious(accountUnClose);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);
  const preStatus = usePrevious(formStatus);

  useEffect(() => {
    initForm();
    setTimeout(() => {
      dispatch(accListSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accountUpdate && !_.isEqual(accountUpdate, preAccountUpdate)) ||
      (accountRevert && !_.isEqual(accountRevert, preAccountRevert)) ||
      (accountApproveClose &&
        !_.isEqual(accountApproveClose, preAccountApproveClose)) ||
      (accountUnClose &&
        !_.isEqual(accountUnClose, preAccountUnClose)) ||
      (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) ||
      (accountAprVsd && !_.isEqual(accountAprVsd, preAccountApprVsd)) ||
      (accountDelete && !_.isEqual(accountDelete, preAccountDelete))
    ) {
      dispatch(accListSearchRequest(dataSearch));
    }
  }, [
    accountUpdate,
    accountRevert,
    accountApproveClose,
    accountApprove,
    accountAprVsd,
    accountDelete,
    accountUnClose,
  ]);

  useEffect(() => {
    if (accountDelete && !_.isEqual(accountDelete, preAccountDelete)) {
      _handleToast(`${t('txt-del-acc-success')}`, 'success');
      // clear update
      dispatch(accountDeleteSuccess(null));
    }
  }, [accountDelete]);

  useEffect(() => {
    if (accountUpdate && !_.isEqual(accountUpdate, preAccountUpdate)) {
      _handleToast('Cập nhật bút toán thành công', 'success');
      // clear update
      dispatch(accountUpdateSuccess(null));
    }
  }, [accountUpdate]);

  useEffect(() => {
    if (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) {
      _handleToast(`${t('txt-appr-acc-success')}`, 'success');
      // clear update
      dispatch(accountApproveSuccess(null));
    }
  }, [accountApprove]);

  useEffect(() => {
    if (accountAprVsd && !_.isEqual(accountAprVsd, preAccountApprVsd)) {
      _handleToast(`${t('txt-appr-acc-success')}`);
      dispatch(accountApproveVSDSuccess(null));
    }
  }, [accountAprVsd]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  function initForm() {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    if (statusCode) {
      dispatch(change('formSearchShortTaiKhoan', 'formStatus', 'CHUA_DUYET'));
      dispatch(
        change(
          'formSearchShortTaiKhoan',
          'formStartDate',
          statusCode === 'OPEN_NEW' ? formatDate(_date, '/', 'dmy') : ''
        )
      );
    }
  }

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.ACCOUNT_TYPE = formAccountType;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;
    dispatch(accListSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.ACCOUNT_TYPE = formAccountType;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;
    _params.data.ALL_FLAG = 1;
    dispatch(accListSearchRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'TK_EXPORT_01';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_ACCOUNT";
    dispatch(globalExportFileVer2Request(params));
  }

  function _handleShowConfigTable() {
    setShowModal(true);
  }

  function handleCloseModal() {
    setShowModal(false);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <>
      <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
        <div className="d-flex align-items-center mr-auto">
          <Form.Label className="fz-13 w-fix">{t('txt-acc-type')}</Form.Label>
          <Field
            name="formAccountType"
            className="form-control w_100 mx-2"
            component={RenderNormalSelect}
            opts={glAccFrontType}
            onBlur={_handleBlur}
            placeholder="-- Tất cả --"
          />
          <Form.Label className="fz-13 w-fix mr-2">
            {t('txt-open-date')}
          </Form.Label>
          <Field
            name="formStartDate"
            className="w_90"
            component={RenderSelectDate}
            classParentName="w-100"
          />
          <Form.Label className="fz-13 w-fix mx-2">
            {t('txt-close-date')}
          </Form.Label>
          <Field
            name="formEndDate"
            className="w_90"
            classParentName="w-100"
            component={RenderSelectDate}
          />
          <Form.Label className="fz-13 w-fix ml-2">
            {t('txt-status')}
          </Form.Label>
          <Field
            name="formStatus"
            className="form-control w_100 mx-2"
            component={RenderNormalSelect}
            opts={glAccStatus}
            onBlur={_handleBlur}
            placeholder="-- Tất cả --"
          />
        </div>
      
        <div>
        <Field
          name="formAccountCode"
          type="text"
          className="form-control"
          placeholder={t('txt-search')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
        </div>
        <div>
        <ExportExcel>
          <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
        </ExportExcel>
        </div>
        {bizCode && (
          <ExportExcel
            onClick={() => _handleShowConfigTable()}
            title={t('txt-field-manage')}
          >
            <img src={IconConfig} alt="" />
          </ExportExcel>
        )}
      </FormFlexCenter>
      {/* <ExportExcel className="ml-auto">
          <img src={IconExcel} alt="" onClick={() => handleExportExcel()} />
        </ExportExcel> */}
      {showModal && (
        <ConfigHeaderTblModal
          onClose={handleCloseModal}
          bizCode={bizCode}
          tblDef={arrHeaderTblAccount}
        />
      )}
    </>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortTaiKhoan',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortTaiKhoan');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const getAccountUpdate = makeGetAccountUpdate();
  const getAccountApprove = makeGetAccountApprove();
  const getAccountApproveVsd = makeGetAccountApproveVsd();
  const getAccountRevert = makeGetAccountRevert();
  const getAccountDelete = makeGetAccountDelete();
  const getAccountApproveClose = makeGetAccountApproveClose();
  const getAccountFrontType = makeGetAccountFrontType();
  const getGlobalAccStatus = makeGetGlobalAccStatus();
  const getAccountUnClose = makeGetAccountUnClose();

  const mapStateToProps = (state) => {
    const {
      formAccountCode,
      formAccountType,
      formStartDate,
      formEndDate,
      formStatus,
    } = selector(
      state,
      'formAccountCode',
      'formAccountType',
      'formStartDate',
      'formEndDate',
      'formStatus'
    );

    return {
      sysSystemInfo: getSystemInfo(state),
      accountUpdate: getAccountUpdate(state),
      accountDelete: getAccountDelete(state),
      accountApprove: getAccountApprove(state),
      accountAprVsd: getAccountApproveVsd(state),
      accountRevert: getAccountRevert(state),
      accountApproveClose: getAccountApproveClose(state),
      glAccFrontType: getAccountFrontType(state),
      glAccStatus: getGlobalAccStatus(state),
      accountUnClose: getAccountUnClose(state),

      formAccountCode,
      formAccountType,
      formStartDate,
      formEndDate,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
