import React, { useState } from 'react';
import { Table } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';

import Paging from 'components/paging';
import { makeGetAccountListSearch, makeGetToken } from 'lib/selector';
import FormSearch from './formSearchTaiKhoan';
import { Button } from 'react-bootstrap';
import { ReactComponent as IconSend } from 'assets/img/icon/send.svg';

import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
import NodataSearch from 'components/noDataSearch';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import {
  accountApproveRequest,
  accountDeleteRequest,
  accountApproveVSDRequest,
} from 'containers/account/actions';
import {
  sysSingleListCfgRequest,
  sysSingleUserCfgRequest,
} from 'containers/system/actions';
import {
  makeGetAccountRight,
  makeGetListCfg,
  makeGetUserCfg,
} from 'lib/selector';
import * as _ from 'lodash';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { BsThreeDots } from 'react-icons/bs';
import PerfectScrollbar from 'react-perfect-scrollbar';
import styled from 'styled-components';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
const FormShow = styled.div`
  min-width: 100px;
  min-height: 50px;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  right: 0;
  top: 100%;
  z-index: 1;

  ul {
    padding: 5px;

    li {
      text-align: left;
      padding: 5px;
      cursor: pointer;
      color: #212529;

      &:hover {
        background-color: #e0e0e0;
      }

      &:not(:last-child) {
        border: 1px solid #e8eaeb;
        border-width: 0 0 1px 0;
      }

      &.li_DA_DUYET {
        background: #e0e0e0;
        cursor: default;
      }
    }
  }
`;

function GroupAction(props) {
  const wrapperRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);
  const { record, fnCallback, rightFunc, t } = props;

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    setShowModal(true);
  }

  function _handleClickItem(fnName) {
    fnCallback &&
      fnCallback[fnName] &&
      fnCallback[fnName](
        ['onDelete', 'onApprove', 'onApproveVSD'].indexOf(fnName) > -1
          ? record.PK_BACK_ACCOUNT
          : record.C_ACCOUNT_CODE
      );
    setShowModal(false);
  }

  return (
    <GroupButton>
      {rightFunc?.C_VIEW === 1 && (
        <a
          title={t('txt-detail')}
          rel="noreferrer noopener"
          onClick={() => _handleClickItem('onDetail')}
        >
          <IconCopy />
        </a>
      )}
      {rightFunc?.C_APPROVE === 1 && (
        <a
          title={t('txt-appr')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onApprove')
              : null
          }
        >
          <IconApprove />
        </a>
      )}
      {/*{rightFunc?.C_APPROVE === 1 && record.C_ACCOUNT_CREDIT_TYPE === '0' && (*/}
      {/*  <a*/}
      {/*    title={t('txt-vsd')}*/}
      {/*    className={record.C_STATUS !== 'DA_DUYET' ? 'disabled' : ''}*/}
      {/*    onClick={() =>*/}
      {/*      record.C_STATUS === 'DA_DUYET'*/}
      {/*        ? _handleClickItem('onApproveVSD')*/}
      {/*        : null*/}
      {/*    }*/}
      {/*  >*/}
      {/*    <IconSend />*/}
      {/*  </a>*/}
      {/*)}*/}
      {rightFunc?.C_UPDATE === 1 && (
        <a
          title={t('txt-del')}
          className={record.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''}
          onClick={() =>
            record.C_STATUS === 'CHUA_DUYET'
              ? _handleClickItem('onDelete')
              : null
          }
        >
          <IconTrash
            title={'txt-del'}
            rel="noreferrer noopener"
            // onClick={() => _handleClickItem('onDetail')}
          />
        </a>
      )}
    </GroupButton>
  );
}

function TabKHCaNhan(props) {
  const [checkAll, setCheckAll] = useState(false);
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [orderCheck, setOrderCheck] = useState([]);
  const [accountDetail, setAccountDetail] = useState(null);
  const [bizCode] = useState('BACK.GET_ALL_ACCOUNT');
  const [dataSearch, setDataSearch] = React.useState(null);

  const { accountList, token, t, userCfg, listCfg, accRight, statusCode } =
    props;
  const dispatch = useDispatch();

  React.useEffect(() => {
    getListConfig();
    getUserConfig();
    return () => {};
  }, []);

  function _handleNextPage(step) {
    setPage(step);
  }

  function getListConfig() {
    if (!token) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_CONFIG',
      group: 'LIST',
      data: {
        BUSINESS_CODE: bizCode,
      },
    };

    dispatch(sysSingleListCfgRequest(params));
  }

  function getUserConfig() {
    if (!token) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_CONFIG',
      group: 'LIST',
      data: {
        BUSINESS_CODE: bizCode,
      },
    };

    dispatch(sysSingleUserCfgRequest(params));
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      //check theo trang thai chua duyet
      // const allFunc = _.filter(accountList, (o) => o.C_STATUS === 'CHUA_DUYET');
      //bo check tick all
      const allFunc = _.filter(accountList);
      setOrderCheck(_.map(allFunc, 'PK_BACK_ACCOUNT'));
    }
  }

  function onClose() {
    setAccountDetail(null);
  }

  function handleEditAccount(accCode) {
    setAccountDetail(accCode);
  }

  function handleDetailAccount(accountCode) {
    if (accRight?.C_VIEW !== 1) return;
    setAccountDetail(accountCode);
  }

  function handleApproveAccount(_accCode) {
    if (!_accCode && !orderCheck.length) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-acc')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(_accCode);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleApproveAccountVSD(_accCode) {
    if (!_accCode && !orderCheck.length) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn duyệt VSD?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApproveVSD(_accCode);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDelAccount(_accCode) {
    if (!_accCode && !orderCheck.length) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-acc')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(_accCode);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(_accCode) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: _accCode || orderCheck.join(','),
      },
    };
    setOrderCheck([]);
    dispatch(accountApproveRequest(params));
  }

  function handleActionApproveVSD(_accCode) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_VSD',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: _accCode || orderCheck.join(','),
        TYPE: '0',
      },
    };
    setOrderCheck([]);
    dispatch(accountApproveVSDRequest(params));
  }

  function handleActionDel(_accCode) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: _accCode || orderCheck.join(','),
      },
    };
    setOrderCheck([]);
    dispatch(accountDeleteRequest(params));
  }
console.log(dataSearch?.data.STATUS)
  return (
    <div className="w-100 d-flex flex-column custom-tabs-content my-3">
      <FormSearch
        page={page}
        recordPerPage={recordPerPage}
        statusCode={statusCode}
        dataSearch={dataSearch}
        setDataSearch={setDataSearch}
      />
      <PerfectScrollbar className="w-100">
        <Table bordered>
          <thead>
            <tr>
              <th>
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              </th>
              {userCfg &&
                !!userCfg.length &&
                userCfg.map((item, index) => {
                  if (item.status === '0') return null;

                  return (
                    <th key={index}>
                      <div className={'headerSticky_' + index}>
                        {_.find(listCfg, (o) => o.code === item.code)?.name}
                      </div>
                    </th>
                  );
                })}
              {(!userCfg || !userCfg.length) && (
                <>
                  <th>{t('txt-acc')}</th>
                  <th>{t('txt-acc-name')}</th>
                  {/*<th>{t('txt-type')}</th>*/}
                  <th>{t('txt-open-date')}</th>
                  <th>{t('txt-close-date')}</th>
                  <th>{t('txt-status')}</th>
                </>
              )}
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {(!userCfg || !userCfg.length) &&
              accountList &&
              accountList.map((item) => (
                <tr
                  key={item.PK_BACK_ACCOUNT}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_BACK_ACCOUNT)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td className="text-center">
                    {/* {item.C_STATUS === 'CHUA_DUYET' && ( */}
                    {
                      <input
                        type={'checkbox'}
                        name={item.PK_BACK_ACCOUNT}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_BACK_ACCOUNT
                        )}
                      />
                    }
                  </td>
                  <td className="text-center">
                    <a
                      rel="noreferrer noopener"
                      onClick={() => handleDetailAccount(item.C_ACCOUNT_CODE)}
                    >
                      {item.C_ACCOUNT_CODE}
                    </a>
                  </td>
                  <td className="">{item.C_ACCOUNT_NAME}</td>
                  {/*<th className="text-center">{item.C_ACCOUNT_TYPE}</th>*/}
                  <td className="text-center">{item.C_OPEN_DATE}</td>
                  <td className="text-center">{item.C_CLOSE_DATE}</td>
                  <td className="text-center">{item.C_STATUS_NAME}</td>
                  <td className="text-center p-0 w_85">
                    {accRight?.C_VIEW ||
                    accRight?.C_APPROVE ||
                    accRight?.C_UPDATE ? (
                      <GroupAction
                        record={item}
                        rightFunc={accRight}
                        t={t}
                        fnCallback={{
                          onEdit: handleEditAccount,
                          onApprove: handleApproveAccount,
                          onDetail: handleDetailAccount,
                          onDelete: handleDelAccount,
                          onApproveVSD: handleApproveAccountVSD,
                        }}
                      />
                    ) : null}
                  </td>
                </tr>
              ))}
            {accountList &&
              userCfg &&
              !!userCfg.length &&
              accountList.map((item) => (
                <tr
                  key={item.PK_BACK_ACCOUNT}
                  className={
                    _.some(orderCheck, (o) => o === item.PK_BACK_ACCOUNT)
                      ? 'row-checked'
                      : ''
                  }
                >
                  <td className="text-center">
                    {/* {item.C_STATUS === 'CHUA_DUYET' && ( */}
                    {
                      <input
                        type={'checkbox'}
                        name={item.PK_BACK_ACCOUNT}
                        onChange={_handleChange}
                        checked={_.some(
                          orderCheck,
                          (o) => o === item.PK_BACK_ACCOUNT
                        )}
                      />
                    }
                  </td>
                  {userCfg.map((it, index) => {
                    if (it.status === '0') return null;

                    if (it.code === 'C_ACCOUNT_CODE')
                      return (
                        <td className="text-center" key={index}>
                          <a
                            rel="noreferrer noopener"
                            onClick={() =>
                              handleDetailAccount(item.C_ACCOUNT_CODE)
                            }
                          >
                            {item.C_ACCOUNT_CODE}
                          </a>
                        </td>
                      );
                    if (it.code === 'C_ACCOUNT_NAME')
                      return (
                        <td className="" key={index}>
                          {item.C_ACCOUNT_NAME}
                        </td>
                      );
                    if (
                      it.code === 'C_CREATE_TIME' ||
                      it.code === 'C_OPEN_DATE'
                    )
                      return (
                        <td className="text-center" key={index}>
                          {item[it.code] ? item[it.code].split(' ')[0] : ''}
                        </td>
                      );
                    return (
                      <td
                        className={
                          it.code === 'C_MARKETING_NAME' ||
                          it.code === 'C_CUST_EMAIL'
                            ? ''
                            : 'text-center'
                        }
                        key={index}
                      >
                        {item[it.code]}
                      </td>
                    );
                  })}

                  <td className="text-center p-0 w_85">
                    {accRight?.C_VIEW ||
                    accRight?.C_APPROVE ||
                    accRight?.C_UPDATE ? (
                      <GroupAction
                        record={item}
                        rightFunc={accRight}
                        t={t}
                        fnCallback={{
                          // onEdit: handleEditAccount,
                          onApprove: handleApproveAccount,
                          onDetail: handleDetailAccount,
                          onDelete: handleDelAccount,
                          onApproveVSD: handleApproveAccountVSD,
                        }}
                      />
                    ) : null}
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
      {(!accountList || !accountList.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        {orderCheck && !!orderCheck.length && dataSearch.data.STATUS === 'CHUA_DUYET' && (
          <div className="mr-auto">
            <Button
              variant="danger"
              className="mr-2"
              onClick={() => handleDelAccount()}
              disabled={accRight?.C_UPDATE !== 1}
              
            >
              {t('bnt-del-entry')}
            </Button>
            <Button
              variant="success"
              className="mr-2"
              onClick={() => handleApproveAccount()}
              disabled={accRight?.C_APPROVE !== 1}
            >
              {t('bnt-appr-entry')}
            </Button>
          </div>
        )}
        {orderCheck && !!orderCheck.length && dataSearch.data.STATUS === 'DA_DUYET' && (
          <div className="mr-auto">
            <Button
              variant="warning"
              className="mr-auto"
              onClick={() => handleApproveAccountVSD()}
              disabled={accRight?.C_APPROVE !== 1}
            >
              {t('txt-vsd')}
            </Button>
          </div>
        )}
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            accountList && !!accountList.length
              ? accountList[0].C_TOTAL_RECORD
              : 0
          }
        />
      </div>

      {accountDetail && (
        <DetailAccountModal
          accountCode={accountDetail}
          onClose={onClose}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountListSearch = makeGetAccountListSearch();
  const getUserCfg = makeGetUserCfg();
  const getListCfg = makeGetListCfg();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountListSearch(state),
      userCfg: getUserCfg(state),
      listCfg: getListCfg(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(TabKHCaNhan)
);
