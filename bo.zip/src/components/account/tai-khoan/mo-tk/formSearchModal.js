import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { accListSearchRequest } from 'containers/account/actions';
import {
  makeGetAccGroupCus,
  makeGetAccountCreditType,
  makeGetCustType,
  makeGetSystemInfo,
  makeGetGlComboFee,
  makeGetGlPolicy
} from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';
import { arrSearchTaiKhoan } from 'utils/const';

import * as _ from 'lodash';

import { makeGetChannelType } from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { makeGetClientDepositCode } from 'lib/selector';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    glCustType,
    handleSubmit,
    submitting,
    t,
    glAccCreditType,
    glChannelType,
    glAccFrontType,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
    onTriggerPopover,
    glAccStatus,
    accGroupCus,
    clDepositCode,
    glComboFee,
    glPolicy
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchTaiKhoan, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.BRANCH_CODE = values.formBranchCode;
    _dataSearch.data.SUB_BRANCH_CODE = values.formSubBranchCode;
    _dataSearch.data.MARKETING_ID = values.formMKTID;
    _dataSearch.data.NATIONAL_TYPE = values.formNationalType;
    _dataSearch.data.CUSTOMER_TYPE = values.formCustomerType;
    _dataSearch.data.ACCOUNT_CREDIT_TYPE = values.formCreditType;
    _dataSearch.data.GROUP_CODE = values.formGroupCode;
    _dataSearch.data.ACCOUNT_NAME = values.formAccountName;
    _dataSearch.data.COMM_CODE = values.formCommCode;
    _dataSearch.data.CARD_ID = values.formCardId;
    _dataSearch.data.MOBILE = values.formMobile;
    _dataSearch.data.VSD_STATUS = values.formVSDStatus;
    _dataSearch.data.CHANNEL_CODE = values.formChannel;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    _dataSearch.data.POLICY_CODE = values.formFeeCombo;
    _dataSearch.data.PROMOTE_CODE = values.formPolicyCode;
    _dataSearch.data.ALL_FLAG = 1;

    dispatch(accListSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);

    dispatch(change('formSearchModalTaiKhoan', 'formBranchCode', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formSubBranchCode', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formMKTID', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formCustomerType', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formNationalType', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formCardId', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formMobile', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formVSDStatus', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formChannel', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formCreatorCode', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formCreditType', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formCommCode', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formPolicyCode', ''));
    dispatch(change('formSearchModalTaiKhoan', 'formFeeCombo', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchTaiKhoan,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formAccountCode' &&
              _objItem.value !== 'formAccountName'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'select') {
              if (_objItem.value === 'formChannel')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name="formChannel"
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={glChannelType}
                      index={6}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formCreditType')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name="formCreditType"
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={glAccCreditType}
                      index={5}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formFeeCombo')
                  return (
                    <Form.Group key={_objItem.value}>
                      <Form.Label className="fz-13">
                        {t(_objItem.label)}
                      </Form.Label>
                      <Field
                        name="formFeeCombo"
                        className="form-control w-100"
                        component={RenderNormalSelect}
                        opts={glComboFee}
                        index={5}
                        placeholder="-- Tất cả --"
                      />
                    </Form.Group>
              );

              if (_objItem.value === 'formPolicyCode')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name="formPolicyCode"
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={glPolicy}
                      index={5}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );


              if (_objItem.value === 'formGroupCode')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name="formGroupCode"
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={accGroupCus}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formVSDStatus')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name="formVSDStatus"
                      className="form-control w-100"
                      component="select"
                    >
                      <option value="">-- Tất cả --</option>
                      <option value={clDepositCode}>Lưu ký tại CTCK</option>
                      <option value="OTHER">Không lưu ký tại CTCK</option>
                    </Field>
                  </Form.Group>
                );

              if (_objItem.value === 'formCustomerType')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name="formCustomerType"
                      className="form-control w-100"
                      component={RenderNormalSelect}
                      opts={glCustType}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );
            }
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalTaiKhoan',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalTaiKhoan');

const makeMapStateToProps = () => {
  const getCustType = makeGetCustType();
  const getAccountCreditType = makeGetAccountCreditType();
  const getChannelType = makeGetChannelType();
  const getSystemInfo = makeGetSystemInfo();
  const getAccGroupCus = makeGetAccGroupCus();
  const getClientDepositCode = makeGetClientDepositCode();
  const getGlComboFee = makeGetGlComboFee();
  const getGlPolicy = makeGetGlPolicy();

  const mapStateToProps = (state, props) => {
    const {
      formBranchCode,
      formSubBranchCode,
      formMKTID,
      formCustomerType, // Loại KH: CA_NHAN/TO_CHUC
      formNationalType, // Loại quốc tịch: TRONG_NUOC/NUOC_NGOAI
      formCreditType,
      formGroupCode,
      formCommCode,
      formCardId,
      formMobile,
      formVSDStatus,
      formCreatorCode,
      formPolicyCode,
      formFeeCombo,

      formChannel,
    } = selector(
      state,
      'formCardId',
      'formCreatorCode',
      'formBranchCode',
      'formSubBranchCode',
      'formMKTID',
      'formChannel',
      'formCustomerType',
      'formCommCode',
      'formGroupCode',
      'formVSDStatus',
      'formNationalType',
      'formAccountType',
      'formMobile',
      'formPolicyCode',
      'formFeeCombo',
    );

    const { dataSearch } = props;

    return {
      glCustType: getCustType(state),
      glAccCreditType: getAccountCreditType(state),
      glChannelType: getChannelType(state),
      sysSystemInfo: getSystemInfo(state),
      accGroupCus: getAccGroupCus(state),
      clDepositCode: getClientDepositCode(state),
      glComboFee: getGlComboFee(state),
      glPolicy: getGlPolicy(state),
      formCardId,
      formCreatorCode,
      formBranchCode,
      formSubBranchCode,
      formMKTID,
      formChannel,
      formCreditType,
      formCommCode,
      formGroupCode,
      formVSDStatus,
      formCustomerType,
      formNationalType,
      formMobile,
      formPolicyCode,
      formFeeCombo,

      initialValues: {
        formCardId: dataSearch?.data?.CARD_ID,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formBranchCode: dataSearch?.data?.BRANCH_CODE,
        formSubBranchCode: dataSearch?.data?.SUB_BRANCH_CODE,
        formMKTID: dataSearch?.data?.MARKETING_ID,
        formChannel: dataSearch?.data?.CHANNEL_CODE,
        formCreditType: dataSearch?.data?.ACCOUNT_CREDIT_TYPE,
        formCommCode: dataSearch?.data?.COMM_CODE,
        formGroupCode: dataSearch?.data?.GROUP_CODE,
        formVSDStatus: dataSearch?.data?.VSD_STATUS,
        formCustomerType: dataSearch?.data?.CUSTOMER_TYPE,
        formNationalType: dataSearch?.data?.NATIONAL_TYPE,
        formMobile: dataSearch?.data?.MOBILE,
        formFeeCombo: dataSearch?.data?.POLICY_CODE,
        formPolicyCode: dataSearch?.data?.PROMOTE_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
