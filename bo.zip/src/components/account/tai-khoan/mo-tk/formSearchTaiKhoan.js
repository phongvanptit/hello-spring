import { accListSearchSuccess } from 'containers/account/actions';
import { makeGetToken } from 'lib/selector';
import React from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';

import { accListSearchRequest } from 'containers/account/actions';
import { makeGetSystemInfo } from 'lib/selector';
import { formatDate } from 'utils';
import {
  ContainerDropdownShow,
  ContainerSearch,
  ContainerSearchDropdown,
} from 'utils/styledComponent';
import FormSearchModal from './formSearchModal';
import FormSearchShort from './formSearchShort';
import { stringToDate } from 'utils';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const wrapperRef = React.useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = React.useState(false);
  const [triggerPopover, setTriggerPopover] = React.useState(false);

  const { token, page, recordPerPage, sysSystemInfo, t, statusCode, dataSearch, setDataSearch } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(accListSearchSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(accListSearchRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target) &&
      !triggerPopover
    ) {
      setShowModal(false);
    }
  }

  function initFormSearch() {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT',
      group: 'LIST',
      data: {
        BRANCH_CODE: '',
        SUB_BRANCH_CODE: '',
        MARKETING_ID: '',
        CUSTOMER_TYPE: '',
        NATIONAL_TYPE: '',
        ACCOUNT_TYPE: '',
        ACCOUNT_CREDIT_TYPE: '',
        GROUP_CODE: '',
        ACCOUNT_CODE: '',
        ACCOUNT_NAME: '',
        COMM_CODE: '',
        CARD_ID: '',
        MOBILE: '',
        FROM_DATE:
          statusCode === 'OPEN_NEW' ? formatDate(_date, '/', 'dmy') : '',
        TO_DATE: '',
        STATUS: statusCode ? 'CHUA_DUYET' : '',
        VSD_STATUS: '',
        CHANNEL_CODE: '',
        CREATOR_CODE: '',
        ALL_FLAG: 1,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };

    setDataSearch(params);
  }

  function _handleShow() {
    setShowModal(!showModal);
  }

  function onTriggerPopover(param) {
    setTriggerPopover(param);
  }

  return (
    <ContainerSearch>
      <div ref={wrapperRef} style={{ position: 'relative' }}>
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              dataSearch={dataSearch}
              setDataSearch={setDataSearch}
              onClose={() => setShowModal(false)}
              onTriggerPopover={onTriggerPopover}
            />
          </ContainerDropdownShow>
        )}
      </div>
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
          bizCode={'BACK.GET_ALL_ACCOUNT'}
          statusCode={statusCode}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
