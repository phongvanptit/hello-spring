import RenderSearchShort from 'components/input/inputSearchShort';
import { accountAuthorSearchRequest } from 'containers/account/actions';
import {
  makeGetAccountAuthorApprove,
  makeGetAccountAuthorDelete,
  makeGetAccountAuthorUpd,
  makeGetPublicStt,
} from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { ExportExcel } from 'utils/styledComponent';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { globalExportFileRequest } from 'containers/report/actions';
import IconPdf from 'assets/img/icon/ms-pdf.svg';
import {
  accAuthorApproveSuccess,
  accAuthorDelSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { Form } from 'react-bootstrap';
import { FormFlexCenter } from 'utils/styledComponent';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    glPublicStt,

    accAuthorUpd,
    accAuthorDel,
    accAuthorAppr,

    formAccountCode,
    formStartDate,
    formEndDate,
    formStatus,
    formCustomerCode,
  } = props;

  const preAccAuthorUpd = usePrevious(accAuthorUpd);
  const preAccAuthorDel = usePrevious(accAuthorDel);
  const preAccAuthorAppr = usePrevious(accAuthorAppr);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accountAuthorSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accAuthorUpd && !_.isEqual(accAuthorUpd, preAccAuthorUpd)) ||
      (accAuthorDel && !_.isEqual(accAuthorDel, preAccAuthorDel)) ||
      (accAuthorAppr && !_.isEqual(accAuthorAppr, preAccAuthorAppr))
    ) {
      dispatch(accountAuthorSearchRequest(dataSearch));
    }
  }, [accAuthorUpd, accAuthorDel, accAuthorAppr]);

  useEffect(() => {
    if (accAuthorAppr && !_.isEqual(accAuthorAppr, preAccAuthorAppr)) {
      _handleToast(t('txt-appr-author-info-success'), 'success');
      dispatch(accAuthorApproveSuccess(null));
    }
  }, [accAuthorAppr]);

  useEffect(() => {
    if (accAuthorDel && !_.isEqual(accAuthorDel, preAccAuthorDel)) {
      _handleToast(t('txt-del-author-info-success'), 'success');
      dispatch(accAuthorDelSuccess(null));
    }
  }, [accAuthorDel]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;
    _params.data.CUSTOMER_CODE = values.formCustomerCode;
    dispatch(accountAuthorSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    // validate date
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;
    _params.data.CUSTOMER_CODE = formCustomerCode;
    dispatch(accountAuthorSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }


  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'TK_EXPORT_03';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_UQ";
    dispatch(globalExportFileVer2Request(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
      <Form.Label className="fz-13 w-fix mx-2">Mã khách hàng</Form.Label>
        <Field
          name="formCustomerCode"
          className="w_120 form-control"
          component={RenderInput}
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glPublicStt}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      
      </div>
      <div>
      <ExportExcel>
          <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
        </ExportExcel>
      </div>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchTKUyQuyenShort',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchTKUyQuyenShort');

const makeMapStateToProps = () => {
  const getAccountAuthorUpd = makeGetAccountAuthorUpd();
  const getAccountAuthorDelete = makeGetAccountAuthorDelete();
  const getAccountAuthorApprove = makeGetAccountAuthorApprove();
  const getPublicStt = makeGetPublicStt();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStartDate, formEndDate, formStatus,formCustomerCode } =
      selector(
        state,
        'formAccountCode',
        'formStartDate',
        'formEndDate',
        'formStatus',
        'formCustomerCode',
      );

    return {
      accAuthorUpd: getAccountAuthorUpd(state),
      accAuthorDel: getAccountAuthorDelete(state),
      accAuthorAppr: getAccountAuthorApprove(state),
      glPublicStt: getPublicStt(state),
      formAccountCode,
      formStartDate,
      formEndDate,
      formStatus,
      formCustomerCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
