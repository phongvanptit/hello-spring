import React from 'react';
import { Form } from 'react-bootstrap';

export default function CustomerAuthorInfo({ custDetail, t }) {
  return (
    <>
      <Form.Group>
        <Form.Label>{t('')}Họ và tên</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CUSTOMER_NAME || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('Account')} ({t('if any')})
        </Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CUSTOMER_CODE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Dealing room')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_SUB_BRANCH_CODE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Card number')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CARD_ID || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-issue-date')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_ISSUE_DATE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Expiry date')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_EXPIRE_DATE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label> {t('txt-issue-place')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_ISSUE_PLACE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Tel')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CUST_TEL || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-mobile')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CUST_MOBILE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-email')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CUST_EMAIL || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-address')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CUST_ADDRESS || ''}
          disabled
        />
      </Form.Group>
    </>
  );
}
