import React from 'react';
import { Form } from 'react-bootstrap';

export default function AccountAuthorInfo({ custDetail, t }) {
  return (
    <>
      <Form.Group>
        <Form.Label>{t('txt-acc-name')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_ACCOUNT_NAME || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-acc-type')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Dealing room')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_SUB_BRANCH_CODE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Card number')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_CARD_ID || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-issue-date')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_ISSUE_DATE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Expiry date')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_EXPIRE_DATE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label> {t('txt-issue-place')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_ISSUE_PLACE || ''}
          disabled
        />
      </Form.Group>

      <hr style={{ gridColumn: '1/5' }} className="my-1" />
      <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
        {t('Representative')}
      </p>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>{t('Full name')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_REPRE_NAME || ''}
          disabled
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>{t('Position')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_REPRE_POSITION || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Card number')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_REPRE_CARD_ID || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-issue-date')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_REPRE_ISSUE_DATE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Expiry date')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_REPRE_EXPIRE_DATE || ''}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label> {t('txt-issue-place')}</Form.Label>
        <input
          type={'text'}
          className="form-control input-order fz-13"
          value={custDetail?.C_REPRE_ISSUE_PLACE || ''}
          disabled
        />
      </Form.Group>
    </>
  );
}
