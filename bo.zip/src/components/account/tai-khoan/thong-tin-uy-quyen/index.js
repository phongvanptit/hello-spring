import React, { useState } from 'react';

import { Table } from 'react-bootstrap';
import Paging from 'components/paging';
import FormSearchTKUyQuyen from './formSearchTKUyQuyen';
import { makeGetToken } from 'lib/selector';
import { makeGetAccountAuthorList } from 'lib/selector';
import { connect, useDispatch } from 'react-redux';
import { translate } from 'react-i18next';

import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';

import DetailTTUyQuyenModal from 'components/modal/account/tai-khoan/thong-tin-uy-quyen/DetailTTUyQuyenModal';
import { GroupButton } from 'utils/styledComponent';
import NodataSearch from 'components/noDataSearch';
import { confirmAlert } from 'react-confirm-alert';
import { accAuthorApproveRequest } from 'containers/account/actions';
import { accAuthorDelRequest } from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';

function ThongTinQuyQuyenComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [pkAuthor, setPkAuthor] = useState(null);

  const { accountList, t, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleClose() {
    setPkAuthor(null);
  }

  function handleConfirm(actionName, pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-author-info')
                : actionName === 'approve'
                ? t('txt-appr-author-info')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel(pk);
                    break;
                  case 'approve':
                    handleActionApprove(pk);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ID: pk,
      },
    };

    dispatch(accAuthorDelRequest(params));
  }

  function handleActionApprove(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_SINGLE_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ID: pk,
      },
    };

    dispatch(accAuthorApproveRequest(params));
  }

  return (
    <>
      <div className="custom-tabs-content my-3">
        <div className="w-100 d-flex flex-column">
          <FormSearchTKUyQuyen page={page} recordPerPage={recordPerPage} />
          <Table bordered>
            <thead>
              <tr>
                {/* <th>{t('txt-author-type')}</th> */}
                <th>{t('txt-acc')}</th>
                <th>{t('txt-acc-name')}</th>
                <th>{t('txt-cust-code')}</th>
                <th>{t('txt-cust-name')}</th>
                <th>{t('txt-from-date')}</th>
                <th>{t('txt-to-date')}</th>
                <th>{t('txt-note')}</th>
                <th>{t('txt-active')}</th>
                <th>{t('txt-status')}</th>
                <th>{t('txt-action')}</th>
              </tr>
            </thead>
            <tbody>
              {accountList &&
                accountList.map((item) => (
                  <tr key={item.PK_ACCOUNT_AUTHOR}>
                    {/* <td className="text-center">
                      <a onClick={() => setPkAuthor(item.PK_ACCOUNT_AUTHOR)}>
                        {item.C_AUTHOR_TYPE}
                      </a>
                    </td> */}
                    <td className="text-center">
                      <a onClick={() => setPkAuthor(item.PK_ACCOUNT_AUTHOR)}>
                        {item.C_ACCOUNT_CODE}
                      </a>
                    </td>
                    <td className="">{item.C_ACCOUNT_NAME}</td>
                    <td className="text-center">
                      <a onClick={() => setPkAuthor(item.PK_ACCOUNT_AUTHOR)}>
                        {item.C_CUSTOMER_CODE}
                      </a>
                    </td>
                    <td className="">{item.C_CUSTOMER_NAME}</td>
                    <td className="text-center">
                      {item.C_EFFECT_DATE
                        ? item.C_EFFECT_DATE.split(' ')[0]
                        : ''}
                    </td>
                    <td className="text-center">
                      {item.C_EXPIRE_DATE
                        ? item.C_EXPIRE_DATE.split(' ')[0]
                        : ''}
                    </td>
                    <td className="">{item.C_CONTENT}</td>
                    <td className="">{item.C_ACTIVE_NAME}</td>
                    <td className={'text-center orderStt_' + item.C_STATUS}>
                      {item.C_STATUS}
                    </td>
                    <td className="text-center p-0 w_85">
                      <GroupButton>
                        {accRight?.C_VIEW === 1 && (
                          <a
                            title={t('txt-detail')}
                            onClick={() => setPkAuthor(item.PK_ACCOUNT_AUTHOR)}
                          >
                            <IconCopy />
                          </a>
                        )}
                        {accRight?.C_APPROVE === 1 &&
                          item?.C_STATUS !== 'DA_DUYET' && (
                            <a
                              title={t('txt-appr')}
                              onClick={() =>
                                handleConfirm('approve', item.PK_ACCOUNT_AUTHOR)
                              }
                            >
                              <IconAppr />
                            </a>
                          )}
                        {accRight?.C_UPDATE === 1 && 
                          item?.C_STATUS === 'CHUA_DUYET' &&
                          item?.C_APPROVER_CODE === '' &&(
                          <a
                            title={t('txt-del')}
                            onClick={() =>
                              handleConfirm('delete', item.PK_ACCOUNT_AUTHOR)
                            }
                          >
                            <IconTrash />
                          </a>
                        )}
                      </GroupButton>
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
          {(!accountList || !accountList.length) && (
            <NodataSearch name={t('txt-acc-1')} />
          )}
          <div className="mt-3 d-flex justify-content-end">
            <Paging
              page={page}
              nextPage={_handleNextPage}
              recordPerPage={recordPerPage}
              setRecordPerPage={setRecordPerPage}
              total={
                (accountList &&
                  !!accountList.length &&
                  accountList[0].C_TOTAL_RECORD) ||
                0
              }
            />
          </div>
        </div>
      </div>
      {pkAuthor && accRight?.C_VIEW === 1 && (
        <DetailTTUyQuyenModal
          id={pkAuthor}
          onClose={handleClose}
          accRight={accRight}
        />
      )}
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountAuthorList = makeGetAccountAuthorList();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountAuthorList(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(ThongTinQuyQuyenComponent)
);
