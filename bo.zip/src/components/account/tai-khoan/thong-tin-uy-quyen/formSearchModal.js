import RenderInput from 'components/input/renderInput';
import { accountAuthorSearchRequest } from 'containers/account/actions';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';

import { makeGetSystemInfo, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import { arrSearchTTUyQuyen } from 'utils/const';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    handleSubmit,
    submitting,

    t,
    setDataSearch,
    onClose,
    onTriggerPopover,
    sysSystemInfo,
    dataSearch,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchTTUyQuyen, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.CUSTOMER_CODE = values.formCustCode;
    dispatch(accountAuthorSearchRequest(_dataSearch));
    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchTKUyQuyenModal', 'formCustCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchTTUyQuyen,
              (o) => o?.value === item
            );

            if (!_objItem) return null;
            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formAccountCode'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchTKUyQuyenModal',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchTKUyQuyenModal');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const getToken = makeGetToken();
  const mapStateToProps = (state, props) => {
    const { formCustCode, formAccountCode } = selector(
      state,
      'formCustCode',
      'formAccountCode'
    );

    const { dataSearch } = props;

    return {
      sysSystemInfo: getSystemInfo(state),
      token: getToken(state),
      formCustCode,
      formAccountCode,
      initialValues: {
        formCustCode: dataSearch?.data?.CUSTOMER_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
