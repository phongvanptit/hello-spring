import RenderSearchShort from 'components/input/inputSearchShort';
import React, { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import * as _ from 'lodash';
import IconConfig from 'assets/img/icon/cog.png';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  accountHolderApproveSuccess,
  accHolderDelSuccess,
  accHolderSearchRequest,
  accHolderUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeAccHolderAppr,
  makeAccHolderDel,
  makeAccHolderUpdate,
} from 'lib/selector';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    accHolderUpd,
    accHolderDel,
    accHolderAppr,
  } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preAccHolderUpd = usePrevious(accHolderUpd);
  const preAccHolderDel = usePrevious(accHolderDel);
  const preAccHolderAppr = usePrevious(accHolderAppr);

  React.useEffect(() => {
    if (accHolderUpd && !_.isEqual(accHolderUpd, preAccHolderUpd)) {
      dispatch(accHolderUpdSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accHolderUpd]);

  React.useEffect(() => {
    if (accHolderDel && !_.isEqual(accHolderDel, preAccHolderDel)) {
      _handleToast(`${t('txt-del-service-success')}`);
      dispatch(accHolderDelSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accHolderDel]);

  React.useEffect(() => {
    if (accHolderAppr && !_.isEqual(accHolderAppr, preAccHolderAppr)) {
      _handleToast(`${t('txt-appr-service-success')}`);
      dispatch(accountHolderApproveSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accHolderAppr]);

  useEffect(() => {
    setTimeout(() => {
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
  }, []);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;

    dispatch(accHolderSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    if (refSubmit.current) refSubmit.current.click();
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)}>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
      <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortAccHolder',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortAccHolder');

const makeMapStateToProps = () => {
  const getAccHolderUpdate = makeAccHolderUpdate();
  const getAccHolderDel = makeAccHolderDel();
  const getAccountHolderAppr = makeAccHolderAppr();

  const mapStateToProps = (state) => {
    const { formAccountCode, formAccountName } = selector(
      state,
      'formAccountCode',
      'formAccountName'
    );

    return {
      accHolderUpd: getAccHolderUpdate(state),
      accHolderDel: getAccHolderDel(state),
      accHolderAppr: getAccountHolderAppr(state),
      formAccountCode,
      formAccountName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
