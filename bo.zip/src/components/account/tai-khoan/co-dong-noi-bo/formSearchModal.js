import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import RenderSelectDate from 'components/input/renderDatePicker';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { accHolderSearchRequest } from 'containers/account/actions';
import { formatDate, stringToDate } from 'utils';
import { makeGetSystemInfo } from 'lib/selector';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
  } = props;

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formAccountCode;
    _dataSearch.data.ACCOUNT_NAME = values.formAccountName;
    _dataSearch.data.PHONE_NUMBER = values.formMobile;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    _dataSearch.data.FROM_DATE = values.formStartDate;
    _dataSearch.data.TO_DATE = values.formEndDate;
    _dataSearch.data.STATUS = '';

    dispatch(accHolderSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalAccHolder', 'formAccountType', ''));
    dispatch(change('formSearchModalAccHolder', 'formShareCode', ''));
    dispatch(change('formSearchModalAccHolder', 'formBranchCode', ''));
    dispatch(change('formSearchModalAccHolder', 'formCreatorCode', ''));
    dispatch(
      change(
        'formSearchModalAccHolder',
        'formStartDate',
        formatDate(_date, '/', 'dmy')
      )
    );
    dispatch(
      change(
        'formSearchModalAccHolder',
        'formEndDate',
        formatDate(
          sysSystemInfo
            ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
            : new Date(),
          '/',
          'dmy'
        )
      )
    );
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        <Form.Group>
          <Form.Label className="fz-13">Nhóm cổ đông</Form.Label>
          <Field
            name="formAccountType"
            type="text"
            className="form-control"
            placeholder={'Nhóm cổ đông'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Mã chứng khoán</Form.Label>
          <Field
            name="formShareCode"
            type="text"
            className="form-control"
            placeholder={'Mã chứng khoán'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Mã phòng GD</Form.Label>
          <Field
            name="formBranchCode"
            type="text"
            className="form-control"
            placeholder={t('txt-creator')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Người tạo</Form.Label>
          <Field
            name="formCreatorCode"
            type="text"
            className="form-control"
            placeholder={'Người tạo'}
            component={RenderInput}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
          <Field
            className="form-control"
            name="formStartDate"
            type="start"
            component={RenderSelectDate}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
          <Field
            className="form-control"
            name="formEndDate"
            type="end"
            component={RenderSelectDate}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalAccHolder',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalAccHolder');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      formAccountType,
      formShareCode,
      formBranchCode,
      formCreatorCode,
      formStartDate,
      formEndDate,
    } = selector(
      state,
      'formAccountType',
      'formShareCode',
      'formBranchCode',
      'formCreatorCode',
      'formStartDate',
      'formEndDate'
    );

    const { dataSearch } = props;

    return {
      getSystemInfo: getSystemInfo(state),
      formAccountType,
      formShareCode,
      formBranchCode,
      formCreatorCode,
      formStartDate,
      formEndDate,

      initialValues: {
        formAccountType: dataSearch?.data?.HOLDER_TYPE,
        formShareCode: dataSearch?.data?.SHARE_CODE,
        formBranchCode: dataSearch?.data?.BRANCH_CODE,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
