import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import RenderSelectDate from 'components/input/renderDatePicker';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { accMarketSearchRequest } from 'containers/account/actions';
import { formatDate, stringToDate } from 'utils';
import { makeGetSystemInfo } from 'lib/selector';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
  } = props;

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formAccountCode;
    _dataSearch.data.ACCOUNT_NAME = values.formAccountName;
    _dataSearch.data.MARKET_CODE = values.formMobile;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    _dataSearch.data.FROM_DATE = values.formStartDate;
    _dataSearch.data.TO_DATE = values.formEndDate;

    dispatch(accMarketSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalAccMarket', 'formAccountCode', ''));
    dispatch(change('formSearchModalAccMarket', 'formAccountName', ''));
    dispatch(change('formSearchModalAccMarket', 'formCreatorCode', ''));
    dispatch(change('formSearchModalAccMarket', 'formMarketCode', ''));
    dispatch(
      change(
        'formSearchModalAccMarket',
        'formStartDate',
        formatDate(_date, '/', 'dmy')
      )
    );
    dispatch(
      change(
        'formSearchModalAccMarket',
        'formEndDate',
        formatDate(
          sysSystemInfo
            ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
            : new Date(),
          '/',
          'dmy'
        )
      )
    );
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-5 w-100">
        <Form.Group>
          <Form.Label className="fz-13">Tài khoản</Form.Label>
          <Field
            name="formAccountCode"
            type="text"
            className="form-control"
            placeholder={'Tài khoản'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Tên tài khoản</Form.Label>
          <Field
            name="formAccountName"
            type="text"
            className="form-control"
            placeholder={'Tên tài khoản'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Thị trường</Form.Label>
          <Field
            name="formMarketCode"
            type="text"
            className="form-control"
            placeholder={'Tên tài khoản'}
            component={RenderInput}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
          <Field
            className="form-control"
            name="formStartDate"
            type="start"
            component={RenderSelectDate}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
          <Field
            className="form-control"
            name="formEndDate"
            type="end"
            component={RenderSelectDate}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Người tạo</Form.Label>
          <Field
            name="formCreatorCode"
            type="text"
            className="form-control"
            placeholder={'Tên tài khoản'}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalAccMarket',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalAccMarket');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      formAccountCode,
      formAccountName,
      formCreatorCode,
      formStartDate,
      formEndDate,
      formMarketCode,
    } = selector(
      state,
      'formAccountCode',
      'formAccountName',
      'formCreatorCode',
      'formStartDate',
      'formEndDate',
      'formMarketCode'
    );

    const { dataSearch } = props;

    return {
      getSystemInfo: getSystemInfo(state),
      formAccountCode,
      formAccountName,
      formCreatorCode,
      formStartDate,
      formEndDate,
      formMarketCode,

      initialValues: {
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formAccountName: dataSearch?.data?.ACCOUNT_NAME,
        formMarketCode: dataSearch?.data?.MARKET_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
