import RenderSearchShort from 'components/input/inputSearchShort';
import React, { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import * as _ from 'lodash';
import IconConfig from 'assets/img/icon/cog.png';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  accMarketDelSuccess,
  accMarketSearchRequest,
  accMarketUpdSuccess,
  accMarketApproveSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeAccMarketAppr,
  makeAccMarketDel,
  makeAccMarketUpdate,
} from 'lib/selector';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    accMarketUpd,
    accMarketDel,
    accMarketAppr,
  } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preAccMarketUpd = usePrevious(accMarketUpd);
  const preAccHolderDel = usePrevious(accMarketDel);
  const preAccAppr = usePrevious(accMarketAppr);

  React.useEffect(() => {
    if (accMarketUpd && !_.isEqual(accMarketUpd, preAccMarketUpd)) {
      dispatch(accMarketUpdSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accMarketUpd]);

  React.useEffect(() => {
    if (accMarketDel && !_.isEqual(accMarketDel, preAccHolderDel)) {
      _handleToast(`${t('txt-del-service-success')}`);
      dispatch(accMarketDelSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accMarketDel]);

  React.useEffect(() => {
    if (accMarketAppr && !_.isEqual(accMarketAppr, preAccAppr)) {
      _handleToast(`${t('Duyệt liên kết tài khoản thành công')}`);
      dispatch(accMarketApproveSuccess(null));
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accMarketAppr]);

  useEffect(() => {
    setTimeout(() => {
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
  }, []);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;

    dispatch(accMarketSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    if (refSubmit.current) refSubmit.current.click();
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)}>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
      <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortAccMarket',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortAccMarket');

const makeMapStateToProps = () => {
  const getAccMarketUpdate = makeAccMarketUpdate();
  const getAccMarketDel = makeAccMarketDel();
  const getAccMarketAppr = makeAccMarketAppr();

  const mapStateToProps = (state) => {
    const { formAccountCode, formAccountName } = selector(
      state,
      'formAccountCode',
      'formAccountName'
    );

    return {
      accMarketUpd: getAccMarketUpdate(state),
      accMarketDel: getAccMarketDel(state),
      accMarketAppr: getAccMarketAppr(state),
      formAccountCode,
      formAccountName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
