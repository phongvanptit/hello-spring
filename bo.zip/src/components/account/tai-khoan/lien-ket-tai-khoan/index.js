import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import FormSearchAccHolder from './formSearch';
import {
  makeGetToken,
  makeAccMarketListSearch,
  makeGetAuthenType,
} from 'lib/selector';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import NodataSearch from 'components/noDataSearch';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import DetailAccountModal from 'components/modal/account/tai-khoan/lien-ket-tai-khoan/DetailAccount';
//import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
import { confirmAlert } from 'react-confirm-alert';
import { accMarketDelRequest } from 'containers/account/actions';
import { accMarketApproveRequest } from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';

function AccountMarketComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);
  const [accountDetail, setAccountDetail] = useState(null);
  const { accMarketList, t, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
    setAccountDetail(null);
  }

  function handleConfirm(actionName, record) {
    if (record.C_STATUS === 'DA_DUYET' && actionName === 'approve') return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'close'
                ? t('txt-del-service')
                : actionName === 'approve'
                ? t('txt-appr-service')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'close':
                    handleActionClose(record);
                    break;
                  case 'approve':
                    handleActionApprove(record);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_ACCOUNT_MARKET,
      },
    };

    dispatch(accMarketDelRequest(params));
  }

  function handleActionApprove(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_ACCOUNT_MARKET,
        NEW_STATUS: 'MAPPING',
      },
    };

    dispatch(accMarketApproveRequest(params));
  }

  return (
    <>
      <div className="w-100 d-flex flex-column custom-tabs-content my-3">
        <FormSearchAccHolder page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th>Tài khoản</th>
              <th>Tên tài khoản</th>
              <th>Thị trường</th>
              <th>Ngày liên kết</th>
              <th>ID liên kết</th>
              <th>Ngày hủy</th>
              <th>ID hủy</th>
              <th>Trạng thái</th>
              <th>{t('txt-creator')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {accMarketList &&
              accMarketList.map((item) => (
                <tr key={item.PK_ACCOUNT_MARKET}>
                  
                  <td className="text-center">
                    <a onClick={() => handleDetail(item.PK_ACCOUNT_HOLDER)}>
                      {item.C_ACCOUNT_CODE}
                    </a>
                  </td>

                  <td className="text-center">{item.C_ACCOUNT_NAME}</td>
                  <td className="text-center">{item.C_MARKET_CODE}</td>
                  <td className="text-center">{item.C_OPEN_DATE}</td>
                  <td className="text-center">{item.C_OPEN_ID}</td>
                  <td className="text-center">
                    {item.C_CLOSE_DATE ? item.C_CLOSE_DATE.split(' ')[0] : ''}
                  </td>
                  <td className="text-center">{item.C_CLOSE_ID}</td>
                  <td className={'text-center orderStt_' + item.C_STATUS}>
                    {item.C_STATUS}
                  </td>
                  <td className="text-center">{item.C_CREATOR_CODE}</td>
                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      <a
                        title={t('txt-detail')}
                        onClick={() => handleDetail(item.PK_ACCOUNT_MARKET)}
                      >
                        <IconCopy />
                      </a>

                      {accRight?.C_APPROVE === 1 &&
                        item?.C_STATUS === 'CHO_LIEN_KET' && (
                          <a
                            title={t('txt-appr')}
                            onClick={() => handleConfirm('approve', item)}
                          >
                            <IconAppr />
                          </a>
                        )}
                      {accRight?.C_UPDATE === 1 &&
                        item?.C_STATUS === 'CHO_LIEN_KET' && (
                          <a
                            title={t('txt-del')}
                            onClick={() => handleConfirm('close', item)}
                          >
                            <IconTrash />
                          </a>
                        )}
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!accMarketList || !accMarketList.length) && (
          <NodataSearch name={t('txt-acc-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (accMarketList &&
                !!accMarketList.length &&
                accMarketList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {/* {accountDetail && (
          <DetailAccountModal
            accountCode={accountDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )} */}
        {detailAccInt && (
          <DetailAccountModal
            onClose={onClose}
            id={detailAccInt}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccMarketListSearch = makeAccMarketListSearch();
  const getAccountRight = makeGetAccountRight();
  const getAuthenType = makeGetAuthenType();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accMarketList: getAccMarketListSearch(state),
      glAuthenType: getAuthenType(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(AccountMarketComponent)
);
