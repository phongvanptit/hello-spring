import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { formatDate } from 'utils';
import RenderInput from 'components/input/renderInput';
import { accListSearchRequest } from 'containers/account/actions';
import { makeGetCustType } from 'lib/selector';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { translate } from 'react-i18next';

import * as _ from 'lodash';
import RenderSelectDate from 'components/input/renderDatePicker';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { makeGetGlobalAccVsdStatus } from 'lib/selector';
import { arrSearchDuyetTTKH } from 'utils/const';
import { makeGetChannelType } from 'lib/selector';
import { makeGetAccountCreditType } from 'lib/selector';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    handleSubmit,
    submitting,
    t,
    glAccCreditType,
    glChannelType,

    dataSearch,
    setDataSearch,
    onClose,
    onTriggerPopover,
    reset,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchDuyetTTKH, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    // _dataSearch.data.ACCOUNT_CODE = values.formAccCode;
    // _dataSearch.data.ACCOUNT_NAME = values.formAccName;
    // _dataSearch.data.CARD_ID = values.formCardID;
    // _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    // _dataSearch.data.VSD_STATUS = values.formVSDStatus;
    // _dataSearch.data.STATUS = values.formStatus;
    // _dataSearch.data.FROM_DATE = values.formStartDate;
    // _dataSearch.data.TO_DATE = values.formEndDate;

    dispatch(accListSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchDuyetTTKH,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formAccCode' &&
              _objItem.value !== 'formAccName'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'date')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    className="form-control"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    onCalendarOpen={() => setCalendarOpen(true)}
                    onCalendarClose={() => setCalendarOpen(false)}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'select') {
              if (_objItem.value === 'formChannel')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={glChannelType}
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formCreditType')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={glAccCreditType}
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formDepositCode')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={[]}
                    />
                  </Form.Group>
                );
            }
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={reset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalTTTK',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalTTTK');

const makeMapStateToProps = () => {
  const getCustType = makeGetCustType();
  const getVsdStatus = makeGetGlobalAccVsdStatus();
  const getChannelType = makeGetChannelType();
  const getAccountCreditType = makeGetAccountCreditType();

  const mapStateToProps = (state, props) => {
    const {
      formAccCode,
      formAccName,
      formDKSH,
      formCreatorCode,
      formBranchCode,
      formSubBranchCode,
      formMKTID,
      formStartDate,
      formEndDate,
      formChannel,
      formCreditType,
      formCommPackage,
      formDepositCode,
    } = selector(
      state,
      'formAccCode',
      'formAccName',
      'formDKSH',
      'formCreatorCode',
      'formBranchCode',
      'formSubBranchCode',
      'formMKTID',
      'formStartDate',
      'formEndDate',
      'formChannel',
      'formCreditType',
      'formCommPackage',
      'formDepositCode'
    );

    const { dataSearch } = props;

    return {
      glCustType: getCustType(state),
      glVsdStatus: getVsdStatus(state),
      glAccCreditType: getAccountCreditType(state),
      glChannelType: getChannelType(state),

      formAccCode,
      formAccName,
      formDKSH,
      formCreatorCode,
      formBranchCode,
      formSubBranchCode,
      formMKTID,
      formStartDate,
      formEndDate,
      formChannel,
      formCreditType,
      formCommPackage,
      formDepositCode,

      initialValues: {
        // formAccCode: dataSearch?.data?.ACCOUNT_CODE,
        // formAccName: dataSearch?.data?.ACCOUNT_NAME,
        // formCardID: dataSearch?.data?.CARD_ID,
        // formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        // formStatus: dataSearch?.data?.STATUS,
        // formVSDStatus: dataSearch?.data?.VSD_STATUS,
        // formStartDate: dataSearch?.data?.FROM_DATE,
        // formEndDate: dataSearch?.data?.TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
