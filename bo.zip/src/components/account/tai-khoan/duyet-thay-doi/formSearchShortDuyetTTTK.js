import RenderSearchShort from 'components/input/inputSearchShort';
import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import { accChangeAllRequest } from 'containers/account/actions';
import { makeGetAccountChangeAppr } from 'lib/selector';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    accountApprove,
  } = props;

  const preAccountApprove = usePrevious(accountApprove);

  useEffect(() => {
    setTimeout(() => {
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
  }, []);

  useEffect(() => {
    if (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [accountApprove]);

  const submit = (values) => {
    console.log(values);

    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;

    dispatch(accChangeAllRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    if (refSubmit.current) refSubmit.current.click();
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)}>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
      {/* <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDuyetTTTK',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDuyetTTTK');

const makeMapStateToProps = () => {
  const getAccountApprove = makeGetAccountChangeAppr();

  const mapStateToProps = (state) => {
    const { formAccountCode, formAccountName } = selector(
      state,
      'formAccountCode',
      'formAccountName'
    );

    return {
      accountApprove: getAccountApprove(state),

      formAccountCode,
      formAccountName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
