import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accListSearchRequest,
  accountCloseSuccess,
  accountRevertSuccess,
  processCloseAccountSuccess,
  accountApproveVSDSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountClose,
  makeGetAccountCreditType,
  makeGetAccountRevert,
  makeGetProcessCloseAccount,
  makeGetAccountApproveVsd,
} from 'lib/selector';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();

  const {
    handleSubmit,
    t,

    dataSearch,
    setDataSearch,
    accRevert,
    accClose,
    processCloseAccount,
    accountAprVsd,

    accountCode,
    creditType,
    fromDate,
    toDate,
    glAccCreditType,
  } = props;

  const preAccRevert = usePrevious(accRevert);
  const preAccClose = usePrevious(accClose);
  const preProcessCloseAcc = usePrevious(processCloseAccount);
  const preStartDate = usePrevious(fromDate);
  const preEndDate = usePrevious(toDate);
  const preAccountApprVsd = usePrevious(accountAprVsd);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accListSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accRevert && !_.isEqual(accRevert, preAccRevert)) ||
      (accClose && !_.isEqual(accClose, preAccClose))
    ) {
      dispatch(accListSearchRequest(dataSearch));
    }
  }, [accRevert, accClose]);

  useEffect(() => {
    if (accRevert && !_.isEqual(accRevert, preAccRevert)) {
      _handleToast(`${t('txt-open-acc-success')}`);
      dispatch(accountRevertSuccess(null));
    }
  }, [accRevert]);

  useEffect(() => {
    if (
      (accountAprVsd && !_.isEqual(accountAprVsd, preAccountApprVsd)) 
    ) {
      dispatch(accListSearchRequest(dataSearch));
    }
  }, [
    accountAprVsd,
  ]);

  useEffect(() => {
    if (accClose && !_.isEqual(accClose, preAccClose)) {
      _handleToast(`${t('txt-close-acc-success')}`);
      dispatch(accountCloseSuccess(null));
    }
  }, [accClose]);

  useEffect(() => {
    if (processCloseAccount && !_.isEqual(processCloseAccount, preProcessCloseAcc)) {
      _handleToast(`${'Trả lãi tiền gửi thành công'}`);
      dispatch(processCloseAccountSuccess(null));
    }
  }, [processCloseAccount]);

  useEffect(() => {
    if (accountAprVsd && !_.isEqual(accountAprVsd, preAccountApprVsd)) {
      _handleToast(`${'Duyệt đẩy VSD thành công'}`);
      dispatch(accountApproveVSDSuccess(null));
    }
  }, [accountAprVsd]);

  useEffect(() => {
    if (fromDate && !_.isEqual(fromDate, preStartDate)) {
      if (!fromDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [fromDate]);

  useEffect(() => {
    if (toDate && !_.isEqual(toDate, preEndDate)) {
      if (!toDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [toDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = accountCode;
    _params.data.ACCOUNT_CREDIT_TYPE = creditType;
    _params.data.FROM_DATE = fromDate;
    _params.data.TO_DATE = toDate;

    dispatch(accListSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = accountCode;
    _params.data.ACCOUNT_CREDIT_TYPE = creditType;
    _params.data.FROM_DATE = fromDate;
    _params.data.TO_DATE = toDate;

    dispatch(accListSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-credit-type')}</Form.Label>
        <Field
          name="creditType"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glAccCreditType}
          onBlur={_handleBlur}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="fromDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="toDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="accountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDongTK',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDongTK');

const makeMapStateToProps = () => {
  const mapStateToProps = (state) => {
    const getAccountRevert = makeGetAccountRevert();
    const getAccountClose = makeGetAccountClose();
    const getProcessCloseAccount = makeGetProcessCloseAccount();
    const getAccountCreditType = makeGetAccountCreditType();
    const getAccountApproveVsd = makeGetAccountApproveVsd();

    const { accountCode, creditType, fromDate, toDate } = selector(
      state,
      'accountCode',
      'creditType',
      'fromDate',
      'toDate'
    );

    return {
      accRevert: getAccountRevert(state),
      accClose: getAccountClose(state),
      processCloseAccount: getProcessCloseAccount(state),
      glAccCreditType: getAccountCreditType(state),
      accountAprVsd: getAccountApproveVsd(state),

      accountCode,
      accountCode,
      creditType,
      fromDate,
      toDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
