import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { accListSearchRequest } from 'containers/account/actions';
import {
  makeGetChannelType,
  makeGetCustomerDelete,
  makeGetGlobalAccStatus,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { formatDate, stringToDate } from 'utils';
import { arrSearchDongTaiKhoan } from 'utils/const';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const {
    handleSubmit,
    submitting,
    t,
    setDataSearch,
    onClose,
    sysSystemInfo,
    dataSearch,
    glChannelType,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchDongTaiKhoan, 'value'));
  }, []);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_NAME = values.accountName;
    _dataSearch.data.CARD_ID = values.cardId;
    _dataSearch.data.CREATOR_CODE = values.creatorCode;
    _dataSearch.data.BRANCH_CODE = values.branchCode;
    _dataSearch.data.SUB_BRANCH_CODE = values.subBranchCode;
    _dataSearch.data.MARKETING_ID = values.marketingId;
    _dataSearch.data.CHANNEL_CODE = values.channel;
    _dataSearch.data.COMM_CODE = values.commPackage;

    dispatch(accListSearchRequest(_dataSearch));
    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchDongTKModal', 'accountName', ''));
    dispatch(change('formSearchDongTKModal', 'cardId', ''));
    dispatch(change('formSearchDongTKModal', 'creatorCode', ''));
    dispatch(change('formSearchDongTKModal', 'branchCode', ''));
    dispatch(change('formSearchDongTKModal', 'subBranchCode', ''));
    dispatch(change('formSearchDongTKModal', 'marketingId', ''));
    dispatch(
      change('formSearchDongTKModal', 'fromDate', formatDate(_date, '/', 'dmy'))
    );
    dispatch(
      change(
        'formSearchDongTKModal',
        'toDate',
        formatDate(
          sysSystemInfo
            ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
            : new Date(),
          '/',
          'dmy'
        )
      )
    );
    dispatch(change('formSearchDongTKModal', 'channel', ''));
    dispatch(change('formSearchDongTKModal', 'commPackage', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100 ">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchDongTaiKhoan,
              (o) => o?.value === item
            );

            if (!_objItem) return null;
            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'accountCode' &&
              _objItem.value !== 'accountName' &&
              _objItem.value !== 'vpbsType'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'select') {
              if (_objItem.value === 'channel')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={glChannelType}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'depositCode')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={[]}
                      placeholder="-- Tất cả --"
                    />
                  </Form.Group>
                );
            }
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchDongTKModal',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchDongTKModal');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCustomerDelete = makeGetCustomerDelete();
  const getSystemInfo = makeGetSystemInfo();
  const getChannelType = makeGetChannelType();
  const getGlobalAccStatus = makeGetGlobalAccStatus();
  const mapStateToProps = (state, props) => {
    const {
      accountCode,
      accountName,
      cardId,
      creatorCode,
      formStatus,
      branchCode,
      subBranchCode,
      marketingId,
      channel,
      commPackage,
      depositCode,
    } = selector(
      state,
      'accountCode',
      'accountName',
      'cardId',
      'creatorCode',
      'formStatus',
      'branchCode',
      'subBranchCode',
      'marketingId',
      'channel',
      'commPackage',
      'depositCode'
    );
    const { dataSearch } = props;
    return {
      token: getToken(state),
      custDel: getCustomerDelete(state),
      sysSystemInfo: getSystemInfo(state),
      glChannelType: getChannelType(state),
      glAccStatus: getGlobalAccStatus(state),
      accountCode,
      accountName,
      cardId,
      creatorCode,
      formStatus,
      branchCode,
      subBranchCode,
      marketingId,
      channel,
      commPackage,
      depositCode,
      initialValues: {
        accountCode: dataSearch?.data?.ACCOUNT_CODE,
        accountName: dataSearch?.data?.ACCOUNT_NAME,
        cardId: dataSearch?.data?.CARD_ID,
        creatorCode: dataSearch?.data?.CREATOR_CODE,
        branchCode: dataSearch?.data?.BRANCH_CODE,
        subBranchCode: dataSearch?.data?.SUB_BRANCH_CODE,
        marketingId: dataSearch?.data?.MARKETING_ID,
        channel: dataSearch?.data?.CHANNEL_CODE,
        commPackage: dataSearch?.data?.COMM_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
