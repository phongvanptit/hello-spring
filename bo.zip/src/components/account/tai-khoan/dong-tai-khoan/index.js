import DetailCloseAccountModal from 'components/modal/account/tai-khoan/dong-tai-khoan/create';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import { Button } from 'react-bootstrap';

import {
  makeGetAccountListSearch,
  makeGetAccountRight,
  makeGetToken,
} from 'lib/selector';

import {
  accountApproveVSDRequest
} from 'containers/account/actions';
import { useDispatch } from 'react-redux';
import { memo, useState } from 'react';
import { Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaUserLock } from 'react-icons/fa';
import { connect } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './formSearchDongTaiKhoan';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import * as _ from 'lodash';
import { confirmAlert } from 'react-confirm-alert';
import { ReactComponent as IconSend } from 'assets/img/icon/send.svg';

function TabDongTaiKhoan(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [accountDetail, setAccountDetail] = useState(null);
  const { t, accountList, token, accRight } = props;
  const [checkAll, setCheckAll] = useState(false);
  const [orderCheck, setOrderCheck] = useState([]);
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.filter(accountList, (o) => o.C_STATUS === 'DA_DUYET');
      setOrderCheck(_.map(allFunc, 'PK_BACK_ACCOUNT'));
    }
  }

  function handleDetailAccount(item) {
    if (accRight?.C_VIEW !== 1) return;
    setAccountDetail(item);
  }

  function onClose() {
    setAccountDetail(null);
  }

  function handlePushVsd(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-vsd')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
            onClick={() => {
              handleActionPushVSD(pk);
              onClose();
            }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionPushVSD(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_VSD',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk || orderCheck.join(','),
        TYPE: '1',
      },
    };
    setOrderCheck([]);
    dispatch(accountApproveVSDRequest(params));
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content my-3">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            <th style={{ width: '26px' }}>
              {accRight?.C_APPROVE === 1 && (
                <input
                  type={'checkbox'}
                  value={checkAll}
                  onChange={_handleChangeCheckAll}
                  checked={checkAll}
                />
              )}
            </th>
            <th>{t('txt-subBranch')}</th>
            <th>{t('txt-type')}</th>
            <th>{t('txt-acc')}</th>
            <th>{t('txt-acc-depository')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('txt-open-date')}</th>
            <th>{t('txt-close-date')}</th>
            <th>{t('txt-status')}</th>
            <th>{t('txt-vsd-status')}</th>
            <th>{t('txt-creator')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {accountList &&
            accountList.map((item) => (
              <tr
                key={item.ROW_NUM}
                className={
                  _.some(orderCheck, (o) => o === item.PK_BACK_ACCOUNT)
                    ? 'row-checked'
                    : ''
                }
              >
                <td className="text-center">
                  {
                  //item.C_STATUS === 'DA_DUYET' && 
                  item.C_ACCOUNT_CREDIT_TYPE === '0' && 
                  (
                    <input
                      type="checkbox"
                      name={item.PK_BACK_ACCOUNT}
                      onChange={_handleChange}
                      checked={_.some(
                        orderCheck,
                        (o) => o === item.PK_BACK_ACCOUNT
                      )}
                    />
                  )}
                </td>
                <td className="text-center">
                  {item.C_SUB_BRANCH_CODE} - {item.C_BRANCH_NAME}
                </td>
                <td className="text-center">{item.C_ACCOUNT_TYPE}</td>
                <td className="text-center">
                  <a
                    rel="noreferrer noopener"
                    onClick={() => handleDetailAccount(item)}
                  >
                    {item.C_ACCOUNT_CODE}
                  </a>
                </td>
                <td className="text-center">{item.C_DCTERM_CODE}</td>
                <td className="">{item.C_ACCOUNT_NAME}</td>
                <td className="text-center">{item.C_OPEN_DATE}</td>
                <td className="text-center">{item.C_CLOSE_DATE}</td>
                <td className="text-center">{item.C_STATUS_NAME}</td>
                <td className="text-center">{item.C_VSD_STATUS_NAME}</td>
                <td className="text-center">{item.C_CREATOR_CODE}</td>
                <td className="text-center p-0">
                  {accRight?.C_VIEW === 1 && item?.C_STATUS === 'DA_DUYET' && (
                    <GroupButton>
                      <a
                        title={'Chi tiết'}
                        onClick={() => handleDetailAccount(item)}
                      >
                        <FaUserLock />
                      </a>
                      {/*{accRight?.C_APPROVE === 1 && item.C_ACCOUNT_CREDIT_TYPE === '0' && */}
                      {/*<a*/}
                      {/*  title={'Duyệt VSD'}*/}
                      {/*  // className={*/}
                      {/*  //   accRight?.C_APPROVE === 1 ? 'disabled' : ''*/}
                      {/*  // }*/}
                      {/*  rel="noreferrer noopener"*/}
                      {/*  onClick={() => handlePushVsd(item.PK_BACK_ACCOUNT)}*/}
                      {/*>*/}
                      {/*  <IconSend />*/}
                      {/*</a>*/}
                    {/*}*/}
                    </GroupButton>
                  )}
                </td>
              </tr>
            ))}
        </tbody>
      </Table>
      {(!accountList || !accountList.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        {orderCheck && !!orderCheck.length && (
          <Button
            variant="danger"
            className="mr-auto"
            onClick={() => handlePushVsd()}
          >
            Duyệt đẩy VSD
          </Button>
        )}
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (accountList &&
              !!accountList.length &&
              accountList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
      {accountDetail && (
        <DetailCloseAccountModal
          accountCode={accountDetail.C_ACCOUNT_CODE}
          onClose={onClose}
          accRight={accRight}
          id={accountDetail.PK_BACK_ACCOUNT}
        />
      )}
    </div>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountListSearch = makeGetAccountListSearch();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountListSearch(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  memo(translate('translations')(TabDongTaiKhoan))
);
