import React from 'react';


import TabMoTK from './mo-tk/index';
import TabDongTK from './dong-tai-khoan/index';
import TabTKAts from './tai-khoan-ats/index';
import TabUyQuyen from './thong-tin-uy-quyen/index';
import TabCDNB from './co-dong-noi-bo/index';
import TabLienKetTk from './lien-ket-tai-khoan/index';
import TabHanChe from './dich-vu-han-che/index';

function TaiKhoanComponent(props) {
  const { type } = props;

  return (
    <>
      <div className="custom-tabs-content my-3">
        {type === 'mo-tk' && <TabMoTK />}
        {type === 'dong-tk' && <TabDongTK />}
        {type === 'tai-khoan-ats' && <TabTKAts />}
        {type === 'uy-quyen' && <TabUyQuyen />}
        {type === 'co-dong-nb' && <TabCDNB />}
        {type === 'lien-ket-tk' && <TabLienKetTk />}
        {type === 'han-che-tk' && <TabHanChe />}
      </div>
    </>
  );
}

export default TaiKhoanComponent;
