import RenderInput from 'components/input/renderInput';
import { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import { accListSearchRequest } from 'containers/account/actions';
import { makeGetSystemInfo } from 'lib/selector';
import { stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
  } = props;

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formAccountCode;
    _dataSearch.data.ACCOUNT_NAME = values.formAccountName;

    dispatch(accListSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalAcc', 'formAccountCode', ''));
    dispatch(change('formSearchModalAcc', 'formAccountName', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-5 w-100">
        <Form.Group>
          <Form.Label className="fz-13">Tài khoản</Form.Label>
          <Field
            name="formAccountCode"
            type="text"
            className="form-control"
            placeholder={'Tài khoản'}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Tên tài khoản</Form.Label>
          <Field
            name="formAccountName"
            type="text"
            className="form-control"
            placeholder={'Tên tài khoản'}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalAcc',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalAcc');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const {
      formAccountCode,
      formAccountName,
      formCreatorCode,
      formStartDate,
      formEndDate,
      formMarketCode,
    } = selector(
      state,
      'formAccountCode',
      'formAccountName',
      'formCreatorCode',
      'formStartDate',
      'formEndDate',
      'formMarketCode'
    );

    const { dataSearch } = props;

    return {
      getSystemInfo: getSystemInfo(state),
      formAccountCode,
      formAccountName,
      formCreatorCode,
      formStartDate,
      formEndDate,
      formMarketCode,

      initialValues: {
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formAccountName: dataSearch?.data?.ACCOUNT_NAME,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
