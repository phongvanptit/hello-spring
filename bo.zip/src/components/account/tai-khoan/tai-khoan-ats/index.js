import { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import {
  makeGetAccountListSearch,
  makeGetAuthenType,
  makeGetToken,
} from 'lib/selector';
import FormSearchAccHolder from './formSearch';

import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailAccountModal from 'components/modal/account/tai-khoan/tai-khoan-ats/DetailAccount';
import NodataSearch from 'components/noDataSearch';
import { translate } from 'react-i18next';
import { GroupButton } from 'utils/styledComponent';
//import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
import {
  accAtsUpdRequest,
  accMarketApproveRequest,
} from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';

function AccountAtsComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);
  const [accountDetail, setAccountDetail] = useState(null);
  const { accountList, t, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
    setAccountDetail(null);
  }

  function handleConfirm(actionName, record) {
    if (record.C_STATUS === 'DA_DUYET' && actionName === 'approve') return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'close'
                ? t('txt-del-service')
                : actionName === 'approve'
                ? t('txt-appr-service')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'close':
                    handleActionClose(record);
                    break;
                  case 'approve':
                    handleActionApprove(record);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_ATS',
      group: 'LIST',
      data: {
        //LIST_ITEM_ID: record?.PK_ACCOUNT_MARKET,
        ACCOUNT_CODE: record?.C_ACCOUNT_CODE,
        BANK_CODE: '',
        ATS_FLAG: 0,
        BANK_ACCOUNT: '',
      },
    };

    dispatch(accAtsUpdRequest(params));
  }

  function handleActionApprove(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_ACCOUNT_MARKET,
        NEW_STATUS: 'MAPPING',
      },
    };

    dispatch(accMarketApproveRequest(params));
  }

  return (
    <>
      <div className="w-100 d-flex flex-column custom-tabs-content my-3">
        <FormSearchAccHolder page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th>Chi nhánh</th>
              <th>Phòng giao dịch</th>
              <th>Loại</th>
              <th>Tài khoản</th>
              <th>Tên tài khoản</th>
              <th>Ngân hàng</th>
              <th>Số tài khoản ngân hàng</th>

              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {accountList &&
              accountList.map((item) => (
                <tr key={item.PK_BACK_ACCOUNT}>
                  <td className="text-center">{item.C_BRANCH_NAME}</td>
                  <td className="text-center">{item.C_SUB_BRANCH_NAME}</td>

                  <td className="text-center">{item.C_ACCOUNT_TYPE}</td>
                  <td className="text-center">{item.C_ACCOUNT_CODE}</td>
                  <td className="text-center">{item.C_ACCOUNT_NAME}</td>
                  <td className="text-center">{item.C_ATS_BANK}</td>

                  <td className="text-center">{item.C_ATS_BANK_ACCOUNT}</td>

                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      <a
                        title={t('txt-detail')}
                        onClick={() => handleDetail(item.PK_BACK_ACCOUNT)}
                      >
                        <IconCopy />
                      </a>

                      <a
                        title={t('txt-del')}
                        onClick={() => handleConfirm('close', item)}
                      >
                        <IconTrash />
                      </a>
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!accountList || !accountList.length) && (
          <NodataSearch name={t('txt-acc-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (accountList &&
                !!accountList.length &&
                accountList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {/* {accountDetail && (
          <DetailAccountModal
            accountCode={accountDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )} */}
        {detailAccInt && (
          <DetailAccountModal
            onClose={onClose}
            id={detailAccInt}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountListSearch = makeGetAccountListSearch();
  const getAccountRight = makeGetAccountRight();
  const getAuthenType = makeGetAuthenType();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountListSearch(state),
      glAuthenType: getAuthenType(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(AccountAtsComponent)
);
