import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';

import { BsThreeDots } from 'react-icons/bs';
import MarketingIDModal from 'components/modal/MarketingModal.js';

import * as _ from 'lodash';

export function CustomerCreateInfo({ custDetail, t }) {
  const [isOpen, setIsOpen] = useState(false);
  function _onClose() {
    setIsOpen(false);
  }

  return (
    <>
      <Form.Group>
        <Form.Label>{t('Full name / Organization name')}</Form.Label>
        <input
          name="customerName"
          type={'text'}
          value={custDetail?.C_CUSTOMER_NAME || ''}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Stock account at APEC')}</Form.Label>
        <input
          name="accountCode"
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-marketing-id')}</Form.Label>
        <div className="w-100 d-flex flex-row">
          <input
            name="marketingId"
            type={'text'}
            className="form-control input-order fz-13"
            disabled
          />
          <Button
            style={{ height: '30px' }}
            className="d-flex align-items-center ml-2"
            onClick={() => setIsOpen(true)}
          >
            <BsThreeDots />
          </Button>
        </div>
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Resident address / Headquarters')}</Form.Label>
        <input
          name="resedenseAddress"
          value={custDetail?.C_RESEDENCE_ADDRESS || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-address')}</Form.Label>
        <input
          name="contactAddress"
          value={custDetail?.C_CUST_ADDRESS || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-branch')}</Form.Label>
        <input
          name="branchName"
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Transaction office')}</Form.Label>
        <input
          name="subBranchName"
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Ownership registration number')}</Form.Label>
        <input
          name="cardID"
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-issue-date')}</Form.Label>
        <input
          name="issueDate"
          value={custDetail?.C_ISSUE_DATE || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label> {t('txt-issue-place')}</Form.Label>
        <input
          name="issuePlace"
          value={custDetail?.C_ISSUE_PLACE || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Date of birth')}</Form.Label>
        <input
          name="birthDay"
          value={custDetail?.C_BIRTH_DAY || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Phone')}</Form.Label>
        <input
          name="phone"
          value={custDetail?.C_CUST_TEL || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Fax')}</Form.Label>
        <input
          name="fax"
          value={custDetail?.C_CUST_FAX || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-mobile')}</Form.Label>
        <input
          name="mobile"
          value={custDetail?.C_CUST_MOBILE || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-email')}</Form.Label>
        <input
          name="email"
          value={custDetail?.C_CUST_EMAIL || ''}
          type={'text'}
          className="form-control input-order fz-13"
          disabled
        />
      </Form.Group>
      {isOpen && <MarketingIDModal onClose={_onClose} />}
    </>
  );
}
