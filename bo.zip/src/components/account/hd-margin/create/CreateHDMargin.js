import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';

import { connect, useDispatch } from 'react-redux';

import { TiArrowBack } from 'react-icons/ti';
import { Button, Card, Form } from 'react-bootstrap';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import { BsThreeDots } from 'react-icons/bs';

import RenderInput from 'components/input/renderInput';
import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { formatDate } from 'utils';
import { required } from 'utils/validation';
import { CustomerCreateInfo } from './CustomerCreateInfo';

import * as _ from 'lodash';
import { translate } from 'react-i18next';

import { makeGetToken, makeGetCustomerDetail } from 'lib/selector';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import RenderInputMask from 'components/input/renderInputMask';

function CreateHDMargin(props) {
  const { token, custDetail, custCode, t } = props;

  const history = useHistory();
  const dispatch = useDispatch();

  React.useEffect(() => {
    return () => {
      // clear
      dispatch(custDetailSuccess(null));
    };
  }, []);

  function submit(values) {
    console.log(values);
  }

  function _handleCheckCustomer() {
    if (!custCode) {
      // dispatch(touch('addAccountInfoform', 'custCode'))
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  const handleKeyDownCustomerCode = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      _handleCheckCustomer();
    }
  };
  const { handleSubmit, submitting, reset } = props;
  return (
    <>
      <div className="d-flex align-items-center mt-2">
        <label className="title-header mb-0 mr-auto">
          {t('Add new margin contract')}
        </label>

        <a
          className="btn-add btn btn-warning text-white"
          onClick={() => history.goBack()}
        >
          <TiArrowBack className="mr-1" /> {t('Back')}
        </a>
      </div>
      <Card className="mt-2 mb-3">
        <Card.Body>
          <form onSubmit={handleSubmit(submit)} className="form-add">
            <div
              className="d-grid grid-4 mb-2"
              style={{ alignItems: 'baseline' }}
            >
              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                {t('Account information / Investor')}
              </p>
              <Form.Group>
                <Form.Label>
                  {t('Account code')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <div className="w-100 d-flex flex-row">
                  <Field
                    name="custCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    validate={[required]}
                    component={RenderInput}
                    onKeyDown={handleKeyDownCustomerCode}
                  />
                  <Button
                    style={{ height: '30px' }}
                    className="d-flex align-items-center ml-2"
                    onClick={_handleCheckCustomer}
                  >
                    <BsThreeDots />
                  </Button>
                </div>
              </Form.Group>

              <CustomerCreateInfo custDetail={custDetail} t={t} />

              <hr style={{ gridColumn: '1/5' }} className="my-1" />
              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                {t('Authorized person')}
              </p>
              <Form.Group>
                <Form.Label>
                  {t('Authorized person')} {t('if any')}{' '}
                </Form.Label>
                <input
                  name="authorName"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('ID Card/ Passport No')}</Form.Label>
                <input
                  name="asuthorCardId"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-issue-date')}</Form.Label>
                <input
                  name="authorIssueDate"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label> {t('txt-issue-place')}</Form.Label>
                <input
                  name="authorIssuePlace"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <hr style={{ gridColumn: '1/5' }} className="my-1" />
              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                {t('Contract information')}
              </p>
              <Form.Group>
                <Form.Label>
                  {t('Contract number')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="contractCode"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderInput}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Product type')}</Form.Label>
                <Field
                  name="ddlProduct"
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={[]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-creator-editor')}</Form.Label>
                <input
                  name="CreatorCode"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Create time / Repair time')}</Form.Label>
                <input
                  name="createTime"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('Open date')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="openDate"
                  className="form-control"
                  classParentName="w-100"
                  component={RenderSelectDate}
                  startDate={formatDate(new Date(), '/', 'dmy')}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Close date')}</Form.Label>
                <Field
                  name="liquidDate"
                  className="form-control"
                  classParentName="w-100"
                  component={RenderSelectDate}
                  startDate={formatDate(new Date(), '/', 'dmy')}
                />
              </Form.Group>
              <span style={{ gridColumn: '3/5' }} />
              <Form.Group>
                <Form.Label>{t('Disbursement source')}</Form.Label>
                <Field
                  name="ddlBank"
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={[]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('Loan type')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <div className="w-100 d-flex flex-row">
                  <Field
                    name="loanType"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                  <Button
                    style={{ height: '30px' }}
                    className="d-flex align-items-center ml-2"
                  >
                    <BsThreeDots />
                  </Button>
                </div>
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('Limit contract')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="loanLimit"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderInputMask}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Contract type')}</Form.Label>
                <Field
                  name="contractType"
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={[]}
                />
              </Form.Group>
              <Form.Group
                className="d-flex justify-content-between"
                style={{ gridColumn: '1/3' }}
              >
                <label>
                  <Field
                    name="chkEEContractFlag"
                    component="input"
                    type="checkbox"
                  />{' '}
                  {t('Signed EE')}
                </label>
                <label>
                  <Field
                    name="chkStatusFlag"
                    component="input"
                    type="checkbox"
                  />{' '}
                  {t('Full profile')}
                </label>
                <label>
                  <Field name="chkHMBTFlag" component="input" type="checkbox" />{' '}
                  {t('Signed abnormal limit')}
                </label>
                <label>
                  <Field
                    name="chkReDeliver"
                    component="input"
                    type="checkbox"
                  />{' '}
                  {t('Liquidation of re-signed')}
                </label>
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-content')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderArea}
                  rows="2"
                />
              </Form.Group>
            </div>
            <hr style={{ gridColumn: '1/5' }} className="my-1" />
            <div className="d-flex justify-content-center mt-2">
              <Button
                variant="outline-primary w_125"
                type="button"
                disabled={submitting}
                onClick={reset}
                className="font-weight-bold fz-13 rounded"
              >
                {t('Delete')}
              </Button>
              <Button
                type="submit"
                disabled={submitting}
                className="font-weight-bold fz-13 ml-2 w_125"
              >
                {t('txt-accept')}
              </Button>
            </div>
          </form>
        </Card.Body>
      </Card>
    </>
  );
}

CreateHDMargin = reduxForm({
  form: 'addHDMarginform',
  enableReinitialize: true,
})(CreateHDMargin);

const selector = formValueSelector('addHDMarginform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCustomerDetail = makeGetCustomerDetail();

  const {
    custCode,
    contractCode,
    ddlProduct,
    openDate,
    liquidDate,
    ddlBank,
    loanType,
    loanLimit,
    contractType,
    formNote,
    chkEEContractFlag,
    chkStatusFlag,
    chkHMBTFlag,
    chkReDeliver,
  } = selector(
    state,
    'custCode',
    'contractCode',
    'ddlProduct',
    'openDate',
    'liquidDate',
    'ddlBank',
    'loanType',
    'loanLimit',
    'contractType',
    'formNote',
    'chkEEContractFlag',
    'chkStatusFlag',
    'chkHMBTFlag',
    'chkReDeliver'
  );

  return {
    token: getToken(state),
    custDetail: getCustomerDetail(state),
    custCode,

    ddlProduct,
    openDate,
    liquidDate,
    ddlBank,
    loanType,
    loanLimit,
    contractType,
    formNote,
    chkEEContractFlag,
    chkStatusFlag,
    chkHMBTFlag,
    chkReDeliver,
    initialValues: {},
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateHDMargin)
);
