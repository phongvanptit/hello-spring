import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';

import { connect, useDispatch } from 'react-redux';

import { TiArrowBack } from 'react-icons/ti';
import { Button, Card, Form } from 'react-bootstrap';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import { BsThreeDots } from 'react-icons/bs';

import RenderInput from 'components/input/renderInput';
import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import { formatDate } from 'utils';
import { required, lengthRequired } from 'utils/validation';
import { AccountCreateInfo } from './AccountCreateInfo';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';

import * as _ from 'lodash';
import { translate } from 'react-i18next';

import { makeGetToken, makeGetAccountSingle } from 'lib/selector';
const length7 = lengthRequired(7);
function CreateHMBT(props) {
  const { token, accountCode, accDetail, t } = props;

  const history = useHistory();
  const dispatch = useDispatch();

  React.useEffect(() => {
    return () => {
      // clear
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  function submit(values) {
    console.log(values);
  }

  function _handleCheckAccount() {
    if (!accountCode) {
      // dispatch(touch('addAccountInfoform', 'custCode'))
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: accountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  const handleKeyDownAccountCode = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      _handleCheckAccount();
    }
  };

  const { handleSubmit, submitting, reset } = props;

  return (
    <>
      <div className="d-flex align-items-center mt-2">
        <label className="title-header mb-0 mr-auto">
          {t('Add new abnormal limit')}
        </label>

        <a
          className="btn-add btn btn-warning text-white"
          onClick={() => history.goBack()}
        >
          <TiArrowBack className="mr-1" />
          {t('Back')}
        </a>
      </div>
      <Card className="mt-2 mb-3">
        <Card.Body>
          <form onSubmit={handleSubmit(submit)} className="form-add">
            <div
              className="d-grid grid-4 mb-2"
              style={{ alignItems: 'baseline' }}
            >
              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                {t('Account information')}
              </p>
              <Form.Group>
                <Form.Label>
                  {t('Account')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <div className="w-100 d-flex flex-row">
                  <Field
                    name="accountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required, length7]}
                    onKeyDown={handleKeyDownAccountCode}
                  />
                  <Button
                    style={{ height: '30px' }}
                    className="d-flex align-items-center ml-2"
                    onClick={_handleCheckAccount}
                  >
                    <BsThreeDots />
                  </Button>
                </div>
              </Form.Group>

              <AccountCreateInfo accDetail={accDetail} t={t} />

              <hr style={{ gridColumn: '1/5' }} className="my-1" />
              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                {t('Contract information')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-creator-editor')}</Form.Label>
                <input
                  name="creatorcode"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Create time / Repair time')}</Form.Label>
                <input
                  name="createTime"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Approver')}</Form.Label>
                <input
                  name="approverCode"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label> {t('Approval time')}</Form.Label>
                <input
                  name="approverTime"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('Contract number')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <input
                  name="contractCode"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('Open date')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="openDate"
                  className="form-control"
                  classParentName="w-100"
                  component={RenderSelectDate}
                  startDate={formatDate(new Date(), '/', 'dmy')}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('Expiry date')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="liquidDate"
                  className="form-control"
                  classParentName="w-100"
                  component={RenderSelectDate}
                  startDate={formatDate(new Date(), '/', 'dmy')}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('Liquidation date')}</Form.Label>
                <input
                  name="liquidDate"
                  type={'text'}
                  className="form-control input-order fz-13"
                  disabled
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>
                  {t('txt-content')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderArea}
                  rows="2"
                  validate={[required]}
                />
              </Form.Group>
            </div>
            <hr style={{ gridColumn: '1/5' }} className="my-1" />
            <div className="d-flex justify-content-center mt-2">
              <Button
                variant="outline-primary w_125"
                type="button"
                disabled={submitting}
                onClick={reset}
                className="font-weight-bold fz-13 rounded"
              >
                {t('Delete')}
              </Button>
              <Button
                type="submit"
                disabled={submitting}
                className="font-weight-bold fz-13 ml-2 w_125"
              >
                {t('txt-accept')}
              </Button>
            </div>
          </form>
        </Card.Body>
      </Card>
    </>
  );
}

CreateHMBT = reduxForm({
  form: 'addHMBTform',
  enableReinitialize: true,
})(CreateHMBT);

const selector = formValueSelector('addHMBTform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();

  const { accountCode, openCode, liquidDate } = selector(
    state,
    'accountCode',
    'accountCode',
    'openCode',
    'liquidDate'
  );

  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    accountCode,
    openCode,
    liquidDate,
    initialValues: {},
  };
};

export default connect(mapStateToProps)(translate('translations')(CreateHMBT));
