import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';

import { BsThreeDots } from 'react-icons/bs';

import * as _ from 'lodash';

export function AccountCreateInfo({ accDetail, t }) {
  return (
    <>
      <Form.Group>
        <Form.Label>{t('txt-acc-name')}</Form.Label>
        <input
          name="accountName"
          value={accDetail?.C_CUSTOMER_NAME || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-acc-type')}</Form.Label>
        <input
          name="accountType"
          value={accDetail?.C_CUSTOMER_TYPE || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Transaction office')}</Form.Label>
        <div className="w-100 d-flex flex-row">
          <input
            name="subBranchName"
            value={''}
            type={'text'}
            className="form-control input-order"
            disabled
          />
          <Button
            style={{ height: '30px' }}
            className="d-flex align-items-center ml-2"
          >
            <BsThreeDots />
          </Button>
        </div>
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('ID Card/ Passport No / Business registration No')}
        </Form.Label>
        <input
          name="cardId"
          value={accDetail?.C_CARD_ID || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-issue-date')}</Form.Label>
        <input
          name="issueDate"
          value={accDetail?.C_ISSUE_DATE || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Expiry date')}</Form.Label>
        <input
          name="expireDate"
          value={accDetail?.C_EXPIRE_DATE || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label> {t('txt-issue-place')}</Form.Label>
        <input
          name="issuePlace"
          value={accDetail?.C_ISSUE_PLACE || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-address')}</Form.Label>
        <input
          name="address"
          value={accDetail?.C_CUST_ADDRESS || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-email')}</Form.Label>
        <input
          name="email"
          value={accDetail?.C_CUST_EMAIL || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('Tel')}</Form.Label>
        <input
          name="phone"
          value={accDetail?.C_CUST_FAX || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-mobile')}</Form.Label>
        <input
          name="mobile"
          value={accDetail?.C_CUST_MOBILE || ''}
          type={'text'}
          className="form-control input-order"
          disabled
        />
      </Form.Group>
    </>
  );
}
