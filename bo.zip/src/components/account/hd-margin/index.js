import React, { useState } from 'react';
import { Link, useHistory } from 'react-router-dom';
import TabHDMarin from './layout/tabHDMargin';
import TabHD3Ben from './layout/tabHD3Ben';
import TabHMBT from './layout/tabHMBT';

import { HiViewGridAdd } from 'react-icons/hi';
import { translate } from 'react-i18next';

import { ReactComponent as IconDownload } from 'assets/img/icon/ic_download.svg';
import { ReactComponent as IconUpload } from 'assets/img/icon/ic_upload.svg';
import { Card, Dropdown } from 'react-bootstrap';

import styled from 'styled-components';

import { ReactComponent as IconProgress } from 'assets/img/icon/iconProgress.svg';
import { ReactComponent as IconLock } from 'assets/img/icon/icLock.svg';
import { BsGearFill } from 'react-icons/bs';
import { setSettingSearch } from 'containers/client/actions';
import { connect, useDispatch } from 'react-redux';

//#region styled
const DivGroup1 = styled.div`
  display: flex;
  align-items: center;
  text-align: center;

  &:not(:last-child) {
    border: 1px dashed #e8eaeb;
    border-width: 0 1px 0 0;
  }
`;

const Oval1 = styled.div`
  color: #fff;
  background: #f2f9ff;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  border-radius: 50%;
  justify-content: center;
  margin-left: 5px;

  & svg {
    height: 20px;
  }
  & svg path {
    fill: #0088ff;
  }
`;

const Text1 = styled.span`
  font-size: 13px;
  padding-left: 5px;
  cursor: pointer;
`;

//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function IndividualComponent(props) {
  const [key, setKey] = useState('hd-margin');

  // const location = useLocation()
  const { push } = useHistory();
  const dispatch = useDispatch();

  const { type, t } = props;

  const preType = usePrevious(type);

  React.useEffect(() => {
    if (type && type !== preType) {
      setKey(type);
    }
  }, [type]);

  function _handleClickTab(params) {
    setKey(params);
  }

  function _handleClick(type, status) {
    // console.log(location)
    push('/account/margin/' + type + '?status=' + status);
  }

  function _handleSettingSearch() {
    dispatch(setSettingSearch(true));
  }

  return (
    <>
      <div className="d-flex align-items-center mt-2">
        <div className="group-title-header">
          <a>
            <IconDownload /> <span>{t('Export file')}</span>
          </a>
          <a>
            <IconUpload /> <span>{t('Import file')}</span>
          </a>
        </div>

        <Dropdown>
          <Dropdown.Toggle
            variant="primary"
            id="dropdown-basic"
            className="btn-add btn btn-warning"
          >
            <HiViewGridAdd />
            {t('Add new')}
          </Dropdown.Toggle>

          <Dropdown.Menu>
            <Dropdown.Item as={'div'}>
              <Link to={'/account/margin/hd-margin/create'}>
                {t('Margin contract')}
              </Link>
            </Dropdown.Item>
            <Dropdown.Item as={'div'}>
              <Link to={'/account/margin/hd-3-ben/create'}>
                {t('Three-party contract')}
              </Link>
            </Dropdown.Item>
            <Dropdown.Item as={'div'}>
              <Link to={'/account/margin/han-muc-bat-thuong/create'}>
                {t('Abnormal limit')}
              </Link>
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>

      <Card className="mt-2">
        <Card.Header className="d-flex">
          {t('Information to be processed')}
        </Card.Header>
        <Card.Body>
          <div
            className="d-grid"
            style={{ gridTemplateColumns: 'repeat(6, minmax(0, 1fr))' }}
          >
            <DivGroup1>
              <Oval1 primary>
                <IconLock />
              </Oval1>
              <Text1 onClick={() => _handleClick('hd-margin', 'CHUA_DUYET')}>
                {t('Margin contract')} {t('Pending')} (10)
              </Text1>
            </DivGroup1>
            <DivGroup1>
              <Oval1 primary>
                <IconLock />
              </Oval1>
              <Text1 onClick={() => _handleClick('hd-3-ben', 'CHUA_DUYET')}>
                {t('Three-party contract')} {t('Pending')}(2)
              </Text1>
            </DivGroup1>
            <DivGroup1>
              <Oval1 green>
                <IconProgress />
              </Oval1>
              <Text1
                onClick={() => _handleClick('han-muc-bat-thuong', 'CHUA_DUYET')}
              >
                {t('Abnormal limit')} {t('Pending')}(5)
              </Text1>
            </DivGroup1>
          </div>
        </Card.Body>
      </Card>

      <div className="custom-tabs mt-2">
        <div
          className={'custom-tab-item ' + (key === 'hd-margin' ? 'active' : '')}
          onClick={() => _handleClickTab('hd-margin')}
        >
          {t('Margin contract')}
        </div>
        <div
          className={'custom-tab-item ' + (key === 'hd-3-ben' ? 'active' : '')}
          onClick={() => _handleClickTab('hd-3-ben')}
        >
          {t('Three-party contract')}
        </div>
        <div
          className={
            'custom-tab-item ' + (key === 'han-muc-bat-thuong' ? 'active' : '')
          }
          onClick={() => _handleClickTab('han-muc-bat-thuong')}
        >
          {t('Abnormal limit')}
        </div>
        <a
          className="ml-auto mr-2"
          style={{ alignSelf: 'center' }}
          onClick={_handleSettingSearch}
        >
          <BsGearFill />
        </a>
      </div>

      <div className="custom-tabs-content">
        {key === 'hd-margin' && <TabHDMarin />}
        {key === 'hd-3-ben' && <TabHD3Ben />}
        {key === 'han-muc-bat-thuong' && <TabHMBT />}
      </div>
    </>
  );
}

export default connect()(translate('translations')(IndividualComponent));
