import React, { useState, memo } from 'react';
import { Table } from 'react-bootstrap';
import { connect } from 'react-redux';
import Paging from 'components/paging';
import FormSearch from './formSearchHDMargin';
import { translate } from 'react-i18next';

function TabHDMarin(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const { t } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch />
      <Table bordered>
        <thead>
          <tr>
            <th>
              <input type="checkbox" />
            </th>
            <th>{t('Time')}</th>
            <th>{t('Creator')}</th>
            <th>{t('Approver')}</th>
            <th>{t('Contract number')}</th>
            <th>{t('Open date')}</th>
            <th>{t('Account')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('Status')}</th>
            <th>{t('Close date')}</th>
          </tr>
        </thead>
        <tbody></tbody>
      </Table>

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
        />
      </div>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {};
};

export default connect(mapStateToProps)(
  memo(translate('translations')(TabHDMarin))
);
