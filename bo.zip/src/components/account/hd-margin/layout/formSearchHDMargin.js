import React, { useEffect, useRef } from 'react';
import { Button, Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { change, Field, formValueSelector, reduxForm } from 'redux-form';
import { makeGetToken } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { formatDate } from 'utils';
import { makeGetCustomerDelete, makeGetAllBranch } from 'lib/selector';
import { useLocation } from 'react-router';
import { translate } from 'react-i18next';
import { makeGetSettingSearch } from 'lib/selector';
import { makeGetSavedSettingSearch } from 'lib/selector';

import * as _ from 'lodash';
import { arrSearchHDMargin } from 'utils/const';
import SettingSearchModal from 'components/modal/settingSearchModal';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function useQuery() {
  const { search } = useLocation();

  return React.useMemo(() => new URLSearchParams(search), [search]);
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const formRef = useRef();
  const dispatch = useDispatch();

  const [showSettingSearch, setShowSettingSearch] = React.useState(false);
  const [arrSel, setArrSel] = React.useState([]);

  const {
    page,
    recordPerPage,
    handleSubmit,
    submitting,
    t,
    reqSetSearch,
    savedSetSearch,
    glAllBranch,
  } = props;

  let query = useQuery();
  const statusSearch = query.get('status') || '';

  //const preCustDelete = usePrevious(custDel);
  const preStatusSearch = usePrevious(statusSearch);
  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preReqSetSearch = usePrevious(reqSetSearch);
  const preSavedSetSearch = usePrevious(savedSetSearch);

  useEffect(() => {
    setTimeout(() => {
      if (refSubmit.current) refSubmit.current.click();
    }, 200);

    setArrSel(_.map(arrSearchHDMargin, 'value'));
  }, []);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (reqSetSearch && reqSetSearch !== preReqSetSearch) {
      setShowSettingSearch(true);
    }
  }, [reqSetSearch]);

  useEffect(() => {
    if (savedSetSearch && !_.isEqual(savedSetSearch, preSavedSetSearch)) {
      console.log(_.map(arrSearchHDMargin, 'value'));
      const arrFieldShow = savedSetSearch
        ? savedSetSearch['SearchHDMargin']
        : '';
      setArrSel(
        !arrFieldShow
          ? _.map(arrSearchHDMargin, 'value')
          : arrFieldShow.split(',')
      );
    }
  }, [savedSetSearch]);

  useEffect(() => {
    if (statusSearch && statusSearch !== preStatusSearch) {
      dispatch(change('formSearchHDMargin', 'formStatus', statusSearch));
      setTimeout(() => {
        if (refSubmit.current) refSubmit.current.click();
      }, 200);
    }
  }, [statusSearch]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  const submit = (values) => {
    console.log(values);
  };

  function _handleCloseSettingSearch() {
    setShowSettingSearch(false);
  }

  return (
    <form
      ref={formRef}
      className="d-flex flex-column align-items-center search-content"
      onSubmit={handleSubmit(submit)}
    >
      <div className="d-grid grid-6 ">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchHDMargin,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (_objItem.type === 'text')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'date')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    className="form-control"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                  />
                </Form.Group>
              );

            if (_objItem.type === 'select') {
              if (_objItem.value === 'formBranchCode')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={glAllBranch}
                    />
                  </Form.Group>
                );

              if (_objItem.value === 'formStatus')
                return (
                  <Form.Group key={_objItem.value}>
                    <Form.Label className="fz-13">
                      {t(_objItem.label)}
                    </Form.Label>
                    <Field
                      name={_objItem.value}
                      className="form-control"
                      component={RenderNormalSelect}
                      opts={[]}
                    />
                  </Form.Group>
                );
            }
          })}

        <div
          className="d-flex mt-2"
          style={{ height: '30px', whiteSpace: 'nowrap' }}
        >
          <Button
            ref={refSubmit}
            type="submit"
            className="btn-search"
            disabled={submitting}
          >
            {t('txt-search')}
          </Button>
        </div>
      </div>
      {showSettingSearch && (
        <SettingSearchModal
          onClose={_handleCloseSettingSearch}
          arrAllSearch={arrSearchHDMargin}
          name="SearchHDMargin"
        />
      )}
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchHDMargin',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchHDMargin');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getCustomerDelete = makeGetCustomerDelete();
  const getSettingSearch = makeGetSettingSearch();
  const getSavedSettingSearch = makeGetSavedSettingSearch();
  const getAllBranch = makeGetAllBranch();
  const mapStateToProps = (state) => {
    const {
      formAccount,
      formContractCode,
      formAccName,
      formCreatorCode,
      formApproverCode,
      formBranchCode,
      formFromDate,
      formToDate,
      formLiquidFromDate,
      formLiquidToDate,
      formStatus,
    } = selector(
      state,
      'formAccount',
      'formContractCode',
      'formAccName',
      'formCreatorCode',
      'formApproverCode',
      'formBranchCode',
      'formFromDate',
      'formToDate',
      'formLiquidFromDate',
      'formLiquidToDate',
      'formStatus'
    );
    return {
      token: getToken(state),
      custDel: getCustomerDelete(state),
      reqSetSearch: getSettingSearch(state),
      savedSetSearch: getSavedSettingSearch(state),
      glAllBranch: getAllBranch(state),
      formAccount,
      formContractCode,
      formAccName,
      formCreatorCode,
      formApproverCode,
      formBranchCode,
      formFromDate,
      formToDate,
      formLiquidFromDate,
      formLiquidToDate,
      formStatus,
      initialValues: {
        formStatus: '',
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
