import TabTKHanChe from './dich-vu-han-che';
import TabLinhHoatPhi from './linh-hoat-phi';
import TabChangeComboFee from './thay-doi-combo-phi';
import TabChangeMarketingId from './thay-doi-marketing-id';
import TabChangeProduct from './thay-doi-san-pham';
import TabSetLimits from './han-muc-rieng';

function ChinhSachTaiKhoanComponent(props) {
  const { type, accRight } = props;

  return (
    <div className="custom-tabs-content my-3">
      {type === 'han-che' && <TabTKHanChe accRight={accRight} />}
      {type === 'linh-hoat-phi' && <TabLinhHoatPhi accRight={accRight} />}
      {type === 'thay-doi-combo-phi' && (
        <TabChangeComboFee accRight={accRight} />
      )}
      {type === 'thay-doi-marketing-id' && (
        <TabChangeMarketingId accRight={accRight} />
      )}
      {type === 'thay-doi-san-pham' && (
        <TabChangeProduct accRight={accRight} />
      )}
      {type === 'han-muc-rieng' && <TabSetLimits accRight={accRight} />}
    </div>
  );
}

export default ChinhSachTaiKhoanComponent;
