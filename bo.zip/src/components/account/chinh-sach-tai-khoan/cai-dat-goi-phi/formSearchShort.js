import RenderSearchShort from 'components/input/inputSearchShort';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import IconConfig from 'assets/img/icon/cog.png';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import { accChangeCommDelSuccess, accChangeCommSearchRequest, accChangeCommUpdSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetAccountChangeCommDel, makeGetAccountChangeCommUpd } from 'lib/selector';
import {
  ExportExcel,
  FormFlexCenter
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    accountDelete,
    accountUpdate,

    formAccountCode,
    formCommCode,
    formFromDate,
    formEndDate,
  } = props;

  const preAccountDelete = usePrevious(accountDelete);
  const preAccountUpdate = usePrevious(accountUpdate);

  const preFromDate = usePrevious(formFromDate);
  const preToDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accChangeCommSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accountUpdate && !_.isEqual(accountUpdate, preAccountUpdate)) ||
      (accountDelete && !_.isEqual(accountDelete, preAccountDelete))
    ) {
      dispatch(accChangeCommSearchRequest(dataSearch));
    }
  }, [accountUpdate, accountDelete]);

  React.useEffect(() => {
    if (accountUpdate && !_.isEqual(accountUpdate, preAccountUpdate)) {
      dispatch(accChangeCommUpdSuccess(null));
    }
  }, [accountUpdate]);

  React.useEffect(() => {
    if (accountDelete && !_.isEqual(accountDelete, preAccountDelete)) {
      _handleToast(`${t('txt-del-fee-package-success')}`, 'success');
      dispatch(accChangeCommDelSuccess(null));
    }
  }, [accountDelete]);

  useEffect(() => {
    if (formFromDate && !_.isEqual(formFromDate, preFromDate)) {
      if (!formFromDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formFromDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preToDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.COMM_CODE = values.formCommCode;
    _params.data.FROM_DATE = values.formFromDate;
    _params.data.TO_DATE = values.formEndDate;
    dispatch(accChangeCommSearchRequest(_params));
    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.COMM_CODE = formCommCode;
    _params.data.FROM_DATE = formFromDate;
    _params.data.TO_DATE = formEndDate;
    dispatch(accChangeCommSearchRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">
          {t('txt-fee-package-new')}
        </Form.Label>
        <Field
          name="formCommCode"
          type="text"
          className="form-control w_100 mr-2"
          placeholder={t('txt-fee-package-new')}
          component={RenderInput}
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formFromDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />

      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
      <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortGoiPhi',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortGoiPhi');

const makeMapStateToProps = () => {
  const getAccountUpdate = makeGetAccountChangeCommUpd();
  const getAccountDelete = makeGetAccountChangeCommDel();

  const mapStateToProps = (state) => {
    const { formAccountCode, formCommCode, formFromDate, formEndDate } =
      selector(
        state,
        'formAccountCode',
        'formCommCode',
        'formFromDate',
        'formEndDate'
      );

    return {
      accountUpdate: getAccountUpdate(state),
      accountDelete: getAccountDelete(state),

      formAccountCode,
      formCommCode,
      formFromDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
