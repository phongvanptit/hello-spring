import RenderInput from 'components/input/renderInput';
import { makeGetCustType, makeGetSystemInfo } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';

import { accChangeCommSearchRequest } from 'containers/account/actions';
import { makeGetAllBranch } from 'lib/selector';
import * as _ from 'lodash';
import { arrSearchCaiDatGoiPhi } from 'utils/const';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    onTriggerPopover,

    sysSystemInfo,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchCaiDatGoiPhi, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_NAME = values.formAccountName;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;

    dispatch(accChangeCommSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);

    dispatch(change('formSearchModalGoiPhi', 'formAccountName', ''));
    dispatch(change('formSearchModalGoiPhi', 'formCreatorCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchCaiDatGoiPhi,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (
              _objItem.type === 'text' &&
              _objItem.value !== 'formAccountCode' &&
              _objItem.value !== 'formAccountName' &&
              _objItem.value !== 'formCommCode'
            )
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalGoiPhi',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalGoiPhi');

const makeMapStateToProps = () => {
  const getCustType = makeGetCustType();
  const getAllBranch = makeGetAllBranch();
  const getSystemInfo = makeGetSystemInfo();

  const mapStateToProps = (state, props) => {
    const {
      formBranchCode,
      formSubBranchCode,
      formMarketingId,
      formCreatorCode,
      formAccountCode,
      formAccountName,
    } = selector(
      state,
      'formBranchCode',
      'formSubBranchCode',
      'formMarketingId',
      'formCreatorCode',
      'formAccountCode',
      'formAccountName'
    );

    const { dataSearch } = props;

    return {
      glCustType: getCustType(state),
      glAllBranch: getAllBranch(state),
      sysSystemInfo: getSystemInfo(state),

      formBranchCode,
      formSubBranchCode,
      formMarketingId,
      formCreatorCode,
      formAccountCode,
      formAccountName,

      initialValues: {
        formCustCode: dataSearch?.data?.ACCOUNT_CODE,
        formCustName: dataSearch?.data?.ACCOUNT_NAME,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
