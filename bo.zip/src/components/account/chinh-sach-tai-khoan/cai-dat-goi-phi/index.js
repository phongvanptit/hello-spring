import React, { memo, useState } from 'react';
import { Table } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import Paging from 'components/paging';
import FormSearch from './formSearchSettingGoiPhi';
import { translate } from 'react-i18next';
import NodataSearch from 'components/noDataSearch';
import { makeGetToken, makeGetSystemInfo } from 'lib/selector';
import { makeGetAccountChangeCommAll } from 'lib/selector';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { GroupButton } from 'utils/styledComponent';
import DetailAccountCommModal from 'components/modal/account/chinh-sach-tai-khoan/cai-dat-goi-phi/DetailAccountComm';
import { confirmAlert } from 'react-confirm-alert';
import { accChangeCommDelRequest } from 'containers/account/actions';
import { _diff2Date, stringToDate, formatDate } from 'utils';

function TabSettingGoiPhi(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);
  const { t, accountList, accRight, token, sysSystemInfo } = props;
  const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
  }

  function handleConfirm(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-package')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_COMM_CHANGE',
      group: 'LIST',
      data: {
        ID: pk,
      },
    };

    dispatch(accChangeCommDelRequest(params));
  }
  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            {/* <th>
              <input type="checkbox" />
            </th> */}
            <th>{t('txt-time')}</th>
            <th>{t('txt-creator')}</th>
            <th>{t('txt-acc')}</th>
            <th>{t('txt-full-name')}</th>
            <th>{t('txt-old-fee-package')}</th>
            <th>{t('txt-new-fee-package')}</th>
            <th>{t('txt-last-fee-package')}</th>
            <th>{t('txt-from-date')}</th>
            <th>{t('txt-to-date')}</th>
            <th>{t('txt-note')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {accountList &&
            accountList.map((item) => (
              <tr key={item.PK_ACCOUNT_COMM}>
                <td className="text-center">
                  {item.C_CREATE_TIME ? item.C_CREATE_TIME : ''}
                </td>
                <td className="text-center">{item.C_CREATOR_CODE}</td>
                <td className="text-center">{item.C_ACCOUNT_CODE}</td>
                <td className="">{item.C_ACCOUNT_NAME}</td>
                <td className="text-center">{item.C_COMM_BEFORE}</td>
                <td className="text-center">{item.C_COMM_CODE}</td>
                <td className="text-center">{item.C_COMM_BACK}</td>
                <td className="text-center">
                  {item.C_EFFECT_DATE ? item.C_EFFECT_DATE.split(' ')[0] : ''}
                </td>
                <td className="text-center">
                  {item.C_EXPIRE_DATE ? item.C_EXPIRE_DATE.split(' ')[0] : ''}
                </td>
                <td className="">{item.C_CONTENT}</td>
                <td className="text-center p-0 w_85">
                  <GroupButton>
                    <a
                      title="Chi tiết"
                      onClick={() => handleDetail(item.PK_ACCOUNT_COMM)}
                    >
                      <IconCopy />
                    </a>
                    {/* {accRight?.C_APPROVE === 1 && (
                      <a
                        title="Duyệt"
                        className={
                          item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                        }
                        onClick={() =>
                          item.C_STATUS === 'CHUA_DUYET'
                            ? handleApproveSelected(item.PK_ACCOUNT_COMM)
                            : {}
                        }
                      >
                        <IconAppr />
                      </a>
                    )} */}
                    {accRight?.C_UPDATE === 1 &&
                      _diff2Date(
                        item?.C_EFFECT_DATE.split(' ')[0],
                        formatDate(date, '/', 'dmy')
                      ) > 0 && (
                        <a
                          title="Xóa"
                          onClick={() => handleConfirm(item.PK_ACCOUNT_COMM)}
                        >
                          <IconTrash />
                        </a>
                      )}
                  </GroupButton>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>

      {(!accountList || !accountList.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            accountList && !!accountList.length
              ? accountList[0].C_TOTAL_RECORD
              : 0
          }
        />
      </div>
      {detailAccInt && (
        <DetailAccountCommModal
          onClose={onClose}
          id={detailAccInt}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountListSearch = makeGetAccountChangeCommAll();
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountListSearch(state),
      sysSystemInfo: getSystemInfo(state),
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  memo(translate('translations')(TabSettingGoiPhi))
);
