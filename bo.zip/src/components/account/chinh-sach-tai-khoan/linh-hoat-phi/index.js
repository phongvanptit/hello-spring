import { useState } from 'react';
import FormSearch from './form/formSearch';

import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailLinhHoatPhiModal from 'components/modal/account/chinh-sach-tai-khoan/linh-hoat-phi/detail';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import { cashDelFlexibleFeeRequest,cashApprFlexibleFeeRequest } from 'containers/cash/actions';
import { makeGetCashListFlexibleFee, makeGetToken } from 'lib/selector';
import { Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { numberFormat } from 'utils';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';

function TabLInhHoatPhi(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [idDetail, setIdDetail] = useState(null);
  const dispatch = useDispatch();

  const { cashListFlexibleFee, subType, t, accRight, token } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(value) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(value);
  }

  function onClose() {
    setIdDetail(null);
  }

  function handleDel(value) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleAppr(value) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn duyệt bút toán</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionAppr(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }
  function handleActionAppr(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
        STATUS: 'DA_DUYET',
      },
    };

    dispatch(cashApprFlexibleFeeRequest(params));
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(cashDelFlexibleFeeRequest(params));
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearch
          page={page}
          recordPerPage={recordPerPage}
          subType={subType}
        />
        <PerfectScrollbar className="w-100 mt-2">
          <Table bordered>
            <thead>
              <tr>
                <th rowSpan={2}>{t('txt-acc-number')}</th>
                <th rowSpan={2}>{t('txt-acc-name')}</th>
                <th rowSpan={2}>{t('txt-effective-date')}</th>
                <th rowSpan={2}>{t('txt-expire-date')}</th>
                <th colSpan={3}>{t('txt-rate-fee-depo')}</th>
                <th rowSpan={2}>{t('txt-status')}</th>
                <th rowSpan={2}>{t('txt-appr-status')}</th>
                <th rowSpan={2}>{t('txt-action')}</th>
              </tr>
              <tr>
                <th>{t('txt-stock')}</th>
                <th>{t('txt-CCQ')}</th>
                <th>{t('txt-bond')}</th>
              </tr>
            </thead>
            <tbody>
              {cashListFlexibleFee &&
                cashListFlexibleFee.map((item) => (
                  <tr key={item.PK_DEPOSIT_FEE_PRIVATE}>
                    <td className="text-center">
                      <a
                        rel="noreferrer noopener"
                        onClick={() =>
                          handleDetail(item.PK_DEPOSIT_FEE_PRIVATE)
                        }
                      >
                        {item.C_ACCOUNT_CODE}
                      </a>
                    </td>
                    <td className="text-center">
                      <a
                        rel="noreferrer noopener"
                        onClick={() =>
                          handleDetail(item.PK_DEPOSIT_FEE_PRIVATE)
                        }
                      >
                        {item.C_ACCOUNT_NAME}
                      </a>
                    </td>
                    <td className="text-center">{item.C_FROM_DATE}</td>
                    <td className="text-center">{item.C_TO_DATE}</td>

                    <td className="text-right">
                      {item.C_CUSTODY_FEE_RATE_SHARE}
                    </td>
                    <td className="text-right">
                      {item.C_CUSTODY_FEE_RATE_FUND}
                    </td>
                    <td className="text-right">
                      {item.C_CUSTODY_FEE_RATE_BOND}
                    </td>
                    <td className="text-center">{item.C_STATUS_NAME}</td>
                    <td className="text-center">
                      {item.C_APPROVE_STATUS_NAME}
                    </td>
                    <td className="text-center p-0 w_85">
                      <GroupButton>
                        <a
                          title={t('txt-detail')}
                          rel="noreferrer noopener"
                          onClick={() =>
                            handleDetail(item.PK_DEPOSIT_FEE_PRIVATE)
                          }
                        >
                          <IconCopy />
                        </a>
                        {accRight?.C_APPROVE === 1 && (
                          <a
                            title={t('txt-appr')}
                            className={
                              item.C_APPROVE_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                            }
                            rel=""
                            onClick={() =>
                              item.C_APPROVE_STATUS === 'CHUA_DUYET'
                                ? handleAppr(item.PK_DEPOSIT_FEE_PRIVATE)
                                : {}
                            }
                          >
                            <IconAppr />
                          </a>
                        )}
                        {accRight?.C_APPROVE === 1 && (
                        <a
                          title={t('txt-del')}
                          className={
                            item.C_APPROVE_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                          }
                          rel="noreferrer noopener"
                          onClick={() =>
                            item.C_APPROVE_STATUS === 'CHUA_DUYET'
                              ? handleDel(item.PK_DEPOSIT_FEE_PRIVATE)
                              : {}
                          }
                        >
                          <IconTrash />
                        </a>
                        )}
                      </GroupButton>
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </PerfectScrollbar>
        {(!cashListFlexibleFee || !cashListFlexibleFee.length) && (
          <NodataSearch name={t('txt-flexible-deposit-fee-1')} />
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (cashListFlexibleFee &&
                !!cashListFlexibleFee.length &&
                cashListFlexibleFee[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailLinhHoatPhiModal
            id={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getCashListFlexibleFee = makeGetCashListFlexibleFee();
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      cashListFlexibleFee: getCashListFlexibleFee(state),
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(TabLInhHoatPhi)
);
