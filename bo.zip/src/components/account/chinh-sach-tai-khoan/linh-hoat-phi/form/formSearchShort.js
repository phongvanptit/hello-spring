import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  cashDelFlexibleFeeSuccess,
  cashListFlexibleFeeRequest,
} from 'containers/cash/actions';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import { cashRejFlexibleFeeSuccess,cashUnAprrFlexibleFeeSuccess,cashAprrFlexibleFeeSuccess } from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetCashDelFlexibleFee,
  makeGetCashRejFlexibleFee,
  makeGetCashUpdFlexibleFee,
  makeGetGlobalStatusList,
  makeGetCashApprFlexibleFee,
  makeGetCashUnApprFlexibleFee,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    cashUpdFlexibleFee,
    cashDelFlexibleFee,
    cashRejFlexibleFee,
    cashApprFlexibleFee,
    cashUnApprFlexibleFee,
    glStatusList,

    formAccountCode,
    formStartDate,
    formEndDate,
    formStatus,
  } = props;

  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  const preCashUpdFlexibleFee = usePrevious(cashUpdFlexibleFee);
  const preCashDelFlexibleFee = usePrevious(cashDelFlexibleFee);
  const preCashRejFlexibleFee = usePrevious(cashRejFlexibleFee);
  const preCashApprFlexibleFee = usePrevious(cashApprFlexibleFee);
  const preCashUnApprFlexibleFee = usePrevious(cashUnApprFlexibleFee);

  useEffect(() => {
    setTimeout(() => {
      dispatch(cashListFlexibleFeeRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (cashUpdFlexibleFee &&
        !_.isEqual(cashUpdFlexibleFee, preCashUpdFlexibleFee)) ||
      (cashDelFlexibleFee &&
        !_.isEqual(cashDelFlexibleFee, preCashDelFlexibleFee)) ||
      (cashRejFlexibleFee &&
        !_.isEqual(cashRejFlexibleFee, preCashRejFlexibleFee)) ||
      (cashApprFlexibleFee &&
        !_.isEqual(cashApprFlexibleFee, preCashApprFlexibleFee)) ||
      (cashUnApprFlexibleFee &&
        !_.isEqual(cashUnApprFlexibleFee, preCashUnApprFlexibleFee))
    ) {
      dispatch(cashListFlexibleFeeRequest(dataSearch));
    }
  }, [cashUpdFlexibleFee, cashDelFlexibleFee, cashRejFlexibleFee,cashApprFlexibleFee,cashUnApprFlexibleFee]);

  useEffect(() => {
    if (
      cashDelFlexibleFee &&
      !_.isEqual(cashDelFlexibleFee, preCashDelFlexibleFee)
    ) {
      dispatch(cashDelFlexibleFeeSuccess(null));
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
    }
  }, [cashDelFlexibleFee]);

  useEffect(() => {
    if (
      cashRejFlexibleFee &&
      !_.isEqual(cashRejFlexibleFee, preCashRejFlexibleFee)
    ) {
      dispatch(cashRejFlexibleFeeSuccess(null));
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
    }
  }, [cashRejFlexibleFee]);

  useEffect(() => {
    if (
      cashApprFlexibleFee &&
      !_.isEqual(cashApprFlexibleFee, preCashApprFlexibleFee)
    ) {
      dispatch(cashAprrFlexibleFeeSuccess(null));
      _handleToast('Duyệt bút toán thành công', 'success');
    }
  }, [cashApprFlexibleFee]);

  useEffect(() => {
    if (
      cashUnApprFlexibleFee &&
      !_.isEqual(cashUnApprFlexibleFee, preCashUnApprFlexibleFee)
    ) {
      dispatch(cashUnAprrFlexibleFeeSuccess(null));
      _handleToast('Hủy duyệt bút toán thành công', 'success');
    }
  }, [cashUnApprFlexibleFee]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus || -1;
    dispatch(cashListFlexibleFeeRequest(_params));
    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;
    dispatch(cashListFlexibleFeeRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="w_120 form-control"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
          onBlur={_handleBlur}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortLinhHoatPhi',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortLinhHoatPhi');

const makeMapStateToProps = () => {
  const getGlStatusList = makeGetGlobalStatusList();
  const getCashUpdFlexibleFee = makeGetCashUpdFlexibleFee();
  const getCashDelFlexibleFee = makeGetCashDelFlexibleFee();
  const getCashRejFlexibleFee = makeGetCashRejFlexibleFee();
  const getCashApprFlexibleFee = makeGetCashApprFlexibleFee();
  const getCashUnApprFlexibleFee = makeGetCashUnApprFlexibleFee();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStartDate, formEndDate, formStatus } =
      selector(
        state,
        'formAccountCode',
        'formStartDate',
        'formEndDate',
        'formStatus'
      );

    return {
      glStatusList: getGlStatusList(state),
      cashUpdFlexibleFee: getCashUpdFlexibleFee(state),
      cashDelFlexibleFee: getCashDelFlexibleFee(state),
      cashRejFlexibleFee: getCashRejFlexibleFee(state),
      cashApprFlexibleFee: getCashApprFlexibleFee(state),
      cashUnApprFlexibleFee: getCashUnApprFlexibleFee(state),

      formAccountCode,
      formStartDate,
      formEndDate,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
