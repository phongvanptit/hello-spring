import { useState } from 'react';

import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import DetailChangeSaleOTNModal from 'components/modal/account/chinh-sach-tai-khoan/thay-doi-cu-moi-sale/detail';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  accountChangeSaleOTNApprRequest
} from 'containers/account/actions';
import { makeGetAccountChangeSaleOTNList, makeGetToken } from 'lib/selector';
import { Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form/formSearch';

function TabChangeOldToNewSale(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [idDetail, setIdDetail] = useState(null);
  const dispatch = useDispatch();

  const { accChangeSaleOTNList, subType, t, accRight, token } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(value) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(value);
  }

  function onClose() {
    setIdDetail(null);
  }

  function handleAppr(value) {
    if (accRight?.C_APPROVE !== 1) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-change-sale-otn')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_TRANSFER_MAKETING_ID',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
        STATUS: 'DA_DUYET',
      },
    };

    dispatch(accountChangeSaleOTNApprRequest(params));
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearch
          page={page}
          recordPerPage={recordPerPage}
          subType={subType}
        />
        <PerfectScrollbar className="w-100 mt-2">
          <Table bordered>
            <thead>
              <tr>
                <th>{t('txt-old-marketing-id')}</th>
                <th>{t('txt-new-marketing-id')}</th>
                <th>{t('txt-branch-old')}</th>
                <th>{t('txt-branch-new')}</th>
                <th>{t('txt-sub-branch-old')}</th>
                <th>{t('txt-sub-branch-new')}</th>
                <th>{t('txt-create-date')}</th>
                <th>{t('txt-status')}</th>
                <th>{t('txt-action')}</th>
              </tr>
            </thead>
            <tbody>
              {accChangeSaleOTNList &&
                accChangeSaleOTNList.map((item) => (
                  <tr key={item.PK_TRANSFER_MARKETING_ID}>
                    <td className="text-center">{item.C_MAKETING_ID_TRANSFER}</td>
                    <td className="text-center">{item.C_MAKETING_ID_RECEIVE}</td>
                    <td className="text-center">{item.C_BRANCH_CODE_TRANSFER}</td>
                    <td className="text-center">{item.C_BRANCH_CODE_RECEIVE}</td>
                    <td className="text-center">{item.C_SUB_BRANCH_CODE_TRANSFER}</td>
                    <td className="text-center">{item.C_SUB_BRANCH_CODE_RECEIVE}</td>

                    <td className="text-center">{item.C_CREATE_TIME}</td>
                    <td className="text-center">{item.C_STATUS_NAME}</td>

                    <td className="text-center p-0 w_85">
                      <GroupButton>
                        <a
                          title={t('txt-detail')}
                          rel="noreferrer noopener"
                          onClick={() => handleDetail(item.PK_TRANSFER_MARKETING_ID)}
                        >
                          <IconCopy />
                        </a>
                        {item?.C_STATUS === 'CHUA_DUYET' && (
                          <a
                            title={t('txt-appr')}
                            rel="noreferrer noopener"
                            onClick={() => handleAppr(item.PK_TRANSFER_MARKETING_ID)}
                          >
                            <IconAppr />
                          </a>
                        )}
                      </GroupButton>
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </PerfectScrollbar>
        {(!accChangeSaleOTNList || !accChangeSaleOTNList.length) && (
          <NodataSearch name={t('txt-change-sale-1')} />
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (accChangeSaleOTNList &&
                !!accChangeSaleOTNList.length &&
                accChangeSaleOTNList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailChangeSaleOTNModal
            id={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getAccountChangeSaleOTNList = makeGetAccountChangeSaleOTNList();
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      accChangeSaleOTNList: getAccountChangeSaleOTNList(state),
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(TabChangeOldToNewSale)
);
