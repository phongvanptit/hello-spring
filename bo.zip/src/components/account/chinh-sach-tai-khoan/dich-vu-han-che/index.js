import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import FormSearch from './formSearchTKHanChe';

import {
  makeGetToken,
  makeGetAccountLimitList,
  makeGetAuthenType,
} from 'lib/selector';
import { translate } from 'react-i18next';
import NodataSearch from 'components/noDataSearch';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import DetailAccountLimitedModal from 'components/modal/account/chinh-sach-tai-khoan/dich-vu-han-che/DetailAccountLimited';
import { confirmAlert } from 'react-confirm-alert';
import { accountLimitDelRequest } from 'containers/account/actions';
import { accountLimitApprRequest } from 'containers/account/actions';

function AccountInternetComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);

  const { accountList, t, accRight, token } = props;

  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
  }

  function handleConfirm(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-limit-service')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: pk,
      },
    };

    dispatch(accountLimitDelRequest(params));
  }

  function handleApproveSelected(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-limit-service')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: pk,
      },
    };

    dispatch(accountLimitApprRequest(params));
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            {/* <th>#</th> */}
            <th>{t('txt-acc')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('txt-note')}</th>
            <th>{t('txt-status')}</th>
            <th>{t('txt-time')}</th>
            <th>{t('txt-creator')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {accountList &&
            accountList.map((item) => (
              <tr key={item.PK_ACCOUNT_LIMITED}>
                <td className="text-center">
                  <a onClick={() => handleDetail(item.PK_ACCOUNT_LIMITED)}>
                    {item.C_ACCOUNT_CODE}
                  </a>
                </td>
                <td className="">{item.C_ACCOUNT_NAME}</td>
                <td className="text-center">{item.C_CONTENT}</td>
                <td className="text-center">{item.C_STATUS_NAME}</td>
                <td className="text-center">
                  {item.C_CREATE_TIME ? item.C_CREATE_TIME.split(' ')[0] : ''}
                </td>
                <td className="text-center">{item.C_CREATOR_CODE}</td>
                <td className="text-center p-0 w_85">
                  <GroupButton>
                  <a
                        title={t('txt-detail')}
                        onClick={() => handleDetail(item.PK_ACCOUNT_LIMITED)}
                      >
                        <IconCopy />
                      </a>
                    {/* {accRight?.C_VIEW === 1 && (
                      <a
                        title={t('txt-detail')}
                        onClick={() => handleDetail(item.PK_ACCOUNT_LIMITED)}
                      >
                        <IconCopy />
                      </a>
                    )} */}

                    {accRight?.C_APPROVE === 1 && (
                      <a
                        title={t('txt-appr')}
                        className={
                          item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                        }
                        onClick={() =>
                          item.C_STATUS === 'CHUA_DUYET'
                            ? handleApproveSelected(item.PK_ACCOUNT_LIMITED)
                            : {}
                        }
                      >
                        <IconAppr />
                      </a>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <a
                        className={
                          item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                        }
                        title={t('txt-del')}
                        onClick={() =>
                          item.C_STATUS === 'CHUA_DUYET'
                            ? handleConfirm(item.PK_ACCOUNT_LIMITED)
                            : {}
                        }
                      >
                        <IconTrash />
                      </a>
                    )}
                  </GroupButton>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>

      {(!accountList || !accountList.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (accountList &&
              !!accountList.length &&
              accountList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
      {detailAccInt && (
        <DetailAccountLimitedModal
          onClose={onClose}
          id={detailAccInt}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountInternetList = makeGetAccountLimitList();
  const getAuthenType = makeGetAuthenType();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountInternetList(state),
      glAuthenType: getAuthenType(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(AccountInternetComponent)
);
