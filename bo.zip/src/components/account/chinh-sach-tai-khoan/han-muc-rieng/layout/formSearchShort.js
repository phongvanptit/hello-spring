import RenderSearchShort from 'components/input/inputSearchShort';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { accountListSetLimitsRequest } from 'containers/account/actions';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import RenderInput from 'components/input/renderInput';
import {
  accountSetLimitsApprSuccess,
  accountSetLimitsDelSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccSetLimitsAppr,
  makeGetAccSetLimitsDel,
  makeGetAccSetLimitsUpd,
  makeGetGLBusinessSetLimits,
  makeGetPublicStt,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    dataSearch,
    setDataSearch,

    glStatusList,
    glBusinessSetLimits,

    accSetLimitsUpd,
    accSetLimitsDel,
    accSetLimitsAppr,
  } = props;

  const preAccSetLimitsUpd = usePrevious(accSetLimitsUpd);
  const preAccSetLimitsDel = usePrevious(accSetLimitsDel);
  const preAccSetLimitsAppr = usePrevious(accSetLimitsAppr);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accountListSetLimitsRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accSetLimitsUpd && !_.isEqual(accSetLimitsUpd, preAccSetLimitsUpd)) ||
      (accSetLimitsDel && !_.isEqual(accSetLimitsDel, preAccSetLimitsDel)) ||
      (accSetLimitsAppr && !_.isEqual(accSetLimitsAppr, preAccSetLimitsAppr))
    ) {
      dispatch(accountListSetLimitsRequest(dataSearch));
    }
  }, [accSetLimitsUpd, accSetLimitsDel, accSetLimitsAppr]);

  useEffect(() => {
    if (accSetLimitsDel && !_.isEqual(accSetLimitsDel, preAccSetLimitsDel)) {
      dispatch(accountSetLimitsDelSuccess(null));
      _handleToast(`${t('txt-del-set-limits-success')}`, 'success');
    }
  }, [accSetLimitsDel]);

  useEffect(() => {
    if (accSetLimitsAppr && !_.isEqual(accSetLimitsAppr, preAccSetLimitsAppr)) {
      dispatch(accountSetLimitsApprSuccess(null));
      _handleToast(`${t('txt-appr-set-limits-success')}`, 'success');
    }
  }, [accSetLimitsAppr]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.BUSINESS_CODE = values.formBusiness;
    _params.data.CREATOR_CODE = values.formCreator;
    _params.data.STATUS = values.formStatus;
    dispatch(accountListSetLimitsRequest(_params));
    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = props.formAccountCode;
    _params.data.BUSINESS_CODE = props.formBusiness;
    _params.data.CREATOR_CODE = props.formCreator;
    _params.data.STATUS = props.formStatus;
    dispatch(accountListSetLimitsRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-bus')}</Form.Label>
        <Field
          name="formBusiness"
          className="w_120 form-control"
          component={RenderNormalSelect}
          opts={glBusinessSetLimits}
          placeholder="-- Tất cả --"
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-creator')}</Form.Label>
        <Field
          name="formCreator"
          className="w_120 form-control"
          component={RenderInput}
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="w_120 form-control"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
          onBlur={_handleBlur}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortHanMucRieng',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortHanMucRieng');

const makeMapStateToProps = () => {
  const getGlStatusList = makeGetPublicStt();
  const getGLBusinessSetLimits = makeGetGLBusinessSetLimits();
  const getAccSetLimitsUpd = makeGetAccSetLimitsUpd();
  const getAccSetLimitsDel = makeGetAccSetLimitsDel();
  const getAccSetLimitsAppr = makeGetAccSetLimitsAppr();

  const mapStateToProps = (state) => {
    const { formAccountCode, formBusiness, formCreator, formStatus } = selector(
      state,
      'formAccountCode',
      'formBusiness',
      'formCreator',
      'formStatus'
    );

    return {
      glStatusList: getGlStatusList(state),
      glBusinessSetLimits: getGLBusinessSetLimits(state),
      accSetLimitsUpd: getAccSetLimitsUpd(state),
      accSetLimitsDel: getAccSetLimitsDel(state),
      accSetLimitsAppr: getAccSetLimitsAppr(state),

      formAccountCode,
      formBusiness,
      formCreator,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
