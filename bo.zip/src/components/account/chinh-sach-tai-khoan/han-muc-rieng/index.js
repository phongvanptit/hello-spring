import { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import FormSearch from './layout/formSearch';

import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import NodataSearch from 'components/noDataSearch';
import {
  accountSetLimitsApprRequest,
  accountSetLimitsDelRequest,
} from 'containers/account/actions';
import { makeGetAccListSetLimits,makeGetAccountRight, makeGetToken } from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { numberFormat } from 'utils';
import { GroupButton } from 'utils/styledComponent';
import DetailSetLimitsModal from 'components/modal/account/chinh-sach-tai-khoan/han-muc-rieng/detail';

function SetLimitsComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);

  const { accListSetLimits, t, accRight, token } = props;

  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
  }

  function handleConfirmDel(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-set-limits')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleConfirmApprove(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-set-limits')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(pk);

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(accountSetLimitsDelRequest(params));
  }

  function handleActionApprove(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(accountSetLimitsApprRequest(params));
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            <th>{t('txt-bus')}</th>
            <th>{t('txt-acc')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('txt-active')}</th>
            <th>{t('txt-value')}</th>
            <th>{t('txt-effective-date')}</th>
            <th>{t('txt-expire-date')}</th>
            <th>{t('txt-note')}</th>
            <th>{t('txt-status')}</th>
            <th>{t('txt-creator')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {accListSetLimits &&
            accListSetLimits.map((item) => (
              <tr key={item.PK_ACCOUNT_PRIVATE}>
                <td className="text-center">{item.C_BUSINESS_NAME}</td>
                <td className="text-center">
                  <a onClick={() => handleDetail(item.PK_ACCOUNT_PRIVATE)}>
                    {item.C_ACCOUNT_CODE}
                  </a>
                </td>
                <td>{item.C_ACCOUNT_NAME}</td>
                <td className="text-center">{item.C_ACTIVE === 1 ? 'Có' : 'Không'}</td>
                <td className="text-right">
                  {numberFormat(item.C_CASH_VALUE, 0, '0')}
                </td>
                <td className="text-center">{item.C_EFFECT_DATE}</td>
                <td className="text-center">{item.C_EXPIRE_DATE}</td>
                <td className="text-center">{item.C_CONTENT}</td>
                <td className="text-center">{item.C_STATUS_NAME}</td>
                <td className="text-center">{item.C_CREATOR_CODE}</td>
                <td className="text-center p-0 w_85">
                  <GroupButton>
                    {accRight?.C_VIEW === 1 && (
                      <a
                        title={t('txt-detail')}
                        onClick={() => handleDetail(item.PK_ACCOUNT_PRIVATE)}
                      >
                        <IconCopy />
                      </a>
                    )}

                    {accRight?.C_APPROVE === 1 && (
                      <a
                        title={t('txt-appr')}
                        className={
                          item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                        }
                        onClick={() =>
                          item.C_STATUS === 'CHUA_DUYET'
                            ? handleConfirmApprove(item.PK_ACCOUNT_PRIVATE)
                            : {}
                        }
                      >
                        <IconAppr />
                      </a>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <a
                        className={
                          item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                        }
                        title={t('txt-del')}
                        onClick={() =>
                          item.C_STATUS === 'CHUA_DUYET'
                            ? handleConfirmDel(item.PK_ACCOUNT_PRIVATE)
                            : {}
                        }
                      >
                        <IconTrash />
                      </a>
                    )}
                  </GroupButton>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>

      {(!accListSetLimits || !accListSetLimits.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (accListSetLimits &&
              !!accListSetLimits.length &&
              accListSetLimits[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
      {detailAccInt && (
        <DetailSetLimitsModal
          onClose={onClose}
          id={detailAccInt}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccListSetLimits = makeGetAccListSetLimits();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accListSetLimits: getAccListSetLimits(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(SetLimitsComponent)
);
