import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import RenderSearchShort from 'components/input/inputSearchShort';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { accountChangeSaleSearchRequest } from 'containers/account/actions';
import {
  makeGetAccountChangeSaleAppr,
  makeGetAccountChangeSaleReject,
  makeGetPublicStt,
} from 'lib/selector';
import { FormFlexCenter } from 'utils/styledComponent';
import { accountChangeSaleApprSuccess } from 'containers/account/actions';
import { accountChangeSaleRejectSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetAccountChangeSaleUpd } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    glPublicStt,
    dataSearch,
    setDataSearch,

    accChangeSaleAppr,
    accChangeSaleReject,
    accChangeSaleUpd,

    formFromDate,
    formEndDate,
  } = props;

  const preAccChangeSaleUpd = usePrevious(accChangeSaleUpd);
  const preAccChangeSaleAppr = usePrevious(accChangeSaleAppr);
  const preAccChangeSaleReject = usePrevious(accChangeSaleReject);

  const preFromDate = usePrevious(formFromDate);
  const preToDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accountChangeSaleSearchRequest(dataSearch));
    }, 200);
  }, []);

  React.useEffect(() => {
    if (
      (accChangeSaleUpd && !_.isEqual(accChangeSaleUpd, preAccChangeSaleUpd)) ||
      (accChangeSaleAppr &&
        !_.isEqual(accChangeSaleAppr, preAccChangeSaleAppr)) ||
      (accChangeSaleReject &&
        !_.isEqual(accChangeSaleReject, preAccChangeSaleReject))
    ) {
      dispatch(accountChangeSaleSearchRequest(dataSearch));
    }
  }, [accChangeSaleUpd, accChangeSaleAppr, accChangeSaleReject]);

  React.useEffect(() => {
    if (
      accChangeSaleAppr &&
      !_.isEqual(accChangeSaleAppr, preAccChangeSaleAppr)
    ) {
      dispatch(accountChangeSaleApprSuccess(null));
      _handleToast(`${t('txt-appr-change-sale-success')}`, 'success');
    }
  }, [accChangeSaleAppr]);

  React.useEffect(() => {
    if (
      accChangeSaleReject &&
      !_.isEqual(accChangeSaleReject, preAccChangeSaleReject)
    ) {
      dispatch(accountChangeSaleRejectSuccess(null));
      _handleToast(`${t('txt-reject-change-sale-success')}`, 'success');
    }
  }, [accChangeSaleReject]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.MAKETING_ID_OLD = values.formOldMKTId;
    _params.data.MAKETING_ID_NEW = values.formNewMKTId;
    _params.data.FROM_DATE = values.formFromDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;

    dispatch(accountChangeSaleSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = props.formAccountCode;
    _params.data.MAKETING_ID_OLD = props.formOldMKTId;
    _params.data.MAKETING_ID_NEW = props.formNewMKTId;
    _params.data.FROM_DATE = props.formFromDate;
    _params.data.TO_DATE = props.formEndDate;
    _params.data.STATUS = props.formStatus;

    dispatch(accountChangeSaleSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  useEffect(() => {
    if (formFromDate && !_.isEqual(formFromDate, preFromDate)) {
      if (!formFromDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formFromDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preToDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="w-fix">{t('txt-old-marketing-id')}</Form.Label>
        <Field
          name="formOldMKTId"
          type="text"
          className="form-control w_100 mx-2"
          placeholder={t('txt-old-marketing-id')}
          component={RenderInput}
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix">
          {t('txt-new-marketing-id')}
        </Form.Label>
        <Field
          name="formNewMKTId"
          type="text"
          className="form-control w_100 mx-2"
          placeholder={t('txt-new-marketing-id')}
          component={RenderInput}
          onBlur={_handleBlur}
        />
        <Form.Label className="fz-13 w-fix mx-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formFromDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glPublicStt}
          onBlur={_handleBlur}
        />
      </div>
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />

      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortIdSale',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortIdSale');

const makeMapStateToProps = () => {
  const getPublicStt = makeGetPublicStt();
  const getAccountChangeSaleUpd = makeGetAccountChangeSaleUpd();
  const getAccountChangeSaleAppr = makeGetAccountChangeSaleAppr();
  const getAccountChangeSaleReject = makeGetAccountChangeSaleReject();

  const mapStateToProps = (state) => {
    const {
      formOldMKTId,
      formNewMKTId,
      formFromDate,
      formEndDate,
      formAccountCode,
      formStatus,
    } = selector(
      state,
      'formOldMKTId',
      'formNewMKTId',
      'formFromDate',
      'formEndDate',
      'formAccountCode',
      'formStatus'
    );

    return {
      glPublicStt: getPublicStt(state),
      accChangeSaleUpd: getAccountChangeSaleUpd(state),
      accChangeSaleAppr: getAccountChangeSaleAppr(state),
      accChangeSaleReject: getAccountChangeSaleReject(state),

      formOldMKTId,
      formNewMKTId,
      formFromDate,
      formEndDate,
      formAccountCode,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
