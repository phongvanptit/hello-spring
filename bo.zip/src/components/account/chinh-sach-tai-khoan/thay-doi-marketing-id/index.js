import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconReject } from 'assets/img/icon/icon_reject.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import DetailDSAPMKTIdModal from "components/modal/account/chinh-sach-tai-khoan/thay-doi-marketing-id/danh-sach-ap-dung";
import DetailMKTIdModal from 'components/modal/account/chinh-sach-tai-khoan/thay-doi-marketing-id/detail';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  accountChangeInforApprRequest,
  accountChangeInforUnApprRequest,
  accountChangeInforDelRequest
} from 'containers/account/actions';
import {
  makeGetAccountChangeInforList,
  makeGetToken,
  makeGetSystemInfo
} from 'lib/selector';
import { memo, useState } from 'react';
import { Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaFile } from 'react-icons/fa';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form/formSearch';
import { StringToInt, _diff2Date, formatDate, stringToDate } from 'utils';
import  { useEffect } from 'react';
function TabChangeMarketingId(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [idDetail, setIdDetail] = useState(null);
  const [idDetailDSAP, setIdDetailDSAP] = useState(null);
  const dispatch = useDispatch();
  const [diff, setDiff] = useState(false);

  const { accChangeAccountInforList,sysSystemInfo, subType, t, accRight, token } = props;
  const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(value) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetail(value);
  }

  function handleDetailDSAP(value) {
    if (accRight?.C_VIEW !== 1) return;
    setIdDetailDSAP(value);
  }

  function onClose() {
    setIdDetail(null);
  }

  function onCloseDSAP() {
    setIdDetailDSAP(null);
  }

  function handleAppr(value) {
    if (accRight?.C_APPROVE !== 1) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-change-marketing-id')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleUnAppr(value) {
    if (accRight?.C_APPROVE !== 1) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn hủy duyệt thay đổi Marketing ID?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionUnApprove(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(accountChangeInforApprRequest(params));
  }

  function handleActionUnApprove(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
        NEW_STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(accountChangeInforUnApprRequest(params));
  }

  function handleDel(value) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };

    dispatch(accountChangeInforDelRequest(params));
  }


  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearch
          page={page}
          recordPerPage={recordPerPage}
          subType={subType}
        />
        <PerfectScrollbar className="w-100 mt-2">
          <Table bordered>
            <thead>
              <tr>
                
                <th>{t('txt-marketing-id-code')}</th>
                <th>{t('txt-branch')}</th>
                <th>{t('txt-subBranch')}</th>
                <th>{t('txt-effective-date')}</th>
                <th>{t('txt-approver')}</th>
                <th>{t('txt-status')}</th>
                <th>{t('txt-list-appr')}</th>
                <th>{t('txt-creator')}</th>
                <th>{t('txt-action')}</th>
              </tr>
            </thead>
            <tbody>
              {accChangeAccountInforList &&
                accChangeAccountInforList.map((item) => (
                  <tr key={item.PK_CHANGE_INFO}>
                    
                    <td className="text-center">{item.C_MARKETING_NEW_NAME}</td>
                    <td className="text-center">{item.C_BRANCH_NEW_NAME}</td>
                    <td className="text-center">{item.C_SUB_BRANCH_NEW_NAME}</td>
                    <td className="text-center">{item.C_EFFECT_DATE}</td>
                    <td className="text-center">{item.C_APPROVER_CODE}</td>
                    <td className="text-center">{item.C_STATUS}</td>
                    
                    <td className="text-center p-0 w_85">
                      <GroupButton>
                        <a
                          title={t('txt-detail')}
                          rel="noreferrer noopener"
                          onClick={() => handleDetailDSAP(item.PK_CHANGE_INFO)}
                        >
                          <FaFile />
                        </a>
                      </GroupButton>
                    </td>
                    <td className="text-center">{item.C_CREATOR_CODE}</td>
                    <td className="text-center p-0 w_85">
                      <GroupButton>
                        <a
                          title={t('txt-detail')}
                          rel="noreferrer noopener"
                          onClick={() => handleDetail(item.PK_CHANGE_INFO)}
                        >
                          <IconCopy />
                        </a>
                        {accRight?.C_APPROVE === 1 && (
                          <a
                            title={t('txt-appr')}
                            className={
                              item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                            }
                            rel=""
                            onClick={() =>
                              item.C_STATUS === 'CHUA_DUYET'
                                ? handleAppr(item.PK_CHANGE_INFO)
                                : {}
                            }
                          >
                            <IconAppr />
                          </a>
                        )}
                        {accRight?.C_APPROVE === 1 && 
                        (
                          _diff2Date(
                            item?.C_EFFECT_DATE,
                            formatDate(date, '/', 'dmy')
                          ) > 0
                        ) &&
                        (
                          <a
                            title={'Hủy duyệt'}
                            className={
                              item.C_STATUS !== 'DA_DUYET' ? 'disabled' : ''
                            }
                            rel=""
                            onClick={() =>
                              item.C_STATUS === 'DA_DUYET'
                                ? handleUnAppr(item.PK_CHANGE_INFO)
                                : {}
                            }
                          >
                            <IconReject />
                          </a>
                        )}
                        
                        {accRight?.C_UPDATE === 1 && (
                          <a
                            title={t('txt-del')}
                            className={
                              item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                            }
                            onClick={() =>
                              item.C_STATUS === 'CHUA_DUYET' ?
                                handleDel(item.PK_CHANGE_INFO)
                                : {}
                            }

                          >
                            <IconTrash />
                          </a>
                        )}
                      </GroupButton>
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </PerfectScrollbar>
        {(!accChangeAccountInforList || !accChangeAccountInforList.length) && (
          <NodataSearch name={t('lab-change-marketing-id')} />
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (accChangeAccountInforList &&
                !!accChangeAccountInforList.length &&
                accChangeAccountInforList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {idDetail && (
          <DetailMKTIdModal
            id={idDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
        {idDetailDSAP && (
          <DetailDSAPMKTIdModal
            id={idDetailDSAP}
            onClose={onCloseDSAP}
            accRight={accRight}
          />
        )}
      </div >
    </>
  );
}

const makeMapStateToProps = () => {
  const getAccountChangeInforList = makeGetAccountChangeInforList();
  const getSystemInfo = makeGetSystemInfo();

  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      accChangeAccountInforList: getAccountChangeInforList(state),
      sysSystemInfo: getSystemInfo(state),
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(memo(TabChangeMarketingId))
);
