import RenderSelectDate from 'components/input/renderDatePicker';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import IconExcel from 'assets/img/icon/ms-excel.png';
import RenderSearchShort from 'components/input/inputSearchShort';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accountChangeAccountInforSearchRequest,
  accountChangeInforApprSuccess,
  accountChangeInforUnApprSuccess,
  accountChangeInforDelSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountChangeAccountInforAppr,
  makeGetAccountChangeComboFeeDel,
  makeGetAccountChangeInforUpd,
  makeGetAccountChangeSaleReject,
  makeGetPublicStt,
  makeGetAccountChangeAccountInforUnAppr
} from 'lib/selector';
import {
  ExportExcel, FormFlexCenter
} from 'utils/styledComponent';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    glPublicStt,
    dataSearch,
    setDataSearch,

    accComboFeeUpd,
    accChangeInforAppr,
    accChangeInforDel,
    formEffectiveDate,
    formEffectiveToDate,
    accChangeInforUnAppr,
  } = props;

  const preaccComboFeeUpd = usePrevious(accComboFeeUpd);
  const preAccChangeComboFeeAppr = usePrevious(accChangeInforAppr);
  const preAccChangeComboFeeDel = usePrevious(accChangeInforDel);
  const preAccChangeUnAppr = usePrevious(accChangeInforUnAppr);

  const preFromDate = usePrevious(formEffectiveDate);
  const preToDate = usePrevious(formEffectiveToDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accountChangeAccountInforSearchRequest(dataSearch));
    }, 200);
  }, []);

  React.useEffect(() => {
    if (
      (accComboFeeUpd && !_.isEqual(accComboFeeUpd, preaccComboFeeUpd)) ||
      (accChangeInforAppr &&
        !_.isEqual(accChangeInforAppr, preAccChangeComboFeeAppr)) ||
        (accChangeInforUnAppr &&
          !_.isEqual(accChangeInforUnAppr, preAccChangeUnAppr)) ||
      (accChangeInforDel &&
        !_.isEqual(accChangeInforDel, preAccChangeComboFeeDel)
      )
    ) {
      dispatch(accountChangeAccountInforSearchRequest(dataSearch));
    }
  }, [accComboFeeUpd, accChangeInforAppr, accChangeInforDel,accChangeInforUnAppr]);

  React.useEffect(() => {
    if (
      accChangeInforAppr &&
      !_.isEqual(accChangeInforAppr, preAccChangeComboFeeAppr)
    ) {
      dispatch(accountChangeInforApprSuccess(null));
      _handleToast(`${t('txt-appr-change-marketing-id-success')}`, 'success');
    }
  }, [accChangeInforAppr]);

  React.useEffect(() => {
    if (
      accChangeInforUnAppr &&
      !_.isEqual(accChangeInforUnAppr, preAccChangeUnAppr)
    ) {
      dispatch(accountChangeInforUnApprSuccess(null));
      _handleToast(`${'Hủy duyệt bút toán thành công'}`, 'success');
    }
  }, [accChangeInforUnAppr]);

  React.useEffect(() => {
    if (
      accChangeInforDel &&
      !_.isEqual(accChangeInforDel, preAccChangeComboFeeDel)
    ) {
      dispatch(accountChangeInforDelSuccess(null));
      _handleToast(`${t('txt-del-change-marketing-id-success')}`, 'success');
    }
  }, [accChangeInforDel]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.CREATOR_CODE = props.formCode;
    _params.data.C_MARKETING_NEW = props.formComboNew;
    _params.data.C_BRANCH_NEW = props.formComboOver;
    _params.data.FROM_DATE = props.formEffectiveDate;
    _params.data.STATUS = props.formStatus;

    dispatch(accountChangeAccountInforSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.CREATOR_CODE = props.formCode;
    _params.data.C_MARKETING_NEW = props.formComboNew;
    _params.data.C_BRANCH_NEW = props.formComboOver;
    _params.data.EFFECT_DATE = props.formEffectiveDate;
    _params.data.STATUS = props.formStatus;

    dispatch(accountChangeAccountInforSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  useEffect(() => {
    if (formEffectiveDate && !_.isEqual(formEffectiveDate, preFromDate)) {
      if (!formEffectiveDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEffectiveDate]);

  useEffect(() => {
    if (formEffectiveToDate && !_.isEqual(formEffectiveToDate, preToDate)) {
      if (!formEffectiveToDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEffectiveToDate]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'TK_EXPORT_04';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_MKT";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix mx-2">
          {t('txt-effective-date')}
        </Form.Label>
        <Field
          name="formEffectiveDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 mx-2"
          component={RenderNormalSelect}
          opts={glPublicStt}
          placeholder="-- Tất cả --"
          onBlur={_handleBlur}
        />
      </div>
      <Field
        name="formCode"
        type="text"
        className="form-control"
        placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ExportExcel>
        <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchMarketingID',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchMarketingID');

const makeMapStateToProps = () => {
  const getPublicStt = makeGetPublicStt();
  const getAccountComboFeeUpd = makeGetAccountChangeInforUpd();
  const getAccountChangeSaleReject = makeGetAccountChangeSaleReject();
  const getAccountChangeComboFeeAppr = makeGetAccountChangeAccountInforAppr();
  const getAccountChangeComboFeeDel = makeGetAccountChangeComboFeeDel();
  const getAccountChangeInfoUnAppr = makeGetAccountChangeAccountInforUnAppr();

  const mapStateToProps = (state) => {
    const {
      formComboNew,
      formComboOver,
      formNewMKTId,
      formEffectiveDate,
      formEffectiveToDate,
      formCode,
      formStatus,
    } = selector(
      state,
      'formComboNew',
      'formComboOver',
      'formNewMKTId',
      'formEffectiveDate',
      'formEffectiveToDate',
      'formCode',
      'formStatus'
    );

    return {
      glPublicStt: getPublicStt(state),
      accComboFeeUpd: getAccountComboFeeUpd(state),
      accChangeSaleReject: getAccountChangeSaleReject(state),
      accChangeInforAppr: getAccountChangeComboFeeAppr(state),
      accChangeInforDel: getAccountChangeComboFeeDel(state),
      accChangeInforUnAppr: getAccountChangeInfoUnAppr(state),
      formComboNew,
      formComboOver,
      formNewMKTId,
      formEffectiveDate,
      formEffectiveToDate,
      formCode,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
