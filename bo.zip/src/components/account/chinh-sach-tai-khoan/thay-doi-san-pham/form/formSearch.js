import { makeGetToken } from 'lib/selector';
import React from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';

import {
  accountChangeAccountInforSearchRequest,
  accountChangeAccountInforSearchSuccess
} from 'containers/account/actions';
import { ContainerSearch } from 'utils/styledComponent';
import FormSearchShort from './formSearchShort';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();

  const [dataSearch, setDataSearch] = React.useState(null);

  const { token, page, recordPerPage } = props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);

  React.useEffect(() => {
    initFormSearch();

    return () => {
      // clear
      setDataSearch(null);
      dispatch(accountChangeAccountInforSearchSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      dataSearch &&
      ((page && !_.isEqual(page, prePage)) ||
        (recordPerPage && !_.isEqual(recordPerPage, preRecordPerPage)))
    ) {
      let _dataSearch = Object.assign({}, dataSearch);
      _dataSearch.data.PAGE = page || 1;
      _dataSearch.data.RECORD_PER_PAGE = recordPerPage || 10;

      dispatch(accountChangeAccountInforSearchRequest(_dataSearch));
      setDataSearch(_dataSearch);
    }
  }, [page, recordPerPage]);

  function initFormSearch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        TYPE: 'PRODUCT',
        FROM_DATE: "",
        TO_DATE: "",
        STATUS: "",
        CREATOR_CODE: "",
        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);
  }

  return (
    <ContainerSearch>
      <span className="mr-auto" />
      {dataSearch && (
        <FormSearchShort
          dataSearch={dataSearch}
          setDataSearch={setDataSearch}
        />
      )}
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
