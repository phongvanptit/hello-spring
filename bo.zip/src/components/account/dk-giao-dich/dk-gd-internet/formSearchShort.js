import RenderSearchShort from 'components/input/inputSearchShort';
import { useEffect, useRef } from 'react';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';

import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import RenderSelectDate from 'components/input/renderDatePicker';
import { accountInternetDelSuccess, accountInternetSearchRequest,accountInternetUpdSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetAccountInternetDel, makeGetAccountInternetUpd } from 'lib/selector';
import { Form } from 'react-bootstrap';
import {
  ButtonSearch,
  ExportExcel,
  FormFlexCenter,
} from 'utils/styledComponent';
import { globalExportFileVer2Request } from 'containers/report/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    accIntUpd,
    accIntDel,

    formAccountCode,
    formStartDate,
    formEndDate,
  } = props;

  const preAccIntUpd = usePrevious(accIntUpd);
  const preAccIntDel = usePrevious(accIntDel);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accountInternetSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accIntUpd && !_.isEqual(accIntUpd, preAccIntUpd)) ||
      (accIntDel && !_.isEqual(accIntDel, preAccIntDel))
    ) {
      dispatch(accountInternetSearchRequest(dataSearch));
    }
  }, [accIntUpd, accIntDel]);

  useEffect(() => {
    if (accIntUpd && !_.isEqual(accIntUpd, preAccIntUpd)) {
      dispatch(accountInternetUpdSuccess(null));
    }
  }, [accIntUpd]);

  useEffect(() => {
    if (accIntDel && !_.isEqual(accIntDel, preAccIntDel)) {
      _handleToast(`${t('txt-del-service-success')}`);
      dispatch(accountInternetDelSuccess(null));
    }
  }, [accIntDel]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;

    dispatch(accountInternetSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;

    dispatch(accountInternetSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleExportExcel(type) {
    const params = dataSearch;
    params.data.TEMPLATE_CODE = 'TK_EXPORT_02';
    params.data.EXPORT_FILE_TYPE = type;
    params.data.RECORD_PER_PAGE = 1000000;
    params.cmd = "EXPORT.EXPORT_ALL_ACCOUNT_INTERNET";
    dispatch(globalExportFileVer2Request(params));
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name={'formAccountCode'}
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
          <img src={IconExcel} alt="" onClick={() => handleExportExcel('EXCEL')} />
      </ExportExcel>
      {/* <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel> */}
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortGDInternet',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortGDInternet');

const makeMapStateToProps = () => {
  const getAccountInternetUpd = makeGetAccountInternetUpd();
  const getAccountInternetDel = makeGetAccountInternetDel();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStartDate, formEndDate } = selector(
      state,
      'formAccountCode',
      'formStartDate',
      'formEndDate'
    );

    return {
      accIntUpd: getAccountInternetUpd(state),
      accIntDel: getAccountInternetDel(state),
      formAccountCode,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
