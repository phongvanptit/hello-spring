import RenderInput from 'components/input/renderInput';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import { stringToDate } from 'utils';

import { accountInternetSearchRequest } from 'containers/account/actions';
import { makeGetSystemInfo } from 'lib/selector';
import * as _ from 'lodash';
import { arrSearchAccInternet } from 'utils/const';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchAccInternet, 'value'));
  }, []);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formCustCode;
    _dataSearch.data.ACCOUNT_NAME = values.formCustName;
    _dataSearch.data.PHONE_NUMBER = values.formMobile;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;

    dispatch(accountInternetSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);

    dispatch(change('formSearchModalGDInternet', 'formCustName', ''));
    dispatch(change('formSearchModalGDInternet', 'formMobile', ''));
    dispatch(change('formSearchModalGDInternet', 'formCreatorCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchAccInternet,
              (o) => o?.value === item
            );

            if (!_objItem || _objItem.value === 'formCustCode') return null;

            if (_objItem.type === 'text')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalGDInternet',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalGDInternet');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const { formCustCode, formCustName, formMobile, formCreatorCode } =
      selector(
        state,
        'formCustCode',
        'formCustName',
        'formMobile',
        'formCreatorCode'
      );

    const { dataSearch } = props;

    return {
      sysSystemInfo: getSystemInfo(state),
      formCustCode,
      formCustName,
      formMobile,
      formCreatorCode,

      initialValues: {
        formCustCode: dataSearch?.data?.ACCOUNT_CODE,
        formCustName: dataSearch?.data?.ACCOUNT_NAME,
        formMobile: dataSearch?.data?.PHONE_NUMBER,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
