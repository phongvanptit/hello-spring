import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Table } from 'react-bootstrap';
import Paging from 'components/paging';
import FormSearchAccInternet from './formSearchAccInternet';
import {
  makeGetToken,
  makeGetAccountInternetList,
  makeGetAuthenType,
} from 'lib/selector';

import * as _ from 'lodash';
import { arrAuthenType } from 'utils/const';
import { translate } from 'react-i18next';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import NodataSearch from 'components/noDataSearch';
import { confirmAlert } from 'react-confirm-alert';
import { accountInternetDelRequest } from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';
import { RiLockPasswordLine } from 'react-icons/ri';
import DetailAccountInternet from 'components/modal/account/dk-giao-dich/dk-gd-internet/DetailAccountInternet';
import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
import PasswordSettingInternet from 'components/modal/account/dk-giao-dich/dk-gd-internet/PasswordSettingInternet';
function AccountInternetComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);
  const [accountDetail, setAccountDetail] = useState(null);
  const [passAccInt, setPassAccInt] = useState(null);
  const { accountList, glAuthenType, t, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetailAccInternet(pk) {
    if (accRight?.C_VIEW !== 1) return;

    setDetailAccInt(pk);
  }

  function handleDetailAccount(accountCode) {
    if (accRight?.C_VIEW !== 1) return;
    setAccountDetail(accountCode);
  }

  function onClose() {
    setDetailAccInt(null);
    setAccountDetail(null);
    setPassAccInt(null);
  }

  function handleConfirm(record) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-service')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionClose(record);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_INTERNET',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_ACCOUNT_INTERNET,
      },
    };

    dispatch(accountInternetDelRequest(params));
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearchAccInternet page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            <th>{t('txt-acc')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('txt-authen')}</th>
            {/* <th>{t('txt-acc-default')}</th> */}
            <th>{t('txt-nick-name')}</th>
            <th>{t('txt-phone-receive-otp')}</th>
            <th>{t('txt-time')}</th>
            <th>{t('txt-creator')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {accountList &&
            accountList.map((item) => (
              <tr key={item.PK_ACCOUNT_INTERNET}>
                <td className="text-center">
                  <a onClick={() => handleDetailAccount(item.C_ACCOUNT_CODE)}>
                    {item.C_ACCOUNT_CODE}
                  </a>
                </td>
                <td className="text-center">{item.C_ACCOUNT_NAME}</td>
                <td className="text-center">
                  {
                    _.find(
                      glAuthenType && !!glAuthenType.length
                        ? glAuthenType
                        : arrAuthenType,
                      (o) => o?.value === item.C_AUTHEN_TYPE
                    )?.label
                  }
                </td>
                {/* <td className="text-center">
                  {item.C_ACCOUNT_DEFAULT == 1 ? t('txt-yes') : t('txt-no')}
                </td> */}
                <td className="text-center">{item.C_NICK_NAME}</td>
                <td className="text-center">{item.C_PHONE_NUMBER}</td>
                <td className="text-center">{item.C_OPEN_DATE}</td>
                <td className="text-center">{item.C_CREATOR_CODE}</td>
                <td className="text-center p-0 w_85">
             
                    <GroupButton>
                      <a
                        title={t('txt-detail')}
                        onClick={() =>
                          handleDetailAccInternet(item.PK_ACCOUNT_INTERNET)
                        }
                      >
                        <IconCopy />
                      </a>
                      {accRight?.C_UPDATE === 1 &&
                     (
                      <a
                        title={t('txt-del')}
                        onClick={() => handleConfirm(item)}
                      >
                        <IconTrash />
                      </a>
                        )}
                      {accRight?.C_UPDATE === 1 && ( 
                      <a
                        title={t('txt-pass-setting')}
                        onClick={() => setPassAccInt(item.PK_ACCOUNT_INTERNET)}
                      >
                        <RiLockPasswordLine size={25} />
                      </a>
                      )}
                    </GroupButton>
           
                </td>
              </tr>
            ))}
        </tbody>
      </Table>
      {(!accountList || !accountList.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (accountList &&
              !!accountList.length &&
              accountList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
      {accountDetail && (
        <DetailAccountModal
          accountCode={accountDetail}
          onClose={onClose}
          accRight={accRight}
        />
      )}
      {detailAccInt && (
        <DetailAccountInternet
          onClose={onClose}
          id={detailAccInt}
          accRight={accRight}
        />
      )}
      {passAccInt && (
        <PasswordSettingInternet
          onClose={onClose}
          id={passAccInt}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountInternetList = makeGetAccountInternetList();
  const getAuthenType = makeGetAuthenType();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accRight: getAccountRight(state),
      accountList: getAccountInternetList(state),
      glAuthenType: getAuthenType(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(AccountInternetComponent)
);
