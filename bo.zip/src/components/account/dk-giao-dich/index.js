import React from 'react';
import TabGDInternet from './dk-gd-internet/index';
import TabGDMobile from './dk-gd-mobile/index';
import TabHCSms from './han-che-sms/index';

function DangKyGDComponent(props) {
  const { type } = props;

  return (
    <>
      <div className="custom-tabs-content my-3">
        {type === 'internet' && <TabGDInternet />}
        {type === 'mobile' && <TabGDMobile />}
        {type === 'sms' && <TabHCSms />}
      </div>
    </>
  );
}

export default DangKyGDComponent;
