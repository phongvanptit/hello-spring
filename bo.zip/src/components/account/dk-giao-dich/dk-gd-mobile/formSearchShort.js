import IconConfig from 'assets/img/icon/cog.png';
import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import {
  accountPhoneApproveSuccess,
  accountPhoneDelSuccess,
  accountPhoneSearchRequest,
  accountPhoneUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  makeGetAccountPhoneApprove,
  makeGetAccountPhoneDel,
  makeGetAccountPhoneUpdate,
  makeGetPublicStt,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import {
  ExportExcel,
  FormFlexCenter
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    accPhoneUpd,
    accPhoneDel,
    accPhoneAppr,

    formAccountCode,
    glStatusList,
    formStartDate,
    formEndDate,
    formStatus,
  } = props;

  const preAccPhoneUpd = usePrevious(accPhoneUpd);
  const preAccPhoneDel = usePrevious(accPhoneDel);
  const preAccPhoneAppr = usePrevious(accPhoneAppr);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(accountPhoneSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (accPhoneUpd && !_.isEqual(accPhoneUpd, preAccPhoneUpd)) ||
      (accPhoneDel && !_.isEqual(accPhoneDel, preAccPhoneDel)) ||
      (accPhoneAppr && !_.isEqual(accPhoneAppr, preAccPhoneAppr))
    ) {
      dispatch(accountPhoneSearchRequest(dataSearch));
    }
  }, [accPhoneUpd, accPhoneDel, accPhoneAppr]);

  React.useEffect(() => {
    if (accPhoneUpd && !_.isEqual(accPhoneUpd, preAccPhoneUpd)) {
      dispatch(accountPhoneUpdSuccess(null));
    }
  }, [accPhoneUpd]);

  React.useEffect(() => {
    if (accPhoneDel && !_.isEqual(accPhoneDel, preAccPhoneDel)) {
      _handleToast(`${t('txt-del-service-success')}`);
      dispatch(accountPhoneDelSuccess(null));
    }
  }, [accPhoneDel]);

  React.useEffect(() => {
    if (accPhoneAppr && !_.isEqual(accPhoneAppr, preAccPhoneAppr)) {
      _handleToast(`${t('txt-appr-service-success')}`);
      dispatch(accountPhoneApproveSuccess(null));
    }
  }, [accPhoneAppr]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formAccountCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;
    _params.data.STATUS = values.formStatus;

    dispatch(accountPhoneSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formAccountCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;
    _params.data.STATUS = formStatus;

    dispatch(accountPhoneSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="w_120 form-control"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
          onBlur={_handleBlur}
        />
      </div>
      
      <Field
        name="formAccountCode"
        type="text"
        className="form-control"
        placeholder={t('txt-acc')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
      <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortGDMobile',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortGDMobile');

const makeMapStateToProps = () => {
  const getAccountPhoneUpdate = makeGetAccountPhoneUpdate();
  const getAccountPhoneDel = makeGetAccountPhoneDel();
  const getAccountPhoneApprove = makeGetAccountPhoneApprove();
  const getGlStatusList = makeGetPublicStt();

  const mapStateToProps = (state) => {
    const { formAccountCode, formStartDate, formEndDate,formStatus } = selector(
      state,
      'formAccountCode',
      'formStartDate',
      'formEndDate',
      'formStatus',
    );

    return {
      glStatusList: getGlStatusList(state),
      accPhoneUpd: getAccountPhoneUpdate(state),
      accPhoneDel: getAccountPhoneDel(state),
      accPhoneAppr: getAccountPhoneApprove(state),
      formAccountCode,
      formStartDate,
      formEndDate,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
