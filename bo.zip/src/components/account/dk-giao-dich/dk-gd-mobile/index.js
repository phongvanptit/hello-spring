import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import FormSearchAccInternet from './formSearchAccMobile';
import {
  makeGetToken,
  makeGetAccountPhoneList,
  makeGetAuthenType,
} from 'lib/selector';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import NodataSearch from 'components/noDataSearch';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import DetailAccountMobileModal from 'components/modal/account/dk-giao-dich/dk-gd-mobile/DetailAccountMobile';
import DetailAccountModal from 'components/modal/account/tai-khoan/mo-tk/DetailAccountModal';
import { confirmAlert } from 'react-confirm-alert';
import { accountPhoneDelRequest } from 'containers/account/actions';
import { accountPhoneApproveRequest } from 'containers/account/actions';
import { makeGetAccountRight } from 'lib/selector';

function AccountInternetComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);
  const [accountDetail, setAccountDetail] = useState(null);
  const { accountList, t, token, accRight } = props;
  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function handleDetailAccount(accountCode) {
    if (accRight?.C_VIEW !== 1) return;
    setAccountDetail(accountCode);
  }

  function onClose() {
    setDetailAccInt(null);
    setAccountDetail(null);
  }

  function handleConfirm(actionName, record) {
    if (record.C_STATUS === 'DA_DUYET' && actionName === 'approve') return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'close'
                ? t('txt-del-service')
                : actionName === 'approve'
                ? t('txt-appr-service')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'close':
                    handleActionClose(record);
                    break;
                  case 'approve':
                    handleActionApprove(record);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_PHONE',
      group: 'LIST',
      data: {
        ID: record?.PK_ACCOUNT_PHONE,
      },
    };

    dispatch(accountPhoneDelRequest(params));
  }

  function handleActionApprove(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_SINGLE_ACCOUNT_PHONE',
      group: 'LIST',
      data: {
        ID: record?.PK_ACCOUNT_PHONE,
      },
    };

    dispatch(accountPhoneApproveRequest(params));
  }

  return (
    <>
      <div className="w-100 d-flex flex-column">
        <FormSearchAccInternet page={page} recordPerPage={recordPerPage} />
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-acc')}</th>
              <th>{t('txt-acc-name')}</th>
              <th>{t('txt-from-date')}</th>
              <th>{t('txt-to-date')}</th>
              <th>{t('txt-note')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-create-time')}</th>
              <th>{t('txt-creator')}</th>
              <th>{t('txt-action')}</th>
            </tr>
          </thead>
          <tbody>
            {accountList &&
              accountList.map((item) => (
                <tr key={item.PK_ACCOUNT_PHONE}>
                  <td className="text-center">
                    <a onClick={() => handleDetailAccount(item.C_ACCOUNT_CODE)}>
                      {item.C_ACCOUNT_CODE}
                    </a>
                  </td>
                  <td className="text-center">{item.C_ACCOUNT_NAME}</td>
                  <td className="text-center">
                    {item.C_EFFECT_DATE ? item.C_EFFECT_DATE.split(' ')[0] : ''}
                  </td>
                  <td className="text-center">
                    {item.C_EXPIRE_DATE ? item.C_EXPIRE_DATE.split(' ')[0] : ''}
                  </td>
                  <td className="">{item.C_CONTENT}</td>
                  <td className={'text-center orderStt_' + item.C_STATUS}>
                    {item.C_STATUS}
                  </td>
                  <td className="text-center">{item.C_CREATE_TIME}</td>
                  <td className="text-center">{item.C_CREATOR_CODE}</td>
                  <td className="text-center p-0 w_85">
                    <GroupButton>
                      {accRight?.C_VIEW === 1 && (
                        <a
                          title={t('txt-detail')}
                          onClick={() => handleDetail(item.PK_ACCOUNT_PHONE)}
                        >
                          <IconCopy />
                        </a>
                      )}
                      {accRight?.C_APPROVE === 1 &&
                        item?.C_STATUS === 'CHUA_DUYET' && (
                          <a
                            title={t('txt-appr')}
                            onClick={() => handleConfirm('approve', item)}
                          >
                            <IconAppr />
                          </a>
                        )}
                      {accRight?.C_UPDATE === 1 &&
                        item?.C_STATUS === 'CHUA_DUYET' && (
                          <a
                            title={t('txt-del')}
                            onClick={() => handleConfirm('close', item)}
                          >
                            <IconTrash />
                          </a>
                        )}
                    </GroupButton>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
        {(!accountList || !accountList.length) && (
          <NodataSearch name={t('txt-acc-1')} />
        )}
        <div className="mt-3 d-flex justify-content-end">
          <Paging
            page={page}
            nextPage={_handleNextPage}
            recordPerPage={recordPerPage}
            setRecordPerPage={setRecordPerPage}
            total={
              (accountList &&
                !!accountList.length &&
                accountList[0].C_TOTAL_RECORD) ||
              0
            }
          />
        </div>
        {accountDetail && (
          <DetailAccountModal
            accountCode={accountDetail}
            onClose={onClose}
            accRight={accRight}
          />
        )}
        {detailAccInt && (
          <DetailAccountMobileModal
            onClose={onClose}
            id={detailAccInt}
            accRight={accRight}
          />
        )}
      </div>
    </>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountInternetList = makeGetAccountPhoneList();
  const getAccountRight = makeGetAccountRight();
  const getAuthenType = makeGetAuthenType();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      accountList: getAccountInternetList(state),
      glAuthenType: getAuthenType(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(AccountInternetComponent)
);
