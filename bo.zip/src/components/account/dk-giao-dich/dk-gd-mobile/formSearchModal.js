import RenderInput from 'components/input/renderInput';
import { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import { accountPhoneSearchRequest } from 'containers/account/actions';
import { makeGetSystemInfo } from 'lib/selector';
import { stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    sysSystemInfo,
  } = props;

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formAccountCode;
    _dataSearch.data.ACCOUNT_NAME = values.formAccountName;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;
    _dataSearch.data.FROM_DATE = values.formStartDate;
    _dataSearch.data.TO_DATE = values.formEndDate;


    dispatch(accountPhoneSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    _date?.setMonth(_date.getMonth() - 1);
    dispatch(change('formSearchModalGDMobile', 'formAccountCode', ''));
    dispatch(change('formSearchModalGDMobile', 'formAccountName', ''));
    dispatch(change('formSearchModalGDMobile', 'formCreatorCode', ''));
    dispatch(change('formSearchModalGDMobile', 'formStartDate', ''));
    dispatch(change('formSearchModalGDMobile', 'formEndDate', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-4 w-100">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-acc')}</Form.Label>
          <Field
            name="formAccountCode"
            type="text"
            className="form-control"
            placeholder={t('txt-acc')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-acc-name')}</Form.Label>
          <Field
            name="formAccountName"
            type="text"
            className="form-control"
            placeholder={t('txt-acc-name')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-creator')}</Form.Label>
          <Field
            name="formCreatorCode"
            type="text"
            className="form-control"
            placeholder={t('txt-creator')}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalGDMobile',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalGDMobile');

const makeMapStateToProps = () => {
  const getSystemInfo = makeGetSystemInfo();
  const mapStateToProps = (state, props) => {
    const { formAccountCode, formAccountName, formCreatorCode,formStartDate,formEndDate } =
      selector(
        state,
        'formAccountCode',
        'formAccountName',
        'formCreatorCode',
        'formStartDate',
        'formEndDate',
      );

    const { dataSearch } = props;

    return {
      getSystemInfo: getSystemInfo(state),
      formAccountCode,
      formStartDate,
      formAccountName,
      formCreatorCode,
      formEndDate,

      initialValues: {
        formAccountCode: dataSearch?.data?.ACCOUNT_CODE,
        formAccountName: dataSearch?.data?.ACCOUNT_NAME,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
        formStartDate: dataSearch?.data?.FROM_DATE,
        formEndDate: dataSearch?.data?.TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
