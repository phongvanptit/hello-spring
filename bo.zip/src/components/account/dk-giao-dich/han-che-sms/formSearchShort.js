import IconConfig from 'assets/img/icon/cog.png';
import RenderSearchShort from 'components/input/inputSearchShort';
import RenderSelectDate from 'components/input/renderDatePicker';
import { limitSmsEmailNotiApproveSuccess, limitSmsEmailNotiDelSuccess, limitSmsEmailNotiSearchRequest, limitSmsEmailNotiUpdSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeLimitSmsEmailNotiAppr, makeLimitSmsEmailNotiDel, makeLimitSmsEmailNotiUpdate } from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import {
  ExportExcel,
  FormFlexCenter
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    limitSmsEmailNotiDel,
    limitSmsEmailNotiAppr,
    limitSmsEmailNotiUpd,

    formCustCode,
    formStartDate,
    formEndDate,
  } = props;

  const preAccountDelete = usePrevious(limitSmsEmailNotiDel);
  const preAccountApprove = usePrevious(limitSmsEmailNotiAppr);
  const preAccountUpdate = usePrevious(limitSmsEmailNotiUpd);
  const preStartDate = usePrevious(formStartDate);
  const preEndDate = usePrevious(formEndDate);

  useEffect(() => {
    setTimeout(() => {
      dispatch(limitSmsEmailNotiSearchRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (limitSmsEmailNotiDel &&
        !_.isEqual(limitSmsEmailNotiDel, preAccountDelete)) ||
      (limitSmsEmailNotiUpd &&
        !_.isEqual(limitSmsEmailNotiUpd, preAccountUpdate)) ||
      (limitSmsEmailNotiAppr &&
        !_.isEqual(limitSmsEmailNotiAppr, preAccountApprove))
    ) {
      dispatch(limitSmsEmailNotiSearchRequest(dataSearch));
    }
  }, [limitSmsEmailNotiDel, limitSmsEmailNotiUpd, limitSmsEmailNotiAppr]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiDel &&
      !_.isEqual(limitSmsEmailNotiDel, preAccountDelete)
    ) {
      _handleToast(`${t('txt-del-limit-service-success')}`, 'success');
      dispatch(limitSmsEmailNotiDelSuccess(null));
    }
  }, [limitSmsEmailNotiDel]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiUpd &&
      !_.isEqual(limitSmsEmailNotiUpd, preAccountUpdate)
    ) {
      dispatch(limitSmsEmailNotiUpdSuccess(null));
    }
  }, [limitSmsEmailNotiUpd]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiAppr &&
      !_.isEqual(limitSmsEmailNotiAppr, preAccountApprove)
    ) {
      _handleToast(`${t('txt-appr-limit-service-success')}`, 'success');
      dispatch(limitSmsEmailNotiApproveSuccess(null));
    }
  }, [limitSmsEmailNotiAppr]);

  useEffect(() => {
    if (formStartDate && !_.isEqual(formStartDate, preStartDate)) {
      if (!formStartDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formStartDate]);

  useEffect(() => {
    if (formEndDate && !_.isEqual(formEndDate, preEndDate)) {
      if (!formEndDate.includes('_')) {
        _handleBlur();
      }
    }
  }, [formEndDate]);

  const submit = (values) => {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = values.formCustCode;
    _params.data.FROM_DATE = values.formStartDate;
    _params.data.TO_DATE = values.formEndDate;

    dispatch(limitSmsEmailNotiSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = formCustCode;
    _params.data.FROM_DATE = formStartDate;
    _params.data.TO_DATE = formEndDate;

    dispatch(limitSmsEmailNotiSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix mr-2">
          {t('txt-from-date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
          classParentName="w-100"
        />
        <Form.Label className="fz-13 w-fix mx-2">{t('txt-to-date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          classParentName="w-100"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="formCustCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      {/* <ButtonSearch ref={refSubmit} type="submit" disabled={submitting}>
        <img src={IconReset} alt="" />
      </ButtonSearch>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel> */}
      <ExportExcel>
        <img src={IconConfig} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShort',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShort');

const makeMapStateToProps = () => {
  const getLimitSmsEmailNotiUpdate = makeLimitSmsEmailNotiUpdate();
  const getLimitSmsEmailNotiAppr = makeLimitSmsEmailNotiAppr();
  const getLimitSmsEmailNotiDel = makeLimitSmsEmailNotiDel();

  const mapStateToProps = (state) => {
    const { formCustCode, formStartDate, formEndDate } = selector(
      state,
      'formCustCode',
      'formStartDate',
      'formEndDate'
    );

    return {
      limitSmsEmailNotiUpd: getLimitSmsEmailNotiUpdate(state),
      limitSmsEmailNotiDel: getLimitSmsEmailNotiDel(state),
      limitSmsEmailNotiAppr: getLimitSmsEmailNotiAppr(state),

      formCustCode,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
