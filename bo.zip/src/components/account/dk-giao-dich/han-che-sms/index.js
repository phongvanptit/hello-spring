import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Table } from 'react-bootstrap';

import Paging from 'components/paging';
import FormSearch from './formSearch';

import {
  makeGetToken,
  makeLimitSmsEmailNotiListSearch,
  makeGetAuthenType,
  makeGetAccountRight
} from 'lib/selector';
import { translate } from 'react-i18next';
import NodataSearch from 'components/noDataSearch';
import { GroupButton } from 'utils/styledComponent';
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconAppr } from 'assets/img/icon/ic_approve.svg';
import DetailAccountSMSModal from 'components/modal/account/dk-giao-dich/han-che-sms/DetailAccountLimited';
import { confirmAlert } from 'react-confirm-alert';
import { limitSmsEmailNotiDelRequest } from 'containers/account/actions';
import { limitSmsEmailNotiApproveRequest } from 'containers/account/actions';

function AccountSmsComponent(props) {
  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [detailAccInt, setDetailAccInt] = useState(null);

  const { limitSmsEmailNotiList, t, accRight, token } = props;

  const dispatch = useDispatch();

  function _handleNextPage(step) {
    setPage(step);
  }

  function handleDetail(pk) {
    if (accRight?.C_VIEW !== 1) return;
    setDetailAccInt(pk);
  }

  function onClose() {
    setDetailAccInt(null);
  }

  function handleConfirm(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-limit-service')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(limitSmsEmailNotiDelRequest(params));
  }

  function handleApproveSelected(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-limit-service')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(limitSmsEmailNotiApproveRequest(params));
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <Table bordered>
        <thead>
          <tr>
            {/* <th>#</th> */}
            <th>Dịch vụ</th>
            <th>{t('txt-acc')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>Từ ngày</th>
            <th>Đến ngày</th>
            <th>{t('txt-note')}</th>
            <th>{t('txt-status')}</th>
            <th>{t('txt-time')}</th>
            <th>{t('txt-creator')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {limitSmsEmailNotiList &&
            limitSmsEmailNotiList.map((item) => (
              <tr key={item.PK_ACCOUNT_SMS}>
                <td className="">{item.C_BIZ_NAME}</td>
                <td className="text-center">
                    {item.C_ACCOUNT_CODE}
                </td>
                <td className="text-center">{item.C_ACCOUNT_NAME}</td>
                <td className="text-center">{item.C_EFFECT_DATE}</td>
                <td className="text-center">{item.C_EXPIRE_DATE}</td>
                <td className="text-center">{item.C_CONTENT}</td>
                <td className="text-center">{item.C_STATUS}</td>
                <td className="text-center">
                  {item.C_CREATE_TIME ? item.C_CREATE_TIME.split(' ')[0] : ''}
                </td>
                <td className="text-center">{item.C_CREATOR_CODE}</td>
                <td className="text-center p-0 w_85">
                  <GroupButton>
                     {accRight?.C_VIEW === 1 && ( 
                    <a
                      title={t('txt-detail')}
                      onClick={() => handleDetail(item.PK_ACCOUNT_SMS)}
                    >
                      <IconCopy />
                    </a>
                    )}

                    {accRight?.C_APPROVE === 1 && ( 
                    <a
                      title={t('txt-appr')}
                      className={
                        item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                      }
                      onClick={() =>
                        item.C_STATUS === 'CHUA_DUYET'
                          ? handleApproveSelected(item.PK_ACCOUNT_SMS)
                          : {}
                      }
                    >
                      <IconAppr />
                    </a>
                    )}
                    {accRight?.C_UPDATE === 1 && ( 
                    <a
                      className={
                        item.C_STATUS !== 'CHUA_DUYET' ? 'disabled' : ''
                      }
                      title={t('txt-del')}
                      onClick={() =>
                        item.C_STATUS === 'CHUA_DUYET'
                          ? handleConfirm(item.PK_ACCOUNT_SMS)
                          : {}
                      }
                    >
                      <IconTrash />
                    </a>
                    )}
                  </GroupButton>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>

      {(!limitSmsEmailNotiList || !limitSmsEmailNotiList.length) && (
        <NodataSearch name={t('txt-acc-1')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (limitSmsEmailNotiList &&
              !!limitSmsEmailNotiList.length &&
              limitSmsEmailNotiList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
      {detailAccInt && (
        <DetailAccountSMSModal
          onClose={onClose}
          id={detailAccInt}
          accRight={accRight}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getLimitSmsEmailNotiListSearch = makeLimitSmsEmailNotiListSearch();
  const getAuthenType = makeGetAuthenType();
  const getAccountRight = makeGetAccountRight();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      limitSmsEmailNotiList: getLimitSmsEmailNotiListSearch(state),
      glAuthenType: getAuthenType(state),
      accRight: getAccountRight(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(AccountSmsComponent)
);
