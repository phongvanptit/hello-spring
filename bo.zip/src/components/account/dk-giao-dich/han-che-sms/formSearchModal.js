import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import { formatDate, stringToDate } from 'utils';
import RenderInput from 'components/input/renderInput';
import { limitSmsEmailNotiSearchRequest } from 'containers/account/actions';
import { makeGetCustType, makeGetSystemInfo } from 'lib/selector';
import { translate } from 'react-i18next';

import * as _ from 'lodash';
import RenderSelectDate from 'components/input/renderDatePicker';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { arrSearchTKHanChe } from 'utils/const';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const [arrSel, setArrSel] = React.useState([]);
  const [calendarOpen, setCalendarOpen] = React.useState(false);

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    onClose,
    onTriggerPopover,
    sysSystemInfo,
  } = props;

  useEffect(() => {
    setArrSel(_.map(arrSearchTKHanChe, 'value'));
  }, []);

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    let _dataSearch = Object.assign({}, dataSearch);
    _dataSearch.data.ACCOUNT_CODE = values.formCustCode;
    _dataSearch.data.CREATOR_CODE = values.formCreatorCode;

    dispatch(limitSmsEmailNotiSearchRequest(_dataSearch));

    setDataSearch && setDataSearch(_dataSearch);
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModal', 'formCreatorCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100">
        {arrSel &&
          arrSel.map((item) => {
            const _objItem = _.find(
              arrSearchTKHanChe,
              (o) => o?.value === item
            );

            if (!_objItem) return null;

            if (_objItem.type === 'text' && _objItem.value !== 'formCustCode')
              return (
                <Form.Group key={_objItem.value}>
                  <Form.Label className="fz-13">{t(_objItem.label)}</Form.Label>
                  <Field
                    name={_objItem.value}
                    type="text"
                    className="form-control"
                    placeholder={t(_objItem.label)}
                    component={RenderInput}
                  />
                </Form.Group>
              );
          })}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModal',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModal');

const makeMapStateToProps = () => {
  const getCustType = makeGetCustType();
  const getSystemInfo = makeGetSystemInfo();

  const mapStateToProps = (state, props) => {
    const { formCustCode, formCreatorCode } = selector(
      state,
      'formCustCode',
      'formCreatorCode'
    );

    const { dataSearch } = props;

    return {
      glCustType: getCustType(state),
      sysSystemInfo: getSystemInfo(state),

      formCustCode,
      formCreatorCode,

      initialValues: {
        formCustCode: dataSearch?.data?.ACCOUNT_CODE,
        formCreatorCode: dataSearch?.data?.CREATOR_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
