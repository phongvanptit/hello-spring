import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Form } from 'react-bootstrap';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  FormFlexCenter,
  ButtonSearch,
  ExportExcel,
} from 'utils/styledComponent';
import { mmAllPartnerRequest } from 'containers/product/actions';
import { makeGetMMUpdPartner } from 'lib/selector';
import { setToast } from 'containers/client/actions';
import { mmUpdPartnerSuccess } from 'containers/product/actions';
import { makeGetMMDelPartner } from 'lib/selector';
import { mmDelPartnerSuccess } from 'containers/product/actions';
import RenderInput from 'components/input/renderInput';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    t
  } = props;

  const submit = (values) => {
    props.dataSearch.data.PARTNER_NAME = values.formPartnerName;
    props.dataSearch.data.CUSTOMER_CODE = values.formCustCode;
    props.dataSearch.data.PARTNER_CODE = values.formPartnerCode;
    props.setDataSearch(props.dataSearch);
    props.callSearch();
  };

  function _handleBlur() {
    if (props.dataSearch && props.dataSearch.data) {
      props.dataSearch.data.PARTNER_NAME = props.formPartnerName;
      props.dataSearch.data.CUSTOMER_CODE = props.formCustCode;
      props.dataSearch.data.PARTNER_CODE = props.formPartnerCode;
      props.setDataSearch(props.dataSearch);
      props.callSearch()
    }
  }

  useEffect(() => {
    _handleBlur()
  }, [props.formCustCode, props.formPartnerCode, props.formPartnerName]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-loan-source-code')}</Form.Label>
        <Field
          name={'formPartnerCode'}
          type="text"
          className="form-control w-80 mx-2"
          placeholder={t('txt-loan-source-code')}
          component={RenderInput}
        />
        {/* <Form.Label className="fz-13">{t('txt-borrower-name')}</Form.Label>
        <Field
          name={'formPartnerName'}
          type="text"
          className="form-control w-80 mx-2"
          placeholder={t('txt-borrower-name')}
          component={RenderInput}
        /> */}
        <Form.Label className="fz-13">{t('txt-cust-code')}</Form.Label>
        <Field
          name={'formCustCode'}
          type="text"
          className="form-control w-80 mx-2"
          placeholder={t('txt-cust-code')}
          component={RenderInput}
        />
      </div>
      <Field
        name="formPartnerName"
        type="text"
        className="form-control"
        placeholder={t('txt-loan-source-name')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDTV');

const makeMapStateToProps = () => {
  const getMMUpdPartner = makeGetMMUpdPartner();
  const getMMDelPartner = makeGetMMDelPartner();

  const mapStateToProps = (state) => {
    const { formPartnerName, formPartnerCode, formCustCode } = selector(
      state,
      'formPartnerName',
      'formPartnerCode',
      'formCustCode',
    );

    return {
      mmUpdPartner: getMMUpdPartner(state),
      mmDelPartner: getMMDelPartner(state),

      formPartnerName,
      formPartnerCode,
      formCustCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
