import React, { Fragment } from 'react';
import { translate } from 'react-i18next';
import { connect } from 'react-redux';
import MmAppendix from './mm-appendix/MmAppendix'

function GroupTabs(props) {
  return (
    <Fragment>
      {props.subType === 'list' && (
        <MmAppendix
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </Fragment>
  );
}

const makeMapStateToProps = () => {

  return (state) => {
    return {

    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(GroupTabs)
);
