import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  FormFlexCenter,
  ButtonSearch,
  ExportExcel,
} from 'utils/styledComponent';
import { mmAllPartnerRequest } from 'containers/product/actions';
import { makeGetMMUpdPartner } from 'lib/selector';
import { setToast } from 'containers/client/actions';
import { mmUpdPartnerSuccess } from 'containers/product/actions';
import { makeGetMMDelPartner } from 'lib/selector';
import { mmDelPartnerSuccess } from 'containers/product/actions';
import { Form } from 'react-bootstrap';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderInput from 'components/input/renderInput';
import { makeGetPublicStt } from 'lib/selector';
import RenderSelectDate from 'components/input/renderDatePicker';
import { makeGetCapContractStt } from 'lib/selector';
import IconConfig from '../../../../../assets/img/icon/cog.png';
import { globalExportFileVer2Request } from '../../../../../containers/report/actions';


function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    t,
    glStatusList
  } = props;

  const submit = (values) => {
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.CUSTOMER_CODE = values.formAccountCode;
    props.dataSearch.data.APPENDIX_CODE = values.formAppendixCode;
    // props.dataSearch.data.OPEN_DATE = values.formFromDate;
    // props.dataSearch.data.EXPIRE_DATE = values.formToDate;
    props.dataSearch.data.PRODUCT_CODE = values.formProdCode;
    props.dataSearch.data.FROM_DATE = props.formFromDate;
    props.dataSearch.data.TO_DATE = props.formToDate;
    props.setDataSearch(props.dataSearch);
    props.callSearch();
  };

  function _handleBlur() {
    if (props.dataSearch && props.dataSearch.data) {
      props.dataSearch.data.STATUS = props.formStatus;
      props.dataSearch.data.CUSTOMER_CODE = props.formAccountCode;
      props.dataSearch.data.APPENDIX_CODE = props.formAppendixCode;
      // props.dataSearch.data.OPEN_DATE = props.formStartDate;
      // props.dataSearch.data.EXPIRE_DATE = props.formEndDate;
      props.dataSearch.data.PRODUCT_CODE = props.formProdCode;
      props.dataSearch.data.FROM_DATE = props.formFromDate;
      props.dataSearch.data.TO_DATE = props.formToDate;
      props.setDataSearch(props.dataSearch);
      props.callSearch()
    }
  }

  const handleExport = () => {
    const cloneData = JSON.parse(JSON.stringify(props.dataSearch))
    cloneData.data.STATUS = props.formStatus;
    cloneData.data.CUSTOMER_CODE = props.formAccountCode;
    cloneData.data.APPENDIX_CODE = props.formAppendixCode;
    cloneData.data.PRODUCT_CODE = props.formProdCode;
    cloneData.data.FROM_DATE = props.formFromDate;
    cloneData.data.TO_DATE = props.formToDate;
    cloneData.data.TEMPLATE_CODE = 'REPORT_MM_01';
    cloneData.data.TYPE_GET_DATA = 'EXPORT';
    cloneData.data.EXPORT_FILE_TYPE = 'EXCEL';

    dispatch(globalExportFileVer2Request(cloneData))
  }

  useEffect(() => {
    _handleBlur()
  }, [props.formFromDate, props.formToDate, props.formStatus, props.formAccountCode, props.formAppendixCode, props.formFromDate, props.formToDate, props.formProdCode]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        {/* Trạng thái */}
        <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 mr-2">{t('txt_finra_tb_appendix_code')}</Form.Label>
        <Field
          name={'formAppendixCode'}
          type="text"
          className="form-control w_125 mr-3"
          placeholder={t('txt_finra_tb_appendix_code')}
          component={RenderInput}
        />
        <Form.Label className="fz-13 mr-2">{t('txt_finra_tb_contract_cus_code')}</Form.Label>
        <Field
          name={'formAccountCode'}
          type="text"
          className="form-control w_110 mr-3"
          placeholder={t('txt_finra_tb_contract_cus_code')}
          component={RenderInput}
        />
        <Form.Label className="fz-13 mr-2">
          Từ ngày
        </Form.Label>
        <Field
          name="formFromDate"
          className="w_90"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 mx-2 ml-3">
          Đến ngày
        </Form.Label>
        <Field
          name="formToDate"
          className="w_90"
          component={RenderSelectDate}
        />
      </div>
      <Field
        name="formProdCode"
        type="text"
        className="form-control"
        placeholder={t('txt-prod-code')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
      <ExportExcel
        onClick={handleExport}
      >
        <img src={IconExcel} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDTV');

const makeMapStateToProps = () => {
  const getMMUpdPartner = makeGetMMUpdPartner();
  const getMMDelPartner = makeGetMMDelPartner();

  const mapStateToProps = (state) => {
    const { 
      formAccountCode, 
      formProdCode, 
      formStatus, 
      formAppendixCode, 
      formFromDate, 
      formToDate,
    } = selector(
        state,
        'formStatus',
        'formAppendixCode',
        'formFromDate',
        'formToDate',
        'formAccountCode',
        'formProdCode',
        'formProdCode',
    );

    return {
      mmUpdPartner: getMMUpdPartner(state),
      mmDelPartner: getMMDelPartner(state),
      // glStatusList: makeGetPublicStt()(state),
      glStatusList: makeGetCapContractStt()(state),

      formStatus,
      formAccountCode,
      formProdCode,
      formAppendixCode,
      formFromDate,
      formToDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
