import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  FormFlexCenter,
  ButtonSearch,
  ExportExcel,
} from 'utils/styledComponent';
import { mmAllPartnerRequest } from 'containers/product/actions';
import { makeGetMMUpdPartner } from 'lib/selector';
import { setToast } from 'containers/client/actions';
import { mmUpdPartnerSuccess } from 'containers/product/actions';
import { makeGetMMDelPartner } from 'lib/selector';
import { mmDelPartnerSuccess } from 'containers/product/actions';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderInput from 'components/input/renderInput';
import { Form } from 'react-bootstrap';
import { makeGetPublicStt } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    t,
    glStatusList
  } = props;

  const submit = (values) => {
    props.dataSearch.data.CUSTOMER_CODE = values.formAccountCode;
    props.dataSearch.data.CUSTOMER_NAME = values.formAccountName;
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.CONTRACT_CODE = values.formContractCode;
    props.setDataSearch(props.dataSearch);
    props.callSearch();
  };

  function _handleBlur() {
    if (props.dataSearch && props.dataSearch.data) {
      props.dataSearch.data.CUSTOMER_CODE = props.formAccountCode;
      props.dataSearch.data.CUSTOMER_NAME = props.formAccountName;
      props.dataSearch.data.STATUS = props.formStatus;
      props.dataSearch.data.CONTRACT_CODE = props.formContractCode;
      props.setDataSearch(props.dataSearch);
      props.callSearch()
    }
  }

  useEffect(() => {
    _handleBlur()
  }, [props.formStatus, props.formAccountCode, props.formAccountName, props.formContractCode]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        {/* Trạng thái */}
        <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13">{t('txt_finra_tb_contract_code')}</Form.Label>
        <Field
          name={'formContractCode'}
          type="text"
          className="form-control w_100 ml-2 mr-3"
          placeholder={t('txt_finra_tb_contract_code')}
          component={RenderInput}
        />
        <Form.Label className="fz-13">{t('txt_finra_tb_contract_cus_code')}</Form.Label>
        <Field
          name={'formAccountCode'}
          type="text"
          className="form-control w_110 ml-2"
          placeholder={t('txt_finra_tb_contract_cus_code')}
          component={RenderInput}
        />
      </div>
      <Field
        name="formAccountName"
        type="text"
        className="form-control"
        placeholder={t('txt_finra_tb_contract_cus_name')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDTV');

const makeMapStateToProps = () => {
  const mapStateToProps = (state) => {
    const { formAccountCode, formAccountName, formContractCode, formStatus } = selector(
      state,
      'formAccountCode',
      'formContractCode',
      'formStatus',
      'formAccountName'
    );

    return {
      glStatusList: makeGetPublicStt()(state),

      formAccountCode,
      formContractCode,
      formStatus,
      formAccountName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
