import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  makeGetAccountRight, makeGetActionFinra,
  makeGetMainListFinra,
  makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form-search/FormSearch';
import { usePrevious } from '../../../../lib/useHook';
import DetailDoiTuongVayModal from '../../../modal/finra/doi-tuong-vay/DetailDoiTuongVayModal';
import {
  actionFinraRequesting,
  mainListFinraRequesting,
  mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { numberFormatDecimal } from '../../../../utils';
import { FaCheck, FaTimes } from 'react-icons/fa';
import UpdateContract from '../../../modal/finra/contract/UpdateContract';

const configActionButton = {
  delete: {
    messageRequest: 'txt_mm_delete_contract_req',
    messageSuccess: 'txt_mm_delete_contract_success',
    cmd: 'MM.DELETE_CONTRACT_BASE'
  },
  approve: {
    messageRequest: 'txt_mm_approve_contract_req',
    messageSuccess: 'txt_mm_approve_contract_success',
    cmd: 'MM.APPROVE_CONTRACT_BASE'
  },
  un_approve: {
    messageRequest: 'txt_mm_unapprove_contract_req',
    messageSuccess: 'txt_mm_unapprove_contract_success',
    cmd: 'MM.UNAPPROVE_CONTRACT_BASE'
  }
}

function MmContract(props) {
  const t = props.t;

  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [recordDetail, setRecordDetail] = useState(undefined);
  const [dataSearch, setDataSearch] = useState(undefined);

  const dispatch = useDispatch();
  const preActionFinra = usePrevious(props.actionFinra);

  useEffect(() => {
    setDataSearch({
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_ALL_CONTRACT_BASE',
      group: 'LIST',
      data: {
        PARTNER_CODE: '',
        PARTNER_NAME: '',
        CUSTOMER_CODE: '',

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    });

    return () => {
      dispatch(mainListFinraSuccess(undefined))
    }
  }, [])

  useEffect(() => {
    if (dataSearch) {
      callSearch()
    }
  }, [dataSearch, props.triggerChangeReloadData]);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
    }
  }, [props.actionFinra]);

  useEffect(() => {
    if (dataSearch) {
      dataSearch.data.PAGE = page
      dataSearch.data.RECORD_PER_PAGE = recordPerPage
      setDataSearch({...dataSearch})
    }
  }, [page, recordPerPage]);

  const callSearch = () => {
    dispatch(mainListFinraRequesting(dataSearch))
  }

  function handleNextPage(step) {
    setPage(step);
  }

  function handleChangeRecordPerPage (value) {
    setRecordPerPage(value)
  }

  function onClose(pk) {
    setRecordDetail(undefined);
  }

  function handleShowItem(value) {
    setRecordDetail(value);
  }

  function handleButtonAction(pk, action) {
    if (!pk) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configActionButton[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleAction(pk, action);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleAction(pk, action) {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configActionButton[action].cmd,
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    props.onSetMessageContent(configActionButton[action].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content my-3">
      <FormSearch callSearch={callSearch} dataSearch={dataSearch} setDataSearch={setDataSearch} />
      <Table bordered>
        <thead>
        <tr>
          <th>#</th>
          <th>{t('txt_finra_tb_contract_code')}</th>
          <th>{t('txt_finra_tb_contract_cus_code')}</th>
          <th>{t('txt_finra_tb_contract_cus_name')}</th>
          <th>{t('txt_finra_tb_contract_card_code')}</th>
          <th>{t('txt_finra_tb_contract_open_date')}</th>
          <th>{t('txt_finra_tb_contract_close_date')}</th>
          <th>{t('txt_finra_tb_contract_status')}</th>
          <th>{t('txt_finra_tb_contract_create_code')}</th>
          <th>{t('txt-action')}</th>
        </tr>
        </thead>
        <tbody>
        {props.allPartner &&
          props.allPartner.map((item) => (
            <tr key={item.ROW_NUM}>
              <td className="text-center">{numberFormatDecimal(item.ROW_NUM)}</td>
              <td className="text-center">{item.C_CONTRACT_CODE}</td>
              <td className="text-center">{item.C_CUSTOMER_CODE}</td>
              <td className="">{item.C_CUSTOMER_NAME}</td>
              <td className="">{item.C_CARD_ID}</td>
              <td className="text-center">{item.C_OPEN_DATE}</td>
              <td className="text-center">{item.C_EXPIRE_DATE}</td>
              <td className="text-center">{item.C_STATUS_NAME}</td>
              <td className="text-center">{item.C_CREATOR_CODE}</td>
              <td className="text-center p-0">
                <GroupButton>
                  {props.accRight?.C_VIEW === 1 && (
                    <a
                      title={t('txt-detail')}
                      rel="noreferrer noopener"
                      onClick={() => handleShowItem(item.PK_MM_CONTRACT)}
                    >
                      <IconCopy />
                    </a>
                  )}
                  {props.accRight?.C_UPDATE === 1 && (
                    <a
                      title={t('txt-del')}
                      className={item?.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                      onClick={() => item?.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_MM_CONTRACT, 'delete') : undefined}
                    >
                      <IconTrash />
                    </a>
                  )}
                  {props.accRight?.C_APPROVE === 1 && (
                    <a
                      title={t('txt-appr')}
                      className={item?.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                      onClick={() => item?.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_MM_CONTRACT, 'approve') : undefined}
                    >
                      <FaCheck />
                    </a>
                  )}

                  {props.accRight?.C_APPROVE === 1 && (
                    <a
                      title={t('txt-unAppr')}
                      className={item?.C_STATUS === 'DA_DUYET' ? '' : 'disabled'}
                      onClick={() => item?.C_STATUS === 'DA_DUYET' ? handleButtonAction(item.PK_MM_CONTRACT, 'un_approve') : undefined}
                    >
                      <FaTimes />
                    </a>
                  )}
                </GroupButton>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {(!props.allPartner || !props.allPartner.length) && (
        <NodataSearch name={t('lab_finra_tab_partner')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={handleChangeRecordPerPage}
          total={
            props.allPartner && !!props.allPartner.length
              ? props.allPartner[0].C_TOTAL_RECORD
              : 0
          }
        />
      </div>
      {recordDetail && (
        <UpdateContract
          itemId={recordDetail}
          onClose={onClose}
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountRight = makeGetAccountRight();
  const getMainListFinra = makeGetMainListFinra();

  return (state) => {
    return {
      token: getToken(state),
      accRight: getAccountRight(state),

      allPartner: getMainListFinra(state),
      actionFinra: makeGetActionFinra()(state),
    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(MmContract)
);
