import React, { Fragment } from 'react';
import { translate } from 'react-i18next';
import { connect } from 'react-redux';
import MmAppendixLiquid from './mm-appendix-liquid/MmAppendixLiquid'

function GroupTabs(props) {
  return (
    <Fragment>
      {props.subType === 'list' && (
        <MmAppendixLiquid
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </Fragment>
  );
}

const makeMapStateToProps = () => {

  return (state) => {
    return {

    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(GroupTabs)
);
