import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { makeGetToken } from 'lib/selector';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import FormSearchShort from './FormSearchShort';
import FormSearchModal from './FormSearchModal';
import {
  ContainerSearch,
  ContainerSearchDropdown,
  ContainerDropdownShow,
} from 'utils/styledComponent';

function FormSearch(props) {
  const t = props.t;

  const [showModal, setShowModal] = React.useState(false);
  const [triggerPopover, setTriggerPopover] = React.useState(false);

  const wrapperRef = React.useRef(null);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target) &&
      !triggerPopover
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    setShowModal(!showModal);
  }

  function onTriggerPopover(param) {
    setTriggerPopover(param);
  }

  return (
    <ContainerSearch>
      {/* <div
        ref={wrapperRef}
        className="mr-auto"
        style={{ position: 'relative' }}
      >
        <ContainerSearchDropdown onClick={_handleShow}>
          {t('txt-filter')}
        </ContainerSearchDropdown>
        {showModal && (
          <ContainerDropdownShow>
            <FormSearchModal
              callSearch={props.callSearch}
              dataSearch={props.dataSearch}
              setDataSearch={props.setDataSearch}
              onClose={() => setShowModal(false)}
              onTriggerPopover={onTriggerPopover}
            />
          </ContainerDropdownShow>
        )}
      </div> */}

      <FormSearchShort
        callSearch={props.callSearch}
        dataSearch={props.dataSearch}
        setDataSearch={props.setDataSearch}
      />
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
