import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import { makeGetToken } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    onClose,
    reset,
  } = props;

  const submit = (values) => {
    props.dataSearch.data.PARTNER_CODE = values.formPartnerCode;
    props.dataSearch.data.PARTNER_NAME = values.formPartnerName;
    props.dataSearch.data.CUSTOMER_CODE = values.formCustCode;

    props.setDataSearch(props.dataSearch);
    props.callSearch();
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalDTV', 'formPartnerCode', ''));
    dispatch(change('formSearchModalDTV', 'formPartnerName', ''));
    dispatch(change('formSearchModalDTV', 'formCustCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100 ">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-borrower-code')}</Form.Label>
          <Field
            name={'formPartnerCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-borrower-code')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-borrower-name')}</Form.Label>
          <Field
            name={'formPartnerName'}
            type="text"
            className="form-control"
            placeholder={t('txt-borrower-name')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-cust-code')}</Form.Label>
          <Field
            name={'formCustCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalDTV');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state, props) => {
    const { formPartnerCode, formPartnerName, formCustCode } = selector(
      state,
      'formPartnerCode',
      'formPartnerName',
      'formCustCode'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      formPartnerCode,
      formPartnerName,
      formCustCode,

      initialValues: {
        formPartnerCode: dataSearch?.data?.PARTNER_CODE,
        formPartnerName: dataSearch?.data?.PARTNER_NAME,
        formCustCode: dataSearch?.data?.CUSTOMER_CODE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
