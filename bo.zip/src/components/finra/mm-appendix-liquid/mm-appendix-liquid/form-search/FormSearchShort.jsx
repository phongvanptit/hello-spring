import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  FormFlexCenter,
  ButtonSearch,
  ExportExcel,
} from 'utils/styledComponent';
import { mmAllPartnerRequest } from 'containers/product/actions';
import { makeGetMMUpdPartner } from 'lib/selector';
import { setToast } from 'containers/client/actions';
import { mmUpdPartnerSuccess } from 'containers/product/actions';
import { makeGetMMDelPartner } from 'lib/selector';
import { mmDelPartnerSuccess } from 'containers/product/actions';
import { Form } from 'react-bootstrap';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetPublicStt } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    t,
    glStatusList
  } = props;

  const submit = (values) => {
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.CUSTOMER_CODE = values.formAccountCode;
    props.dataSearch.data.APPENDIX_CODE = values.formAppendixCode;
    props.dataSearch.data.OPEN_DATE = values.formStartDate;
    props.dataSearch.data.EXPIRE_DATE = values.formEndDate;
    props.dataSearch.data.PRODUCT_CODE = values.formProdCode;
    props.setDataSearch(props.dataSearch);
    props.callSearch();
  };

  function _handleBlur() {
    if (props.dataSearch && props.dataSearch.data) {
      props.dataSearch.data.STATUS = props.formStatus;
      props.dataSearch.data.CUSTOMER_CODE = props.formAccountCode;
      props.dataSearch.data.APPENDIX_CODE = props.formAppendixCode;
      props.dataSearch.data.OPEN_DATE = props.formStartDate;
      props.dataSearch.data.EXPIRE_DATE = props.formEndDate;
      props.dataSearch.data.PRODUCT_CODE = props.formProdCode;
      props.setDataSearch(props.dataSearch);
      props.callSearch()
    }
  }

  useEffect(() => {
    _handleBlur()
  }, [props.formStatus, props.formAccountCode, props.formAppendixCode, props.formStartDate, props.formEndDate, props.formProdCode]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        {/* Trạng thái */}
        <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13 mr-2">{t('txt_finra_tb_appendix_code')}</Form.Label>
        <Field
          name={'formAppendixCode'}
          type="text"
          className="form-control w_125 mr-3"
          placeholder={t('txt_finra_tb_appendix_code')}
          component={RenderInput}
        />
        <Form.Label className="fz-13 mr-2">{t('txt_finra_tb_contract_cus_code')}</Form.Label>
        <Field
          name={'formAccountCode'}
          type="text"
          className="form-control w_110 mr-3"
          placeholder={t('txt_finra_tb_contract_cus_code')}
          component={RenderInput}
        />
        {/* <Form.Label className="fz-13 mr-2">
          {t('txt_finra_tb_appendix_open_date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 mx-2 ml-3">{t('txt_finra_tb_appendix_expire_date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          component={RenderSelectDate}
        /> */}
      </div>
      <Field
        name="formProdCode"
        type="text"
        className="form-control"
        placeholder={t('txt-prod-code')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDTV');

const makeMapStateToProps = () => {
  const getMMUpdPartner = makeGetMMUpdPartner();
  const getMMDelPartner = makeGetMMDelPartner();

  const mapStateToProps = (state) => {
    const { formAccountCode, formProdCode, formStatus, formAppendixCode, formStartDate, formEndDate } = selector(
      state,
      'formStatus',
      'formAppendixCode',
      'formStartDate',
      'formEndDate',
      'formAccountCode',
      'formProdCode'
    );

    return {
      mmUpdPartner: getMMUpdPartner(state),
      mmDelPartner: getMMDelPartner(state),
      glStatusList: makeGetPublicStt()(state),

      formStatus,
      formAccountCode,
      formProdCode,
      formAppendixCode,
      formStartDate,
      formEndDate,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
