import { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetCapTermContract } from 'lib/selector';
import { StringToInt } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import RenderInput from 'components/input/renderInput';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    dataSearch,
    onClose,
    capTermContract,
  } = props;

  const submit = (values) => {
    dataSearch.data.PRODUCT_CODE = values.formProdCode;
    dataSearch.data.PRODUCT_NAME = values.formProdName;
    dataSearch.data.TERM_CODE = values.formTermCode;
    dataSearch.data.TRADING_DATE = values.formTradingDate;
    dataSearch.data.CAPITAL = values.formCapital ? StringToInt(values.formCapital + '') : '';
    props.setDataSearch(dataSearch)
    props.callSearch()
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalBLS', 'formProdName', ''));
    dispatch(change('formSearchModalBLS', 'formTermCode', ''));
    dispatch(change('formSearchModalBLS', 'formTradingDate', ''));
    dispatch(change('formSearchModalBLS', 'formCapital', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100 ">
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-prod-name')}</Form.Label>
          <Field
            name={'formProdName'}
            className="form-control"
            classParentName="w-100"
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-period')}</Form.Label>
          <Field
            name={'formTermCode'}
            className="form-control w-100"
            component={RenderNormalSelect}
            opts={capTermContract}
            placeholder="-- Tất cả --"
          />
        </Form.Group>

        <Form.Group>
          <Form.Label className="fz-13">{t('txt-effective-date')}</Form.Label>
          <Field
            name={'formTradingDate'}
            className="form-control"
            classParentName="w-100"
            component={RenderSelectDate}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-capital-number')}</Form.Label>
          <Field
            name={'formCapital'}
            className="form-control w-100"
            component={RenderInputMask}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalBLS',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalBLS');

const makeMapStateToProps = () => {
  const getCapTermContract = makeGetCapTermContract();

  const mapStateToProps = (state, props) => {
    const {
      formProdCode,
      formProdName,
      formTermCode,
      formTradingDate,
      formCapital,
    } = selector(
      state,
      'formProdCode',
      'formProdName',
      'formTermCode',
      'formTradingDate',
      'formCapital'
    );

    const { dataSearch } = props;

    return {
      capTermContract: getCapTermContract(state),
      formProdCode,
      formProdName,
      formTermCode,
      formTradingDate,
      formCapital,

      initialValues: {
        formProdCode: dataSearch?.data?.PRODUCT_CODE,
        formProdName: dataSearch?.data?.PRODUCT_NAME,
        formTermCode: dataSearch?.data?.TERM_CODE,
        formTradingDate: dataSearch?.data?.TRADING_DATE,
        formCapital: dataSearch?.data?.CAPITAL,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
