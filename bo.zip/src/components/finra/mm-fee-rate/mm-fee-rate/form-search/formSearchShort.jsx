import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import {
  FormFlexCenter,
} from 'utils/styledComponent';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const {
    handleSubmit,
    t,
  } = props;

  const submit = (values) => {
    props.dataSearch.data.PRODUCT_CODE = values.formProdCode;
    props.setDataSearch(props.dataSearch);
    props.callSearch()
  };

  function _handleBlur() {
    props.dataSearch.data.PRODUCT_CODE = props.formProdCode;
    props.setDataSearch(props.dataSearch);
    props.callSearch()
  }

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)}>
      <Field
        name="formProdCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortBLS',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortBLS');

const makeMapStateToProps = () => {
  const mapStateToProps = (state) => {
    const { formProdCode, formProdName } = selector(
      state,
      'formProdCode',
      'formProdName'
    );

    return {
      formProdCode,
      formProdName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
