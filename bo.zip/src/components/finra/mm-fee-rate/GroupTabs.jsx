import React, { Fragment } from 'react';
import { translate } from 'react-i18next';
import { connect } from 'react-redux';
import MmFeeRate from './mm-fee-rate/MmFeeRate';
import MmLiquidPolicy from './mm-liquid-policy/MmLiquidPolicy';

function GroupTabs(props) {
  return (
    <Fragment>
      {/*{props.subType === 'list' && (*/}
      {/*  <MmFeeRate*/}
      {/*    onComplete={props.onComplete}*/}
      {/*    onSetMessageContent={props.onSetMessageContent}*/}
      {/*    triggerChangeReloadData={props.triggerChangeReloadData}*/}
      {/*  />*/}
      {/*)}*/}
      {props.subType === 'list' && (
        <MmLiquidPolicy
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </Fragment>
  );
}

const makeMapStateToProps = () => {

  return (state) => {
    return {

    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(GroupTabs)
);
