import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import {
  FormFlexCenter,
} from 'utils/styledComponent';
import { Form } from 'react-bootstrap';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetPublicStt } from '../../../../../lib/reselect/global';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const {
    handleSubmit,
    t,
  } = props;

  const submit = (values) => {
    props.dataSearch.data.LIQUID_CODE = values.formProdCode;
    props.dataSearch.data.STATUS = values.formStatus;
    props.setDataSearch(props.dataSearch);
    props.callSearch()
  };

  function _handleBlur() {
    props.dataSearch.data.LIQUID_CODE = props.formProdCode;
    props.dataSearch.data.STATUS = props.formStatus;
    props.setDataSearch(props.dataSearch);
    props.callSearch()
  }

  useEffect(() => {
    if (props.dataSearch) {
      _handleBlur()
    }
  }, [props.formStatus]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_160 mx-2"
          component={RenderNormalSelect}
          opts={props.glPublicStt}
          placeholder="-- Tất cả --"
        />
      </div>

      <Field
        name="formProdCode"
        type="text"
        className="form-control"
        placeholder={t('txt-search')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
);
}

FormSearch = reduxForm({
  form: 'formSearchShortMLP',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortMLP');

const makeMapStateToProps = () => {

  const mapStateToProps = (state) => {
    const {
      formProdCode,
      formStatus
    } = selector(
      state,
      'formProdCode',
      'formStatus'
    );

    return {
      glPublicStt: makeGetPublicStt()(state),

      formProdCode,
      formStatus,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
