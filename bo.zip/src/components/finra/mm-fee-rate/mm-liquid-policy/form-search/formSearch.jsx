import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { makeGetToken } from 'lib/selector';
import { translate } from 'react-i18next';

import FormSearchShort from './formSearchShort';
import FormSearchModal from './formSearchModal';
import {
  ContainerSearch,
  ContainerSearchDropdown,
  ContainerDropdownShow,
} from 'utils/styledComponent';
import * as _ from 'lodash';

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}


function FormSearch(props) {
  const wrapperRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);
  const [triggerPopover, setTriggerPopover] = React.useState(false);

  const t = props.t;

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target) &&
      !triggerPopover
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    setShowModal(!showModal);
  }

  function onTriggerPopover(param) {
    setTriggerPopover(param);
  }

  return (
    <ContainerSearch>
      <div
        ref={wrapperRef}
        className="mr-auto"
        style={{ position: 'relative' }}
      >
        {/*<ContainerSearchDropdown onClick={_handleShow}>*/}
        {/*  {t('txt-filter')}*/}
        {/*</ContainerSearchDropdown>*/}
        {/*{showModal && (*/}
        {/*  <ContainerDropdownShow>*/}
        {/*    <FormSearchModal*/}
        {/*      callSearch={props.callSearch}*/}
        {/*      dataSearch={props.dataSearch}*/}
        {/*      setDataSearch={props.setDataSearch}*/}
        {/*      onClose={() => setShowModal(false)}*/}
        {/*      onTriggerPopover={onTriggerPopover}*/}
        {/*    />*/}
        {/*  </ContainerDropdownShow>*/}
        {/*)}*/}
      </div>

      <FormSearchShort
        callSearch={props.callSearch}
        dataSearch={props.dataSearch}
        setDataSearch={props.setDataSearch}
      />
    </ContainerSearch>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
