import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  makeGetAccountRight, makeGetActionFinra,
  makeGetMainListFinra,
  makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form-search/formSearch';
import { usePrevious } from '../../../../lib/useHook';
import {
  actionFinraRequesting,
  mainListFinraRequesting,
  mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { numberFormat, numberFormatDecimal } from '../../../../utils';
import DetailBieuLaiSuatModal from '../../../modal/finra/bieu-lai-suat/DetailBieuLaiSuatModal';
import UpdateLiquidPolicy from '../../../modal/finra/liquiq-policy/UpdateLiquidPolicy';

const configActionButton = {
  delete: {
    messageRequest: 'txt_mm_delete_liq_policy_req',
    messageSuccess: 'txt_mm_delete_liq_policy_success',
    cmd: 'MM.DELETE_LIQUID_POLICY'
  },
  approve: {
    messageRequest: 'txt_mm_approve_liq_policy_req',
    messageSuccess: 'txt_mm_approve_liq_policy_success',
    cmd: 'MM.APPROVE_LIQUID_POLICY'
  }
}

function MmLiquidPolicy(props) {
  const t = props.t;

  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [recordDetail, setRecordDetail] = useState(undefined);
  const [dataSearch, setDataSearch] = useState(undefined);

  const dispatch = useDispatch();
  const preActionFinra = usePrevious(props.actionFinra);

  useEffect(() => {
    setDataSearch({
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_ALL_LIQUID_POLICY',
      group: 'LIST',
      data: {
        LIQUID_CODE: '',
        LIQUID_NAME: '',
        STATUS: '',

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    });

    return () => {
      dispatch(mainListFinraSuccess(undefined))
    }
  }, [])

  useEffect(() => {
    if (dataSearch) {
      callSearch()
    }
  }, [dataSearch, props.triggerChangeReloadData]);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
    }
  }, [props.actionFinra]);

  const callSearch = () => {
    dispatch(mainListFinraRequesting(dataSearch))
  }

  useEffect(() => {
    if (dataSearch) {
        dataSearch.data.PAGE = page
        dataSearch.data.RECORD_PER_PAGE = recordPerPage
        setDataSearch({ ...dataSearch })
    }
  }, [page, recordPerPage]);

  function handleNextPage(step) {
    setPage(step)
    callSearch()
  }

  function handleChangeRecordPerPage (value) {
    setRecordPerPage(value)
    callSearch()
  }

  function onClose(pk) {
    setRecordDetail(undefined);
  }

  function handleShowItem(value) {
    console.log(value);
    setRecordDetail(value);
  }

  function handleButtonAction(pk, action) {
    if (!pk) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configActionButton[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleAction(pk, action);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleAction(pk, action) {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configActionButton[action].cmd,
      group: 'LIST',
      data: {
        ITEM_ID: pk
      },
    };

    props.onSetMessageContent(configActionButton[action].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content my-3">
      <FormSearch callSearch={callSearch} dataSearch={dataSearch} setDataSearch={setDataSearch} />
      <Table bordered>
        <thead>
        <tr>
          <th>#</th>
          <th>{t('txt_finra_tb_policy_code')}</th>
          <th>{t('txt_finra_tb_policy_name')}</th>
          <th>{t('txt_finra_tb_content')}</th>
          <th>{t('txt_finra_tb_status')}</th>
          <th>{t('txt_finra_tb_create_time')}</th>
          <th>{t('txt_finra_tb_create_code')}</th>
          <th>{t('txt-action')}</th>
        </tr>
        </thead>
        <tbody>
        {props.allFeeRate &&
          props.allFeeRate.map((item) => (
            <tr key={item.ROW_NUM}>
              <td className="text-center">{numberFormatDecimal(item.ROW_NUM)}</td>
              <td className="text-center">{item.C_LIQUID_CODE}</td>
              <td className="">{item.C_LIQUID_NAME}</td>
              <td className="text-center">{item.C_CONTENT}</td>
              <td className="text-center">{item.C_STATUS_NAME}</td>
              <td className="text-center">{item.C_CREATE_TIME}</td>
              <td className="text-center">{item.C_CREATOR_CODE}</td>
              <td className="text-center p-0">
                <GroupButton>
                  {props.accRight?.C_VIEW === 1 && (
                    <a
                      title={t('txt-detail')}
                      rel="noreferrer noopener"
                      onClick={() => handleShowItem(item.PK_LIQUID_POLICY)}
                    >
                      <IconCopy />
                    </a>
                  )}
                  {props.accRight?.C_APPROVE === 1 && (
                    <a
                      title={t('txt-appr')}
                      className={item.C_STATUS === 'DA_DUYET' ? 'disabled' : ''}
                      rel="noreferrer noopener"
                      onClick={() => item.C_STATUS === 'DA_DUYET' ? undefined : handleButtonAction(item.PK_LIQUID_POLICY, 'approve')}
                    >
                      <IconApprove />
                    </a>
                  )}
                  {props.accRight?.C_UPDATE === 1 && (
                    <a
                      title={t('txt-del')}
                      className={item.C_STATUS === 'DA_DUYET' ? 'disabled' : ''}
                      rel="noreferrer noopener"
                      onClick={() => item.C_STATUS === 'DA_DUYET' ? undefined : handleButtonAction(item.PK_LIQUID_POLICY, 'delete')}
                    >
                      <IconTrash />
                    </a>
                  )}
                </GroupButton>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {(!props.allFeeRate || !props.allFeeRate.length) && (
        <NodataSearch name={t('lab_finra_tab_partner')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={handleChangeRecordPerPage}
          total={
            props.allFeeRate && !!props.allFeeRate.length
              ? props.allFeeRate[0].C_TOTAL_RECORD
              : 0
          }
        />
      </div>
      {recordDetail && (
        <UpdateLiquidPolicy
          itemId={recordDetail}
          onClose={onClose}
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountRight = makeGetAccountRight();
  const getMainListFinra = makeGetMainListFinra();

  return (state) => {
    return {
      token: getToken(state),
      accRight: getAccountRight(state),

      allFeeRate: getMainListFinra(state),
      actionFinra: makeGetActionFinra()(state),
    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(MmLiquidPolicy)
);
