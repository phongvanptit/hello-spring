import React, { Fragment } from 'react';
import { translate } from 'react-i18next';
import { connect } from 'react-redux';
import MmProduct from './mm-product/MmProduct';
import MmLiquidPolicy from '../mm-fee-rate/mm-liquid-policy/MmLiquidPolicy';
import MmFeeChange from '../mm-product/mm-fee-change/MmFeeChange';
import MmProductWebType from './mm-product-web-type/MmProductWebType';

function GroupTabs(props) {
  return (
    <Fragment>
      {props.subType === 'list' && (
        <MmProduct
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
      {props.subType === 'policy' && (
        <MmLiquidPolicy
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
      {props.subType === 'fee-change' && (
        <MmFeeChange
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
      {props.subType === 'web-type' && (
        <MmProductWebType
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </Fragment>
  );
}

const makeMapStateToProps = () => {

  return (state) => {
    return {

    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(GroupTabs)
);
