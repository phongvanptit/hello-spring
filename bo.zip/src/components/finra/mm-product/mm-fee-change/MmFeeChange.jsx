import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
    makeGetAccountRight, makeGetActionFinra,
    makeGetMainListFinra,
    makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form-search/FormSearch';
import { usePrevious } from '../../../../lib/useHook';
import {
    actionFinraRequesting,
    mainListFinraRequesting,
    mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { numberFormat, numberFormatDecimal } from '../../../../utils';
import UpdateFeeChange from '../../../modal/finra/fee-change/UpdateFeeChange';

const configActionButton = {
    delete: {
        messageRequest: 'txt_mm_delete_fee_change_req',
        messageSuccess: 'txt_mm_delete_fee_change_success',
        cmd: 'MM.DELETE_REQUEST_UPDATE'
    },
    approve: {
        messageRequest: 'txt_mm_approve_fee_change_req',
        messageSuccess: 'txt_mm_approve_fee_change_success',
        cmd: 'MM.APPROVE_REQUEST_UPDATE'
    },
}

function MmFeeChange(props) {
    const t = props.t;

    const [page, setPage] = useState(1);
    const [recordPerPage, setRecordPerPage] = useState(10);
    const [recordDetail, setRecordDetail] = useState(undefined);
    const [dataSearch, setDataSearch] = useState(undefined);

    const dispatch = useDispatch();
    const preActionFinra = usePrevious(props.actionFinra);

    useEffect(() => {
        setDataSearch({
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ALL_REQUEST',
            group: 'LIST',
            data: {
                PRODUCT_CODE: '',
                LIQUID_NAME: '',
                STATUS: '',
                FROM_DATE: '',
                FROM_DATE: '',
                TO_DATE: '',
                APPLY_FROM_DATE: '',
                APPLY_TO_DATE: '',

                PAGE: page || 1,
                RECORD_PER_PAGE: recordPerPage || 10,
            },
        });

        return () => {
            dispatch(mainListFinraSuccess(undefined))
        }
    }, [])

    useEffect(() => {
        if (dataSearch) {
            callSearch()
        }
    }, [dataSearch, props.triggerChangeReloadData]);

    useEffect(() => {
        if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
            props.onComplete()
        }
    }, [props.actionFinra]);

    const callSearch = () => {
        dispatch(mainListFinraRequesting(dataSearch))
    }

    useEffect(() => {
        if (dataSearch) {
            dataSearch.data.PAGE = page
            dataSearch.data.RECORD_PER_PAGE = recordPerPage
            setDataSearch({ ...dataSearch })
        }
    }, [page, recordPerPage]);

    function handleNextPage(step) {
        if (dataSearch) {
            setPage(step);
            dataSearch.data.PAGE = step
            setDataSearch({ ...dataSearch })
        }
    }

    function handleChangeRecordPerPage(value) {
        if (dataSearch) {
            setRecordPerPage(value)
            dataSearch.data.RECORD_PER_PAGE = value
            setDataSearch({ ...dataSearch })
        }
    }

    function onClose(pk) {
        setRecordDetail(undefined);
    }

    function handleShowItem(value) {
        setRecordDetail(value);
    }

    function handleButtonAction(pk, action) {
        if (!pk) return;
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configActionButton[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                handleAction(pk, action);
                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    function handleAction(pk, action) {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configActionButton[action].cmd,
            group: 'LIST',
            data: {
                ITEM_ID: pk
            },
        };

        props.onSetMessageContent(configActionButton[action].messageSuccess)
        dispatch(actionFinraRequesting(params))
    }

    return (
        <div className="w-100 d-flex flex-column custom-tabs-content my-3">
            <FormSearch callSearch={callSearch} dataSearch={dataSearch} setDataSearch={setDataSearch} />
            <Table bordered>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>{t('txt_finra_tb_appendix_product_code')}</th>
                        <th>Lãi suất</th>
                        <th title='Lãi suất điều chỉnh'>LS điều chỉnh</th>
                        <th>Ngày áp dụng</th>
                        <th>{t('txt_finra_tb_status')}</th>
                        <th>{t('txt_finra_tb_create_time')}</th>
                        <th>{t('txt_finra_tb_create_code')}</th>
                        <th>{t('txt-approver')}</th>
                        <th>{t('txt-action')}</th>
                    </tr>
                </thead>
                <tbody>
                    {props.allFeeChange &&
                        props.allFeeChange.map((item) => (
                            <tr key={item.ROW_NUM}>
                                <td className="text-center">{numberFormatDecimal(item.ROW_NUM)}</td>
                                <td className="text-center">{item.C_PRODUCT_CODE}</td>
                                <td className="text-center">{item.C_FEE_RATE}%</td>
                                <td className="text-center">{item.C_FEE_RATE_CHANGE}%</td>
                                <td className="text-center">{item.C_APPLY_DATE}</td>
                                <td className="text-center">{item.C_STATUS_NAME}</td>
                                <td className="text-center">{item.C_CREATE_TIME}</td>
                                <td className="text-center">{item.C_CREATOR_CODE}</td>
                                <td className="text-center">{item.C_APPROVER_CODE}</td>
                                <td className="text-center p-0">
                                    <GroupButton>
                                        {props.accRight?.C_VIEW === 1 && (
                                            <a
                                                title={t('txt-detail')}
                                                rel="noreferrer noopener"
                                                onClick={() => handleShowItem(item.PK_REQUEST_CHANGE)}
                                            >
                                                <IconCopy />
                                            </a>
                                        )}
                                        {props.accRight?.C_APPROVE === 1 && (
                                            <a
                                                title={t('txt-appr')}
                                                className={item.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                                                rel="noreferrer noopener"
                                                onClick={() => item.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_REQUEST_CHANGE, 'approve') : undefined }
                                            >
                                                <IconApprove />
                                            </a>
                                        )}
                                        {props.accRight?.C_UPDATE === 1 && (
                                            <a
                                                title={t('txt-del')}
                                                className={item.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                                                rel="noreferrer noopener"
                                                onClick={() => item.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_REQUEST_CHANGE, 'delete') : undefined}
                                            >
                                                <IconTrash />
                                            </a>
                                        )}
                                    </GroupButton>
                                </td>
                            </tr>
                        ))}
                </tbody>
            </Table>

            {(!props.allFeeChange || !props.allFeeChange.length) && (
                <NodataSearch name={t('lab_finra_tab_partner')} />
            )}

            <div className="mt-3 d-flex justify-content-end">
                <Paging
                    page={page}
                    nextPage={handleNextPage}
                    recordPerPage={recordPerPage}
                    setRecordPerPage={handleChangeRecordPerPage}
                    total={
                        props.allFeeChange && !!props.allFeeChange.length
                            ? props.allFeeChange[0].C_TOTAL_RECORD
                            : 0
                    }
                />
            </div>
            {recordDetail && (
                <UpdateFeeChange
                    itemId={recordDetail}
                    onClose={onClose}
                    onComplete={props.onComplete}
                    onSetMessageContent={props.onSetMessageContent}
                    triggerChangeReloadData={props.triggerChangeReloadData}
                />
            )}
        </div>
    );
}

const makeMapStateToProps = () => {
    const getToken = makeGetToken();
    const getAccountRight = makeGetAccountRight();
    const getMainListFinra = makeGetMainListFinra();

    return (state) => {
        return {
            token: getToken(state),
            accRight: getAccountRight(state),

            allFeeChange: getMainListFinra(state),
            actionFinra: makeGetActionFinra()(state),
        };
    };
};

export default connect(makeMapStateToProps)(
    translate('translations')(MmFeeChange)
);
