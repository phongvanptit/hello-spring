import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import IconReset from 'assets/img/icon/icons-reset.png';
import IconExcel from 'assets/img/icon/ms-excel.png';
import {
    FormFlexCenter,
    ButtonSearch,
    ExportExcel,
} from 'utils/styledComponent';
import { Form } from 'react-bootstrap';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetPublicStt } from 'lib/selector';
import RenderSelectDate from 'components/input/renderDatePicker';
import { makeGetListApplyStatusFinra } from '../../../../../lib/selector';

function usePrevious(value) {
    const ref = useRef();

    useEffect(() => {
        ref.current = value;
    }, [value]);

    return ref.current;
}

function FormSearch(props) {

    const {
        handleSubmit,
        t,
        glStatusList
    } = props;

    const preStartDate = usePrevious(props.formStartDate);
    const preEndDate = usePrevious(props.formEndDate);

    useEffect(() => {
        if (props.formStartDate && !_.isEqual(props.formStartDate, preStartDate)) {
            if (!props.formStartDate.includes('_')) {
                _handleBlur();
            }
        }
    }, [props.formStartDate]);

    useEffect(() => {
        if (props.formEndDate && !_.isEqual(props.formEndDate, preEndDate)) {
            if (!props.formEndDate.includes('_')) {
                _handleBlur();
            }
        }
    }, [props.formEndDate]);

    const submit = (values) => {
        props.dataSearch.data.STATUS = values.formStatus;
        props.dataSearch.data.APPLY_FROM_DATE = values.formStartDate;
        props.dataSearch.data.APPLY_TO_DATE = values.formEndDate;
        props.dataSearch.data.PRODUCT_CODE = values.formProdCode;
        props.setDataSearch(props.dataSearch);
        props.callSearch();
    };

    function _handleBlur() {
        if (props.dataSearch && props.dataSearch.data) {
            props.dataSearch.data.STATUS = props.formStatus;
            props.dataSearch.data.APPLY_FROM_DATE = props.formStartDate;
            props.dataSearch.data.APPLY_TO_DATE = props.formEndDate;
            props.dataSearch.data.PRODUCT_CODE = props.formProdCode;
            props.setDataSearch(props.dataSearch);
            props.callSearch()
        }
    }

    useEffect(() => {
        _handleBlur()
    }, [props.formStatus, props.formAccountCode, props.formAppendixCode, props.formStartDate, props.formEndDate, props.formProdCode]);

    return (
        <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
            <div className="d-flex align-items-center mr-auto">
                {/* Trạng thái */}
                <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
                <Field
                    name="formStatus"
                    className="form-control w_100 ml-2 mr-3"
                    component={RenderNormalSelect}
                    opts={props.listApplyStatus}
                    placeholder="-- Tất cả --"
                />
                <Form.Label className="fz-13 w-fix mr-2">
                    Ngày áp dụng từ ngày
                </Form.Label>
                <Field
                    name="formStartDate"
                    className="w_90"
                    component={RenderSelectDate}
                    classParentName="w-100"
                />
                <Form.Label className="fz-13 w-fix mx-2">
                    Ngày áp dụng đến ngày
                </Form.Label>
                <Field
                    name="formEndDate"
                    className="w_90"
                    classParentName="w-100"
                    component={RenderSelectDate}
                />
                {/* <Form.Label className="fz-13 mr-2">
          {t('txt_finra_tb_appendix_open_date')}
        </Form.Label>
        <Field
          name="formStartDate"
          className="w_90"
          component={RenderSelectDate}
        />
        <Form.Label className="fz-13 mx-2 ml-3">{t('txt_finra_tb_appendix_expire_date')}</Form.Label>
        <Field
          name="formEndDate"
          className="w_90"
          component={RenderSelectDate}
        /> */}
            </div>
            <Field
                name="formProdCode"
                type="text"
                className="form-control"
                placeholder={t('txt-prod-code')}
                component={RenderSearchShort}
                onBlur={_handleBlur}
                clickSearch={_handleBlur}
            />
        </FormFlexCenter>
    );
}

FormSearch = reduxForm({
    form: 'formSearchShortDTV',
    enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDTV');

const makeMapStateToProps = () => {
    const mapStateToProps = (state) => {
        const { formProdCode, formStatus, formStartDate, formEndDate } = selector(
            state,
            'formStatus',
            'formStartDate',
            'formEndDate',
            'formProdCode'
        );

        return {
            glStatusList: makeGetPublicStt()(state),
            listApplyStatus: makeGetListApplyStatusFinra()(state),

            formStatus,
            formProdCode,
            formStartDate,
            formEndDate,
        };
    };
    return mapStateToProps;
};

export default connect(makeMapStateToProps)(
    translate('translations')(FormSearch)
);
