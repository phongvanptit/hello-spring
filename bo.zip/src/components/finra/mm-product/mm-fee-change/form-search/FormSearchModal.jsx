import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import { makeGetToken } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    onClose,
    reset,
  } = props;

  const submit = (values) => {

    props.setDataSearch(props.dataSearch);
    props.callSearch();
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalDTV', 'formPartnerCode', ''));
    dispatch(change('formSearchModalDTV', 'formPartnerName', ''));
    dispatch(change('formSearchModalDTV', 'formCustCode', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100 ">
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalDTV');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state, props) => {
    const { formPartnerCode, formPartnerName, formCustCode } = selector(
      state,
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),

      initialValues: {
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
