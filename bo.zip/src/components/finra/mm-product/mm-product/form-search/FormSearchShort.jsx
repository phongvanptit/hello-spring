import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import {
  FormFlexCenter,
} from 'utils/styledComponent';
import { makeGetGlobalStatusList, makeGetListProductTypeFinra, makeGetMMUpdPartner } from 'lib/selector';
import { setToast } from 'containers/client/actions';
import { makeGetMMDelPartner } from 'lib/selector';
import { Form } from 'react-bootstrap';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetPublicStt } from 'lib/selector';
import { makeGetListWebProductTypeFinra } from 'lib/selector';
import { getListWebProductTypeRequesting } from 'containers/finra/actions';
import { makeGetToken } from 'lib/selector';
import { getListWebProductTypeSuccess } from 'containers/finra/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    token,
    handleSubmit,
    t,
    glStatusList
  } = props;

  useEffect(() => {
    getListProductWebType()

    return () => {
      props.reset();
    };
  }, []);

  function getListProductWebType() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'MM_PRODUCT_WEB_TYPE.GET_ALL_SELECT',
      group: 'LIST',
      data: {
        TYPE_GET: 'INSERT'
      },
    };
  
    dispatch(getListWebProductTypeRequesting(params));
  }

  const submit = (values) => {
    props.dataSearch.data.PRODUCT_CODE = values.formProdCode;
    props.dataSearch.data.PRODUCT_NAME = values.formProdName;
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.ACTIVE = values.formActive;
    props.dataSearch.data.PRODUCT_TYPE = values.formProductType;
    props.dataSearch.data.WEB_PRODUCT_TYPE = values.formWebProductType;
    props.setDataSearch(props.dataSearch);
    props.callSearch();
  };

  function _handleBlur() {
    if (props.dataSearch && props.dataSearch.data) {
      props.dataSearch.data.PRODUCT_CODE = props.formProdCode;
      props.dataSearch.data.PRODUCT_NAME = props.formProdName;
      props.dataSearch.data.STATUS = props.formStatus;
      props.dataSearch.data.ACTIVE = props.formActive;
      props.dataSearch.data.PRODUCT_TYPE = props.formProductType;
      props.dataSearch.data.WEB_PRODUCT_TYPE = props.formWebProductType;
      props.setDataSearch(props.dataSearch);
      props.callSearch()
    }
  }

  useEffect(() => {
    _handleBlur()
  }, [props.formStatus, props.formProdCode, props.formProdName, props.formActive, props.formProductType, props.formWebProductType]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        {/* Trạng thái */}
        <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13">{t('txt-prod-code')}</Form.Label>
        <Field
          name={'formProdCode'}
          type="text"
          className="form-control w_150 ml-2 mr-3"
          placeholder={t('txt-prod-code')}
          component={RenderInput}
        />
        <Form.Label className="fz-13">{t('txt-active')}</Form.Label>
        <Field
          name={'formActive'}
          className="form-control w_120 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={props.glActiveList}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13">Loại sản phẩm</Form.Label>
        <Field
          name={'formProductType'}
          className="form-control w_150 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={props.glListProductType}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13">Loại SP web/app</Form.Label>
        <Field
          name={'formWebProductType'}
          className="form-control w_130 ml-2 mr-4"
          component={RenderNormalSelect}
          opts={props.glListWebProductType}
          placeholder="-- Tất cả --"
        />
      </div>
      <Field
        name="formProdName"
        type="text"
        className="form-control"
        placeholder={t('txt-prod-name')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDTV',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDTV');

const makeMapStateToProps = () => {
  const getMMUpdPartner = makeGetMMUpdPartner();
  const getMMDelPartner = makeGetMMDelPartner();

  const mapStateToProps = (state) => {
    const {
      formStatus,
      formProdCode,
      formProdName,
      formActive,
      formProductType,
      formWebProductType,
    } = selector(
      state,
      'formStatus',
      'formProdCode',
      'formProdName',
      'formActive',
      'formProductType',
      'formWebProductType',
    );

    return {
      token: makeGetToken()(state),

      mmUpdPartner: getMMUpdPartner(state),
      mmDelPartner: getMMDelPartner(state),
      glStatusList: makeGetPublicStt()(state),
      glActiveList: makeGetGlobalStatusList()(state),
      glListProductType: makeGetListProductTypeFinra()(state),
      glListWebProductType: makeGetListWebProductTypeFinra()(state),

      formStatus,
      formProdCode,
      formProdName,
      formActive,
      formProductType,
      formWebProductType,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
