import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  makeGetAccountRight, makeGetActionFinra,
  makeGetMainListFinra,
  makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form-search/FormSearch';
import { usePrevious } from '../../../../lib/useHook';
import { FaCheck, FaTimes } from 'react-icons/fa';
import { MdDateRange } from "react-icons/md";
import PerfectScrollBar from 'react-perfect-scrollbar';
import DetailDoiTuongVayModal from '../../../modal/finra/doi-tuong-vay/DetailDoiTuongVayModal';
import {
  actionFinraRequesting,
  mainListFinraRequesting,
  mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { numberFormat, numberFormatDecimal } from '../../../../utils';
import DetailBieuLaiSuatModal from '../../../modal/finra/bieu-lai-suat/DetailBieuLaiSuatModal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import UpdateProduct from '../../../modal/finra/product/UpdateProduct';
import UpdateProductWebType from '../../../modal/finra/product-web-type/UpdateProductWebType';
import { TbReload } from 'react-icons/tb';
import { IoReload } from 'react-icons/io5';

const configActionButton = {
  delete: {
    messageRequest: 'txt_mm_delete_product_web_type_req',
    messageSuccess: 'txt_mm_delete_product_web_type_success',
    cmd: 'MM_PRODUCT_WEB_TYPE.DELETE_ITEM'
  },
  approve: {
    messageRequest: 'txt_mm_approve_product_web_type_req',
    messageSuccess: 'txt_mm_approve_product_web_type_success',
    cmd: 'MM_PRODUCT_WEB_TYPE.APPROVE_ITEM'
  },
  active: {
    messageRequest: 'txt_mm_active_product_web_type_req',
    messageSuccess: 'txt_mm_active_product_web_type_success',
    cmd: 'MM_PRODUCT_WEB_TYPE.CHANGE_ACTIVE_ITEM'
  },
}

function MmProductWebType(props) {
  const t = props.t;

  const [page, setPage] = useState(1);
  const [recordPerPage, setRecordPerPage] = useState(10);
  const [recordDetail, setRecordDetail] = useState(undefined);
  const [dataSearch, setDataSearch] = useState(undefined);

  const dispatch = useDispatch();
  const preActionFinra = usePrevious(props.actionFinra);

  useEffect(() => {
    setDataSearch({
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_PRODUCT_WEB_TYPE.GET_ALL',
      group: 'LIST',
      data: {
        CODE: undefined,
        NAME: undefined,
        STATUS: undefined,
        ACTIVE: undefined,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    });

    return () => {
      dispatch(mainListFinraSuccess(undefined))
    }
  }, [])

  useEffect(() => {
    if (dataSearch) {
      callSearch()
    }
  }, [dataSearch, props.triggerChangeReloadData]);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
    }
  }, [props.actionFinra]);

  const callSearch = () => {
    dispatch(mainListFinraRequesting(dataSearch))
  }

  function handleNextPage(step) {
    if (dataSearch) {
      setPage(step);
      dataSearch.data.PAGE = step
      setDataSearch({ ...dataSearch })
    }
  }

  function handleChangeRecordPerPage (value) {
    if (dataSearch) {
      setRecordPerPage(value)
      dataSearch.data.RECORD_PER_PAGE = value
      setDataSearch({...dataSearch})
    }
  }

  function onClose(pk) {
    setRecordDetail(undefined);
  }

  function handleShowItem(value) {
    setRecordDetail(value);
  }

  function handleButtonAction(pk, action) {
    if (!pk) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configActionButton[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleAction(pk, action);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleAction(pk, action) {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configActionButton[action].cmd,
      group: 'LIST',
      data: {
        ITEM_ID: pk
      },
    };

    props.onSetMessageContent(configActionButton[action].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  return (
    <div className="w-100 d-flex flex-column custom-tabs-content my-3">
      <FormSearch callSearch={callSearch} dataSearch={dataSearch} setDataSearch={setDataSearch} />
      <PerfectScrollbar>
        <Table bordered>
          <thead>
          <tr>
            <th>#</th>
            <th>Mã</th>
            <th>Tên</th>
            <th>Trạng thái</th>
            <th>Active</th>
            <th>{t('txt-action')}</th>
          </tr>
          </thead>
          <tbody>
          {props.allPartner &&
            props.allPartner.map((item) => (
              <tr key={item.ROW_NUM}>
                <td className="text-center">{item.ROW_NUM}</td>
                <td className="text-center">{item.C_CODE}</td>
                <td className="text-center">{item.C_NAME}</td>
                <td className="text-center">{item.C_STATUS_NAME}</td>
                <td className="text-center">{item.C_ACTIVE === 1 ? 'Hoạt động' : 'Không hoạt động'}</td>
                <td className="text-center p-0">
                  <GroupButton>
                    {props.accRight?.C_VIEW === 1 && (
                      <a
                        title={t('txt-detail')}
                        rel="noreferrer noopener"
                        onClick={() => handleShowItem(item.PK_PRODUCT_WEB_TYPE)}
                      >
                        <IconCopy />
                      </a>
                    )}
                    {props.accRight?.C_APPROVE === 1 && (
                      <a
                        title={t('txt-appr')}
                        className={item.C_STATUS === 'DA_DUYET' ? 'disabled' : ''}
                        rel="noreferrer noopener"
                        onClick={() => item.C_STATUS === 'DA_DUYET' ? undefined : handleButtonAction(item.PK_PRODUCT_WEB_TYPE, 'approve')}
                      >
                        <IconApprove />
                      </a>
                    )}
                    {/*{props.accRight?.C_APPROVE === 1 && (*/}
                    {/*  <a*/}
                    {/*    title={t('txt-del')}*/}
                    {/*    className={item.C_STATUS !== 'DA_DUYET' ? 'disabled' : ''}*/}
                    {/*    rel="noreferrer noopener"*/}
                    {/*    onClick={() => item.C_STATUS === 'DA_DUYET' ? handleButtonAction(item.PK_PRODUCT_WEB_TYPE, 'active') : undefined}*/}
                    {/*  >*/}
                    {/*    <IoReload   />*/}
                    {/*  </a>*/}
                    {/*)}*/}
                    {props.accRight?.C_UPDATE === 1 && (
                      <a
                        title={t('txt-del')}
                        className={Boolean(item.C_APPROVER_CODE) ? 'disabled' : ''}
                        rel="noreferrer noopener"
                        onClick={() => !Boolean(item.C_APPROVER_CODE) ? handleButtonAction(item.PK_PRODUCT_WEB_TYPE, 'delete') : undefined}
                      >
                        <IconTrash />
                      </a>
                    )}
                  </GroupButton>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </PerfectScrollbar>

      {(!props.allPartner || !props.allPartner.length) && (
        <NodataSearch name={t('lab_finra_tab_partner')} />
      )}

      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={handleChangeRecordPerPage}
          total={
            props.allPartner && !!props.allPartner.length
              ? props.allPartner[0].C_TOTAL_RECORD
              : 0
          }
        />
      </div>
      {recordDetail && (
        <UpdateProductWebType
          itemId={recordDetail}
          onClose={onClose}
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getAccountRight = makeGetAccountRight();
  const getMainListFinra = makeGetMainListFinra();

  return (state) => {
    return {
      token: getToken(state),
      accRight: getAccountRight(state),

      allPartner: getMainListFinra(state),
      actionFinra: makeGetActionFinra()(state),
    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(MmProductWebType)
);
