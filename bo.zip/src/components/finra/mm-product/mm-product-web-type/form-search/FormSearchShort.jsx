import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import {
  FormFlexCenter,
} from 'utils/styledComponent';
import { makeGetGlobalStatusList, makeGetListProductTypeFinra, makeGetMMUpdPartner } from 'lib/selector';
import { setToast } from 'containers/client/actions';
import { makeGetMMDelPartner } from 'lib/selector';
import { Form } from 'react-bootstrap';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { makeGetPublicStt } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    t,
    glStatusList
  } = props;

  const submit = (values) => {
    props.dataSearch.data.CODE = values.formCode;
    props.dataSearch.data.NAME = values.formName;
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.ACTIVE = values.formActive;
    props.setDataSearch({ ...props.dataSearch });
    props.callSearch();
  };

  function _handleBlur() {
    if (props.dataSearch && props.dataSearch.data) {
      props.dataSearch.data.CODE = props.formCode;
      props.dataSearch.data.NAME = props.formName;
      props.dataSearch.data.STATUS = props.formStatus;
      props.dataSearch.data.ACTIVE = props.formActive;
      props.setDataSearch({ ...props.dataSearch });
      props.callSearch()
    }
  }

  useEffect(() => {
    _handleBlur()
  }, [props.formStatus, props.formCode, props.formName, props.formActive]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        <Form.Label className="fz-13">Mã loại SP</Form.Label>
        <Field
          name={'formName'}
          type="text"
          className="form-control w_150 ml-2 mr-4"
          placeholder='Mã loại SP'
          component={RenderInput}
        />
        <Form.Label className="fz-13">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_150 ml-2 mr-4"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
        />
        <Form.Label className="fz-13">{t('txt-active')}</Form.Label>
        <Field
          name={'formActive'}
          className="form-control w_150 ml-2 mr-4"
          component={RenderNormalSelect}
          opts={props.glActiveList}
          placeholder="-- Tất cả --"
        />
      </div>
      <Field
        name="formCode"
        type="text"
        className="form-control"
        placeholder={'Tên loại SP'}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalPWT',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalPWT');

const makeMapStateToProps = () => {
  const mapStateToProps = (state) => {
    const {
      formCode,
      formName,
      formStatus,
      formActive,
    } = selector(
      state,
      'formCode',
      'formName',
      'formStatus',
      'formActive',
    );

    return {
      glStatusList: makeGetPublicStt()(state),
      glActiveList: makeGetGlobalStatusList()(state),
      glListProductType: makeGetListProductTypeFinra()(state),

      formCode,
      formName,
      formStatus,
      formActive,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
