import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import { makeGetToken } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    onClose,
    reset,
  } = props;

  const submit = (values) => {
    props.dataSearch.data.CODE = values.formCode;
    props.dataSearch.data.NAME = values.formName;
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.ACTIVE = values.formActive;

    props.setDataSearch(props.dataSearch);
    props.callSearch();
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalPWT', 'formCode', ''));
    dispatch(change('formSearchModalPWT', 'formName', ''));
    dispatch(change('formSearchModalPWT', 'formStatus', ''));
    dispatch(change('formSearchModalPWT', 'formActive', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100 ">
        <Form.Group>
          <Form.Label className="fz-13">Mã</Form.Label>
          <Field
            name={'formCode'}
            type="text"
            className="form-control"
            placeholder='Mã'
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Tên</Form.Label>
          <Field
            name={'formName'}
            type="text"
            className="form-control"
            placeholder='Tên'
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Trạng thái</Form.Label>
          <Field
            name={'formStatus'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label className="fz-13">Active</Form.Label>
          <Field
            name={'formActive'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalPWT',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalPWT');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state, props) => {
    const { formCode, formName, formStatus, formActive } = selector(
      state,
      'formCode',
      'formName',
      'formStatus',
      'formActive'
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      formCode,
      formName,
      formStatus,
      formActive,

      initialValues: {
        formCode: dataSearch?.data?.CODE,
        formName: dataSearch?.data?.NAME,
        formStatus: dataSearch?.data?.STATUS,
        formActive: dataSearch?.data?.ACTIVE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
