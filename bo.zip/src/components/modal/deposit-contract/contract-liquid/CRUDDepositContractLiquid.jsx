import {
    makeGetDetailDepositContractLiquid,
    makeGetMmContactBaseCode,
    makeGetCapTermContract,
    makeGetToken
} from "lib/selector";
import React, { useEffect, useState } from "react";
import { translate } from "react-i18next";
import { connect, useDispatch } from "react-redux";
import { Field, change, formValueSelector, reduxForm } from "redux-form";
import { lengthRequired } from "utils/validation";
import styled from 'styled-components';
import ReactModal from 'react-modal';
import { actionDepositContractSuccess } from "containers/deposit-contract/actions";
import { getDetailDepositContractLiquidSuccess } from "containers/deposit-contract/actions";
import { mmGetExpireDateSuccess } from "containers/product/actions";
import { mmContactBaseCodeSuccess } from "containers/product/actions";
import { getDetailDepositContractLiquidRequesting } from "../../../../containers/deposit-contract/actions";
import { FaTimes } from "react-icons/fa";
import { confirmAlert } from "react-confirm-alert";
import { actionDepositContractRequesting } from "containers/deposit-contract/actions";
import { StringToNumber } from "utils";
import { required } from "utils/validation";
import { Form } from 'react-bootstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import renderNewInput from "components/input/renderNewInput";
import RenderInput from "components/input/renderInput";
import RenderNormalSelect from "components/input/renderNormalSelect";
import RenderSelectDate from 'components/input/renderDatePicker';
import { makeGetMmGetExpireDate } from "lib/selector";
import { numberFormatDecimal } from "utils";
import RenderInputMask from "components/input/renderInputMask";
import { makeGetCapFeeBase } from "lib/selector";
import { validateNumberExact } from "utils/validation";
import RenderArea from "components/input/renderArea";
import { mainItemDepositContractRequesting } from "containers/deposit-contract/actions";
import { makeGetMainDetailDepositContract } from "lib/selector";
import { custDetailRequest } from "containers/customer/actions";
import { cashBalanceRequest } from "containers/cash/actions";
import * as _ from 'lodash';
import { makeGetCustomerDetail } from "lib/selector";
import { mmGetExpireDateRequest } from "containers/product/actions";
import { makeGetCashBalance } from "lib/selector";
import Decimal from 'decimal.js'
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import { makeGetAccountRight } from "lib/selector";
import { custDetailSuccess } from "containers/customer/actions";
import { makeGetActionDepositContract } from "lib/selector";
import { StringToDouble } from "utils";

ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
    content: {
        top: '40px',
        bottom: 'auto',
        left: 'calc( 50% - 500px )',
        height: 'auto',
        width: '1000px',
        padding: '0',
        borderWidth: '0',
        borderColor: '#f3f3f3',
        overflow: 'inherit',
    },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
        font-size: 13px;
    }
`;

const length7 = lengthRequired(6);

//#endregion

function usePrevious(value) {
    const ref = React.useRef();

    React.useEffect(() => {
        ref.current = value;
    }, [value]);

    return ref.current;
}

const configNotification = {
    create: {
        messageRequest: 'txt_mm_create_deposit_contract_liquid_req',
        messageSuccess: 'txt_mm_create_deposit_contract_liquid_success',
        cmd: 'MM.UPDATE_DEPOSIT_CONTRACT_LIQUID'
    },
    update: {
        messageRequest: 'txt_mm_update_deposit_contract_liquid_req',
        messageSuccess: 'txt_mm_update_deposit_contract_liquid_success',
        cmd: 'MM.UPDATE_DEPOSIT_CONTRACT_LIQUID'
    },
    delete: {
        messageRequest: 'txt_mm_delete_deposit_contract_liquid_req',
        messageSuccess: 'txt_mm_delete_deposit_contract_liquid_success',
        cmd: 'MM.DELETE_DEPOSIT_CONTRACT_LIQUID'
    },
    approve: {
        messageRequest: 'txt_mm_approve_deposit_contract_liquid_req',
        messageSuccess: 'txt_mm_approve_deposit_contract_liquid_success',
        cmd: 'MM.APPROVE_ITEM_DEPOSIT_CONTRACT_LIQUID'
    },
    un_approve: {
        messageRequest: 'txt_mm_un_approve_deposit_contract_liquid_req',
        messageSuccess: 'txt_mm_un_approve_deposit_contract_liquid_success',
        cmd: 'MM.UN_APPROVE_ITEM_DEPOSIT_CONTRACT_LIQUID'
    }
}

function CRUDDepositContractLiquid(props) {
    const { handleSubmit, submitting, onClose, t,
        capTermContract,
        mmGetExpireDate,
        capFeeBase,
        detailDepositContract,
        actionLiquid,
        token,
        formTerm,
        formOpenDate,
        formCapital,
        formFeeRate,
        formOrtherFeeRate,
        formFeeBase,
        accRight,
        detailDepositContractLiquid
    } = props;
    const [isApproved, setIsApproved] = useState(true);
    const dispatch = useDispatch();

    const preActionLiquid = usePrevious(props.actionLiquid)
    const preFormOpenDate = usePrevious(formOpenDate)
    const preCustomerCode = usePrevious(props.formCustomerCode);
    const preFormTerm = usePrevious(formTerm)
    const [isInitLoad, setIsInitLoad] = useState(true);

    useEffect(() => {
        initForm()
        getDetailItem()

        return () => {
            dispatch(getDetailDepositContractLiquidSuccess(undefined))
            dispatch(mmContactBaseCodeSuccess(undefined))
            dispatch(mmGetExpireDateSuccess(undefined))
            dispatch(actionDepositContractSuccess(undefined))

            props.reset();
        };
    }, []);

    // bind dữ liệu
    useEffect(() => {
        if (props.detailDepositContract) {
            dispatch(change('CRUDDepositContractLiquid', 'formCustomerCode', props.detailDepositContract?.C_CUSTOMER_CODE));
            dispatch(change('CRUDDepositContractLiquid', 'formOpenDate', props.detailDepositContract?.C_OPEN_DATE));
            dispatch(change('CRUDDepositContractLiquid', 'formExpireDate', props.detailDepositContract?.C_EXPIRE_DATE));
            dispatch(change('CRUDDepositContractLiquid', 'formAppendixNumber', props.detailDepositContract?.C_INV_APPENDIX_CODE));
            dispatch(change('CRUDDepositContractLiquid', 'formTerm', props.detailDepositContract?.C_TERM));
            dispatch(change('CRUDDepositContractLiquid', 'formCapital', props.detailDepositContract?.C_CAPITAL));
            dispatch(change('CRUDDepositContractLiquid', 'formFeeRate', props.detailDepositContract?.C_FEE_RATE));
            dispatch(change('CRUDDepositContractLiquid', 'formOrtherFeeRate', props.detailDepositContract?.C_OTHER_FEE_RATE));
            dispatch(change('CRUDDepositContractLiquid', 'formFeeBase', props.detailDepositContract?.C_FEE_BASE));
            dispatch(change('CRUDDepositContractLiquid', 'formLiquidTaxRate', props.detailDepositContract?.C_TAX));

            setIsApproved(props.detailDepositContract.C_STATUS === 'DA_DUYET')

            if (props.itemId) {
                getDetailLiquid()
            }
        }
    }, [props.detailDepositContract])

    useEffect(() => {
        if (
            props.formCustomerCode &&
            props.formCustomerCode.length === 6 &&
            !_.isEqual(props.formCustomerCode, preCustomerCode)
        ) {
            _handleCheckCustomer();
            _handleCheckBalance();
        } else dispatch(custDetailSuccess(null));
    }, [props.formCustomerCode]);

    useEffect(() => {
        if (props.actionLiquid && !_.isEqual(props.actionLiquid, preActionLiquid)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionLiquid])

    useEffect(() => {
        if (
            (formTerm && !_.isEqual(formTerm, preFormTerm)) ||
            (formOpenDate && !_.isEqual(formOpenDate + '', preFormOpenDate + ''))
        ) {
            getExpireDate();
        }
    }, [formOpenDate, formTerm]);

    useEffect(() => {
        if (props.detailDepositContractLiquid) {
            dispatch(change('CRUDDepositContractLiquid', 'formLiquidFee', numberFormatDecimal(props.detailDepositContractLiquid?.C_FEE)));
            dispatch(change('CRUDDepositContractLiquid', 'formLiquidTax', numberFormatDecimal(props.detailDepositContractLiquid?.C_TAX_VALUE)));
            dispatch(change('CRUDDepositContractLiquid', 'formLiquidCapital', numberFormatDecimal(props.detailDepositContractLiquid?.C_CAPITAL)));
            dispatch(change('CRUDDepositContractLiquid', 'formContent', numberFormatDecimal(props.detailDepositContractLiquid?.C_CONTENT)));

            // setIsInitLoad(false)
        }
    }, [props.detailDepositContractLiquid]);

    const processNumber = (value) => {
        if (value === null || value === undefined) {
            return '0';
        } else if (typeof value === 'string' && value.trim() === '') {
            return '0';
        } else {
            return StringToDouble(value);
        }
    }

    const initForm = () => {
        dispatch(change('CRUDDepositContractLiquid', 'formLiquidCapital', '0'));
        dispatch(change('CRUDDepositContractLiquid', 'formLiquidTax', '0'));
        dispatch(change('CRUDDepositContractLiquid', 'formLiquidFee', '0'));
    }

    function _handleCheckCustomer() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'BACK.GET_SINGLE_CUSTOMER',
            group: 'LIST',
            data: {
                CUSTOMER_ID: props.detailDepositContract?.C_CUSTOMER_CODE,
            },
        };

        dispatch(custDetailRequest(params));
    }

    function _handleCheckBalance() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'BACK.GET_CASH_BALANCE',
            group: 'LIST',
            data: {
                CUSTOMER_CODE: props.detailDepositContract?.C_CUSTOMER_CODE,
            },
        };
        dispatch(cashBalanceRequest(params));
    }

    function getDetailItem() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ITEM_DEPOSIT_CONTRACT',
            group: 'LIST',
            data: {
                ITEM_ID: props.depositCtID
            },
        };

        dispatch(mainItemDepositContractRequesting(params));
    }

    const getDetailLiquid = () => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ITEM_DEPOSIT_CONTRACT_LIQUID',
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId
            },
        };
        dispatch(getDetailDepositContractLiquidRequesting(params));
    }

    function getExpireDate() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'MM.GET_DEPOSIT_CONTRACT_EXPIRE_DATE',
            group: 'LIST',
            data: {
                OPEN_DATE: props.formOpenDate,
                TERM: props.formTerm,
            },
        };

        dispatch(mmGetExpireDateRequest(params));
    }

    useEffect(() => {
        if (
            props?.formOpenDate
            && props?.formCapital
            && props?.formFeeRate
            && props?.formOrtherFeeRate
            && props?.formFeeBase
            && mmGetExpireDate?.C_DAY_DIFF
        ) {
            const dayDiff = new Decimal(processNumber(props.mmGetExpireDate?.C_DAY_DIFF));
            const feeRate = new Decimal(processNumber(props.formFeeRate));
            const baseFee = new Decimal(processNumber(props.formFeeBase));

            if (isInitLoad) {
                // Lãi suất *Số ngày vay* Số tiền vay/100/365
                const capital = new Decimal(processNumber(props.formCapital));
                const otherFeeRate = new Decimal(processNumber(props.formOrtherFeeRate));

                var feeValue = Decimal.round(capital.mul(dayDiff).mul(feeRate).div(100).div(baseFee)).toNumber()
                var otherFeeValue = Decimal.round(Decimal(feeValue).mul(otherFeeRate).div(100)).toNumber()
                var feeAfterCal = numberFormatDecimal(Decimal(feeValue).sub(otherFeeValue).toNumber())
                dispatch(change('CRUDDepositContractLiquid', 'formFee', feeAfterCal))
                setIsInitLoad(false)
            }

            if (props.formLiquidCapital) {
                const capitalLq = new Decimal(processNumber(props.formLiquidCapital));
                const taxRate = new Decimal(processNumber(props.formLiquidTaxRate));


                const fee = capitalLq.mul(feeRate).mul(dayDiff).div(baseFee).div(100)
                const tax = fee.mul(taxRate).div(100)

                dispatch(change('CRUDDepositContractLiquid', 'formLiquidFee', fee.round().toString()));
                dispatch(change('CRUDDepositContractLiquid', 'formLiquidTax', tax.round().toString()));
            }
        }
    }, [mmGetExpireDate?.C_DAY_DIFF, props.formLiquidCapital]);

    const handleButtonAction = (action) => {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configNotification[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                if (['create', 'update'].includes(action)) {
                                    UpdateLiquid(action)
                                } else {
                                    handleActionWithID(action);
                                }
                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    const UpdateLiquid = (type) => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification[type].cmd,
            group: 'LIST',
            data: {
                "ITEM_ID": props.itemId,
                "INV_APPENDIX_CODE": props.depositCtID,
                "LIQUID_TYPE": "MANUAL",
                "CAPITAL": StringToNumber(props.formLiquidCapital),
                "CONTENT": props.formContent,
            },
        };
        props.onSetMessageContent(configNotification[type].messageSuccess)
        dispatch(actionDepositContractRequesting(params))
    }

    function handleActionWithID(action) {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: configNotification[action].cmd,
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId,
            },
        };

        props.onSetMessageContent(configNotification[action].messageSuccess)
        dispatch(actionDepositContractRequesting(params));
    }

    const submit = () => {
        handleButtonAction(props.itemId ? 'update' : 'create')
    }

    return (
        <ReactModal
            isOpen={true}
            contentLabel="onRequestClose Example"
            onRequestClose={onClose}
            shouldCloseOnOverlayClick={true}
            overlayClassName="overlay"
            style={customStyles}
        >
            <div
                className="w-100 p-0 rounded"
                style={{ maxHeight: 'calc(100vh - 120px)', overflow: 'hidden' }}
            >
                <div className="py-2 d-flex justify-content-between">
                    <b className="fz-16 pl-3">{t(props.itemId ? 'txt_deposit_contract_liquid_modal_update' : 'txt_deposit_contract_liquid_modal_create')}</b>
                    <a onClick={onClose} className="pr-3">
                        <FaTimes />
                    </a>
                </div>
                <StyleContainer>
                    <form onSubmit={handleSubmit(submit)}>
                        <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 260px)' }}>
                            <FormAdd>
                                {/* Mã khách hàng */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-cust-code')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formCustomerCode"
                                        className="form-control input-order fz-13"
                                        classParent="w-100"
                                        component={renderNewInput}
                                        validate={[required, length7]}
                                        index="3"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Tên khách hàng */}
                                <Form.Group style={{ gridColumn: '2/4' }}>
                                    <Form.Label>{t('txt-cust-name')}</Form.Label>
                                    <Form.Control
                                        value={props.custDetail?.C_CUSTOMER_NAME || ''}
                                        disabled
                                    />
                                </Form.Group>
                                {/* MKT ID */}
                                <Form.Group>
                                    <Form.Label>{t('txt-marketing-id')}</Form.Label>
                                    <Form.Control
                                        type={'text'}
                                        className="input-order fz-13"
                                        value={props.custDetail?.C_MARKETING_ID || ''}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Mã hợp đồng */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-contract-code')}{' '}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formAppendixNumber"
                                        className="form-control"
                                        component={RenderInput}
                                        validate={[required]}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Kỳ hạn */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt-period')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formTerm"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        validate={[required]}
                                        opts={capTermContract}
                                        required
                                        disabled
                                    />
                                </Form.Group>
                                {/* Ngày mở */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-open-date')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formOpenDate"
                                        className="form-control input-order fz-13"
                                        classParentName="w-100"
                                        component={RenderSelectDate}
                                        validate={[required]}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Ngày hết hạn */}
                                <Form.Group>
                                    <Form.Label>{t('txt-expire-date')}</Form.Label>
                                    <input
                                        value={mmGetExpireDate?.C_EXPIRE_DATE || ''}
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Số ngày */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>{t('txt-number-day')}</Form.Label>
                                    <input
                                        value={mmGetExpireDate?.C_DAY_DIFF || ''}
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Số dư tài khoản */}
                                <Form.Group>
                                    <Form.Label>{t('txt-acc-balance')}</Form.Label>
                                    <input
                                        value={
                                            props?.cashBalance?.C_CASH_BALANCE_BO === 0
                                                ? '0'
                                                : numberFormatDecimal(props?.cashBalance?.C_CASH_BALANCE_BO) || ''
                                        }
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Giá trị tiền gửi */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt_deposit_contract_value')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formCapital"
                                        className="form-control"
                                        component={RenderInputMask}
                                        validate={[required]}
                                        disabled
                                    // onBlur={handleBlurCapital}
                                    />
                                </Form.Group>
                                {/* Lãi suất */}
                                <Form.Group>
                                    <Form.Label>{t('txt-interest-rate-1')}</Form.Label>
                                    <Field
                                        name='formFeeRate'
                                        component={RenderInputMask}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Phí khác */}
                                <Form.Group>
                                    <Form.Label>{t('txt-fee-other')}</Form.Label>
                                    <Field
                                        name="formOrtherFeeRate"
                                        className="form-control"
                                        component={RenderInputMask}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Cơ sở tính lãi */}
                                <Form.Group>
                                    <Form.Label>{t('txt-interest-calculation-basis')}</Form.Label>
                                    <Field
                                        name="formFeeBase"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        opts={capFeeBase}
                                        required
                                        disabled
                                    />
                                </Form.Group>
                                {/* Trả lãi */}
                                <Form.Group>
                                    <Form.Label>{t('txt-pay-interest')}</Form.Label>
                                    <Field
                                        name="formFee"
                                        component={RenderInputMask}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                <p
                                    style={{ gridColumn: '1/5' }}
                                    className="color-thm mb-0 fz-13"
                                >
                                    Thông tin thanh lý
                                </p>
                                {/* Giá trị thanh lý */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt_deposit_cotract_liquid_capital')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formLiquidCapital"
                                        className="form-control"
                                        component={RenderInputMask}
                                        validate={[required, validateNumberExact]}
                                    />
                                </Form.Group>
                                {/* Tỉ lệ lãi (%/năm) */}
                                {/* <Form.Group>
                                    <Form.Label>
                                        Tỉ lệ lãi (%/năm)
                                    </Form.Label>
                                    <Field
                                        name="formLiquidFeeRate"
                                        className="form-control"
                                        component={RenderInputMask}
                                        allowDecimal={true}
                                        decimalLimit={6}
                                        disabled
                                    />
                                </Form.Group> */}
                                {/* Lãi nhận */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt_deposit_cotract_liquid_fee')}
                                    </Form.Label>
                                    <Field
                                        name="formLiquidFee"
                                        className="form-control"
                                        component={RenderInputMask}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Tỷ lệ thuế (%) */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt_deposit_cotract_liquid_tax')}
                                    </Form.Label>
                                    <Field
                                        name="formLiquidTaxRate"
                                        className="form-control"
                                        component={RenderInputMask}
                                        allowDecimal={true}
                                        decimalLimit={6}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Thuế */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt-tax')}
                                    </Form.Label>
                                    <Field
                                        name="formLiquidTax"
                                        className="form-control"
                                        component={RenderInputMask}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Nội dungg */}
                                <Form.Group style={{ gridColumn: '1/5' }}>
                                    <Form.Label>{t('txt-content')}</Form.Label>
                                    <Field
                                        name="formContent"
                                        className="form-control input-order fz-13"
                                        component={RenderArea}
                                        rows={2}
                                    />
                                </Form.Group>

                                {/* Bộ thông tin thêm */}
                                <Form.Label>
                                    {t('txt-creator')} : {props.detailDepositContractLiquid?.C_CREATOR_CODE}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '3/5' }}>
                                    {t('txt-create-time')} : {props.detailDepositContractLiquid?.C_CREATE_TIME}
                                </Form.Label>
                                <Form.Label>
                                    {t('txt-approver')}: {props.detailDepositContractLiquid?.C_APPROVER_CODE}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '3/5' }}>
                                    {t('txt-approve-time')} : {props.detailDepositContractLiquid?.C_APPROVE_TIME}
                                </Form.Label>

                            </FormAdd>
                        </PerfectScrollbar>
                        <hr style={{ gridColumn: '1/5' }} />
                        <div
                            className="d-flex"
                            style={{
                                height: '30px',
                                whiteSpace: 'nowrap',
                                gridColumn: '1/5',
                            }}
                        >
                            <BtnClose type="button" onClick={onClose} className="mr-auto">
                                {t('txt-close')}
                            </BtnClose>
                            <div className="d-flex">
                                {!props.itemId && (
                                    <>
                                        {accRight?.C_UPDATE === 1 && (
                                            <BtnSubmit
                                                type="submit"
                                                disabled={submitting}
                                            >
                                                {t('txt-add')}
                                            </BtnSubmit>
                                        )}
                                    </>
                                )}
                                {props.itemId && (
                                    <>
                                        {detailDepositContractLiquid?.C_STATUS === 'CHUA_DUYET' && (
                                            <>
                                                {accRight?.C_APPROVE === 1 && (
                                                    <BtnSubmit
                                                        type="button"
                                                        disabled={submitting}
                                                        className="success mr-2"
                                                        onClick={() => handleButtonAction('approve')}
                                                    >
                                                        {t('txt-appr')}
                                                    </BtnSubmit>
                                                )}
                                                {accRight?.C_UPDATE === 1 && (
                                                    <>
                                                        <BtnSubmit
                                                            type="button"
                                                            disabled={submitting}
                                                            className="danger mr-2"
                                                            onClick={() => handleButtonAction('del')}
                                                        >
                                                            {t('txt-del')}
                                                        </BtnSubmit>
                                                        <BtnSubmit type="submit" disabled={submitting}>
                                                            {t('txt-accept')}
                                                        </BtnSubmit>
                                                    </>
                                                )}
                                            </>
                                        )}

                                        {detailDepositContractLiquid?.C_STATUS === 'DA_DUYET' && (
                                            <>
                                                {accRight?.C_APPROVE === 1 && (
                                                    <BtnSubmit
                                                        type="button"
                                                        disabled={submitting}
                                                        className="danger"
                                                        onClick={() => handleButtonAction('un_approve')}
                                                    >
                                                        {t('txt-unAppr')}
                                                    </BtnSubmit>
                                                )}
                                            </>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    </form>
                </StyleContainer>
            </div>
        </ReactModal >
    )
}

CRUDDepositContractLiquid = reduxForm({
    form: 'CRUDDepositContractLiquid',
    enableReinitialize: true
})(CRUDDepositContractLiquid);

const selector = formValueSelector('CRUDDepositContractLiquid');

const mapStateToProps = (state) => {
    const {
        formCustomerCode,
        formOpenDate,
        formExpireDate,
        formTerm,
        formContent,
        formCapital,
        formFeeRate,
        formFee,
        formFeeBase,
        formOrtherFeeRate,
        formAppendixNumber,
        formLiquidTaxRate,
        formLiquidFee,
        formLiquidTax,
        formLiquidCapital,
    } = selector(
        state,
        'formCustomerCode',
        'formOpenDate',
        'formExpireDate',
        'formTerm',
        'formCapital',
        'formContent',
        'formAppendixNumber',
        'formFee',
        'formFeeBase',
        'formFeeRate',
        'formOrtherFeeRate',
        'formLiquidTaxRate',
        'formLiquidFee',
        'formLiquidTax',
        'formLiquidCapital',
    );

    return {
        token: makeGetToken()(state),
        actionLiquid: makeGetActionDepositContract()(state),
        detailDepositContractLiquid: makeGetDetailDepositContractLiquid()(state),
        liquidCodeInfo: makeGetMmContactBaseCode()(state),
        capTermContract: makeGetCapTermContract()(state),
        mmGetExpireDate: makeGetMmGetExpireDate()(state),
        capFeeBase: makeGetCapFeeBase()(state),
        detailDepositContract: makeGetMainDetailDepositContract()(state),
        custDetail: makeGetCustomerDetail()(state),
        cashBalance: makeGetCashBalance()(state),
        accRight: makeGetAccountRight()(state),

        formCustomerCode,
        formOpenDate,
        formExpireDate,
        formContent,
        formCapital,
        formFee,
        formTerm,
        formFeeRate,
        formFeeBase,
        formOrtherFeeRate,
        formAppendixNumber,
        formLiquidTaxRate,
        formLiquidFee,
        formLiquidTax,
        formLiquidCapital,
    };
};

export default connect(mapStateToProps)(
    translate('translations')(CRUDDepositContractLiquid)
);