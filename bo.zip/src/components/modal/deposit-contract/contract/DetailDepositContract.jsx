import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import renderNewInput from '../../../input/renderNewInput';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm, FieldArray } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';
import { makeGetToken, makeGetMainDetailDepositContract, makeGetActionDepositContract, makeGetAccountRight } from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import { usePrevious } from 'lib/useHook';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { _diff2Date, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import {
    mainItemDepositContractSuccess,
    actionDepositContractSuccess,
    secondListDepositContractSuccess,
    mainItemDepositContractRequesting,
    actionDepositContractRequesting
} from 'containers/deposit-contract/actions';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import {
    makeGetCapTermContract,
    makeGetCapLenderType,
    makeGetMmGetExpireDate,
    makeGetCustomerDetail,
    makeGetMmGetFeeRate,
    makeGetCapFeeBase,
    makeGetCashBalance
} from 'lib/selector';
import { } from 'lib/selector';
import RenderInputMask from 'components/input/renderInputMask';
import { mmGetFeeRateRequest } from 'containers/product/actions';
import { StringToInt, numberFormatDecimal, StringToDouble } from 'utils';
import { cashBalanceRequest } from 'containers/cash/actions';
import { custDetailRequest } from 'containers/customer/actions';
import { setToast } from 'containers/client/actions';
import { mmGetExpireDateRequest } from 'containers/product/actions';
import Decimal from 'decimal.js'

const configNotification = {
    update: {
        messageRequest: 'txt_mm_update_deposit_contract_req',
        messageSuccess: 'txt_mm_update_deposit_contract_success',
        cmd: 'MM.UPDATE_DEPOSIT_CONTRACT'
    },
    delete: {
        messageRequest: 'txt_mm_delete_deposit_contract_req',
        messageSuccess: 'txt_mm_delete_deposit_contract_success',
        cmd: 'MM.DELETE_DEPOSIT_CONTRACT'
    },
    approve: {
        messageRequest: 'txt_mm_approve_deposit_contract_req',
        messageSuccess: 'txt_mm_approve_deposit_contract_success',
        cmd: 'MM.APPROVE_ITEM_DEPOSIT_CONTRACT'
    },
    un_approve: {
        messageRequest: 'txt_mm_un_approve_deposit_contract_req',
        messageSuccess: 'txt_mm_un_approve_deposit_contract_success',
        cmd: 'MM.UN_APPROVE_ITEM_DEPOSIT_CONTRACT'
    }
}

const customStyles = {
    content: {
        top: '40px',
        bottom: 'auto',
        left: 'calc( 50% - 500px )',
        height: 'auto',
        width: '1000px',
        padding: '0',
        borderWidth: '0',
        borderColor: '#f3f3f3',
        overflow: 'inherit',
    },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(6);

function DetailDepositContract(props) {
    const [isApproved, setIsApproved] = useState(true);
    const dispatch = useDispatch();
    const {
        token,
        formOpenDate,
        handleSubmit,
        submitting,
        onClose,
        t,
        detailDepositContract,
        accRight,
        capLenderType,
        capTermContract,
        mmGetExpireDate,
        formCapital,
        formTerm,
        mmGetFeeRate,
        capFeeBase,
        cashBalance,
        formFeeRate,
        formOrtherFeeRate,
        formFeeBase,
    } = props;

    const preActionDepositContract = usePrevious(props.actionDepositContract)
    const preFormOpenDate = usePrevious(formOpenDate);
    const preFormTerm = usePrevious(formTerm);

    function handleButtonAction(action, data) {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configNotification[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                if (action === 'update') {
                                    handleActionWithData(action, data)
                                } else if (['del', 'approve', 'un_approve'].includes(action)) {
                                    handleActionWithID(action);
                                }
                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    const _handleToast = (msg, type = 'info') => {
        const toastMsg = {
            id: Math.random(),
            msg: msg,
            title: 'Thông báo',
            type,
        };
        dispatch(setToast(toastMsg));
    };

    function submit(_values) {
        if (!props.custDetail) {
            _handleToast(`${t(configNotification.create.messageRequest)}`, 'error');
            return;
        }

        const data = {
            ITEM_ID: props.itemId,
            INV_APPENDIX_CODE: props?.formAppendixNumber,
            CUSTOMER_CODE: props?.formCustomerCode,
            OPEN_DATE: props?.formOpenDate,
            EXPIRE_DATE: mmGetExpireDate?.C_EXPIRE_DATE,
            CAPITAL: StringToInt(props?.formCapital),
            TERM: props?.formTerm,
            FEE_RATE: StringToInt(props?.formFeeRate),
            OTHER_FEE_RATE: StringToInt(props?.formOrtherFeeRate),
            FEE_BASE: props?.formFeeBase,
            FEE: StringToInt(mmGetFeeRate?.C_FEE),
            MARKETING_ID: props?.custDetail?.C_MARKETING_ID,
            CONTENT: props?.formContent,
        }

        handleActionWithData('update', data);
    }

    function handleActionWithID(action) {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: configNotification[action].cmd,
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId,
            },
        };

        props.onSetMessageContent(configNotification[action].messageSuccess)
        dispatch(actionDepositContractRequesting(params));
    }

    function handleActionWithData(action, data) {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification[action].cmd,
            group: 'LIST',
            data: data,
        };

        props.onSetMessageContent(configNotification[action].messageSuccess)
        dispatch(actionDepositContractRequesting(params));
    }

    function getDetailItem() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ITEM_DEPOSIT_CONTRACT',
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId
            },
        };

        dispatch(mainItemDepositContractRequesting(params));
    }

    function handleBlurCapital() {
        // get fee rate
        if (formCapital && formTerm && formOpenDate) getFeeRate();
    }

    function getFeeRate() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'MM.GET_FEE_RATE',
            group: 'LIST',
            data: {
                CHANNEL: 'D',
                RATE_TYPE: 'IN',
                GROUP: 'CA_NHAN',
                TERM: formTerm,
                OPEN_DATE: formOpenDate,
                EXPIRE_DATE: mmGetExpireDate?.C_EXPIRE_DATE,
                CAPITAL: StringToInt(formCapital),
            },
        };

        dispatch(mmGetFeeRateRequest(params));
    }

    function _handleCheckBalance() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'BACK.GET_CASH_BALANCE',
            group: 'LIST',
            data: {
                CUSTOMER_CODE: props.detailDepositContract?.C_CUSTOMER_CODE,
            },
        };
        dispatch(cashBalanceRequest(params));
    }

    function _handleCheckCustomer() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'BACK.GET_SINGLE_CUSTOMER',
            group: 'LIST',
            data: {
                CUSTOMER_ID: props.detailDepositContract?.C_CUSTOMER_CODE,
            },
        };

        dispatch(custDetailRequest(params));
    }

    function getExpireDate() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'MM.GET_DEPOSIT_CONTRACT_EXPIRE_DATE',
            group: 'LIST',
            data: {
                OPEN_DATE: props.formOpenDate,
                TERM: props.formTerm,
            },
        };

        dispatch(mmGetExpireDateRequest(params));
    }

    useEffect(() => {
        if (props.actionDepositContract && !_.isEqual(props.actionDepositContract, preActionDepositContract)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionDepositContract])

    useEffect(() => {
        dispatch(actionDepositContractSuccess(undefined))
        dispatch(mainItemDepositContractSuccess(undefined))
        dispatch(secondListDepositContractSuccess(undefined))

        getDetailItem()

        return () => {
            dispatch(actionDepositContractSuccess(undefined))
            dispatch(mainItemDepositContractSuccess(undefined))
            dispatch(secondListDepositContractSuccess(undefined))

            props.reset();
        };
    }, []);

    // bind dữ liệu
    useEffect(() => {
        if (props.detailDepositContract) {
            dispatch(change('detailDepositContractModal', 'formCustomerCode', props.detailDepositContract?.C_CUSTOMER_CODE));
            dispatch(change('detailDepositContractModal', 'formOpenDate', props.detailDepositContract?.C_OPEN_DATE));
            dispatch(change('detailDepositContractModal', 'formExpireDate', props.detailDepositContract?.C_EXPIRE_DATE));
            dispatch(change('detailDepositContractModal', 'formContent', props.detailDepositContract?.C_CONTENT));
            dispatch(change('detailDepositContractModal', 'formAppendixNumber', props.detailDepositContract?.C_INV_APPENDIX_CODE));
            dispatch(change('detailDepositContractModal', 'formTerm', props.detailDepositContract?.C_TERM));
            dispatch(change('detailDepositContractModal', 'formCapital', props.detailDepositContract?.C_CAPITAL));
            dispatch(change('detailDepositContractModal', 'formFeeRate', props.detailDepositContract?.C_FEE_RATE));
            dispatch(change('detailDepositContractModal', 'formOrtherFeeRate', props.detailDepositContract?.C_OTHER_FEE_RATE));
            dispatch(change('detailDepositContractModal', 'formFeeBase', props.detailDepositContract?.C_FEE_BASE));
            dispatch(change('detailDepositContractModal', 'formContent', props.detailDepositContract?.C_CONTENT));

            setIsApproved(props.detailDepositContract.C_STATUS === 'DA_DUYET')

            _handleCheckCustomer();
            _handleCheckBalance();
        }
    }, [props.detailDepositContract])

    useEffect(() => {
        if (
            (formTerm && !_.isEqual(formTerm, preFormTerm)) ||
            (formOpenDate && !_.isEqual(formOpenDate + '', preFormOpenDate + ''))
        ) {
            getExpireDate();
        }
    }, [formOpenDate, formTerm]);

    useEffect(() => {
        if (
            props?.formOpenDate
            && props?.formCapital
            && props?.formFeeRate
            && props?.formOrtherFeeRate
            && props?.formFeeBase
            && mmGetExpireDate?.C_DAY_DIFF
        ) {
            // Lãi suất *Số ngày vay* Số tiền vay/100/365
            var feeValue = Decimal.round(Decimal(StringToDouble(props.formCapital)).mul(mmGetExpireDate?.C_DAY_DIFF).mul(props.formFeeRate).div(100).div(props.formFeeBase)).toNumber()
            var otherFeeValue = Decimal.round(Decimal(feeValue).mul(props?.formOrtherFeeRate).div(100)).toNumber()
            var feeAfterCal = numberFormatDecimal(Decimal(feeValue).sub(otherFeeValue).toNumber())
            dispatch(change('detailDepositContractModal', 'formFee', feeAfterCal))
        }
    }, [formOpenDate, formCapital, formFeeRate, formOrtherFeeRate, formFeeBase]);

    return (
        <ReactModal
            isOpen={true}
            contentLabel="onRequestClose Example"
            onRequestClose={onClose}
            shouldCloseOnOverlayClick={true}
            overlayClassName="overlay"
            style={customStyles}
        >
            <div
                className="w-100 p-0 rounded"
                style={{ maxHeight: 'calc(100vh - 120px)' }}
            >
                <div className="py-2 d-flex justify-content-between">
                    <b className="fz-16 pl-3">
                        {t('txt_deposit_contract_modal_detail')}
                    </b>
                    <a onClick={onClose} className="pr-3">
                        <FaTimes />
                    </a>
                </div>
                <StyleContainer>
                    <form onSubmit={handleSubmit(submit)}>
                        <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
                            <FormAdd>
                                {/* Mã khách hàng */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>{t('txt-cust-code')}</Form.Label>
                                    <Field
                                        name="formCustomerCode"
                                        className="form-control input-order fz-13"
                                        classParent="w-100"
                                        component={renderNewInput}
                                        validate={[required, length7]}
                                        index="3"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Tên khách hàng */}
                                <Form.Group style={{ gridColumn: '2/4' }}>
                                    <Form.Label>{t('txt-cust-name')}</Form.Label>
                                    <Form.Control
                                        value={props.custDetail?.C_CUSTOMER_NAME || ''}
                                        disabled
                                    />
                                </Form.Group>
                                {/* MKT ID */}
                                <Form.Group>
                                    <Form.Label>{t('txt-marketing-id')}</Form.Label>
                                    <Form.Control
                                        type={'text'}
                                        className="input-order fz-13"
                                        value={props.custDetail?.C_MARKETING_ID || ''}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Mã hợp đồng */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-contract-code')}{' '}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formAppendixNumber"
                                        className="form-control"
                                        component={RenderInput}
                                        validate={[required]}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Kỳ hạn */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt-period')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formTerm"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        validate={[required]}
                                        opts={capTermContract}
                                        required
                                    />
                                </Form.Group>
                                {/* Ngày mở */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-open-date')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formOpenDate"
                                        className="form-control input-order "
                                        classParentName="w-100"
                                        component={RenderSelectDate}
                                        startDate={formatDate(new Date(), '/', 'dmy')}
                                        validate={required}
                                    />
                                </Form.Group>
                                {/* Ngày hết hạn */}
                                <Form.Group>
                                    <Form.Label>{t('txt-expire-date')}</Form.Label>
                                    <input
                                        value={mmGetExpireDate?.C_EXPIRE_DATE || ''}
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Số ngày */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>{t('txt-number-day')}</Form.Label>
                                    <input
                                        value={mmGetExpireDate?.C_DAY_DIFF || ''}
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Số dư tài khoản */}
                                <Form.Group>
                                    <Form.Label>{t('txt-acc-balance')}</Form.Label>
                                    <input
                                        value={
                                            props?.cashBalance?.C_CASH_BALANCE_BO === 0
                                                ? '0'
                                                : numberFormatDecimal(props?.cashBalance?.C_CASH_BALANCE_BO) || ''
                                        }
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Giá trị tiền gửi */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt_deposit_contract_value')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formCapital"
                                        className="form-control"
                                        component={RenderInputMask}
                                        validate={[required]}
                                    // onBlur={handleBlurCapital}
                                    />
                                </Form.Group>
                                {/* Lãi suất */}
                                <Form.Group>
                                    <Form.Label>{t('txt-interest-rate-1')}</Form.Label>
                                    <Field
                                        name='formFeeRate'
                                        component={RenderInputMask}
                                        className="form-control"
                                    />
                                </Form.Group>
                                {/* Phí khác */}
                                <Form.Group>
                                    <Form.Label>{t('txt-fee-other')}</Form.Label>
                                    <Field
                                        name="formOrtherFeeRate"
                                        className="form-control"
                                        component={RenderInputMask}
                                    />
                                </Form.Group>
                                {/* Cơ sở tính lãi */}
                                <Form.Group>
                                    <Form.Label>{t('txt-interest-calculation-basis')}</Form.Label>
                                    <Field
                                        name="formFeeBase"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        opts={capFeeBase}
                                    />
                                </Form.Group>
                                {/* Trả lãi */}
                                <Form.Group>
                                    <Form.Label>{t('txt-pay-interest')}</Form.Label>
                                    <Field
                                        name="formFee"
                                        component={RenderInputMask}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Nội dung */}
                                <Form.Group style={{ gridColumn: '1/5' }}>
                                    <Form.Label>{t('txt-content')}</Form.Label>
                                    <Field
                                        name="formContent"
                                        className="form-control input-order fz-13"
                                        component={RenderArea}
                                        rows={2}
                                    />
                                </Form.Group>
                                
                                <Form.Label>
                                    {t('txt-creator')} : {detailDepositContract?.C_CREATOR_CODE}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '3/5' }}>
                                    {t('txt-create-time')} : {props.detailDepositContract?.C_CREATE_TIME}
                                </Form.Label>
                                <Form.Label>
                                    {t('txt-approver')}: {detailDepositContract?.C_APPROVER_CODE}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '3/5' }}>
                                    {t('txt-approve-time')} : {props.detailDepositContract?.C_APPROVE_TIME}
                                </Form.Label>
                            </FormAdd>
                        </PerfectScrollbar>
                        <hr style={{ gridColumn: '1/5' }} />
                        <div
                            className="d-flex"
                            style={{
                                height: '30px',
                                whiteSpace: 'nowrap',
                                gridColumn: '1/5',
                            }}
                        >
                            <BtnClose type="button" onClick={onClose} className="mr-auto">
                                {t('txt-close')}
                            </BtnClose>
                            <div className="d-flex">
                                {detailDepositContract?.C_STATUS === 'CHUA_DUYET' && (
                                    <>
                                        {accRight?.C_APPROVE === 1 && (
                                            <BtnSubmit
                                                type="button"
                                                disabled={submitting}
                                                className="success mr-2"
                                                onClick={() => handleButtonAction('approve')}
                                            >
                                                {t('txt-appr')}
                                            </BtnSubmit>
                                        )}
                                        {accRight?.C_UPDATE === 1 && (
                                            <>
                                                <BtnSubmit
                                                    type="button"
                                                    disabled={submitting}
                                                    className="danger mr-2"
                                                    onClick={() => handleButtonAction('del')}
                                                >
                                                    {t('txt-del')}
                                                </BtnSubmit>
                                                <BtnSubmit type="submit" disabled={submitting}>
                                                    {t('txt-accept')}
                                                </BtnSubmit>
                                            </>
                                        )}
                                    </>
                                )}
                                {detailDepositContract?.C_STATUS === 'DA_DUYET' &&
                                    accRight?.C_APPROVE === 1 && (
                                        <BtnSubmit
                                            type="button"
                                            disabled={submitting}
                                            className="danger"
                                            onClick={() => handleButtonAction('un_approve')}
                                        >
                                            {t('txt-unAppr')}
                                        </BtnSubmit>
                                    )}
                            </div>
                        </div>
                    </form>
                </StyleContainer>
            </div>
        </ReactModal>
    );
}


DetailDepositContract = reduxForm({
    form: 'detailDepositContractModal',
    enableReinitialize: true,
})(DetailDepositContract);

const selector = formValueSelector('detailDepositContractModal');

const mapStateToProps = (state) => {
    const {
        formCustomerCode,
        formOpenDate,
        formExpireDate,
        formTerm,
        formContent,
        formCapital,
        formFeeRate,
        formFee,
        formFeeBase,
        formOrtherFeeRate,
        formAppendixNumber
    } = selector(
        state,
        'formCustomerCode',
        'formOpenDate',
        'formExpireDate',
        'formTerm',
        'formCapital',
        'formContent',
        'formAppendixNumber',
        'formFee',
        'formFeeBase',
        'formFeeRate',
        'formOrtherFeeRate',
    );

    return {
        token: makeGetToken()(state),
        actionDepositContract: makeGetActionDepositContract()(state),
        detailDepositContract: makeGetMainDetailDepositContract()(state),
        accRight: makeGetAccountRight()(state),
        capLenderType: makeGetCapLenderType()(state),
        capTermContract: makeGetCapTermContract()(state),
        mmGetExpireDate: makeGetMmGetExpireDate()(state),
        mmGetFeeRate: makeGetMmGetFeeRate()(state),
        capFeeBase: makeGetCapFeeBase()(state),
        cashBalance: makeGetCashBalance()(state),
        custDetail: makeGetCustomerDetail()(state),

        formCustomerCode,
        formOpenDate,
        formExpireDate,
        formContent,
        formCapital,
        formFee,
        formTerm,
        formFeeRate,
        formFeeBase,
        formOrtherFeeRate,
        formAppendixNumber
    };
};

export default connect(mapStateToProps)(
    translate('translations')(DetailDepositContract)
);