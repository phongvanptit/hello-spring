import RenderArea from '../../../input/renderArea';
import RenderInput from '../../../input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNewInput from 'components/input/renderNewInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import { setToast } from '../../../../containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm, FieldArray } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';
import {
    custDetailRequest,
    custDetailSuccess,
} from '../../../../containers/customer/actions';
import renderNewInput from '../../../input/renderNewInput';
import {
    makeGetMmContactBaseCode,
    makeGetCapTermContract,
    makeGetCapLenderType
} from 'lib/selector';

import {
    makeGetAccountRight,
    makeGetActionDepositContract,
    makeGetCapFeeBase,
    makeGetCashBalance,
    makeGetCustomerDetail,
    makeGetMainDetailDepositContract,
    makeGetMmGetExpireDate,
    makeGetMmGetFeeRate,
    makeGetSecondListDepositContract,
    makeGetToken
} from '../../../../lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import {
    actionDepositContractRequesting,
    actionDepositContractSuccess,
    mainItemDepositContractRequesting,
    mainItemDepositContractSuccess, secondListDepositContractRequesting, secondListDepositContractSuccess
} from '../../../../containers/deposit-contract/actions';
import NodataSearch from '../../../noDataSearch';
import { numberFormat, numberFormatDecimal, StringToDouble, StringToInt } from '../../../../utils';
import { mmGetExpireDateSuccess } from 'containers/product/actions';
import { mmGetExpireDateRequest } from 'containers/product/actions';
import RenderInputMask from 'components/input/renderInputMask';
import { mmGetFeeRateRequest } from 'containers/product/actions';
import { cashBalanceRequest } from 'containers/cash/actions';
import { cashBalanceSuccess } from 'containers/cash/actions';
import Decimal from 'decimal.js'
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
    content: {
        top: '40px',
        bottom: 'auto',
        left: 'calc( 50% - 500px )',
        height: 'auto',
        width: '1000px',
        padding: '0',
        borderWidth: '0',
        borderColor: '#f3f3f3',
        overflow: 'inherit',
    },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
    const ref = React.useRef();

    React.useEffect(() => {
        ref.current = value;
    }, [value]);

    return ref.current;
}

const configNotification = {
    create: {
        messageRequest: 'txt_deposit_contract_modal_create',
        messageSuccess: 'txt_deposit_contract_create_success',
        cmd: 'MM.UPDATE_DEPOSIT_CONTRACT'
    }
}

function AddDepositContract(props) {
    const [isApproved, setIsApproved] = useState(true);
    const { handleSubmit, submitting, onClose, t, formCustomerCode, mmContactBaseCode, token
        , capTermContract
        , capLenderType
        , mmGetExpireDate
        , formOpenDate
        , formTerm
        , formCapital
        , mmGetFeeRate
        , capFeeBase
        , cashBalance
        , formFeeRate
        , formOrtherFeeRate
        , formFeeBase
        , formFee
    } = props;

    const dispatch = useDispatch();
    const preActionDepositContract = usePrevious(props.actionDepositContract)
    const preCustomerCode = usePrevious(props.formCustomerCode);
    const preFormOpenDate = usePrevious(formOpenDate);
    const preFormTerm = usePrevious(formTerm);

    useEffect(() => {
        initForm();
        dispatch(custDetailSuccess(undefined))
        dispatch(cashBalanceSuccess(undefined))
        dispatch(actionDepositContractSuccess(undefined))
        dispatch(mainItemDepositContractSuccess(undefined))
        dispatch(secondListDepositContractSuccess(undefined))
        dispatch(mmGetExpireDateSuccess(null));

        return () => {
            dispatch(custDetailSuccess(undefined));
            dispatch(cashBalanceSuccess(undefined));
            dispatch(actionDepositContractSuccess(undefined))
            dispatch(mainItemDepositContractSuccess(undefined))
            dispatch(secondListDepositContractSuccess(undefined))
            dispatch(mmGetExpireDateSuccess(null));

            props.reset();
        };
    }, []);

    useEffect(() => {
        if (props.detailPolicy) {
            dispatch(change('UpdateLiquidPolicy', 'formLiquidPolicyCode', props.detailPolicy.C_LIQUID_CODE));
            dispatch(change('UpdateLiquidPolicy', 'formLiquidPolicyName', props.detailPolicy.C_LIQUID_NAME));
            dispatch(change('UpdateLiquidPolicy', 'formContent', props.detailPolicy.C_CONTENT));

            setIsApproved(props.detailPolicy.C_STATUS === 'DA_DUYET')

            console.log(props.detailPolicy.C_STATUS === 'DA_DUYET');
        }
    }, [props.detailPolicy])

    useEffect(() => {
        if (props.listRate) {
            dispatch(change('UpdateLiquidPolicy', 'formItems', props.listRate.map((item) => {
                return {
                    fromValue: numberFormatDecimal(item.C_FROM_VALUE),
                    toValue: numberFormatDecimal(item.C_TO_VALUE),
                    rateValue: numberFormatDecimal(item.C_LIQUID_RATE),
                }
            })));
        }
    }, [props.listRate])

    useEffect(() => {
        if (props.actionDepositContract && !_.isEqual(props.actionDepositContract, preActionDepositContract)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionDepositContract])

    useEffect(() => {
        if (
            props.formCustomerCode &&
            props.formCustomerCode.length === 6 &&
            !_.isEqual(props.formCustomerCode, preCustomerCode)
        ) {
            _handleCheckCustomer();
            _handleCheckBalance();
        } else dispatch(custDetailSuccess(null));
    }, [props.formCustomerCode]);

    function _handleCheckCustomer() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'BACK.GET_SINGLE_CUSTOMER',
            group: 'LIST',
            data: {
                CUSTOMER_ID: props.formCustomerCode,
            },
        };

        dispatch(custDetailRequest(params));
    }

    function _handleCheckBalance() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'BACK.GET_CASH_BALANCE',
            group: 'LIST',
            data: {
                CUSTOMER_CODE: props.formCustomerCode,
            },
        };
        dispatch(cashBalanceRequest(params));
    }

    useEffect(() => {
        if (
            (formTerm && !_.isEqual(formTerm, preFormTerm)) ||
            (formOpenDate && !_.isEqual(formOpenDate + '', preFormOpenDate + ''))
        ) {
            getExpireDate();
        }
    }, [formOpenDate, formTerm]);

    useEffect(() => {
        if (
            props?.formOpenDate
            && props?.formCapital
            && props?.formFeeRate
            && props?.formOrtherFeeRate
            && props?.formFeeBase
        ) {
            // Lãi suất *Số ngày vay* Số tiền vay/100/365
            var feeValue = Decimal.round(Decimal(StringToDouble(props.formCapital)).mul(mmGetExpireDate?.C_DAY_DIFF).mul(props.formFeeRate).div(100).div(props.formFeeBase)).toNumber()
            var otherFeeValue = Decimal.round(Decimal(feeValue).mul(props?.formOrtherFeeRate).div(100)).toNumber()
            var feeAfterCal = numberFormatDecimal(Decimal(feeValue).sub(otherFeeValue).toNumber())
            dispatch(change('AddDepositContract', 'formFee', feeAfterCal))
        }
    }, [formOpenDate, formCapital, formFeeRate, formOrtherFeeRate, formFeeBase, formTerm]);

    function submit(value) {
        if (!props.custDetail) {
            _handleToast(`${t(configNotification.create.messageRequest)}`, 'error');
            return;
        }

        const data = {
            ITEM_ID: '',
            INV_APPENDIX_CODE: props?.formAppendixNumber,
            CUSTOMER_CODE: props?.formCustomerCode,
            OPEN_DATE: props?.formOpenDate,
            EXPIRE_DATE: mmGetExpireDate?.C_EXPIRE_DATE,
            CAPITAL: StringToInt(props?.formCapital),
            TERM: props?.formTerm,
            FEE_RATE_NET: StringToInt(mmGetFeeRate?.C_FEE_RATE_NET),
            FEE_RATE: StringToInt(props?.formFeeRate),
            OTHER_FEE_RATE: StringToInt(props?.formOrtherFeeRate),
            FEE_BASE: props?.formFeeBase,
            FEE: StringToInt(mmGetFeeRate?.C_FEE),
            MARKETING_ID: props?.custDetail?.C_MARKETING_ID,
            CONTENT: props?.formContent
        }
        handleButtonAction('create', data);
    }

    function initForm() {
        dispatch(change('AddDepositContract', 'formTerm', 30));
        dispatch(change('AddDepositContract', 'formFeeBase', 365));
        dispatch(change('AddDepositContract', 'formOrtherFeeRate', '5'));
    }

    function handleButtonAction(action, data) {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configNotification[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                handleUpdateCall('create', data);
                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    const handleUpdateCall = (action, data) => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification[action].cmd,
            group: 'LIST',
            data: data,
        };

        props.onSetMessageContent(configNotification[action].messageSuccess)
        dispatch(actionDepositContractRequesting(params));
    }

    const _handleToast = (msg, type = 'info') => {
        const toastMsg = {
            id: Math.random(),
            msg: msg,
            title: 'Thông báo',
            type,
        };
        dispatch(setToast(toastMsg));
    };

    function getExpireDate() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'MM.GET_DEPOSIT_CONTRACT_EXPIRE_DATE',
            group: 'LIST',
            data: {
                OPEN_DATE: formOpenDate,
                TERM: formTerm,
            },
        };

        dispatch(mmGetExpireDateRequest(params));
    }

    function handleBlurCapital() {
        // get fee rate
        if (formCapital && formTerm && formOpenDate) getFeeRate();
    }

    function getFeeRate() {
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'MM.GET_FEE_RATE',
            group: 'LIST',
            data: {
                CHANNEL: 'D',
                RATE_TYPE: 'IN',
                GROUP: 'CA_NHAN',
                TERM: formTerm,
                OPEN_DATE: formOpenDate,
                EXPIRE_DATE: mmGetExpireDate?.C_EXPIRE_DATE,
                CAPITAL: StringToInt(formCapital),
            },
        };

        dispatch(mmGetFeeRateRequest(params));
    }

    // [BEGIN JSX block]
    return (
        <ReactModal
            isOpen={true}
            contentLabel="onRequestClose Example"
            onRequestClose={onClose}
            shouldCloseOnOverlayClick={true}
            overlayClassName="overlay"
            style={customStyles}
        >
            <div
                className="w-100 p-0 rounded"
                style={{ maxHeight: 'calc(100vh - 120px)' }}
            >
                <div className="py-2 d-flex justify-content-between">
                    <b className="fz-16 pl-3">{t('txt_deposit_contract_modal_create')}</b>
                    <a onClick={onClose} className="pr-3">
                        <FaTimes />
                    </a>
                </div>
                <StyleContainer>
                    <form onSubmit={handleSubmit(submit)}>
                        <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
                            <FormAdd>
                                {/* Mã khách hàng */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-cust-code')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formCustomerCode"
                                        className="form-control input-order fz-13"
                                        classParent="w-100"
                                        component={renderNewInput}
                                        validate={[required, length7]}
                                        index="3"
                                    />
                                </Form.Group>
                                {/* Tên khách hàng */}
                                <Form.Group style={{ gridColumn: '2/4' }}>
                                    <Form.Label>{t('txt-cust-name')}</Form.Label>
                                    <Form.Control
                                        value={props.custDetail?.C_CUSTOMER_NAME || ''}
                                        disabled
                                    />
                                </Form.Group>
                                {/* MKT ID */}
                                <Form.Group>
                                    <Form.Label>{t('txt-marketing-id')}</Form.Label>
                                    <Form.Control
                                        type={'text'}
                                        className="input-order fz-13"
                                        value={props.custDetail?.C_MARKETING_ID || ''}
                                        disabled
                                    />
                                </Form.Group>
                                {/* Mã hợp đồng */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-contract-code')}{' '}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formAppendixNumber"
                                        className="form-control"
                                        component={RenderInput}
                                        validate={[required]}
                                    />
                                </Form.Group>
                                {/* Kỳ hạn */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt-period')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formTerm"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        validate={[required]}
                                        opts={capTermContract}
                                        required
                                    />
                                </Form.Group>
                                {/* Ngày mở */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        {t('txt-open-date')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formOpenDate"
                                        className="form-control input-order fz-13"
                                        classParentName="w-100"
                                        component={RenderSelectDate}
                                        validate={[required]}
                                    />
                                </Form.Group>
                                {/* Ngày hết hạn */}
                                <Form.Group>
                                    <Form.Label>{t('txt-expire-date')}</Form.Label>
                                    <input
                                        value={mmGetExpireDate?.C_EXPIRE_DATE || ''}
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Số ngày */}
                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>{t('txt-number-day')}</Form.Label>
                                    <input
                                        value={mmGetExpireDate?.C_DAY_DIFF || ''}
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Số dư tài khoản */}
                                <Form.Group>
                                    <Form.Label>{t('txt-acc-balance')}</Form.Label>
                                    <input
                                        value={
                                            props?.cashBalance?.C_CASH_BALANCE_BO === 0
                                                ? '0'
                                                : numberFormatDecimal(props?.cashBalance?.C_CASH_BALANCE_BO) || ''
                                        }
                                        type={'text'}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Giá trị tiền gửi */}
                                <Form.Group>
                                    <Form.Label>
                                        {t('txt_deposit_contract_value')}
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formCapital"
                                        className="form-control"
                                        component={RenderInputMask}
                                        validate={[required]}
                                    // onBlur={handleBlurCapital}
                                    />
                                </Form.Group>
                                {/* Lãi suất */}
                                <Form.Group>
                                    <Form.Label>{t('txt-interest-rate-1')}</Form.Label>
                                    <Field
                                        name='formFeeRate'
                                        component={RenderInputMask}
                                        className="form-control"
                                    />
                                </Form.Group>
                                {/* Phí khác */}
                                <Form.Group>
                                    <Form.Label>{t('txt-fee-other')}</Form.Label>
                                    <Field
                                        name="formOrtherFeeRate"
                                        className="form-control"
                                        component={RenderInputMask}
                                    />
                                </Form.Group>
                                {/* Cơ sở tính lãi */}
                                <Form.Group>
                                    <Form.Label>{t('txt-interest-calculation-basis')}</Form.Label>
                                    <Field
                                        name="formFeeBase"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        opts={capFeeBase}
                                        required
                                    />
                                </Form.Group>
                                {/* Trả lãi */}
                                <Form.Group>
                                    <Form.Label>{t('txt-pay-interest')}</Form.Label>
                                    <Field
                                        name="formFee"
                                        component={RenderInputMask}
                                        className="form-control"
                                        disabled
                                    />
                                </Form.Group>
                                {/* Nội dung */}
                                <Form.Group style={{ gridColumn: '1/5' }}>
                                    <Form.Label>{t('txt-content')}</Form.Label>
                                    <Field
                                        name="formContent"
                                        className="form-control input-order fz-13"
                                        component={RenderArea}
                                        rows={2}
                                    />
                                </Form.Group>
                            </FormAdd>
                        </PerfectScrollbar>
                        <hr style={{ gridColumn: '1/5' }} />
                        <div
                            className="d-flex"
                            style={{
                                height: '30px',
                                whiteSpace: 'nowrap',
                                gridColumn: '1/5',
                            }}
                        >
                            <BtnClose type="button" onClick={onClose} className="mr-auto">
                                {t('txt-close')}
                            </BtnClose>
                            <div className="d-flex">
                                <BtnSubmit type="submit" disabled={submitting}>
                                    {t('txt-add')}
                                </BtnSubmit>
                            </div>
                        </div>
                    </form>
                </StyleContainer>
            </div>
        </ReactModal >
    );
    // [END JSX block]
}

AddDepositContract = reduxForm({
    form: 'AddDepositContract',
    enableReinitialize: true
})(AddDepositContract);

const selector = formValueSelector('AddDepositContract');

const mapStateToProps = (state) => {
    const {
        formCustomerCode,
        formTerm,
        formCapital,
        formOpenDate,
        formAppendixNumber,
        formContent,
        formFeeRate,
        formFeeBase,
        formFee,
        formOrtherFeeRate,
        formItems
    } = selector(
        state,
        'formCustomerCode',
        'formTerm',
        'formCapital',
        'formOpenDate',
        'formAppendixNumber',
        'formContent',
        'formFeeBase',
        'formFee',
        'formFeeRate',
        'formOrtherFeeRate',
        'formItems',
    );

    return {
        token: makeGetToken()(state),
        accRight: makeGetAccountRight()(state),
        capTermContract: makeGetCapTermContract()(state),
        actionDepositContract: makeGetActionDepositContract()(state),
        detailPolicy: makeGetMainDetailDepositContract()(state),
        listRate: makeGetSecondListDepositContract()(state),
        mmContactBaseCode: makeGetMmContactBaseCode()(state),
        custDetail: makeGetCustomerDetail()(state),
        capLenderType: makeGetCapLenderType()(state),
        mmGetExpireDate: makeGetMmGetExpireDate()(state),
        mmGetFeeRate: makeGetMmGetFeeRate()(state),
        capFeeBase: makeGetCapFeeBase()(state),
        cashBalance: makeGetCashBalance()(state),

        formCapital,
        formTerm,
        formAppendixNumber,
        formOpenDate,
        formContent,
        formItems,
        formCustomerCode,
        formFeeRate,
        formOrtherFeeRate,
        formFeeBase,
        formFee
    };
};

export default connect(mapStateToProps)(
    translate('translations')(AddDepositContract)
);
