import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Form } from 'react-bootstrap';
import { makeGetToken } from 'lib/selector';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '80px',
    bottom: 'auto',
    left: 'calc( 50% - 300px )',
    height: 'auto',
    width: '600px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

//#endregion

function MarketingIDModal(props) {
  const { onClose } = props;

  const dispatch = useDispatch();

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      // shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)', overflow: 'hidden' }}
      >
        <div
          className="fz-13 font-weight-bold py-2 text-center text-white"
          style={{ background: '#202d3f' }}
        >
          Chi tiết thông tin marketing
          <a onClick={onClose} className="float-right mr-3 text-white">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form className="form-add">
            <div
              className="info d-grid"
              style={{
                gridTemplateColumns: 'auto auto',
                gap: '10px',
              }}
            >
              <Form.Label className="fz-13">Marketing ID</Form.Label>
              <input name="marketingCode" className="form-control" disabled />
              <Form.Label className="fz-13">Tên marketing ID</Form.Label>
              <input name="marketingName" className="form-control" disabled />
              <Form.Label className="fz-13">Email</Form.Label>
              <input name="email" className="form-control" disabled />
              <Form.Label className="fz-13">Điện thoại</Form.Label>
              <input name="phone" className="form-control" disabled />
              <Form.Label className="fz-13">Chi nhánh</Form.Label>
              <input name="branchName" className="form-control" disabled />
              <Form.Label className="fz-13">Phòng giao dịch</Form.Label>
              <input name="subBranchName" className="form-control" disabled />
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  return {
    token: getToken(state),
  };
};

export default connect(mapStateToProps)(MarketingIDModal);
