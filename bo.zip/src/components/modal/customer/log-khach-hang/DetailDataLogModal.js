import React from 'react';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { translate } from 'react-i18next';

import { makeGetToken } from 'lib/selector';

import { BtnClose } from 'utils/styledComponent';
import { Form } from 'react-bootstrap';

import PerfectScrollbar from 'react-perfect-scrollbar';
import NodataSearch from 'components/noDataSearch';
import { sysSingleDataLogRequest } from 'containers/system/actions';
import { sysSingleDataLogSuccess } from 'containers/system/actions';
import { makeGetSingleDataLog } from 'lib/selector';
ReactModal.setAppElement('#root');

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const SubContainer = styled.div`
  background: #f5f5f5;
  border-radius: 12px;
  padding: 12px;
  position: relative;

  &.sub-content {
    margin-top: 50px;
  }

  .text-header {
    font-weight: 700;
    font-size: 16px;
    line-height: 24px;
    color: #3c3c3c;
  }

  input.hasChange {
    background: #fdeed9 !important;
    color: #fe5353;
  }
`;

const ImgTicket = styled.img`
  position: absolute;

  &.img-ToLeft {
    left: -40px;
    top: 50%;
    transform: translateY(-50%);
  }

  &.img-ToRight {
    right: -40px;
    top: 50%;
    transform: translateY(-50%);
  }
  &.img-ToTop {
    top: -40px;
    right: 50%;
    transform: translateX(50%);
  }
  &.img-ToBottom {
    bottom: -40px;
    right: 50%;
    transform: translateX(50%);
  }
  &.img-FromLeft {
    left: -40px;
    top: 50%;
    transform: translateY(-50%);
  }
  &.img-FromTop {
    top: -40px;
    right: 50%;
    transform: translateX(50%);
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailDataLogModal(props) {
  const [arrDest, setArrDest] = React.useState(null);
  const [arrSource, setArrSource] = React.useState(null);
  const [arrProperty, setArrProperty] = React.useState([]);
  const dispatch = useDispatch();

  const { token, id, accChangeSingle } = props;

  const preAccChangeSingle = usePrevious(accChangeSingle);

  React.useEffect(() => {
    getRecordDetail();

    return () => {
      dispatch(sysSingleDataLogSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (accChangeSingle && !_.isEqual(accChangeSingle, preAccChangeSingle)) {
      handleGetPropertyChange();
    }
  }, [accChangeSingle]);

  function getRecordDetail() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_DATA_LOG',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(sysSingleDataLogRequest(params));
  }

  function handleGetPropertyChange() {
    //
    const _arrProperty = [];
    const _dest = accChangeSingle?.C_NEW_DATA
      ? JSON.parse(accChangeSingle?.C_NEW_DATA)
      : [];
    const _source = accChangeSingle?.C_OLD_DATA
      ? JSON.parse(accChangeSingle?.C_OLD_DATA)
      : [];

    if (!Array.isArray(_dest) && !Array.isArray(_source))
      Object.keys(_dest).forEach((element) => {
        console.log(element)
        if (!_.isEqual(_dest[element.trim()], _source[element.trim()])) {
          _arrProperty.push(element.trim());
        }
      });
    setArrDest(_dest);
    setArrSource(_source);
    setArrProperty(_arrProperty);
  }

  const { onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={
        accChangeSingle &&
        accChangeSingle?.C_ACTION_TYPE !== 'DELETE' &&
        accChangeSingle?.C_ACTION_TYPE !== 'INSERT'
          ? {
              content: {
                inset: '40px',
                padding: '0',
                borderWidth: '0',
                borderColor: '#f3f3f3',
                overflow: 'inherit',
              },
            }
          : {
              content: {
                top: '40px',
                bottom: 'auto',
                left: 'calc( 50% - 400px )',
                height: 'auto',
                width: '800px',
                padding: '0',
                borderWidth: '0',
                borderColor: '#f3f3f3',
                overflow: 'inherit',
              },
            }
      }
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <div
            className={
              'd-grid ' +
              (accChangeSingle &&
                accChangeSingle?.C_ACTION_TYPE !== 'DELETE' &&
                accChangeSingle?.C_ACTION_TYPE !== 'INSERT' &&
                'grid-2')
            }
          >
            {accChangeSingle && accChangeSingle?.C_ACTION_TYPE !== 'INSERT' && (
              <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
                {arrSource && (
                  <SubContainer>
                    <div className="text-header">
                      {t('txt-detail-info-before')}
                    </div>
                    <FormAdd>
                      {Object.keys(arrSource).map((item, index) => (
                        <Form.Group key={index}>
                          <Form.Label>{item}</Form.Label>
                          <Form.Control
                            value={arrSource[item.trim()]}
                            disabled
                            // className={
                            //   arrProperty.indexOf(item) > -1 ? 'hasChange' : ''
                            // }
                            className={
                              'cursor-pointer' +
                              (arrProperty?.indexOf(item) > -1
                                ? ' hasChange'
                                : '')
                            }
                          />
                        </Form.Group>
                      ))}
                    </FormAdd>
                  </SubContainer>
                )}
                {!arrSource && <NodataSearch name={t('txt-cust')} />}
              </PerfectScrollbar>
            )}
            {accChangeSingle && accChangeSingle?.C_ACTION_TYPE !== 'DELETE' && (
              <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
                {arrDest && (
                  <SubContainer>
                    <div className="text-header">
                      {t('txt-detail-info-after')}
                    </div>
                    <FormAdd>
                      {Object.keys(arrDest).map((item, index) => (
                        <Form.Group key={index}>
                          <Form.Label>{item}</Form.Label>
                          <Form.Control
                            value={arrDest[item.trim()]}
                            disabled
                            // className={
                            //   arrProperty.indexOf(item) > -1 ? 'hasChange' : ''
                            // }
                            className={
                              'cursor-pointer' +
                              (arrProperty?.indexOf(item) > -1
                                ? ' hasChange'
                                : '')
                            }
                          />
                        </Form.Group>
                      ))}
                    </FormAdd>
                  </SubContainer>
                )}
                {!arrDest && <NodataSearch name={t('txt-cust')} />}
              </PerfectScrollbar>
            )}
          </div>
          <hr style={{ gridColumn: '1/5' }} />
          <div
            className="d-flex"
            style={{
              height: '30px',
              whiteSpace: 'nowrap',
              gridColumn: '1/5',
            }}
          >
            <BtnClose type="button" onClick={onClose} className="w_60 mx-auto">
              {t('txt-close')}
            </BtnClose>
          </div>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountChangeSingle = makeGetSingleDataLog();

  return {
    token: getToken(state),
    accChangeSingle: getAccountChangeSingle(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailDataLogModal)
);
