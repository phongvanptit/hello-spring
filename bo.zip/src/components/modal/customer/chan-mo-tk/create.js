import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { setToast } from 'containers/client/actions';
import { makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';
import { formatDate } from 'utils';
import {
  validateTTHH
} from 'utils/validation';

import RenderArea from 'components/input/renderArea';
import {
  custBlackUpdateRequest,
  custBlackUpdateSuccess,
} from 'containers/customer/actions';
import {
  makeGetGlobalCardIDType,
  makeGetNationalList,
} from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { makeGetCustBlackUpdate } from 'lib/selector';
import { StringToDouble } from 'utils';
import { change} from 'redux-form';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateChanMoTK(props) {
  const dispatch = useDispatch();
  const {
    handleSubmit,
    submitting,
    reset,
    t,
    pristine,
    onClose,
    id,
    token,
    custBlackUpd,
    glCardIDType,
    glNational,
  } = props;

  const preCustBlackUpd = usePrevious(custBlackUpd);
  React.useEffect(() => {
    initForm();
  }, []);

  function initForm() {
    dispatch(
      change(
        'CreateChanMoTKform',
        'formBirthDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(
      change(
        'CreateChanMoTKform',
        'formIssueDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(
      change(
        'CreateChanMoTKform',
        'formExpireDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(
      change(
        'CreateChanMoTKform',
        'formFromDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(
      change(
        'CreateChanMoTKform',
        'formToDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(change('CreateChanMoTKform', 'formCustGender', 'M'));
    dispatch(change('CreateChanMoTKform', 'formNationality', '234'));
    dispatch(change('CreateChanMoTKform', 'formCardIdType', '1'));
  }

  useEffect(() => {
    if (
      custBlackUpd &&
      !_.isEqual(custBlackUpd, preCustBlackUpd)
    ) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      //dispatch(custBlackUpdateSuccess(null));
      onClose();
    }
  }, [custBlackUpd]);

  function submit(values) {
    handleConfirm(values);
  }

  function handleConfirm(values) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove(values);
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUST_BLACK',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        CUSTOMER_NAME: values.formName,
        CARD_ID_TYPE: values.formCardIdType,
        CARD_ID: values.formCardId,
        ISSUE_DATE: values.formIssueDate,
        ISSUE_PLACE: values.formIssuePlace,
        BIRTH_DAY: values.formBirthDate,
        CUST_GENDER: values.formCustGender,
        CUST_EMAIL: values.formCustEmail,
        CUST_MOBILE: values.formCustMobile,
        CUST_TEL: values.formCustTel,
        CUST_ADDRESS: values.formCustAddress,
        RESEDENCE_ADDRESS: values.formCustResedenceAddress,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        FROM_DATE: values.formFromDate,
        TO_DATE: values.formToDate,
        CONTENT: values.formNote,
      },
    };

    dispatch(custBlackUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Khai báo khách hàng bị chặn</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    Tên khách hàng
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-gender')}</Form.Label>
                  <div>
                    <label>
                      <Field
                        name="formCustGender"
                        className="cursor-pointer"
                        component="input"
                        type="radio"
                        value="M"
                      />{' '}
                      {t('txt-male')}
                    </label>
                    <label className="ml-3">
                      <Field
                        name="formCustGender"
                        className="cursor-pointer"
                        component="input"
                        type="radio"
                        value="F"
                      />{' '}
                      {t('txt-female')}
                    </label>
                  </div>
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-date-of-birth')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBirthDate"
                    className="form-control input-order"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    validate={required}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-card-type')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCardIdType"
                    className="form-control input-order"
                    component={RenderNormalSelect}
                    required
                    opts={glCardIDType}
                    validate={required}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-card-id')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCardId"
                    className="form-control input-order"
                    component={RenderInput}
                    validate={[required]}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  {t('txt-issue-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formIssueDate"
                    className="form-control input-order"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    validate={required}
                  />
                </Form.Group>
                
                <Form.Group >
                  <Form.Label>
                  {t('txt-issue-place')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formIssuePlace"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-national')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formNationality"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glNational}
                    required
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  {t('txt-tax-code')}
                  </Form.Label>
                  <Field
                    name="formTaxCode"
                    className="form-control input-order"
                    component={RenderInput}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  Số di động
                  </Form.Label>
                  <Field
                    name="formCustMobile"
                    className="form-control input-order"
                    component={RenderInput}
                    //validate={[required]}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  Số cố định
                  </Form.Label>
                  <Field
                    name="formCustTel"
                    className="form-control input-order"
                    component={RenderInput}
                    //validate={[required]}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  Email
                  </Form.Label>
                  <Field
                    name="formCustEmail"
                    className="form-control input-order"
                    component={RenderInput}
                    //validate={[required]}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  Địa chỉ
                    <span className="text-danger"></span>
                  </Form.Label>
                  <Field
                    name="formCustAddress"
                    className="form-control input-order"
                    component={RenderInput}
                    //validate={[required]}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}> 
                  <Form.Label>
                  Địa chỉ thường trú
                    <span className="text-danger"></span>
                  </Form.Label>
                  <Field
                    name="formCustResedenceAddress"
                    className="form-control input-order"
                    component={RenderInput}
                    //validate={[required]}
                    //onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                  Từ ngày
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFromDate"
                    className="form-control input-order"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                  Đến ngày
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formToDate"
                    className="form-control input-order"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    validate={validateTTHH}
                  />
                </Form.Group>
                <hr style={{ gridColumn: '1/4' }} className="my-1" />

                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>

          
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit
                  type="submit"
                  disabled={pristine || submitting}
                  className="w_125 ml-2"
                >
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateChanMoTK = reduxForm({
  form: 'CreateChanMoTKform',
  enableReinitialize: true,
})(CreateChanMoTK);

const selector = formValueSelector('CreateChanMoTKform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCustBlackUpdate = makeGetCustBlackUpdate();
  const getGlobalCardIDType = makeGetGlobalCardIDType();
  const getNationalList = makeGetNationalList();
  const {
    formName,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formNationality,
    formTaxCode,
    formCustMobile,
    formCustTel,
    formCustEmail,
    formCustAddress,
    formCustResedenceAddress,
    formFromDate,
    formToDate,
    formNote,
  } = selector(
    state,
    'formName',
    'formCustGender',
    'formBirthDate',
    'formCardIdType',
    'formCardId',
    'formIssueDate',
    'formExpireDate',
    'formIssuePlace',
    'formNationality',
    'formTaxCode',
    'formCustMobile',
    'formCustTel',
    'formCustEmail',
    'formCustAddress',
    'formCustResedenceAddress',
    'formFromDate',
    'formToDate',
    'formNote',
  );
  return {
    token: getToken(state),
    glCardIDType: getGlobalCardIDType(state),
    glNational: getNationalList(state),

    custBlackUpd: getCustBlackUpdate(state),
    formName,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formNationality,
    formTaxCode,
    formCustMobile,
    formCustTel,
    formCustEmail,
    formCustAddress,
    formCustResedenceAddress,
    formFromDate,
    formToDate,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateChanMoTK)
);
