import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import renderNewInput from 'components/input/renderNewInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import renderSelectBank from 'components/input/renderSelectBank';
import RenderSelectSubBranch from 'components/input/renderSelectSubBranch';
import {
  accBenUpdRequest,
  accBenUpdSuccess,
  accBenSingleRequest,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';

import {
  allRightHolderRequest,
  allRightHolderSuccess,
} from 'containers/right/actions';

import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  makeGetAccBenType,
  makeGetAccBenUpdate,
  makeGetAllBank,
  makeGetAllSubBranch,
  makeGetCustomerDetail,
  makeGetNationalList,
  makeGetProvinceList,
  makeGetToken,
  makeGetHolderRight,
} from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { BsTrash } from 'react-icons/bs';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import {
  Field,
  FieldArray,
  change,
  formValueSelector,
  getFormSyncErrors,
  reduxForm,
} from 'redux-form';
import styled from 'styled-components';
import { formatDate, removeAccent, stringToDate } from 'utils';
import { BtnClose, BtnSubmit, TabsSectionHeader } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import AddKhachHangModal from '../thong-tin-kh/AddKhachHangModal';
import ToggleButton from 'react-toggle-button';
const length7 = lengthRequired(6);
ReactModal.setAppElement('#root');

//#region styled
const customStyles = {
  content: {
    inset: '40px 120px auto 120px',
    // minWidth: "850px",
    // maxWidth: "calc(100vw - 160px)",
    // left: 'calc( 50% - 375px )',
    height: 'auto',
    // width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const FormBanksAccount = styled.div`
  grid-column: 1/5;
  display: flex;
  flex-direction: column;

  .table td,
  .table th {
    padding: 6px 7px;

    img {
      max-height: 75px;
      max-width: 150px;
    }
  }
`;

//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function convert_vi_to_en(str) {
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
  str = str.replace(/đ/g, 'd');
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
  str = str.replace(/Đ/g, 'D');
  str = str.replace(
    /!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g,
    ' '
  );
  str = str.replace(/  +/g, ' ');
  return str;
}

function BanksAccount({
  fields,
  glAllBank,
  glProvince,
  glAllSubBranch,
  glAccBenType,
  accDetail,
  handleToast,
  t,
  banks,
}) {
  const [checkVaildate, setCheckValidata] = React.useState(false);
  const [checkInfor, setCheckInfor] = React.useState(null);

  // React.useEffect(() => {
  //   validateAddBen(fields.getAll());
  // }, [fields]);

  // const validateAddBen = (values) => {
  //   const errors = [];
  //   // Lặp qua mỗi bank trong danh sách banks
  //   Array.isArray(values) &&
  //     values.forEach((bank, index) => {
  //       const bankBranchHand = bank.bankBranchHand;
  //       const bankBranch = bank.bankBranch;
  //       // Kiểm tra nếu cả hai trường đều trống
  //       if (!bankBranchHand && !bankBranch) {
  //         setCheckValidata(true);
  //       } else setCheckValidata(false);
  //     });
  // };

  React.useEffect(() => {
    validateAddBen(fields.getAll());
  }, [fields]);

  const validateAddBen = (values) => {
    const errors = [];
    // Lặp qua mỗi bank trong danh sách banks
    Array.isArray(values) &&
      values.forEach((bank, index) => {
        const accountType = bank.accountType;
        //console.log('account-type',bank.accountType);
        // Kiểm tra nếu cả hai trường đều trống
        if (accountType !== 'OTHER') {
          setCheckInfor(true);
        } else setCheckInfor(false);
      });
  };

  return (
    <FormBanksAccount>
      {(!banks || !banks.length) && (
        <small className="text-danger">
          Phải có ít nhất 1 tài khoản thụ hưởng!
        </small>
      )}
      <Table bordered>
        <thead>
          <tr>
            <th>{t('txt-acc-number')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('txt-bank')}</th>
            <th>{t('txt-province-city')}</th>
            <th>{t('txt-branch-ol')}</th>
            <th>{t('txt-branch-hand')}</th>
            <th>{t('txt-acc-type')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {fields.map((bank, index) => (
            <tr key={index}>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankAccount`}
                  className="form-control w_120"
                  component={RenderInput}
                  validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankAccountName`}
                  className="form-control"
                  component={RenderInput}
                  validate={required}
                  disabled={checkInfor}
                  //validate={!checkInfor ? required : null}
                  //disabled
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankName`}
                  className="form-control"
                  component={renderSelectBank}
                  opts={glAllBank}
                  validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankProvince`}
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={glProvince}
                  validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankBranch`}
                  className="form-control"
                  classParent="w-100"
                  component={RenderSelectSubBranch}
                  //   gwCode={formGateway}
                  bankCode={fields.get(index)?.bankName}
                  provinceCode={fields.get(index)?.bankProvince}
                  opts={glAllSubBranch}
                  //validate={required}
                  //validate={checkVaildate ? required : undefined}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankBranchHand`}
                  className="form-control w_120"
                  component={RenderInput}
                  //validate={checkVaildate ? required : undefined}
                  //   validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.accountType`}
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={glAccBenType}
                  required
                  validate={required}
                />
              </td>

              <td className="text-center align-baseline">
                <a title={t('txt-del')} onClick={() => fields.remove(index)}>
                  <BsTrash />
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div
        className="d-flex"
        style={{
          height: '30px',
          whiteSpace: 'nowrap',
          gridColumn: '1/4',
        }}
      >
        <BtnSubmit
          className="w_125 info"
          onClick={() => {
            if (fields.length > 4) {
              handleToast(`${t('txt-add-5-acc-beneficiary')}`, 'warning');
              return;
            }
            if (!accDetail) {
              handleToast(`${t('txt-no-data-cust')}`, 'warning');
              return;
            }

            fields.push({
              bankAccountName: convert_vi_to_en(
                accDetail?.C_CUSTOMER_NAME
              ).toUpperCase(),
              accountType: 'BANK',
            });
          }}
        >
          {t('txt-add-acc')}
        </BtnSubmit>
        <BtnSubmit
          className="w_125 ml-2 danger"
          type="button"
          onClick={() => fields.removeAll()}
        >
          {t('bnt-del-entry')}
        </BtnSubmit>
      </div>
    </FormBanksAccount>
  );
}

function AccountBeneficaryModal(props) {
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = React.useState(false);
  const [showAddKH, setShowAddKH] = React.useState(false);

  const {
    token,
    custUpd,
    formCustCode,
    custDetail,
    t,
    accBenSingle,
    banks,
    allRightHolder,
  } = props;

  const preCustUpdate = usePrevious(custUpd);
  const preFormCustCode = usePrevious(formCustCode);
  const preAccBenSingle = usePrevious(accBenSingle);

  React.useEffect(() => {
    return () => {
      dispatch(custDetailSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (custUpd && !_.isEqual(custUpd, preCustUpdate)) {
      _handleToast(`${t('txt-add-acc-success')}`, 'success');
      // clear update
      dispatch(accBenUpdSuccess(null));
      onClose(formCustCode);
    }
  }, [custUpd]);

  React.useEffect(() => {
    if (accBenSingle && !_.isEqual(accBenSingle, preAccBenSingle)) {
      // accountBeneficaryModalform
      if (!!accBenSingle.length) {
        dispatch(
          change(
            'accountBeneficaryModalform',
            'formCustCode',
            accBenSingle[0].C_CUSTOMER_CODE
          )
        );
      }
    }
  }, [accBenSingle]);

  React.useEffect(() => {
    if (
      formCustCode &&
      formCustCode.trim().length === 6 &&
      !_.isEqual(formCustCode, preFormCustCode)
    ) {
      // check khách hàng
      _handleCheckCustomer();
      //get lits
      _handleGetDetailBen();
    } else {
      dispatch(custDetailSuccess(null));
      dispatch(allRightHolderSuccess(null));
    }
  }, [formCustCode]);

  function submit(values) {
    if (isLoading) return;
    if (!values.banks || !values.banks.length) {
      _handleToast('Phải có ít nhất 1 tài khoản thụ hưởng!', 'error');
      return;
    }

    setIsLoading(true);

    let _bankAccount = [];
    values.banks.forEach((element) => {
      _bankAccount.push({
        BANK_CODE: element.bankName, // mã tk ngân hàng
        BANK_ACCOUNT_CODE: element.bankAccount, // số tk ngân hàng
        BANK_ACCOUNT_NAME: removeAccent(element.bankAccountName), // tên tài khoản ngân hàng
        BANK_BRANCH_CODE: element.bankBranch, // chi nhánh online
        BANK_BRANCH_NAME: element.bankBranchHand, //  chi nhánh nhập tay
        ACCOUNT_TYPE: element.accountType,
        // CHANNEL_CODE: element.channel,
        PROVINCE_CODE: element.bankProvince,
      });
    });

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACC_BEN',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: formCustCode,
        OPEN_DATE: values.formOpenDate,
        CONTENT: values.formContent,
        LIST_BANK_ACCOUNT: _bankAccount,
      },
    };

    dispatch(accBenUpdRequest(params));
  }

  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formCustCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleGetDetailBen() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACC_BEN',
      group: 'LIST',
      data: {
        ITEM_ID: formCustCode,
      },
    };

    dispatch(allRightHolderRequest(params));
  }

  function _handleAddCallback() {
    setShowAddKH(true);
  }

  function _handleCloseModalAdd(custCode = null) {
    if (custCode && typeof custCode === 'string') {
      dispatch(change('accountBeneficaryModalform', 'formCustCode', custCode));
    }

    setShowAddKH(false);
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const {
    handleSubmit,
    submitting,
    onClose,

    glAllBank,
    glProvince,
    glAllSubBranch,
    glAccBenType,
    errors,
  } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <div className="d-flex">
            <b className="fz-16 pl-3 mr-5">{t('txt-add-ben-acc')}</b>
          </div>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustCode"
                    className="form-control input-order"
                    classParent="w-100"
                    component={renderNewInput}
                    validate={[required, length7]}
                    actionAdd
                    fnAddCallback={_handleAddCallback}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-open-date')}</Form.Label>
                  <Field
                    name="formOpenDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    validate={required}
                    disabled
                  />
                </Form.Group> */}
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_CARD_ID || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_ISSUE_DATE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={custDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={custDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>

                <TabsSectionHeader>
                  <ul>
                    <li className={'active '}>
                      Danh sách tài khoản thụ hưởng của khách hàng
                    </li>
                  </ul>
                </TabsSectionHeader>

                <Table bordered style={{ gridColumn: '1/5' }}>
                  <thead>
                    <tr>
                      <th>{t('txt-acc-number')}</th>
                      <th>{t('txt-acc-name')}</th>
                      <th>{t('txt-bank')}</th>
                      <th>{t('txt-province-city')}</th>
                      <th>{t('txt-branch')}</th>
                      <th>{t('txt-acc-type')}</th>
                      <th>Chi nhánh nhập tay</th>
                      <th>{t('txt-open-date')}</th>
                      <th>Hoạt động</th>
                      <th>{t('txt-status')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allRightHolder &&
                      allRightHolder.map((item, index) => (
                        <tr key={index}>
                          <td className="text-center">
                            {item.C_BANK_ACCOUNT_CODE}
                          </td>
                          <td className="text-center">
                            {item.C_BANK_ACCOUNT_NAME}
                          </td>
                          <td className="text-center">{item.C_BANK_NAME}</td>
                          <td className="text-center">
                            {item.C_PROVINCE_NAME}
                          </td>
                          <td className="text-center">
                            {item.C_BANK_BRANCH_NAME}
                          </td>
                          <td className="text-center">
                            {item.C_ACCOUNT_TYPE_NAME}
                          </td>
                          <td className="text-center">
                            {item.C_BANK_BRANCH_HAND}
                          </td>
                          <td className="text-center">{item.C_OPEN_DATE}</td>
                          <td className="text-center">
                            {item.C_ACTIVE === 1
                              ? 'Hoạt động'
                              : 'Không hoạt động'}
                          </td>
                          <td className="text-center">
                            {item.C_STATUS === 'DA_DUYET'
                              ? 'Đã duyệt'
                              : 'Chưa duyệt'}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </Table>
                {(!allRightHolder || !allRightHolder.length) && (
                  <p className="fz-13 text-center">{t('txt-no-info')}</p>
                )}

                {/* TODO: Tabs Section  */}
                <TabsSectionHeader>
                  <ul>
                    <li
                      className={
                        'active ' +
                        (errors?.banks &&
                        _.some(
                          errors?.banks,
                          (o) => o && Object.keys(o)?.length > 0
                        )
                          ? 'error'
                          : '')
                      }
                    >
                      {t('txt-ben-acc')}
                    </li>
                  </ul>
                </TabsSectionHeader>

                <FieldArray
                  name="banks"
                  glAllBank={glAllBank}
                  glProvince={glProvince}
                  glAllSubBranch={glAllSubBranch}
                  glAccBenType={glAccBenType}
                  component={BanksAccount}
                  accDetail={custDetail}
                  handleToast={_handleToast}
                  t={t}
                  banks={banks}
                />
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting || isLoading}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {showAddKH && <AddKhachHangModal onClose={_handleCloseModalAdd} />}
    </ReactModal>
  );
}

AccountBeneficaryModal = reduxForm({
  form: 'accountBeneficaryModalform',
  enableReinitialize: true,
})(AccountBeneficaryModal);

const selector = formValueSelector('accountBeneficaryModalform');

const mapStateToProps = (state, _props) => {
  const getToken = makeGetToken();
  const getCustomerUpdate = makeGetAccBenUpdate();
  const getProvinceList = makeGetProvinceList();
  const getNationalList = makeGetNationalList();
  const getAllBank = makeGetAllBank();
  const getAllSubBranch = makeGetAllSubBranch();
  const getAccBenType = makeGetAccBenType();
  const getAllRightHolder = makeGetHolderRight();

  const getCustomerDetail = makeGetCustomerDetail();

  const {
    formCustCode,
    formOpenDate,
    formContent,

    banks,
  } = selector(
    state,
    'formCustCode',
    'formOpenDate',
    'formContent',

    'banks'
  );
  const sysSystemInfo = state.system.sysSystemInfo;
  return {
    token: getToken(state),
    glProvince: getProvinceList(state),
    glNational: getNationalList(state),
    custUpd: getCustomerUpdate(state),
    glAllBank: getAllBank(state),
    glAllSubBranch: getAllSubBranch(state),
    glAccBenType: getAccBenType(state),
    custDetail: getCustomerDetail(state),
    allRightHolder: getAllRightHolder(state),

    formCustCode,
    formOpenDate,
    formContent,

    banks,

    errors: getFormSyncErrors('accountBeneficaryModalform')(state),

    initialValues: {
      formCustCode: '',
      formContent: '',
      formOpenDate:
        formatDate(stringToDate(sysSystemInfo?.C_T_DATE, 'dmy'), '/', 'dmy') ||
        '',
      formOpenDate: formatDate(new Date(), '/', 'dmy'),

      banks: [],
    },
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AccountBeneficaryModal)
);
