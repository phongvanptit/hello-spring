import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { change, Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { translate } from 'react-i18next';

import { setToast } from 'containers/client/actions';
import { accountSingleSuccess } from 'containers/account/actions';

import { makeGetToken } from 'lib/selector';
import { makeGetAccountSingle } from 'lib/selector';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { makeGetAuthenType } from 'lib/selector';
import { makeGetInternetFunc } from 'lib/selector';
import { makeGetAccountInternetUpd } from 'lib/selector';
import { accountInternetDelSuccess } from 'containers/account/actions';
import { accountInternetUpdSuccess } from 'containers/account/actions';
import { accountSingleRequest } from 'containers/account/actions';
import { accountInternetUpdRequest } from 'containers/account/actions';
import { Form } from 'react-bootstrap';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import { required } from 'utils/validation';
import { lengthRequired } from 'utils/validation';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { arrAuthenType } from 'utils/const';
import RenderInput from 'components/input/renderInput';
import { validatePhone } from 'utils/validation';
import RenderArea from 'components/input/renderArea';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.form`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;

  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddTKThuHuongModal(props) {
  const dispatch = useDispatch();
  const [orderCheck, setOrderCheck] = React.useState([]);

  const {
    token,
    formAccountCode,
    glAuthenType,
    glInternetFunc,
    accDetail,
    accInternetUpd,
  } = props;

  const preAccDetail = usePrevious(accDetail);
  const preAccInternetUpd = usePrevious(accInternetUpd);

  React.useEffect(() => {
    return () => {
      dispatch(accountInternetDelSuccess(null));
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (accDetail && !_.isEqual(accDetail, preAccDetail)) {
      dispatch(
        change(
          'addAccInternetModalform',
          'formPhoneOTP',
          accDetail?.C_CUST_MOBILE
        )
      );
    }
  }, [accDetail]);

  React.useEffect(() => {
    if (accInternetUpd && !_.isEqual(accInternetUpd, preAccInternetUpd)) {
      _handleToast(`${t('txt-add-acc-beneficiary-success')}`, 'success');
      dispatch(accountInternetUpdSuccess(null));
      onClose();
    }
  }, [accInternetUpd]);

  function _handleChangeChkAll(e) {
    const { checked } = e.target;
    console.log(e);
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(glInternetFunc, 'C_CODE');
      setOrderCheck(allFunc);
    }
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
    }

    setOrderCheck(xxx);
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!accDetail) {
      _handleToast('Không có thông tin tài khoản', 'error');
      return;
    }
    // console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_INTERNET',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: values?.formAccountCode,
        AUTHEN_TYPE: values?.formEntrustAuthenType,
        PHONE_NUMBER: values?.formPhoneOTP,
        CONTENT: values?.formNote,
        FUNC: orderCheck,
      },
    };

    dispatch(accountInternetUpdRequest(params));
  }

  function _handleAddCallback() {}

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới dịch vụ</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <FormAdd onSubmit={handleSubmit(submit)}>
            <Form.Group>
              <Form.Label>{t('txt-acc')}</Form.Label>{' '}
              <span className="text-danger">*</span>
              <Field
                name="formAccountCode"
                className="form-control input-order"
                component={renderNewInputAccount}
                validate={[required, length7]}
                fnAddCallback={_handleAddCallback}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-acc-name')}</Form.Label>
              <Form.Control
                type={'text'}
                className="form-control input-order"
                value={accDetail?.C_ACCOUNT_NAME || ''}
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('Card type')}</Form.Label>
              <Form.Control
                type={'text'}
                className="input-order"
                value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('Card number')}</Form.Label>
              <Form.Control
                type={'text'}
                className="input-order"
                value={accDetail?.C_MARKETING_ID || ''}
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-email')}</Form.Label>
              <Form.Control
                type={'text'}
                className="input-order"
                value={accDetail?.C_CUST_EMAIL || ''}
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-mobile')}</Form.Label>
              <Form.Control
                type={'text'}
                className="input-order"
                value={accDetail?.C_CUST_MOBILE || ''}
                disabled
              />
            </Form.Group>

            <Form.Group style={{ gridColumn: '3/5' }}>
              <Form.Label>
                {t('Electronic service')}
                <span className="text-danger">*</span>
              </Form.Label>
              <div className="d-flex">
                <label>
                  <Field
                    name="formUseWebTrading"
                    component="input"
                    type="checkbox"
                    checked
                    disabled
                  />{' '}
                  Webtrading
                </label>
                <label className="ml-3">
                  <Field
                    name="formUseOTPForLogin"
                    component="input"
                    type="checkbox"
                  />{' '}
                  {t('OTP authentication when logging in')}
                </label>
              </div>
            </Form.Group>

            <Form.Group>
              <Form.Label>
                {t('Authentication type')}{' '}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formEntrustAuthenType"
                className="form-control input-order "
                component={RenderNormalSelect}
                opts={
                  glAuthenType && !!glAuthenType.length
                    ? glAuthenType
                    : arrAuthenType
                }
                validate={[required]}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('Phone number to receive OTP')}</Form.Label>
              <Field
                name="formPhoneOTP"
                className="form-control input-order "
                component={RenderInput}
                validate={[validatePhone]}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('Email OTP authentication')}</Form.Label>
              <div className="d-flex">
                <label>
                  <Field
                    name="formOTPEmail"
                    component="input"
                    type="checkbox"
                  />{' '}
                  {t('Email OTP authentication')}
                </label>
              </div>
            </Form.Group>
            <p style={{ gridColumn: '1/5' }} className="color-thm mb-0 fz-13">
              {t('Functional rights')}
            </p>

            <Form.Group
              className="d-grid grid-3"
              style={{ gridColumn: '1/5', gap: '5px 10px' }}
            >
              <label>
                <Field
                  name="custChkAll"
                  component="input"
                  type="checkbox"
                  onChange={_handleChangeChkAll}
                />{' '}
                Tất cả
              </label>
              {glInternetFunc &&
                glInternetFunc.map((item, index) => (
                  <label key={index}>
                    <Field
                      name={item.C_CODE}
                      component="input"
                      type="checkbox"
                      checked={_.some(orderCheck, (o) => o === item.C_CODE)}
                      onChange={_handleChange}
                    />{' '}
                    {item.C_NAME}
                  </label>
                ))}
            </Form.Group>
            <Form.Group style={{ gridColumn: '1/5' }}>
              <Form.Label>{'Ghi chú'}</Form.Label>
              <Field
                name="formNote"
                className="form-control input-order"
                component={RenderArea}
                rows={2}
              />
            </Form.Group>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                Đóng
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                Xác nhận
              </BtnSubmit>
            </div>
          </FormAdd>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddTKThuHuongModal = reduxForm({
  form: 'addTkThuHuongModalform',
  enableReinitialize: true,
})(AddTKThuHuongModal);

const selector = formValueSelector('addTkThuHuongModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAuthenType = makeGetAuthenType();
  const getInternetFunc = makeGetInternetFunc();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountInternetUpd = makeGetAccountInternetUpd();

  const {
    formAccountCode,
    formPhoneOTP,
    formEntrustAuthenType,
    formUseWebTrading,
    formUseOTPForLogin,
    formOTPEmail,
    formNote,
  } = selector(
    state,
    'formAccountCode',
    'formPhoneOTP',
    'formEntrustAuthenType',
    'formUseWebTrading',
    'formUseOTPForLogin',
    'formOTPEmail',
    'formNote'
  );

  return {
    token: getToken(state),
    glAuthenType: getAuthenType(state),
    glInternetFunc: getInternetFunc(state),
    accDetail: getAccountSingle(state),
    accInternetUpd: getAccountInternetUpd(state),

    formAccountCode,
    formPhoneOTP,
    formEntrustAuthenType,
    formUseWebTrading,
    formUseOTPForLogin,
    formOTPEmail,
    formNote,

    initialValues: {
      formEntrustAuthenType: 'O',
      formPhoneOTP: '',
      formUseWebTrading: true,
      formUseOTPForLogin: false,
      formOTPEmail: false,
      formNote: '',
    },
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddTKThuHuongModal)
);
