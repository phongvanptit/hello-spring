import {
  accBenApprRequest,
  accBenChangeActiveRequest,
  accBenChangeActiveSuccess,
  accBenDelRequest,
  accBenSingleRequest,
} from 'containers/account/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  makeGetAccBenApprove,
  makeGetAccBenChangeActive,
  makeGetAccBenDel,
  makeGetAccBenSingle,
  makeGetCustomerDetail,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { BsFillBookmarkCheckFill, BsTrash } from 'react-icons/bs';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import ToggleButton from 'react-toggle-button';
import styled from 'styled-components';
import { GroupButton, TabsSectionHeader } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled
const customStyles = {
  content: {
    inset: '40px 120px auto 120px',
    height: 'auto',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailBeneficaryModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    accBenDel,
    custDetail,
    t,
    id,
    accBenSingle,
    accBenAppr,
    accRight,
    accBenChangeActive,
  } = props;

  const preAccBenDel = usePrevious(accBenDel);
  const preAccBenAppr = usePrevious(accBenAppr);
  const preAccBenChangeActive = usePrevious(accBenChangeActive);
  const preId = usePrevious(id);

  React.useEffect(() => {
    return () => {
      dispatch(custDetailSuccess(null));
      dispatch(accBenChangeActiveSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (id && !_.isEqual(id, preId)) {
      // get cust info
      _handleCheckCustomer();
      //get lits
      _handleGetDetailBen();
    }
  }, [id]);

  React.useEffect(() => {
    if (
      accBenChangeActive &&
      !_.isEqual(accBenChangeActive, preAccBenChangeActive)
    ) {
      //get lits
      _handleGetDetailBen();
      dispatch(accBenChangeActiveSuccess(null));
    }
  }, [accBenChangeActive]);

  React.useEffect(() => {
    if (
      (accBenDel && !_.isEqual(accBenDel, preAccBenDel)) ||
      (accBenAppr && !_.isEqual(accBenAppr, preAccBenAppr))
    ) {
      _handleGetDetailBen();
    }
  }, [accBenDel, accBenAppr]);

  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: id,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleGetDetailBen() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACC_BEN',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accBenSingleRequest(params));
  }

  function handleApproveAccountBeneficary(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-appr-acc-beneficiary')}</p>
            <button onClick={onClose}> {t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApproveAll(pk);
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDelAccountBeneficary(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1> {t('txt-confirm')}</h1>
            <p> {t('txt-del-acc-beneficiary')}</p>
            <button onClick={onClose}> {t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACC_BEN',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(accBenDelRequest(params));
  }

  function handleActionApproveAll(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACC_BEN',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(accBenApprRequest(params));
  }

  function _handleToggle(id, value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACTIVE_ACC_BEN',
      group: 'LIST',
      data: {
        ITEM_ID: id,
        ACTIVE: value ? 0 : 1,
      },
    };
    dispatch(accBenChangeActiveRequest(params));
  }

  const { onClose } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <div className="d-flex">
            <b className="fz-16 pl-3 mr-5">{t('txt-detail-ben-acc')}</b>
          </div>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUSTOMER_CODE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label> {t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <span />
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_CARD_ID || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_ISSUE_DATE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={custDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={custDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <TabsSectionHeader>
                  <ul>
                    <li className={'active '}>{t('txt-ben-acc')}</li>
                  </ul>
                </TabsSectionHeader>

                <Table bordered style={{ gridColumn: '1/5' }}>
                  <thead>
                    <tr>
                      <th>{t('txt-acc-number')}</th>
                      <th>{t('txt-acc-name')}</th>
                      <th>{t('txt-bank')}</th>
                      <th>{t('txt-province-city')}</th>
                      <th>{t('txt-branch')}</th>
                      <th>{t('txt-acc-type')}</th>
                      <th>Chi nhánh nhập tay</th>
                      <th>{t('txt-open-date')}</th>
                      <th>{t('txt-status')}</th>
                      <th>{t('txt-active')}</th>
                      <th>{t('txt-action')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {accBenSingle &&
                      accBenSingle.map((item, index) => (
                        <tr key={index}>
                          <td className="text-center">
                            {item.C_BANK_ACCOUNT_CODE}
                          </td>
                          <td className="text-center">
                            {item.C_BANK_ACCOUNT_NAME}
                          </td>
                          <td className="text-center">{item.C_BANK_NAME}</td>
                          <td className="text-center">
                            {item.C_PROVINCE_NAME}
                          </td>
                          <td className="text-center">
                            {item.C_BANK_BRANCH_NAME}
                          </td>
                          <td className="text-center">
                            {item.C_ACCOUNT_TYPE_NAME}
                          </td>
                          <td className="text-center">{item.C_BANK_BRANCH_HAND}</td>
                          <td className="text-center">{item.C_OPEN_DATE}</td>
                          <td className="text-center">
                            {item.C_STATUS === 'DA_DUYET'
                              ? 'Đã duyệt'
                              : 'Chưa duyệt'}
                          </td>
                          <th>
                            <span class="d-flex justify-content-center">
                              <ToggleButton
                                value={item.C_ACTIVE === 1 ? true : false}
                                onToggle={(value) =>
                                  _handleToggle(item?.PK_ACCOUNT_BEN, value)
                                }
                              />
                            </span>
                          </th>
                          <td className="text-center align-baseline">
                            <GroupButton>
                              {item.C_STATUS === 'CHUA_DUYET' &&
                              accRight?.C_APPROVE === 1 ? (
                                <a
                                  title={t('txt-appr')}
                                  onClick={() =>
                                    handleApproveAccountBeneficary(
                                      item.PK_ACCOUNT_BEN
                                    )
                                  }
                                >
                                  <BsFillBookmarkCheckFill />
                                </a>
                              ) : (
                                <span />
                              )}
                              {item.C_STATUS === 'CHUA_DUYET' &&
                              item.C_APPROVER_CODE === '' &&
                              accRight?.C_UPDATE === 1 && (
                                <a
                                  title={t('txt-del')}
                                  onClick={() =>
                                    handleDelAccountBeneficary(
                                      item.PK_ACCOUNT_BEN
                                    )
                                  }
                                >
                                  <BsTrash />
                                </a>
                              )}
                            </GroupButton>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </Table>
              </FormAdd>
            </PerfectScrollbar>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

const mapStateToProps = (state, _props) => {
  const getToken = makeGetToken();

  const getCustomerDetail = makeGetCustomerDetail();
  const getAccBenSingle = makeGetAccBenSingle();
  const getAccBenDel = makeGetAccBenDel();
  const getAccBenChangeActive = makeGetAccBenChangeActive();
  const getAccBenApprove = makeGetAccBenApprove();
  return {
    token: getToken(state),

    custDetail: getCustomerDetail(state),
    accBenSingle: getAccBenSingle(state),
    accBenDel: getAccBenDel(state),
    accBenChangeActive: getAccBenChangeActive(state),
    accBenAppr: getAccBenApprove(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailBeneficaryModal)
);
