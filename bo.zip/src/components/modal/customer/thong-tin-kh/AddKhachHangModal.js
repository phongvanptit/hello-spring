import React from 'react';
import { connect, useDispatch } from 'react-redux';

import { Form, Table } from 'react-bootstrap';
import {
  change,
  Field,
  FieldArray,
  FormSection,
  formValueSelector,
  getFormSyncErrors,
  reduxForm,
  updateSyncErrors,
} from 'redux-form';

import ReactModal from 'react-modal';
import styled from 'styled-components';
import * as _ from 'lodash';
import { translate } from 'react-i18next';

import RenderInput from 'components/input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import RenderFileInput from 'components/input/renderFileInput';
import RenderArea from 'components/input/renderArea';
import renderSelectBank from 'components/input/renderSelectBank';
import RenderSelectSubBranch from 'components/input/renderSelectSubBranch';
import RenderSelectIssuePlace from 'components/input/inputSelectIssuePlace';
import RenderSuggestNational from 'components/input/renderSuggestNationalNew';
import RenderSuggestProvince from 'components/input/renderSuggestProvince';

import { setToast } from 'containers/client/actions';
import { custUpdateRequest } from 'containers/customer/actions';
import { custUpdateSuccess } from 'containers/customer/actions';
import {
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
  makeGetToken,
  makeGetNationalList,
  makeGetProvinceList,
  makeGetCustomerUpdate,
  makeGetAllBank,
  makeGetAllSubBranch,
  makeGetSingleUserFront,
  makeGetSysBpmByType,
  makeGetGlobalCardIDType,
  makeGetGlobalCardIDTypeOrg,
} from 'lib/selector';

import { BsTrash } from 'react-icons/bs';
import { FaEye, FaTimes } from 'react-icons/fa';
import Spinner from 'assets/img/spinner.gif';
import {
  required,
  lengthRequired,
  maxLength,
  minLength,
  validateTT
} from 'utils/validation';
import { BtnClose, BtnSubmit, TabsSectionHeader } from 'utils/styledComponent';
import { arrAuthenSign } from 'utils/const';
import { _diff2Date, StringToInt, getAge, formatDate } from 'utils';
import { makeGetAccBenType } from 'lib/selector';
import { makeGetChannelType } from 'lib/selector';
import { removeAccent } from 'utils';
import { makeGetCustCodeAuto } from 'lib/selector';
import {
  getCustCodeRequest,
  getCustCodeSuccess,
} from 'containers/customer/actions';
import ImagesViewer from 'components/images-viewer/imageViewer';
import RenderInputNumber from 'components/input/renderInputNumber';
import { BtnDetail } from 'utils/styledComponent';
import DetailMarketingId from 'components/modal/detail-pop-up/detailMarketingId';
import CreateIssuePlace from './layout/CreateIssuePlace';
import { makeGetGlIssuePlace } from 'lib/selector';
import { globalIssuePlaceSuccess } from 'containers/global/actions';
import { globalIssuePlaceRequest } from 'containers/global/actions';
import { validatePhone } from 'utils/validation';
ReactModal.setAppElement('#root');

const arrTypeXT = [
  { value: 'ANH_MAT_TRUOC', label: 'CMT/CCCD (mặt trước)' },
  { value: 'ANH_MAT_SAU', label: 'CMT/CCCD (mặt sau)' },
  { value: 'ANH_CHAN_DUNG', label: 'Ảnh chân dung' },
  { value: 'ANH_CHU_KY', label: 'Chữ ký' },
];

const appUrl = `${process.env.REACT_APP_API_URL}`;
const fileUrl = `${process.env.REACT_APP_FILE_URL}/upload`;

const length6 = lengthRequired(6);
const maxLength20 = maxLength(12);
const minLength14 = minLength(14);

//#region styled
const customStyles = {
  content: {
    inset: '40px 200px auto',
    // top: '40px',
    // bottom: 'auto',
    // left: 'calc( 50% - 375px )',
    height: 'auto',
    // width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const FormContent = styled.div`
  grid-column: 1/5;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  display: none;

  &.active {
    display: grid;
  }

  img {
    max-height: 75px;
    max-width: -webkit-fill-available;
  }
`;

const FormBanksAccount = styled.div`
  grid-column: 1/5;
  display: flex;
  flex-direction: column;

  .table td,
  .table th {
    padding: 6px 7px;

    img {
      max-height: 75px;
      max-width: 150px;
    }
  }
`;

//#endregion

const validateLocalMobile = (value, _allValues, props) => {
  /*const { sysBpm } = props;
  const isValidMobile =
    _.find(sysBpm, (o) => o.step === 'check_mobile')?.status === 1;
  if (!isValidMobile) return undefined;*/

  if (!value) return 'Trường không được để trống';

  let vnf_regex = /(((\+|)84)|0)(3|5|7|8|9)+([0-9]{8})\b/;
  const _value = value.replace(/ /g, '');
  if (!_value || (vnf_regex.test(_value) && _value.indexOf('_') < 0))
    return undefined;

  return 'Định dạng SĐT không đúng';
};

const validateLocalEmail = (value, _allValues, props) => {
  const { sysBpm } = props;
  // const isValidEmail =
  //   _.find(sysBpm, (o) => o.step === 'check_email')?.status === 1;
  // if (!isValidEmail) return undefined;

  var re =
    /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

  if (!value || re.test(value)) return undefined;

  return 'Định dạng Email không đúng';
};

const validateCustCode = (value, _allValues, props) => {
  const { sysBpm } = props;
  //var re = /^[a-zA-Z0-9]+$/;
  var re = /^[0-9]+$/;
  if (!value) return 'Trường không được để trống';
  if (re.test(value)) return undefined;

  //return 'Mã khách hàng có kí tự đặc biệt';
  return 'Mã khách hàng chỉ cho nhập số';
};

const validateMktId = (value, _allValues, props) => {
  const { sysBpm } = props;
  const isValidEmail =
    _.find(sysBpm, (o) => o.step === 'CHECK_MKTID')?.value === true;
  if (!isValidEmail) return undefined;

  if (!value) return 'Trường không được để trống';

  if (value.length !== 4) return 'Độ dài 4 ký tự';
  if (isNaN(Number(value))) return 'Hãy nhập số';

  return undefined;
};

const validateExpireDate = (value, _allValues, props) => {
  const { formIssueDate } = _allValues;
  if (!value) return 'Trường không được để trống';

  const _diff1 = _diff2Date(value, formIssueDate);
  const _diff2 = _diff2Date(value, formatDate(new Date(), '/', 'dmy'));

  if (_diff1 < 0 || _diff2 < 0) return 'Ngày hết hạn không hợp lệ';

  return undefined;
};

const validateExpireDate1 = (value, _allValues, props) => {
  const { formIssueDate } = _allValues;

  const _diff1 = _diff2Date(value, formIssueDate);
  const _diff2 = _diff2Date(value, formatDate(new Date(), '/', 'dmy'));

  if (_diff1 < 0 || _diff2 < 0) return 'Ngày hết hạn không hợp lệ';

  return undefined;
};

const warn = (values) => {
  const warns = {};
  //var format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  var format = /[`!@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?~]/;
  const { formCustName } = values;
  let _arr = [];
  if (formCustName) {
    // if (format.test(formCustName) && /[0-9]/.test(formCustName)) {
    //   _arr.push('Tên khách hàng có ký tự số, ký tự đặc biệt');
    // } else 
    if (format.test(formCustName)) {
      _arr.push('Tên khách hàng có ký tự đặc biệt');
    } 
    // else if (/[0-9]/.test(formCustName))
    //   _arr.push('Tên khách hàng có ký tự số')
    ;
  }
  warns.formCustName = _arr;
  return warns;
};

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function convert_vi_to_en(str) {
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
  str = str.replace(/đ/g, 'd');
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
  str = str.replace(/Đ/g, 'D');
  str = str.replace(
    /!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g,
    ' '
  );
  str = str.replace(/  +/g, ' ');
  return str;
}

function ThongTinKhachHang(props) {
  const { className, customerType, bpmLienHe, t } = props;

  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {customerType === 'CA_NHAN'
            ? `${t('txt-residence-address')}`
            : `${t('txt-office')}`}
          {/* {bpmLienHe?.CHECK_RESEDENCE_ADDR ? (
            <span className="text-danger">*</span>
          ) : null} */}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhResedenceAddr"
          className="form-control input-order"
          component={RenderInput}
          // validate={bpmLienHe?.CHECK_RESEDENCE_ADDR ? required : null}
          validate={required}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-contact-address')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhContactAddr"
          className="form-control input-order"
          component={RenderInput}
          validate={[required, minLength14]}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-tel')}</Form.Label>
        <Field
          name="ttkhTel"
          className="form-control input-order"
          component={RenderInputNumber}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile-1')}
          {/* {bpmLienHe?.CHECK_MOBILE ? (
            <span className="text-danger">*</span>
          ) : null} */}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhMobile"
          className="form-control input-order"
          component={RenderInputNumber}
          validate={[validateLocalMobile, required]}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          Email<span className="text-danger">*</span>
          {/* {bpmLienHe?.CHECK_EMAIL ? (
            <span className="text-danger">*</span>
          ) : null} */}
        </Form.Label>
        <Field
          name="ttkhEmail"
          className="form-control input-order"
          component={RenderInput}
          validate={[validateLocalEmail,required]}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>Fax</Form.Label>
        <Field
          name="ttkhFax"
          className="form-control input-order"
          component={RenderInput}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '1/5' }}>
        <Form.Label>{t('txt-note')}</Form.Label>
        <Field
          name="ttkhNote"
          className="form-control input-order"
          component={RenderArea}
          rows={2}
        />
      </Form.Group>
    </FormContent>
  );
}

function ThongTinLienHe(props) {
  const { className, isCheckGiamHo, bpmGiamHo, t, glIssuePlace } = props;
  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {t('txt-repre_name')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhName"
          className="form-control input-order"
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-repre-relation')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhRelation"
          className="form-control input-order"
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-id')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhCardId"
          className="form-control input-order"
          component={RenderInput}
          //validate={isCheckGiamHo ? [required,maxLength20] : null}
          validate={isCheckGiamHo ? [required,maxLength20] : maxLength20}
          
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-date')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhIssueDate"
          className="form-control input-order"
          classParentName="w-100"
          component={RenderSelectDate}
          startDate={isCheckGiamHo ? formatDate(new Date(), '/', 'dmy') : null}
          validate={isCheckGiamHo ? required : null}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-expire-date')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhExpireDate"
          className="form-control input-order"
          classParentName="w-100"
          component={RenderSelectDate}
          //startDate={isCheckGiamHo ? formatDate(new Date(), '/', 'dmy') : null}
          validate={isCheckGiamHo ? [required,validateExpireDate] : validateExpireDate1}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-place')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhIssuePlace"
          className="form-control input-order"
          // component={RenderInput}
          component={RenderSelectIssuePlace}
          opts={glIssuePlace}
          // fnAddCallback={fnAddCallback}
          validate={isCheckGiamHo ? required : null}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_MOBILE && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhMobile"
          className="form-control input-order"
          component={RenderInput}
          // validate={
          //   isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_MOBILE ? required : null
          // }
          validate={[ validatePhone]}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-email')}
          {/* {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_EMAIL && (
            <span className="text-danger">*</span>
          )} */}
        </Form.Label>
        <Field
          name="ttlhEmail"
          className="form-control input-order"
          component={RenderInput}
          // validate={[
          //   isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_EMAIL ? required : null,
          // ]}
          validate={validateLocalEmail}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-contact-address')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_ADDRESS && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhAddress"
          className="form-control input-order"
          component={RenderInput}
          validate={
            isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_ADDRESS ? required : null
          }
        />
      </Form.Group>
    </FormContent>
  );
}

function ThongTinDaiDien(props) {
  const {
    glNational,
    className,
    customerType,
    bpmDaiDien,
    t,
    glCardIDType,
    glIssuePlace,
  } = props;

  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {t('txt-full-name')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddName"
          className="form-control input-order"
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_NAME
              ? required
              : null
          }
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-national')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddNationality"
          className="form-control input-order fz-13"
          component={RenderSuggestNational}
          // opts={glNational}
          required
          validate={customerType === 'TO_CHUC' ? required : null}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-resident-vn')}
          <span className="text-danger">*</span>
        </Form.Label>
        <div>
          <label>
            <Field
              name="ttddResidentInVN"
              component="input"
              type="radio"
              value="1"
              className="cursor-pointer"
            />{' '}
            {t('txt-yes')}
          </label>
          <label className="ml-3">
            <Field
              name="ttddResidentInVN"
              component="input"
              type="radio"
              value="0"
              className="cursor-pointer"
            />{' '}
            {t('txt-no')}
          </label>
        </div>
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-type')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddCardIdType"
          className="form-control input-order"
          component={RenderNormalSelect}
          opts={glCardIDType}
          validate={customerType === 'TO_CHUC' ? required : null}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-id')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddCardID"
          className="form-control input-order"
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_CARDID
              ? required
              : null
          }
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-date')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddIssueDate"
          className="form-control input-order"
          classParentName="w-100"
          component={RenderSelectDate}
          startDate={formatDate(new Date(), '/', 'dmy')}
          validate={
            (customerType === 'TO_CHUC' )
              ? validateTT
              : null
          }
          //validate={[validateTT, required]}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-place')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddIssuePlace"
          className="form-control input-order"
          // component={RenderInput}
          component={RenderSelectIssuePlace}
          opts={glIssuePlace}
          // fnAddCallback={fnAddCallback}
          validate={customerType === 'TO_CHUC' ? required : null}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-position')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddPosition"
          className="form-control input-order"
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_POSITION
              ? required
              : null
          }
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '2/4' }}>
        <Form.Label>{t('txt-contact-address')}</Form.Label>
        <Field
          name="ttddAddress"
          className="form-control input-order"
          component={RenderInput}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-gender')}</Form.Label>
        <div>
          <label>
            <Field
              name="ttddGender"
              className="cursor-pointer"
              component="input"
              type="radio"
              value="M"
            />{' '}
            {t('txt-male')}
          </label>
          <label className="ml-3">
            <Field
              name="ttddGender"
              className="cursor-pointer"
              component="input"
              type="radio"
              value="F"
            />{' '}
            {t('txt-female')}
          </label>
        </div>
      </Form.Group>

      <Form.Group>
        <Form.Label>
          {t('txt-tel')}
          {bpmDaiDien?.CHECK_REPRE_TEL && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttddTel"
          className="form-control input-order"
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_TEL
              ? required
              : null
          }
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile')}
          {bpmDaiDien?.CHECK_REPRE_MOBILE && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttddMobile"
          className="form-control input-order"
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_MOBILE
              ? required
              : null
          }
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-email')}</Form.Label>
        <Field
          name="ttddEmail"
          className="form-control input-order"
          component={RenderInput}
          validate={validateLocalEmail}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-authen-sign')}</Form.Label>
        <Field
          name="ttddAuthenSign"
          className="form-control input-order"
          component={RenderNormalSelect}
          opts={arrAuthenSign}
          validate={required}
        />
      </Form.Group>
    </FormContent>
  );
}

function BanksAccount({
  fields,
  glAllBank,
  glProvince,
  glAllSubBranch,
  glAccBenType,
  glChannelType,
  custName,
  handleToast,
  t,
  meta: { error, submitFailed },
}) {
  const [checkVaildate, setCheckValidata] = React.useState(false);
  const [checkInfor, setCheckInfor] = React.useState(null);
  React.useEffect(() => {
    validateAddBen(fields.getAll());
  }, [fields]);

  // const validateAddBen = (values) => {
  //   const errors = [];
  //   // Lặp qua mỗi bank trong danh sách banks
  //   Array.isArray(values) &&
  //     values.forEach((bank, index) => {
  //       const bankBranchHand = bank.bankBranchHand;
  //       const bankBranch = bank.bankBranch;
  //       // Kiểm tra nếu cả hai trường đều trống
  //       if (!bankBranchHand && !bankBranch) {
  //         setCheckValidata(true);
  //       } else setCheckValidata(false);
  //     });
  // };
  const validateAddBen = (values) => {
    const errors = [];
    // Lặp qua mỗi bank trong danh sách banks
    Array.isArray(values) &&
    values.forEach((bank, index) => {
        const accountType = bank.accountType;
       //console.log('account-type',bank.accountType);
        // Kiểm tra nếu cả hai trường đều trống
        if (accountType !== 'OTHER') {
          setCheckInfor(true);
        } else setCheckInfor(false);
      });
  };
  return (
    <FormBanksAccount>
      {submitFailed && error && <small className="text-danger">{error}</small>}
      <Table bordered>
        <thead>
          <tr>
            <th>{t('txt-acc-number')}</th>
            <th>{t('txt-acc-name')}</th>
            <th>{t('txt-bank')}</th>
            <th>{t('txt-province-city')}</th>
            <th>Chi nhánh</th>
            <th>{t('txt-branch-hand')}</th>
            <th>{t('txt-acc-type')}</th>
            <th>{t('txt-action')}</th>
          </tr>
        </thead>
        <tbody>
          {fields.map((bank, index) => (
            <tr key={index}>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankAccount`}
                  className="form-control"
                  component={RenderInput}
                  validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankAccountName`}
                  className="form-control"
                  component={RenderInput}
                  validate={required}
                  disabled={checkInfor}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankName`}
                  className="form-control"
                  component={renderSelectBank}
                  opts={glAllBank}
                  validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankProvince`}
                  className="form-control"
                  component={RenderSuggestProvince}
                  validate={required}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankBranch`}
                  className="form-control"
                  classParent="w-100"
                  component={RenderSelectSubBranch}
                  bankCode={fields.get(index)?.bankName}
                  provinceCode={fields.get(index)?.bankProvince}
                  opts={glAllSubBranch}
                  //validate={checkVaildate ? required : undefined}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.bankBranchHand`}
                  className="form-control w-100"
                  component={RenderInput}
                  //validate={checkVaildate ? required : undefined}
                />
              </td>
              <td className="text-center align-baseline">
                <Field
                  name={`${bank}.accountType`}
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={glAccBenType}
                  required
                  validate={required}
                />
              </td>

              <td className="text-center align-baseline">
                <a onClick={() => fields.remove(index)}>
                  <BsTrash />
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div
        className="d-flex"
        style={{
          height: '30px',
          whiteSpace: 'nowrap',
          gridColumn: '1/4',
        }}
      >
        <BtnSubmit
          type="button"
          className="w_125 info"
          onClick={() => {
            if (fields.length > 4) {
              handleToast(`${t('txt-add-5-acc-beneficiary')}`, 'warning');
              return;
            }
            if (!custName) {
              handleToast(`${t('txt-no-data-cust')}`, 'warning');
              return;
            }

            fields.push({
              bankAccountName: convert_vi_to_en(custName).toUpperCase(),
              accountType: 'BANK',
              channel: 'I',
            });
          }}
        >
          {t('txt-add-acc')}
        </BtnSubmit>
        <BtnSubmit
          type="button"
          className="w_125 ml-2 danger"
          onClick={() => fields.removeAll()}
        >
          {t('bnt-del-entry')}
        </BtnSubmit>
      </div>
    </FormBanksAccount>
  );
}

function XacThucAccount({
  fields,
  onPreview,
  meta: { error, submitFailed },
  t,
}) {
  function previewImage(record) {
    // readurl from type file
    onPreview(readurl(record));
  }

  function readurl(file) {
    // file reader
    return URL.createObjectURL(file);
  }

  return (
    <FormBanksAccount>
      {submitFailed && error && <small className="text-danger">{error}</small>}
      <PerfectScrollbar>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-file-type')}</th>
              <th>{t('txt-chose-file')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {fields.map((xt, index) => (
              <tr key={index}>
                <td className="text-center">
                  <Field
                    name={`${xt}.xtAccountType`}
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={arrTypeXT}
                    validate={required}
                  />
                </td>
                <td className="text-center">
                  <Field
                    name={`${xt}.xtAccountImage`}
                    className="fz-13"
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    component={RenderFileInput}
                    validate={required}
                  />
                </td>
                <td className="text-center">
                  <a
                    onClick={() => {
                      if (fields.get(index)?.xtAccountImage)
                        return previewImage(fields.get(index)?.xtAccountImage);
                      return;
                    }}
                    className={
                      'mx-1 ' +
                      (!fields.get(index)?.xtAccountImage ? 'disabled' : '')
                    }
                    title="Xem"
                  >
                    <FaEye />
                  </a>
                  <a
                    onClick={() => fields.remove(index)}
                    className="mx-1"
                    title="Xóa"
                  >
                    <BsTrash />
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
      <div
        className="d-flex"
        style={{
          height: '30px',
          whiteSpace: 'nowrap',
          gridColumn: '1/4',
        }}
      >
        <BtnSubmit
          type="button"
          className="w_125 info"
          onClick={() => {
            if (fields.length > arrTypeXT.length) return;

            fields.push({});
          }}
        >
          {t('txt-add-file')}
        </BtnSubmit>

        <BtnSubmit
          type="button"
          onClick={() => fields.removeAll()}
          className="w_125 ml-2 danger"
        >
          {t('bnt-del-entry')}
        </BtnSubmit>
      </div>
    </FormBanksAccount>
  );
}

function AddKhachHangModal(props) {
  const abortController = new AbortController();

  const dispatch = useDispatch();
  const [customerType, setCustomerType] = React.useState('CA_NHAN');
  const [tabActive, setTabActive] = React.useState('THONG_TIN_LIEN_HE');
  const [isLoading, setIsLoading] = React.useState(false);
  const [isCheckGiamHo, setIsCheckGiamHo] = React.useState(false);
  const [bpmLienHe, setBpmLienHe] = React.useState(null);
  const [bpmGiamHo, setBpmGiamHo] = React.useState(null);
  const [bpmDaiDien, setBpmDaiDien] = React.useState(null);
  const [imgPreview, setImgPreview] = React.useState(null);
  const [detailMarketingId, setDetailMarketingId] = React.useState(null);
  const [createIssuePlace, setCreateIssuePlace] = React.useState(false);
  const {
    token,
    formMktId,
    custUpd,
    formCustCode,
    formBirthDate,
    formCardId,
    errors,
    sysBpm,
    thongTinLienHe,
    custCodeAuto,
    glIssuePlace,
  } = props;

  const preCustUpdate = usePrevious(custUpd);
  const preSysBpm = usePrevious(sysBpm);
  const preCustomerType = usePrevious(customerType);
  const preFormBirthDate = usePrevious(formBirthDate);
  const preFormCustCode = usePrevious(formCustCode);
  const preTtkhResedenceAddr = usePrevious(thongTinLienHe?.ttkhResedenceAddr);
  const preCustCodeAuto = usePrevious(custCodeAuto);
  const preglIssuePlace =  usePrevious(glIssuePlace);

  let _filePaths = {};

  React.useEffect(() => {
    //_handleGetMKTDef();
    initForm();
    getGlobalIssuePlace();
    return () => {
      abortController.abort();
      dispatch(custUpdateSuccess(null));
      dispatch(singleUserFrontSuccess(null));
      dispatch(getCustCodeSuccess(null));
      dispatch(globalIssuePlaceSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (custUpd && !_.isEqual(custUpd, preCustUpdate)) {
      _handleToast(`${t('txt-add-cust-success')}`, 'success');
      // clear update
      dispatch(custUpdateSuccess(null));
      dispatch(singleUserFrontSuccess(null));
      onClose(formCustCode);
    }
  }, [custUpd]);

  React.useEffect(() => {
    if (sysBpm && !_.isEqual(sysBpm, preSysBpm)) {
      let checkLienHe = {},
        checkGiamHo = {},
        checkDaiDien = {};
      checkLienHe.CHECK_CUST_ADDR =
        _.find(sysBpm, (o) => o.step === 'CHECK_CUST_ADDR')?.value || false;
      checkLienHe.CHECK_RESEDENCE_ADDR =
        _.find(sysBpm, (o) => o.step === 'CHECK_RESEDENCE_ADDR')?.value ||
        false;
      checkLienHe.CHECK_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_MOBILE')?.value || false;
      checkLienHe.CHECK_EMAIL =
        _.find(sysBpm, (o) => o.step === 'CHECK_EMAIL')?.value || false;

      checkGiamHo.CHECK_CONTACT_NAME =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_NAME')?.value || false;
      checkGiamHo.CHECK_CONTACT_RELATION =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_RELATION')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_CARDID =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_CARDID')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ISSUE_DATE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ISSUE_DATE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ISSUE_PLACE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ISSUE_PLACE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ADDRESS =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ADDRESS')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_MOBILE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_EMAIL =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_EMAIL')?.value || false;

      checkDaiDien.CHECK_REPRE_NAME =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_NAME')?.value || false;
      checkDaiDien.CHECK_REPRE_CARDID =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_CARDID')?.value || false;
      checkDaiDien.CHECK_REPRE_ISSUE_DATE =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_ISSUE_DATE')?.value ||
        false;
      checkDaiDien.CHECK_REPRE_POSITION =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_POSITION')?.value ||
        false;
      checkDaiDien.CHECK_REPRE_TEL =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_TEL')?.value || false;
      checkDaiDien.CHECK_REPRE_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_MOBILE')?.value || false;

      setBpmLienHe(checkLienHe);
      setBpmGiamHo(checkGiamHo);
      setBpmDaiDien(checkDaiDien);
    }
  }, [sysBpm]);

  React.useEffect(() => {
    if (
      thongTinLienHe?.ttkhResedenceAddr &&
      !_.isEqual(thongTinLienHe?.ttkhResedenceAddr, preTtkhResedenceAddr)
    ) {
      dispatch(
        change(
          'openCustomerModalform',
          'thongTinLienHe.ttkhContactAddr',
          thongTinLienHe?.ttkhResedenceAddr
        )
      );
    }
  }, [thongTinLienHe?.ttkhResedenceAddr]);

  React.useEffect(() => {
    if (customerType && !_.isEqual(customerType, preCustomerType)) {
      dispatch(
        change('openCustomerModalform', 'formCustomerType', customerType)
      );
      dispatch(
        change(
          'openCustomerModalform',
          'formCardIdType',
          customerType === 'CA_NHAN' ? '01' : '03'
        )
      );
      if (customerType === 'CA_NHAN' && tabActive === 'THONG_TIN_DAI_DIEN')
        setTabActive('THONG_TIN_LIEN_HE');
    }
  }, [customerType]);

  // React.useEffect(() => {
  //   if (formMktId && formMktId.length === 4) {
  //     _handleCheckMKT();
  //     _handleGetCustCode();
  //   } else {
  //     dispatch(singleUserFrontSuccess(null));
  //     dispatch(getCustCodeSuccess(null));
  //   }
  // }, [formMktId]);

  React.useEffect(() => {
      _handleGetCustCode();
  }, []);

  React.useEffect(() => {
    if (formMktId && formMktId.length === 4) {
      _handleCheckMKT();
      
    } else {
      dispatch(singleUserFrontSuccess(null));
      
    }
  }, [formMktId]);

  React.useEffect(() => {
    if (glIssuePlace && !_.isEqual(glIssuePlace, preglIssuePlace)) {
      dispatch(
        change(
          'openCustomerModalform',
          'formIssuePlace',
          glIssuePlace[0]?.value
        )
      );
    }
  }, [glIssuePlace]);

  React.useEffect(() => {
    if (custCodeAuto && !_.isEqual(custCodeAuto, preCustCodeAuto)) {
      dispatch(
        change(
          'openCustomerModalform',
          'formCustCode',
          custCodeAuto?.C_CUSTOMER_CODE
        )
      );
    }
  }, [custCodeAuto]);

  React.useEffect(() => {
    if (formBirthDate && !_.isEqual(formBirthDate, preFormBirthDate)) {
      const _errText = validateBirthDate(formBirthDate);

      dispatch(
        updateSyncErrors('openCustomerModalform', {
          ...errors,
          formBirthDate: _errText,
        })
      );
    }
  }, [formBirthDate]);

  React.useEffect(() => {
    // check_cardid
    // check_acc
    if (
      formCustCode &&
      formCustCode.trim().length === 6 &&
      !_.isEqual(formCustCode, preFormCustCode) &&
      _.find(sysBpm, (o) => o.step === 'CHECK_CUST_CODE')?.value === true
    ) {
      // check tài khoản đã tồn tại
      _handleCheckCustomer('formCustCode');
    }
  }, [formCustCode]);
console.log('data',glIssuePlace)
  function initForm() {
    const d = new Date();
    dispatch(change('openCustomerModalform', 'customerType', 'CA_NHAN'));
    dispatch(change('openCustomerModalform', 'formCustGender', 'M'));
    dispatch(
      change(
        'openCustomerModalform',
        'formBirthDate',
        formatDate(d.setFullYear(d.getFullYear() - 20), '/', 'dmy')
      )
    );
    dispatch(change('openCustomerModalform', 'formCardIdType', '5'));

    dispatch(
      change(
        'openCustomerModalform',
        'formIssueDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    // dispatch(
    //   change(
    //     'openCustomerModalform',
    //     'formExpireDate',
    //     formatDate(new Date(), '/', 'dmy')
    //   )
    // );
    dispatch(
      change(
        'openCustomerModalform',
        'formIssuePlace',
        glIssuePlace[0]?.value || ''
      )
    );
// console.log('data',glIssuePlace)
//     dispatch(
//       change(
//         'openCustomerModalform',
//         'formIssuePlace',
//         glIssuePlace[0]?.value
//       )
//     );

    dispatch(change('openCustomerModalform', 'formNationality', '234'));
    dispatch(change('openCustomerModalform', 'formResidentInVN', '1'));
    dispatch(change('openCustomerModalform', 'formStaffFlag', '0'));

    //Thong tin dai dien

    dispatch(
      change('openCustomerModalform', 'thongTinDaiDien.ttddNationality', '234')
    );
    dispatch(
      change('openCustomerModalform', 'thongTinDaiDien.ttddResidentInVN', '1')
    );
    dispatch(
      change('openCustomerModalform', 'thongTinDaiDien.ttddCardIdType', '1')
    );
    dispatch(
      change('openCustomerModalform', 'thongTinDaiDien.ttddIssuePlace', '1')
    );
    dispatch(
      change(
        'openCustomerModalform',
        'thongTinDaiDien.ttddIssueDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );

    dispatch(
      change('openCustomerModalform', 'thongTinDaiDien.ttddGender', 'M')
    );
    dispatch(
      change(
        'openCustomerModalform',
        'thongTinDaiDien.ttddAuthenSign',
        'BROKER'
      )
    );

    dispatch(change('openCustomerModalform', 'banks', []));
    dispatch(change('openCustomerModalform', 'xacthucTK', []));
  }

  function _handleBlurCardId() {
    if (
      formCardId &&
      _.find(sysBpm, (o) => o.step === 'CHECK_CARDID')?.value === true
    ) {
      _handleCheckCustomer('formCardId', 10);
    }
  }

  function _handleCheckCustomer(name, times = 1000) {
    if (!props[name]) {
      // dispatch(touch('addAccountInfoform', 'custCode'))
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: props[name],
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        if (res.code == 1 && res.data.length > 0) {
          _handleToast(`${t('txt-cust-exists')}`, 'error');

          setTimeout(() => {
            dispatch(change('openCustomerModalform', name, '', false));
          }, times);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function getGlobalIssuePlace() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE: 'ISSUE_PLACE',
      },
    };
    dispatch(globalIssuePlaceRequest(params));
  }

  function _handleGetMKTDef() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_PARAMETER',
      group: 'LIST',
      data: {
        ITEM_ID: 'MARKETING_ID_DEFAULT',
      },
    };

    const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }
    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        if (res.code > 0 && !!res.data) {
          dispatch(
            change(
              'openCustomerModalform',
              'formMktId',
              res.data[0].C_SYSTEM_PARAMETER_VALUE
            )
          );
        } else if (res.re === 'Unauthorized') {
          // logout
          dispatch({ type: 'INVALID_SESSION' });
          onClose();
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function submit(values) {
    setIsLoading(true);
    if (values.xacthucTK && values.xacthucTK) {
      var iterator = asyncIterator(values.xacthucTK);
      handleUploadAnh(values, iterator);
    } else {
      handleNextProcess(values, null);
    }
  }

  function asyncIterator(_array) {
    return {
      next: function () {
        if (_array.length) {
          return {
            value: _array.shift(),
            done: false,
          };
        } else {
          return {
            done: true,
          };
        }
      },
    };
  }

  function handleUploadAnh(values, iterator) {
    const _iterator = iterator.next();
    if (_iterator.done) {
      // next process
      handleNextProcess(values, _filePaths);
    } else {
      // upload
      fileUpload(_iterator.value.xtAccountImage).then((response) => {
        if (response.code > 0) {
          // create request
          switch (_iterator.value.xtAccountType) {
            case 'ANH_MAT_TRUOC':
              _filePaths.pathAnhMt = response.FILE_DIR;
              break;
            case 'ANH_MAT_SAU':
              _filePaths.pathAnhMs = response.FILE_DIR;
              break;
            case 'ANH_CHAN_DUNG':
              _filePaths.pathAnhCD = response.FILE_DIR;
              break;
            case 'ANH_CHU_KY':
              _filePaths.pathAnhCK = response.FILE_DIR;
              break;

            default:
              break;
          }
          handleUploadAnh(values, iterator);
        } else {
          setIsLoading(false);
          _handleToast(response.re);
        }
      });
    }
  }

  function fileUpload(file) {
    const formData = new FormData();
    formData.append('file', file);
    const request = fetch(fileUrl, {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    return request
      .then((response) => response.json())
      .then((json) => json)
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
  }

  function handleNextProcess(values, filePaths) {
    let _params;
    if (customerType === 'CA_NHAN') {
      _params = renderParamCaNhan(values);
    } else {
      _params = renderParamToChuc(values);
    }

    let _bankAccount = [];

    values.banks.forEach((element) => {
      _bankAccount.push({
        BANK_CODE: element.bankName, // mã tk ngân hàng
        BANK_ACCOUNT_CODE: element.bankAccount, // số tk ngân hàng
        BANK_ACCOUNT_NAME: removeAccent(element.bankAccountName), // tên tài khoản ngân hàng
        BANK_BRANCH_CODE: element.bankBranch, // chi nhánh online
        BANK_BRANCH_NAME: element.bankBranchHand, //  chi nhánh nhập tay
        ACCOUNT_TYPE: element.accountType,
        CHANNEL_CODE: element.channel,
        PROVINCE_CODE: element.bankProvince,
      });
    });

    if (_params) {
      _params.data.FRONT_CARD_IMAGE = filePaths.pathAnhMt;
      _params.data.BACK_CARD_IMAGE = filePaths.pathAnhMs;
      _params.data.SIGN_IMAGE = filePaths.pathAnhCK;
      _params.data.FACE_IMAGE = filePaths.pathAnhCD;
      // tài khoản thụ hưởng
      _params.data.LIST_BANK_ACCOUNT = _bankAccount;

      dispatch(custUpdateRequest(_params));
      setIsLoading(false);
    }
  }
  console.log(props.formNationality);
  function renderParamCaNhan(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: '',
        MARKETING_ID: values.formMktId,
        CHANNEL_CODE: 'D',
        CUSTOMER_TYPE: 'CA_NHAN',
        CUSTOMER_CODE: values.formCustCode, // mã khách hàng
        // CUSTOMER_NAME: values.formCustName?.toUpperCase(),
        CUSTOMER_NAME: values.formCustName,
        CUST_PRE_NAME: '', // Tên tiền tố Mrs/Mr/Ms
        CARD_ID_TYPE: values.formCardIdType, // loại đăng ký sở hữu
        CARD_ID: values.formCardId,
        VSD_SID: values.formVsdSid,
        INVESTOR_CODE: values.formInvestorCode,
        BIRTH_DAY: values.formBirthDate,
        ISSUE_DATE: values.formIssueDate,
        EXPIRE_DATE: values.formExpireDate,
        ISSUE_PLACE: values.formIssuePlace,
        CUST_GENDER: values.formCustGender,
        CUST_EMAIL: values.thongTinLienHe?.ttkhEmail,
        CUST_MOBILE: values.thongTinLienHe?.ttkhMobile,
        CUST_TEL: values.thongTinLienHe?.ttkhTel,
        CUST_FAX: values.thongTinLienHe?.ttkhFax,
        // CUST_WEBSITE: values.thongTinKhachHang?.ttkhWebsite,
        CUST_ADDRESS: values.thongTinLienHe?.ttkhContactAddr,
        RESEDENCE_ADDRESS: values.thongTinLienHe?.ttkhResedenceAddr,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        PROVINCE_CODE: '',
        VN_FLAG: StringToInt(values.formResidentInVN),
        STAFF_FLAG: StringToInt(values.formStaffFlag),
        CONTENT: values.thongTinLienHe?.ttkhNote,
        AUTHEN_SIGN: values.thongTinDaiDien?.ttddAuthenSign,

        REPRE_NAME: values.nguoiGiamHo?.ttlhName,
        // REPRE_GENDER: values.nguoiGiamHo?.ttlhName,
        REPRE_POSITION: values.nguoiGiamHo?.ttlhRelation,
        REPRE_CARD_ID: values.nguoiGiamHo?.ttlhCardId,
        // REPRE_BIRTH_DAY: values.nguoiGiamHo?.ttlhName,
        REPRE_ISSUE_DATE: values.nguoiGiamHo?.ttlhIssueDate,
        REPRE_EXPIRE_DATE: values.nguoiGiamHo?.ttlhExpireDate,
        REPRE_ISSUE_PLACE: values.nguoiGiamHo?.ttlhIssuePlace,
        REPRE_ADDRESS: values.nguoiGiamHo?.ttlhAddress,
        REPRE_MOBILE: values.nguoiGiamHo?.ttlhMobile,
        // REPRE_TEL: values.nguoiGiamHo?.ttlhName,
        // REPRE_FAX: values.nguoiGiamHo?.ttlhName,
        REPRE_EMAIL: values.nguoiGiamHo?.ttlhEmail,
        // REPRE_VN_FLAG: values.nguoiGiamHo?.ttlhName,
        // REPRE_NATIONAL_CODE : values.nguoiGiamHo?.ttlhName,
      },
    };

    return params;
  }

  function renderParamToChuc(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: '',
        MARKETING_ID: values.formMktId,
        CHANNEL_CODE: 'D',
        CUSTOMER_TYPE: 'TO_CHUC',
        CUSTOMER_CODE: values.formCustCode,
        CUSTOMER_NAME: values.formCustName?.toUpperCase(),
        CUST_SHORT_NAME: values.formCustShortName?.toUpperCase(),
        BUSINESS_TYPE: values.formBussinessType,
        CARD_ID_TYPE: values.formCardIdType,
        CARD_ID: values.formCardId,
        VSD_SID: values.formVsdSid,
        INVESTOR_CODE: values.formInvestorCode,
        ISSUE_DATE: values.formIssueDate,
        EXPIRE_DATE: values.formExpireDate,
        ISSUE_PLACE: values.formIssuePlace,
        CUST_EMAIL: values.thongTinLienHe?.ttkhEmail,
        CUST_MOBILE: values.thongTinLienHe?.ttkhMobile,
        CUST_TEL: values.thongTinLienHe?.ttkhTel,
        CUST_FAX: values.thongTinLienHe?.ttkhFax,
        CUST_ADDRESS: values.thongTinLienHe?.ttkhContactAddr,
        RESEDENCE_ADDRESS: values.thongTinLienHe?.ttkhResedenceAddr,
        // CUST_WEBSITE: values.thongTinLienHe?.ttkhWebsite,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        PROVINCE_CODE: '',
        VN_FLAG: StringToInt(values.formResidentInVN),
        STAFF_FLAG: StringToInt(values.formStaffFlag),
        CONTENT: values.thongTinLienHe?.ttkhNote,
        AUTHEN_SIGN: values.thongTinDaiDien?.ttddAuthenSign,

        REPRE_NAME: values.thongTinDaiDien?.ttddName,
        REPRE_GENDER: values.thongTinDaiDien?.ttddGender,
        REPRE_POSITION: values.thongTinDaiDien?.ttddPosition,
        REPRE_CARD_ID_TYPE: values.thongTinDaiDien?.ttddCardIdType,
        REPRE_CARD_ID: values.thongTinDaiDien?.ttddCardID,
        // REPRE_BIRTH_DAY: values.thongTinDaiDien?.C_REPRE_BIRTH_DAY,
        REPRE_ISSUE_DATE: values.thongTinDaiDien?.ttddIssueDate,
        // REPRE_EXPIRE_DATE: values.thongTinDaiDien?.REPRE_EXPIRE_DATE,
        REPRE_ISSUE_PLACE: values.thongTinDaiDien?.ttddIssuePlace,
        REPRE_ADDRESS: values.thongTinDaiDien?.ttddAddress,
        REPRE_MOBILE: values.thongTinDaiDien?.ttddMobile,
        REPRE_TEL: values.thongTinDaiDien?.ttddTel,
        REPRE_FAX: '',
        REPRE_EMAIL: values.thongTinDaiDien?.ttddEmail,
        REPRE_VN_FLAG: StringToInt(values.thongTinDaiDien?.ttddResidentInVN),
        REPRE_NATIONAL_CODE: values.thongTinDaiDien?.ttddNationality,
      },
    };

    return params;
  }

  function _handleCheckMKT() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function _handleGetCustCode() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CUSTOMER_CODE',
      group: 'LIST',
      data: {
        MARKETING_ID: formMktId,
      },
    };
    dispatch(getCustCodeRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const validateBirthDate = (value) => {
    if (!value) return 'Trường không được để trống';
    const _isValidBirth = _.find(sysBpm, (o) => o.step === 'CHECK_AGE');
    if (_isValidBirth && _isValidBirth?.value === true) {
      //check ngày sinh ko lơn hơn ngày hiện tại
      const _diff = _diff2Date(value, formatDate(new Date(), '/', 'dmy'));
      if (_diff > 0) return 'Ngày sinh không đúng';
      const _age = getAge(value);
      for (let index = 0; index < _isValidBirth.data.length; index++) {
        const element = _isValidBirth.data[index];
        if (element.value === true && element.code === 'KHONG_DU_TUOI') {
          if (_age <= element?.v2 && _age >= element.v1) return 'Không đủ tuổi';
        }

        if (element.value === true && element.code === 'MO_TAI_KHOAN') {
          if (_age > element?.v2 || _age < element.v1)
            return `Chỉ mở tk từ ${element.v1} - ${element.v2} tuổi`;
        }
        if (element.value === true && element.code === 'CAN_GIAM_HO') {
          setIsCheckGiamHo(true);
        } else setIsCheckGiamHo(false);
      }
    } else setIsCheckGiamHo(false);
  };

  const {
    handleSubmit,
    submitting,
    onClose,
    t,
    glNational,

    thongTinKhachHang,
    glAllBank,
    glProvince,
    glAllSubBranch,
    glAccBenType,
    glChannelType,
    singleUserFront,
    formCustName,
    glCardIDType,
    glCardIDTypeOrg,
  } = props;

  function handleClose() {
    setImgPreview(null);
  }

  function handleDetailMarketingId() {
    if (!formMktId) return;
    setDetailMarketingId(formMktId);
  }

  // thêm mới nơi cấp
  function fnAddCallback() {
    setCreateIssuePlace(true);
  }

  function setIssuePlace(code) {
    dispatch(change('openCustomerModalform', 'formIssuePlace', code));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      {isLoading && (
        <div className="loading">
          <img src={Spinner} alt="" />
        </div>
      )}
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <div className="d-flex">
            <b className="fz-16 pl-3 mr-5">{t('txt-add-cust')}</b>
            <div className="d-flex align-items-center">
              <label className="fz-13">
                <input
                  type={'radio'}
                  name="customerType"
                  onChange={() => setCustomerType('CA_NHAN')}
                  defaultChecked={customerType === 'CA_NHAN'}
                  value={'CA_NHAN'}
                  className="mr-2 cursor-pointer"
                />
                {t('txt-individual-1')}
              </label>
              <label className="ml-5 fz-13">
                <input
                  type={'radio'}
                  name="customerType"
                  onChange={() => setCustomerType('TO_CHUC')}
                  defaultChecked={customerType === 'TO_CHUC'}
                  value={'TO_CHUC'}
                  className="mr-2 cursor-pointer"
                />
                {t('txt-organization-1')}
              </label>
            </div>
          </div>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustCode"
                    className="form-control input-order"
                    component={RenderInputNumber}
                    validate={[validateCustCode, length6]}
                    space
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    ID Sale
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <div className="w-100">
                      <Field
                        name="formMktId"
                        className="form-control input-order"
                        classParent="w-100"
                        component={RenderNewInputMkt}
                        // validate={[required, validateMktId]}
                        validate={required}
                      />
                    </div>
                    <BtnDetail
                      type="button"
                      onClick={() => handleDetailMarketingId()}
                    />
                  </div>
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-marketing-name')}</Form.Label>
                  <Form.Control
                    value={singleUserFront?.C_FRONT_USER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-company-employee')}</Form.Label>
                  <div>
                    <label>
                      <Field
                        name="formStaffFlag"
                        component="input"
                        type="radio"
                        value="1"
                        className="cursor-pointer"
                      />{' '}
                      {t('txt-yes')}
                    </label>
                    <label className="ml-3">
                      <Field
                        name="formStaffFlag"
                        component="input"
                        type="radio"
                        value="0"
                        className="cursor-pointer"
                      />{' '}
                      {t('txt-no')}
                    </label>
                  </div>
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {customerType === 'CA_NHAN'
                      ? `${t('txt-cust-name')}`
                      : `${t('txt-organization-name')}`}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustName"
                    className="form-control input-order"
                    component={RenderInput}
                    validate={required}
                  />
                </Form.Group>
                {customerType === 'CA_NHAN' ? (
                  <>
                    <Form.Group>
                      <Form.Label>
                        {t('txt-gender')}
                        <span className="text-danger">*</span>
                      </Form.Label>
                      <div>
                        <label>
                          <Field
                            name="formCustGender"
                            component="input"
                            type="radio"
                            className="cursor-pointer"
                            value="M"
                          />{' '}
                          {t('txt-male')}
                        </label>
                        <label className="ml-3">
                          <Field
                            name="formCustGender"
                            component="input"
                            type="radio"
                            className="cursor-pointer"
                            value="F"
                          />{' '}
                          {t('txt-female')}
                        </label>
                      </div>
                    </Form.Group>
                    <Form.Group>
                      <Form.Label>
                        {t('txt-date-of-birth')}
                        <span className="text-danger">*</span>
                      </Form.Label>
                      <Field
                        name="formBirthDate"
                        className="form-control input-order"
                        classParentName="w-100"
                        component={RenderSelectDate}
                        startDate={formatDate(new Date(), '/', 'dmy')}
                        validate={required}
                      />
                    </Form.Group>
                  </>
                ) : (
                  <>
                    <Form.Group>
                      <Form.Label>{t('txt-short-name')}</Form.Label>
                      <Field
                        name="formCustShortName"
                        className="form-control input-order"
                        component={RenderInput}
                      />
                    </Form.Group>
                    <Form.Group>
                      <Form.Label>{t('txt-business-type')}</Form.Label>
                      <Field
                        name="formBussinessType"
                        className="form-control input-order"
                        component={RenderInput}
                      />
                    </Form.Group>
                  </>
                )}
                <Form.Group>
                  <Form.Label>
                    {t('txt-card-type')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCardIdType"
                    className="form-control input-order"
                    component={RenderNormalSelect}
                    required
                    opts={
                      customerType === 'CA_NHAN'
                        ? glCardIDType
                        : glCardIDTypeOrg
                    }
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-card-id')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCardId"
                    className="form-control input-order"
                    component={RenderInput}
                    validate={[required, maxLength20]}
                    onBlur={_handleBlurCardId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-issue-date')}
                    {_.find(sysBpm, (o) => o.step === 'CHECK_ISSUE_DATE')
                      ?.value && <span className="text-danger">*</span>}
                  </Form.Label>
                  <Field
                    name="formIssueDate"
                    className="form-control input-order"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    validate={required}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-expire-date')}
                    {_.find(sysBpm, (o) => o.step === 'CHECK_EXPIRE')?.value}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formExpireDate"
                    className="form-control input-order"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    validate={validateExpireDate}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-issue-place')}
                    <span className="text-danger">*</span>
                    {/* {_.find(sysBpm, (o) => o.step === 'CHECK_ISSUE_PLACE')
                      ?.value && <span className="text-danger">*</span>} */}
                  </Form.Label>
                  <Field
                    name="formIssuePlace"
                    className="form-control input-order"
                    component={RenderSelectIssuePlace}
                    validate={required}
                    actionAdd
                    opts={glIssuePlace}
                    fnAddCallback={fnAddCallback}
                    // validate={
                    //   _.find(sysBpm, (o) => o.step === 'CHECK_ISSUE_PLACE')
                    //     ?.value
                    //     ? required
                    //     : null
                    // }
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-tax-code')}
                    {_.find(sysBpm, (o) => o.step === 'CHECK_TAX_CODE')
                      ?.value && <span className="text-danger">*</span>}
                  </Form.Label>
                  <Field
                    name="formTaxCode"
                    className="form-control input-order"
                    component={RenderInputNumber}
                    validate={
                      _.find(sysBpm, (o) => o.step === 'CHECK_TAX_CODE')?.value
                        ? required
                        : null
                    }
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-national')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formNationality"
                    className="form-control input-order fz-13"
                    component={RenderSuggestNational}
                    // opts={glNational}
                    required
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-resident-vn')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <div>
                    <label>
                      <Field
                        name="formResidentInVN"
                        component="input"
                        type="radio"
                        className="cursor-pointer"
                        value="1"
                      />{' '}
                      {t('txt-yes')}
                    </label>
                    <label className="ml-3">
                      <Field
                        name="formResidentInVN"
                        component="input"
                        type="radio"
                        className="cursor-pointer"
                        value="0"
                      />{' '}
                      {t('txt-no')}
                    </label>
                  </div>
                </Form.Group>

                {/* <Form.Group>
                  <Form.Label>VSD SID</Form.Label>
                  <Field
                    name="formVsdSid"
                    className="form-control input-order"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Mã NĐT</Form.Label>
                  <Field
                    name="formInvestorCode"
                    className="form-control input-order"
                    component={RenderInput}
                  />
                </Form.Group> */}

                {/* TODO: Tabs Section  */}
                <TabsSectionHeader>
                  <ul style={{ backgroundColor: 'rgba(28, 28, 28, 0.12)' }}>
                    <li
                      onClick={() => setTabActive('THONG_TIN_LIEN_HE')}
                      className={
                        (tabActive === 'THONG_TIN_LIEN_HE' ? 'active ' : '') +
                        (errors?.thongTinLienHe &&
                        Object.keys(errors?.thongTinLienHe)?.length > 0
                          ? 'error'
                          : '')
                      }
                    >
                      {t('txt-contact-info')}
                    </li>
                    {customerType === 'TO_CHUC' && (
                      <li
                        onClick={() => setTabActive('THONG_TIN_DAI_DIEN')}
                        className={
                          (tabActive === 'THONG_TIN_DAI_DIEN'
                            ? 'active '
                            : '') +
                          (errors?.thongTinDaiDien &&
                          Object.keys(errors?.thongTinDaiDien)?.length > 0
                            ? 'error'
                            : '')
                        }
                      >
                        {t('txt-representative')}
                      </li>
                    )}
                    {customerType !== 'TO_CHUC' && (
                      <li
                        onClick={() => setTabActive('NGUOI_GIAM_HO')}
                        className={
                          (tabActive === 'NGUOI_GIAM_HO' ? 'active ' : '') +
                          (errors?.nguoiGiamHo &&
                          Object.keys(errors?.nguoiGiamHo)?.length > 0
                            ? 'error'
                            : '')
                        }
                      >
                        {t('txt-guardian')}
                      </li>
                    )}
                    <li
                      onClick={() => setTabActive('XAC_THUC_KH')}
                      className={
                        (tabActive === 'XAC_THUC_KH' ? 'active ' : '') +
                        (errors?.xacthucTK &&
                        _.some(
                          errors?.xacthucTK,
                          (o) => o && Object.keys(o)?.length > 0
                        )
                          ? 'error'
                          : '')
                      }
                    >
                      {t('txt-cust-authentication')}
                    </li>
                    <li
                      onClick={() => setTabActive('TAI_KHOAN_NGAN_HANG')}
                      className={
                        (tabActive === 'TAI_KHOAN_NGAN_HANG' ? 'active ' : '') +
                        (errors?.banks &&
                        _.some(
                          errors?.banks,
                          (o) => o && Object.keys(o)?.length > 0
                        )
                          ? 'error'
                          : '')
                      }
                    >
                      {t('txt-ben-acc')}
                    </li>
                  </ul>
                </TabsSectionHeader>
                <FormSection name="thongTinLienHe">
                  <ThongTinKhachHang
                    t={t}
                    data={thongTinKhachHang}
                    className={
                      tabActive === 'THONG_TIN_LIEN_HE' ? 'active' : ''
                    }
                    customerType={customerType}
                    bpmLienHe={bpmLienHe}
                  />
                </FormSection>
                <FormSection name="nguoiGiamHo">
                  <ThongTinLienHe
                    t={t}
                    data={thongTinKhachHang}
                    className={tabActive === 'NGUOI_GIAM_HO' ? 'active' : ''}
                    isCheckGiamHo={isCheckGiamHo}
                    bpmGiamHo={bpmGiamHo}
                    glIssuePlace={glIssuePlace}
                  />
                </FormSection>
                <FormSection name="thongTinDaiDien">
                  <ThongTinDaiDien
                    t={t}
                    glNational={glNational}
                    data={thongTinKhachHang}
                    className={
                      tabActive === 'THONG_TIN_DAI_DIEN' ? 'active' : ''
                    }
                    customerType={customerType}
                    bpmDaiDien={bpmDaiDien}
                    glCardIDType={glCardIDType}
                    glIssuePlace={glIssuePlace}
                  />
                </FormSection>
                <div
                  style={{
                    gridColumn: '1/5',
                    display: tabActive === 'XAC_THUC_KH' ? 'block' : 'none',
                  }}
                >
                  <FieldArray
                    name="xacthucTK"
                    component={XacThucAccount}
                    t={t}
                    onPreview={setImgPreview}
                  />
                </div>
                <div
                  style={{
                    gridColumn: '1/5',
                    display:
                      tabActive === 'TAI_KHOAN_NGAN_HANG' ? 'block' : 'none',
                  }}
                >
                  <FieldArray
                    name="banks"
                    glAllBank={glAllBank}
                    glProvince={glProvince}
                    glAllSubBranch={glAllSubBranch}
                    glAccBenType={glAccBenType}
                    glChannelType={glChannelType}
                    component={BanksAccount}
                    custName={formCustName}
                    handleToast={_handleToast}
                    t={t}
                  />
                </div>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-confirm')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {imgPreview && <ImagesViewer onClose={handleClose} imgs={[imgPreview]} />}
      {detailMarketingId && (
        <DetailMarketingId
          id={detailMarketingId}
          onClose={() => setDetailMarketingId(null)}
        />
      )}
      {createIssuePlace && (
        <CreateIssuePlace
          onClose={() => setCreateIssuePlace(false)}
          setIssuePlace={setIssuePlace}
        />
      )}
    </ReactModal>
  );
}

AddKhachHangModal = reduxForm({
  form: 'openCustomerModalform',
  enableReinitialize: true,
  warn,
})(AddKhachHangModal);

const selector = formValueSelector('openCustomerModalform');

const mapStateToProps = (state, _props) => {
  const getToken = makeGetToken();
  const getCustomerUpdate = makeGetCustomerUpdate();
  const getProvinceList = makeGetProvinceList();
  const getNationalList = makeGetNationalList();
  const getAllBank = makeGetAllBank();
  const getAllSubBranch = makeGetAllSubBranch();
  const getSingleUserFront = makeGetSingleUserFront();
  const getSysBpmByType = makeGetSysBpmByType();
  const getAccBenType = makeGetAccBenType();
  const getChannelType = makeGetChannelType();
  const getCustCodeAuto = makeGetCustCodeAuto();
  const getGlobalCardIDType = makeGetGlobalCardIDType();
  const getGlobalCardIDTypeOrg = makeGetGlobalCardIDTypeOrg();
  const getGlIssuePlace = makeGetGlIssuePlace();
  const {
    formCustomerType,
    formCustCode,
    formCustName,
    formCustShortName,
    formMktId,
    formBussinessType,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formVsdSid,
    formInvestorCode,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formTaxCode,
    formNationality,
    formResidentInVN,
    formStaffFlag,

    thongTinLienHe,
    nguoiGiamHo,
    thongTinDaiDien,
    banks,
    xacthucTK,
  } = selector(
    state,
    'formCustomerType',
    'formCustCode',
    'formCustName',
    'formCustShortName',
    'formMktId',
    'formBussinessType',
    'formCustGender',
    'formBirthDate',
    'formCardIdType',
    'formCardId',
    'formInvestorCode',
    'formVsdSid',
    'formIssueDate',
    'formExpireDate',
    'formIssuePlace',
    'formTaxCode',
    'formNationality',
    'formResidentInVN',
    'formStaffFlag',

    'thongTinLienHe',
    'nguoiGiamHo',
    'thongTinDaiDien',
    'banks',
    'xacthucTK'
  );

  return {
    token: getToken(state),
    glProvince: getProvinceList(state),
    glNational: getNationalList(state),
    custUpd: getCustomerUpdate(state),
    glAllBank: getAllBank(state),
    glAllSubBranch: getAllSubBranch(state),
    singleUserFront: getSingleUserFront(state),
    glCardIDType: getGlobalCardIDType(state),
    glCardIDTypeOrg: getGlobalCardIDTypeOrg(state),
    glIssuePlace: getGlIssuePlace(state),

    sysBpm: getSysBpmByType(
      state,
      formCustomerType === 'CA_NHAN' ? 'INDIVIDUAL' : 'ORGANIZATION'
    ),
    glAccBenType: getAccBenType(state),
    glChannelType: getChannelType(state),
    custCodeAuto: getCustCodeAuto(state),

    formCustomerType,
    formCustCode,
    formCustName,
    formCustShortName,
    formMktId,
    formBussinessType,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formVsdSid,
    formInvestorCode,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formTaxCode,
    formNationality,
    formResidentInVN,
    formStaffFlag,

    thongTinLienHe,
    nguoiGiamHo,
    thongTinDaiDien,
    banks,
    xacthucTK,

    errors: getFormSyncErrors('openCustomerModalform')(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddKhachHangModal)
);
