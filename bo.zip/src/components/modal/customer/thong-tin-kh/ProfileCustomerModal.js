import React from 'react';
import { connect, useDispatch } from 'react-redux';

import ReactModal from 'react-modal';

import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';

import * as _ from 'lodash';

import { makeGetToken } from 'lib/selector';
import { translate } from 'react-i18next';
import { makeGetNationalList } from 'lib/selector';
import { makeGetCommPackage } from 'lib/selector';
import { makeGetAccountFrontType } from 'lib/selector';
import { makeGetDepositCode } from 'lib/selector';
import { makeGetCustomerDetail } from 'lib/selector';
import { makeGetAuthenType } from 'lib/selector';
import { makeGetInternetFunc } from 'lib/selector';
import { makeGetLimitedService } from 'lib/selector';
import { accountSingleRequest } from 'containers/account/actions';

import DefThumb from 'assets/img/default-thumbnail.png';
import NoData from 'assets/img/no-data.png';
import TableChangeHistory from './layout/TableChangeHistory';
import { custDetailRequest } from 'containers/customer/actions';
import { custDetailSuccess } from 'containers/customer/actions';
import { BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '0',
    bottom: '0',
    right: '0',
    left: '0',
    // left: 'calc( 50% - 375px )',
    // height: 'auto',
    // width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: grid;
  grid-template-columns: 250px auto;
  column-gap: 10px;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const StyleCustomerInfo = styled.div`
  display: grid;
  grid-template-columns: 75px 100px auto 100px;
  gap: 10px;

  font-size: 13px;
  align-items: baseline;
  border-bottom: 1px solid #e2e8f0;

  ul.cust-info {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;

    li {
      display: grid;
      grid-template-columns: 75px auto;
      gap: 10px;

      span:last-of-type {
        color: #000;
      }
    }
  }
`;

const TabsHeaderCustomerInfo = styled.div`
  grid-column: 1/5;
  display: flex;
  background: aliceblue;
  padding: 5px 0 5px 5px;
  border-radius: 5px;

  ul {
    display: flex;
    font-size: 13px;

    li {
      padding: 5px 10px;
      cursor: pointer;

      &.active {
        background: #fffbeb;

        border: 1px solid #fcbd17;
        border-radius: 5px;
      }
    }
  }
`;

const LeftContent = styled.div`
  display: flex;
  flex-direction: column;

  .left-header {
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 24px;
    color: #1a202c;
  }

  img {
    width: -webkit-fill-available;
  }
`;

const StyleTabContent = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const SubTabsHeader = styled.div`
  display: flex;
  background: #e2e8f0;
  padding: 5px 0 5px 5px;

  ul {
    display: flex;
    font-size: 13px;

    li {
      padding: 5px 10px;
      cursor: pointer;
      color: #718096;

      &.active {
        background: #9d9d9d;
        border: 1px solid #939393;
        border-radius: 5px;
        color: #fff;
      }
    }
  }
`;

const SubTabsContent = styled.div`
  height: calc(100vh - 240px);
`;

//#endregion

function ProfileAccountModal(props) {
  const dispatch = useDispatch();
  const [tabActive, setTabActive] = React.useState('TAI_KHOAN_CO_SO');
  const [subTabActive, setSubTabActive] = React.useState('LICH_SU_THAY_DOI');

  const { token, custDetail, accountCode } = props;

  React.useEffect(() => {
    if (accountCode) {
      handleGetSingleCustomer();
    }

    return () => {
      dispatch(custDetailSuccess(null));
    };
  }, []);

  function handleGetSingleCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: accountCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function handleGetCustomerLimited() {}

  function handleGetSingleAccount(type) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: accountCode + (type === 'TAI_KHOAN_CO_SO' ? 1 : 8),
      },
    };

    dispatch(accountSingleRequest(params));
  }

  const { onClose, t } = props;

  //   console.log(custDetail, glNational)

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-acc-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <div className="d-flex align-items-center justify-content-center">
            {custDetail?.C_FACE_IMAGE ? (
              <img
                src={custDetail?.C_FACE_IMAGE}
                alt=""
                style={{
                  maxHeight: '130px',
                  maxWidth: '-webkit-fill-available',
                }}
              />
            ) : (
              <img src={DefThumb} alt="" height={130} />
            )}
          </div>
          <StyleCustomerInfo>
            <label>{t('txt-account')}</label>
            <label>{custDetail?.C_CUSTOMER_CODE}</label>
            <ul className="cust-info">
              <li>
                <span>{t('txt-full-name')}</span>
                <b>{custDetail?.C_CUSTOMER_NAME}</b>
              </li>
              <li>
                <span>NV chăm sóc</span>
                <span>{custDetail?.C_MARKETING_ID}</span>
              </li>
              <li>
                <span>{t('txt-card-id')}</span>
                <span>{custDetail?.C_CARD_ID}</span>
              </li>
              <li>
                <span>{t('txt-issue-date')}</span>
                <span>{custDetail?.C_ISSUE_DATE}</span>
              </li>
              <li>
                <span> {t('txt-mobile')}</span>
                <span>{custDetail?.C_CUST_MOBILE}</span>
              </li>
              <li>
                <span>{t('txt-contact-address')}</span>
                <span>{custDetail?.C_CUST_ADDRESS}</span>
              </li>
            </ul>
            <div>
              <BtnSubmit type="button" className="mx-1 w-100 success">
                {t('txt-change')}
              </BtnSubmit>
            </div>
            <TabsHeaderCustomerInfo>
              <ul>
                <li
                  onClick={() => setTabActive('TAI_KHOAN_CO_SO')}
                  className={tabActive === 'TAI_KHOAN_CO_SO' ? 'active' : ''}
                >
                  {t('txt-acc-cs')}
                </li>
                <li
                  onClick={() => setTabActive('TAI_KHOAN_PHAI_SINH')}
                  className={
                    tabActive === 'TAI_KHOAN_PHAI_SINH' ? 'active' : ''
                  }
                >
                  {t('txt-acc-ps')}
                </li>
              </ul>
            </TabsHeaderCustomerInfo>
          </StyleCustomerInfo>
          <LeftContent>
            <span className="left-header">{t('txt-acc-bank')}</span>
            <div>
              <img src={NoData} alt="" />
            </div>
            <span className="left-header mt-2">{t('txt-limited-service')}</span>
            <div>
              <img src={NoData} alt="" />
            </div>
          </LeftContent>
          <StyleTabContent>
            <SubTabsHeader>
              <ul>
                <li
                  onClick={() => setSubTabActive('LICH_SU_THAY_DOI')}
                  className={
                    subTabActive === 'LICH_SU_THAY_DOI' ? 'active' : ''
                  }
                >
                  {t('txt-history')}
                </li>
                <li
                  onClick={() => setSubTabActive('TRANG_THAI_TK')}
                  className={subTabActive === 'TRANG_THAI_TK' ? 'active' : ''}
                >
                  {t('txt-acc-status')}
                </li>
                <li
                  onClick={() => setSubTabActive('DANH_MUC_DAU_TU')}
                  className={subTabActive === 'DANH_MUC_DAU_TU' ? 'active' : ''}
                >
                  {t('txt-portfolio-investment')}
                </li>
              </ul>
            </SubTabsHeader>
            <SubTabsContent>
              {subTabActive === 'LICH_SU_THAY_DOI' && (
                <TableChangeHistory t={t} />
              )}
              {/* {subTabActive === 'TRANG_THAI_TK' && (
                <AccountStatusListed t={t} singleAccount={singleAccount} />
              )} */}
            </SubTabsContent>
          </StyleTabContent>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getNationalList = makeGetNationalList();
  const getCommPackage = makeGetCommPackage();
  const getAccountFrontType = makeGetAccountFrontType();
  const getDepositCode = makeGetDepositCode();
  const getAuthenType = makeGetAuthenType();
  const getInternetFunc = makeGetInternetFunc();
  const getLimitedService = makeGetLimitedService();
  const getCustomerDetail = makeGetCustomerDetail();

  return {
    token: getToken(state),
    glCommPackage: getCommPackage(state),
    glAccFrontType: getAccountFrontType(state),
    glDepositCode: getDepositCode(state),
    glNational: getNationalList(state),
    glAuthenType: getAuthenType(state),
    glInternetFunc: getInternetFunc(state),
    glLimitedService: getLimitedService(state),

    custDetail: getCustomerDetail(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(ProfileAccountModal)
);
