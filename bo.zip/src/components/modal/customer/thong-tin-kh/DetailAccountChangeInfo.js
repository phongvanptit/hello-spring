import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { Form, Table } from 'react-bootstrap';
import {
  Field,
  FieldArray,
  FormSection,
  change,
  formValueSelector,
  reduxForm,
  updateSyncErrors,
} from 'redux-form';
import {
  maxLength,
  minLength,
  required,
  // validateAddBen,
  validateTTHH
} from 'utils/validation';
import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { BsTrash } from 'react-icons/bs';
import { FaEye, FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { BtnClose, BtnSubmit, TabsSectionHeader } from 'utils/styledComponent';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderFileInput from 'components/input/renderFileInput';
import RenderInput from 'components/input/renderInput';
import RenderSelectIssuePlace from 'components/input/inputSelectIssuePlace';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { setToast } from 'containers/client/actions';
import { accBenUpdRequest, accBenUpdSuccess } from 'containers/account/actions';
import CreateIssuePlace from './layout/CreateIssuePlace';
import RenderSuggestNational from 'components/input/renderSuggestNationalNew';
import {
  makeGetCustomerApprove,
  makeGetCustomerDetail,
  makeGetNationalList,
  makeGetSingleUserFront,
  makeGetToken,
  makeGetGlobalCardIDType,
  makeGetAllSubBranch,
  makeGetAllBank,
  makeGetAccBenType,
  makeGetProvinceList,
  makeGetAccBenUpdate,
  makeGetCustomerUpdate,
} from 'lib/selector';

import {
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import {
  custApproveRequest,
  custDetailRequest,
  custDetailSuccess,
  custUpdateSuccess,
  custUpdateRequest,
} from 'containers/customer/actions';

import { accBenSingleRequest } from 'containers/account/actions';
// import { validateAddBen } from 'utils/validation';
import ImagesViewer from 'components/images-viewer/imageViewer';
import DetailMarketingId from 'components/modal/detail-pop-up/detailMarketingId';
import { accBenSingleSuccess } from 'containers/account/actions';
import {
  custDeleteRequest,
  custRejectRequest,
} from 'containers/customer/actions';
import {
  makeGetCustomerDelete,
  makeGetCustomerReject,
  makeGetAccBenSingle,
  makeGetGlIssuePlace,
  makeGetGlobalCardIDTypeOrg,
} from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnDetail } from 'utils/styledComponent';
import {
  removeAccent,
  formatDate,
  _diff2Date,
  getAge,
  StringToInt,
} from 'utils';
import ThongTinLienHe1 from './layout/ThongTinLienHe';
import NguoiGiamHo1 from './layout/NguoiGiamHo';
import ThongTinDaiDien1 from './layout/ThongTinDaiDien';
import BanksAccount1 from './layout/BanksAccount';
import XacThucAccount1 from './layout/XacThucAccount';
import { globalIssuePlaceSuccess } from 'containers/global/actions';
import { globalIssuePlaceRequest } from 'containers/global/actions';

ReactModal.setAppElement('#root');

const arrTypeXT = [
  { value: 'ANH_MAT_TRUOC', label: 'CMT/CCCD (mặt trước)' },
  { value: 'ANH_MAT_SAU', label: 'CMT/CCCD (mặt sau)' },
  { value: 'ANH_CHAN_DUNG', label: 'Ảnh chân dung' },
  { value: 'ANH_CHU_KY', label: 'Chữ ký' },
];

const appUrl = `${process.env.REACT_APP_API_URL}`;
const fileUrl = `${process.env.REACT_APP_FILE_URL}/upload`;
//#region styled

const customStyles = {
  content: {
    inset: '40px 200px auto',
    height: 'auto',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.form`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;

  input.form-control,
  label {
    font-size: 13px;
  }
`;
const maxLength20 = maxLength(12);
const warn = (values) => {
  const warns = {};
  //var format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  var format = /[`!@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?~]/;
  const { formCustName } = values;
  let _arr = [];
  if (formCustName) {
    // if (format.test(formCustName) && /[0-9]/.test(formCustName)) {
    //   _arr.push('Tên khách hàng có ký tự số, ký tự đặc biệt');
    // } else 
    if (format.test(formCustName)) {
      _arr.push('Tên khách hàng có ký tự đặc biệt');
    } 
    // else if (/[0-9]/.test(formCustName))
    //   _arr.push('Tên khách hàng có ký tự số')
    ;
  }
  warns.formCustName = _arr;
  return warns;
};

//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailCustChangeInfoModal(props) {
  const abortController = new AbortController();

  const dispatch = useDispatch();
  const [tabActive, setTabActive] = React.useState('THONG_TIN_LIEN_HE');
  const [checkAdd, setCheckAdd] = useState(false);
  const [arrProperty, setArrProperty] = React.useState([]);
  const [imgPreview, setImgPreview] = React.useState(null);
  const [detailMarketingId, setDetailMarketingId] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isCheckGiamHo, setIsCheckGiamHo] = React.useState(false);
  const [bpmLienHe, setBpmLienHe] = React.useState(null);
  const [bpmGiamHo, setBpmGiamHo] = React.useState(null);
  const [bpmDaiDien, setBpmDaiDien] = React.useState(null);
  const [createIssuePlace, setCreateIssuePlace] = React.useState(false);
  const [checkSubmit, setCheckSubmit] = React.useState(null);
  const {
    submitting,
    token,
    formMktId,
    custDetail,
    customerType,
    t,
    accRight,
    thongTinKhachHang,
    record,
    onClose,
    handleSubmit,
    singleUserFront,
    glCardIDTypeOrg,
    glCardIDType,
    glNational,
    accBenSingle,
    readonly,
    glIssuePlace,
    glAllBank,
    glProvince,
    glAllSubBranch,
    glAccBenType,
    glChannelType,
    formCustName,
    custAppr,
    custReject,
    custDel,
    formCustCode,
    accBenUpd,
    fields,
    id,
    custUpd,
    formBirthDate,
    formCardId,
    errors,
    sysBpm,
    action,
  } = props;

  const preCustomerType = usePrevious(customerType);
  const preCustDetail = usePrevious(custDetail);
  const preCustAppr = usePrevious(custAppr);
  const preCustReject = usePrevious(custReject);
  const preCustDel = usePrevious(custDel);
  const preAccBenUpd = usePrevious(accBenUpd);
  const preCustUpdate = usePrevious(custUpd);
  const preSysBpm = usePrevious(sysBpm);
  const preFormBirthDate = usePrevious(formBirthDate);
  let _filePaths = {};

  React.useEffect(() => {
    handleGetSingleCustomer();
    handleGetDetailBen();
    getGlobalIssuePlace();

    return () => {
      abortController.abort();

      dispatch(custDetailSuccess(null));
      dispatch(singleUserFrontSuccess(null));
      dispatch(accBenSingleSuccess(null));
      dispatch(custUpdateSuccess(null));
      dispatch(globalIssuePlaceSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (custUpd && !_.isEqual(custUpd, preCustUpdate)) {
      onClose();
    }
  }, [custUpd]);

  React.useEffect(() => {
    if (sysBpm && !_.isEqual(sysBpm, preSysBpm)) {
      let checkLienHe = {},
        checkGiamHo = {},
        checkDaiDien = {};
      checkLienHe.CHECK_CUST_ADDR =
        _.find(sysBpm, (o) => o.step === 'CHECK_CUST_ADDR')?.value || false;
      checkLienHe.CHECK_RESEDENCE_ADDR =
        _.find(sysBpm, (o) => o.step === 'CHECK_RESEDENCE_ADDR')?.value ||
        false;
      checkLienHe.CHECK_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_MOBILE')?.value || false;
      checkLienHe.CHECK_EMAIL =
        _.find(sysBpm, (o) => o.step === 'CHECK_EMAIL')?.value || false;

      checkGiamHo.CHECK_CONTACT_NAME =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_NAME')?.value || false;
      checkGiamHo.CHECK_CONTACT_RELATION =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_RELATION')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_CARDID =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_CARDID')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ISSUE_DATE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ISSUE_DATE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ISSUE_PLACE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ISSUE_PLACE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ADDRESS =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ADDRESS')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_MOBILE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_EMAIL =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_EMAIL')?.value || false;

      checkDaiDien.CHECK_REPRE_NAME =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_NAME')?.value || false;
      checkDaiDien.CHECK_REPRE_CARDID =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_CARDID')?.value || false;
      checkDaiDien.CHECK_REPRE_ISSUE_DATE =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_ISSUE_DATE')?.value ||
        false;
      checkDaiDien.CHECK_REPRE_POSITION =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_POSITION')?.value ||
        false;
      checkDaiDien.CHECK_REPRE_TEL =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_TEL')?.value || false;
      checkDaiDien.CHECK_REPRE_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_MOBILE')?.value || false;

      setBpmLienHe(checkLienHe);
      setBpmGiamHo(checkGiamHo);
      setBpmDaiDien(checkDaiDien);
    }
  }, [sysBpm]);

  React.useEffect(() => {
    if (custDetail && !_.isEqual(custDetail, preCustDetail)) {
      initForm();
      if (custDetail?.C_STATUS === 'CHUA_DUYET') {
        handleGetPropertyChange();
      }
    }
  }, [custDetail]);

  React.useEffect(() => {
    if (customerType && !_.isEqual(customerType, preCustomerType)) {
      if (customerType === 'CA_NHAN' && tabActive === 'THONG_TIN_DAI_DIEN')
        setTabActive('THONG_TIN_LIEN_HE');
    }
  }, [customerType]);

  React.useEffect(() => {
    if (formMktId && formMktId.length === 4) {
      _handleCheckMKT();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMktId]);

  React.useEffect(() => {
    if (formBirthDate && !_.isEqual(formBirthDate, preFormBirthDate)) {
      const _errText = validateBirthDate(formBirthDate);

      dispatch(
        updateSyncErrors('detailCustomerModalform', {
          ...errors,
          formBirthDate: _errText,
        })
      );
    }
  }, [formBirthDate]);

  React.useEffect(() => {
    if (
      (custAppr && !_.isEqual(custAppr, preCustAppr)) ||
      (custReject && !_.isEqual(custReject, preCustReject)) ||
      (custDel && !_.isEqual(custDel, preCustDel))
    ) {
      onClose();
    }
  }, [custAppr, custReject, custDel]);

  React.useEffect(() => {
    if (accBenUpd && checkAdd && !_.isEqual(accBenUpd, preAccBenUpd)) {
      handleGetDetailBen();
      setCheckAdd(false);
    }
  }, [accBenUpd]);

  function initForm() {
    const custSingle =
      custDetail.C_STATUS === 'DANG_SUA_DOI' && custDetail?.C_DATA
        ? JSON.parse(custDetail?.C_DATA)
        : custDetail;

    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'customerType',
        custDetail?.C_CUSTOMER_TYPE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formCustCode',
        custDetail?.C_CUSTOMER_CODE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formCustName',
        custSingle?.C_CUSTOMER_NAME
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formCustShortName',
        custSingle?.C_CUST_SHORT_NAME
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formMktId',
        custSingle?.C_MARKETING_ID
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formBussinessType',
        custSingle?.C_BUSINESS_TYPE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formCustGender',
        custSingle?.C_CUST_GENDER
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formBirthDate',
        custSingle?.C_BIRTH_DAY
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formCardIdType',
        custSingle?.C_CARD_ID_TYPE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formCardId',
        custSingle?.C_CARD_ID
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formIssueDate',
        custSingle?.C_ISSUE_DATE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formExpireDate',
        custSingle?.C_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formIssuePlace',
        custSingle?.C_ISSUE_PLACE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formTaxCode',
        custSingle?.C_TAX_CODE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formNationality',
        custSingle?.C_NATIONAL_CODE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formResidentInVN',
        custSingle?.C_VN_FLAG + ''
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formVsdSid',
        custSingle?.C_VSD_SID 
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formInvestorCode',
        custSingle?.C_INVESTOR_CODE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'formStaffFlag',
        custSingle?.C_STAFF_FLAG + ''
      )
    );
    // thông tin liên hệ
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhResedenceAddr',
        custSingle?.C_RESEDENCE_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhContactAddr',
        custSingle?.C_CUST_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhProvince',
        custSingle?.C_PROVINCE_CODE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhTel',
        custSingle?.C_CUST_TEL
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhFax',
        custSingle?.C_CUST_FAX
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhMobile',
        custSingle?.C_CUST_MOBILE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhEmail',
        custSingle?.C_CUST_EMAIL
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinLienHe.ttkhNote',
        custSingle?.C_CONTENT
      )
    );
    // nguoi giam ho
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhName',
        custSingle?.C_REPRE_NAME
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhRelation',
        custSingle?.C_REPRE_POSITION
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhCardId',
        custSingle?.C_REPRE_CARD_ID
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhIssueDate',
        custSingle?.C_REPRE_ISSUE_DATE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhExpireDate',
        custSingle?.C_REPRE_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhIssuePlace',
        custSingle?.C_REPRE_ISSUE_PLACE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhAddress',
        custSingle?.C_REPRE_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhMobile',
        custSingle?.C_REPRE_MOBILE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'nguoiGiamHo.ttlhEmail',
        custSingle?.C_REPRE_EMAIL
      )
    );
    //Thong tin dai dien
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddName',
        custSingle?.C_REPRE_NAME
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddNationality',
        custSingle?.C_REPRE_NATIONAL_CODE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddResidentInVN',
        custSingle?.C_REPRE_VN_FLAG + ''
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddCardIdType',
        custSingle?.C_REPRE_CARD_ID_TYPE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddCardID',
        custSingle?.C_REPRE_CARD_ID
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddIssueDate',
        custSingle?.C_REPRE_ISSUE_DATE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddIssuePlace',
        custSingle?.C_REPRE_ISSUE_PLACE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddPosition',
        custSingle?.C_REPRE_POSITION
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddAddress',
        custSingle?.C_REPRE_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddGender',
        custSingle?.C_REPRE_GENDER
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddEmail',
        custSingle?.C_REPRE_EMAIL
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddMobile',
        custSingle?.C_REPRE_MOBILE
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddTel',
        custSingle?.C_REPRE_TEL
      )
    );
    dispatch(
      change(
        'detailCustChangeInfoModalForm',
        'thongTinDaiDien.ttddAuthenSign',
        custSingle?.C_AUTHEN_SIGN
      )
    );
    //Xác thực khách hàng
    let _xts = [];
    
    if (custDetail.C_FRONT_CARD_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_MAT_TRUOC',
        xtAccountImage: custDetail.C_FRONT_CARD_IMAGE,
        xtImageName: custDetail.C_FILE_NAME_FRONT_CARD,
      });
    }
    if (custDetail.C_BACK_CARD_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_MAT_SAU',
        xtAccountImage: custDetail.C_BACK_CARD_IMAGE,
        xtImageName: custDetail.C_FILE_NAME_BACK_CARD,
      });
    }
    if (custDetail.C_FACE_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_CHAN_DUNG',
        xtAccountImage: custDetail.C_FACE_IMAGE,
        xtImageName: custDetail.C_FILE_NAME_FACE_IMAGE,
      });
    }
    if (custDetail.C_SIGN_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_CHU_KY',
        xtAccountImage: custDetail.C_SIGN_IMAGE,
        xtImageName: custDetail.C_FILE_NAME_SIGN_IMAGE,
      });
    }
    console.log('xt',_xts);
    dispatch(change('detailCustChangeInfoModalForm', 'xacthucTK', _xts));
  }

  function handleGetSingleCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: record?.C_CUSTOMER_CODE,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function handleGetDetailBen() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACC_BEN',
      group: 'LIST',
      data: {
        ITEM_ID: record?.C_CUSTOMER_CODE,
      },
    };

    dispatch(accBenSingleRequest(params));
  }

  function handleGetPropertyChange() {
    const _arrProperty = [];
    const _dest = Object.assign({}, custDetail);
    delete _dest.C_DATA;
    const _source = custDetail?.C_DATA ? JSON.parse(custDetail?.C_DATA) : [];
    if (_dest && _source)
      Object.keys(_dest).forEach((element) => {
        if (!_.isEqual(_dest[element.trim()] + '', _source[element.trim()])) {
          _arrProperty.push(element.trim());
        }
      });

    setArrProperty(_arrProperty);
  }

  function _handleBlurCardId() {
    if (
      formCardId &&
      _.find(sysBpm, (o) => o.step === 'CHECK_CARDID')?.value === true
    ) {
      _handleCheckCustomer('formCardId', 10);
    }
  }

  function _handleCheckCustomer(name, times = 1000) {
    if (!props[name]) {
      // dispatch(touch('addAccountInfoform', 'custCode'))
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: props[name],
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        if (res.code == 1 && res.data.length > 0) {
          _handleToast(`${t('txt-exists')}`, 'error');

          setTimeout(() => {
            dispatch(change('detailCustomerModalform', name, '', false));
          }, times);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function submit(values) {
    if (!action && !checkSubmit) handleConfirmAcc(values);
  }

  function handleActionEditAcc(values) {
    if (values.xacthucTK && values.xacthucTK) {
      var iterator = asyncIterator(values.xacthucTK);
      handleUploadAnh(values, iterator);
    } else {
      handleNextProcess(values, null);
    }
  }

  function asyncIterator(_array) {
    return {
      next: function () {
        if (_array.length) {
          return {
            value: _array.shift(),
            done: false,
          };
        } else {
          return {
            done: true,
          };
        }
      },
    };
  }

  function handleUploadAnh(values, iterator) {
    const _iterator = iterator.next();
    if (_iterator.done) {
      // next process
      handleNextProcess(values, _filePaths);
    } else {
      // upload
      // check file
      if (typeof _iterator.value.xtAccountImage === 'string') {
        // next
        handleUploadAnh(values, iterator);
      } else {
        // upload
        fileUpload(_iterator.value.xtAccountImage).then((response) => {
          if (response.code > 0) {
            // create request
            switch (_iterator.value.xtAccountType) {
              case 'ANH_MAT_TRUOC':
                _filePaths.pathAnhMt = response.FILE_DIR;
                break;
              case 'ANH_MAT_SAU':
                _filePaths.pathAnhMs = response.FILE_DIR;
                break;
              case 'ANH_CHAN_DUNG':
                _filePaths.pathAnhCD = response.FILE_DIR;
                break;
              case 'ANH_CHU_KY':
                _filePaths.pathAnhCK = response.FILE_DIR;
                break;

              default:
                break;
            }
            handleUploadAnh(values, iterator);
          } else {
            setIsLoading(false);
            _handleToast(response.re);
          }
        });
      }
    }
  }

  function fileUpload(file) {
    console.log('file', file);
    const formData = new FormData();
    formData.append('file', file);
    console.log('formdata', formData);
    const request = fetch(fileUrl, {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    return request
      .then((response) => response.json())
      .then((json) => json)
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
  }

  function handleNextProcess(values, filePaths) {
    let _params;
    if (customerType === 'CA_NHAN') {
      _params = renderParamCaNhan(values);
    } else {
      _params = renderParamToChuc(values);
    }

    let _bankAccount = [];
    values.banks?.forEach((element) => {
      _bankAccount.push({
        BANK_CODE: element.bankName, // mã tk ngân hàng
        BANK_ACCOUNT_CODE: element.bankAccount, // số tk ngân hàng
        BANK_ACCOUNT_NAME: removeAccent(element.bankAccountName), // tên tài khoản ngân hàng
        BANK_BRANCH_CODE: element.bankBranch, // chi nhánh online
        BANK_BRANCH_NAME: element.bankBranchHand, //  chi nhánh nhập tay
        ACCOUNT_TYPE: element.accountType,
        CHANNEL_CODE: element.channel,
        PROVINCE_CODE: element.bankProvince,
      });
    });

    if (_params) {
      _params.data.FRONT_CARD_IMAGE = filePaths.pathAnhMt;
      _params.data.BACK_CARD_IMAGE = filePaths.pathAnhMs;
      _params.data.SIGN_IMAGE = filePaths.pathAnhCK;
      _params.data.FACE_IMAGE = filePaths.pathAnhCD;
      // tài khoản thụ hưởng
      _params.data.LIST_BANK_ACCOUNT = _bankAccount;
      {
        /* console.log(_params, filePaths); */
      }
      dispatch(custUpdateRequest(_params));
      setIsLoading(false);
    }
  }

  function renderParamCaNhan(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custDetail?.PK_CUST_CUSTOMER,
        MARKETING_ID: values.formMktId,
        CHANNEL_CODE: 'D',
        CUSTOMER_TYPE: 'CA_NHAN',
        CUSTOMER_CODE: values.formCustCode, // mã khách hàng
        //CUSTOMER_NAME: values.formCustName?.toUpperCase(),
        CUSTOMER_NAME: values.formCustName,
        CUST_PRE_NAME: '', // Tên tiền tố Mrs/Mr/Ms
        CARD_ID_TYPE: values.formCardIdType, // loại đăng ký sở hữu
        CARD_ID: values.formCardId,
        VSD_SID: values.formVsdSid,
        INVESTOR_CODE: values.formInvestorCode,
        BIRTH_DAY: values.formBirthDate,
        ISSUE_DATE: values.formIssueDate,
        EXPIRE_DATE: values.formExpireDate,
        ISSUE_PLACE: values.formIssuePlace,
        CUST_GENDER: values.formCustGender,
        CUST_EMAIL: values.thongTinLienHe?.ttkhEmail,
        CUST_MOBILE: values.thongTinLienHe?.ttkhMobile,
        CUST_TEL: values.thongTinLienHe?.ttkhTel,
        CUST_FAX: values.thongTinLienHe?.ttkhFax,
        // CUST_WEBSITE: values.thongTinKhachHang?.ttkhWebsite,
        CUST_ADDRESS: values.thongTinLienHe?.ttkhContactAddr,
        RESEDENCE_ADDRESS: values.thongTinLienHe?.ttkhResedenceAddr,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        PROVINCE_CODE: '',
        VN_FLAG: StringToInt(values.formResidentInVN),
        STAFF_FLAG: StringToInt(values.formStaffFlag),
        CONTENT: values.thongTinLienHe?.ttkhNote,
        AUTHEN_SIGN: values.thongTinDaiDien?.ttddAuthenSign,

        REPRE_NAME: values.nguoiGiamHo?.ttlhName,
        // REPRE_GENDER: values.nguoiGiamHo?.ttlhName,
        REPRE_POSITION: values.nguoiGiamHo?.ttlhRelation,
        REPRE_CARD_ID: values.nguoiGiamHo?.ttlhCardId,
        // REPRE_BIRTH_DAY: values.nguoiGiamHo?.ttlhName,
        REPRE_ISSUE_DATE: values.nguoiGiamHo?.ttlhIssueDate,
        REPRE_EXPIRE_DATE: values.nguoiGiamHo?.ttlhExpireDate,
        REPRE_ISSUE_PLACE: values.nguoiGiamHo?.ttlhIssuePlace,
        REPRE_ADDRESS: values.nguoiGiamHo?.ttlhAddress,
        REPRE_MOBILE: values.nguoiGiamHo?.ttlhMobile,
        // REPRE_TEL: values.nguoiGiamHo?.ttlhName,
        // REPRE_FAX: values.nguoiGiamHo?.ttlhName,
        REPRE_EMAIL: values.nguoiGiamHo?.ttlhEmail,
        // REPRE_VN_FLAG: values.nguoiGiamHo?.ttlhName,
        // REPRE_NATIONAL_CODE : values.nguoiGiamHo?.ttlhName,
      },
    };

    return params;
  }

  function getGlobalIssuePlace() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE: 'ISSUE_PLACE',
      },
    };
    dispatch(globalIssuePlaceRequest(params));
  }

  function renderParamToChuc(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custDetail?.PK_CUST_CUSTOMER,
        MARKETING_ID: values.formMktId,
        CHANNEL_CODE: 'D',
        CUSTOMER_TYPE: 'TO_CHUC',
        CUSTOMER_CODE: values.formCustCode,
        //CUSTOMER_NAME: values.formCustName?.toUpperCase(),
        CUSTOMER_NAME: values.formCustName,
        CUST_SHORT_NAME: values.formCustShortName?.toUpperCase(),
        BUSINESS_TYPE: values.formBussinessType,
        CARD_ID_TYPE: values.formCardIdType,
        CARD_ID: values.formCardId,
        VSD_SID: values.formVsdSid,
        INVESTOR_CODE: values.formInvestorCode,
        ISSUE_DATE: values.formIssueDate,
        EXPIRE_DATE: values.formExpireDate,
        ISSUE_PLACE: values.formIssuePlace,
        CUST_EMAIL: values.thongTinLienHe?.ttkhEmail,
        CUST_MOBILE: values.thongTinLienHe?.ttkhMobile,
        CUST_TEL: values.thongTinLienHe?.ttkhTel,
        CUST_FAX: values.thongTinLienHe?.ttkhFax,
        CUST_ADDRESS: values.thongTinLienHe?.ttkhContactAddr,
        RESEDENCE_ADDRESS: values.thongTinLienHe?.ttkhResedenceAddr,
        // CUST_WEBSITE: values.thongTinLienHe?.ttkhWebsite,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        PROVINCE_CODE: '',
        VN_FLAG: StringToInt(values.formResidentInVN),
        STAFF_FLAG: StringToInt(values.formStaffFlag),
        CONTENT: values.thongTinLienHe?.ttkhNote,
        AUTHEN_SIGN: values.thongTinDaiDien?.ttddAuthenSign,

        REPRE_NAME: values.thongTinDaiDien?.ttddName,
        REPRE_GENDER: values.thongTinDaiDien?.ttddGender,
        REPRE_POSITION: values.thongTinDaiDien?.ttddPosition,
        REPRE_CARD_ID_TYPE: values.thongTinDaiDien?.ttddCardIdType,
        REPRE_CARD_ID: values.thongTinDaiDien?.ttddCardID,
        // REPRE_BIRTH_DAY: values.thongTinDaiDien?.C_REPRE_BIRTH_DAY,
        REPRE_ISSUE_DATE: values.thongTinDaiDien?.ttddIssueDate,
        // REPRE_EXPIRE_DATE: values.thongTinDaiDien?.REPRE_EXPIRE_DATE,
        REPRE_ISSUE_PLACE: values.thongTinDaiDien?.ttddIssuePlace,
        REPRE_ADDRESS: values.thongTinDaiDien?.ttddAddress,
        REPRE_MOBILE: values.thongTinDaiDien?.ttddMobile,
        REPRE_TEL: values.thongTinDaiDien?.ttddTel,
        REPRE_FAX: '',
        REPRE_EMAIL: values.thongTinDaiDien?.ttddEmail,
        REPRE_VN_FLAG: StringToInt(values.thongTinDaiDien?.ttddResidentInVN),
        REPRE_NATIONAL_CODE: values.thongTinDaiDien?.ttddNationality,
      },
    };

    return params;
  }

  function handleConfirmAddBenAcc(values) {
    console.log(values);
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-ben-acc')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionAddBenAcc(values);
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleConfirmAcc(values) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-upd-cust')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionEditAcc(values);
                handleActionAddBenAcc(values);
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function _handleCheckMKT() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const validateBirthDate = (value) => {
    if (!value) return 'Trường không được để trống';

    const _isValidBirth = _.find(sysBpm, (o) => o.step === 'CHECK_AGE');
    if (_isValidBirth && _isValidBirth?.value === true) {
      //check ngày sinh ko lơn hơn ngày hiện tại
      const _diff = _diff2Date(value, formatDate(new Date(), '/', 'dmy'));
      if (_diff > 0) return 'Ngày sinh không đúng';
      const _age = getAge(value);
      for (let index = 0; index < _isValidBirth.data.length; index++) {
        const element = _isValidBirth.data[index];
        if (element.value === true && element.code === 'KHONG_DU_TUOI') {
          if (_age <= element?.v2 && _age >= element.v1) return 'Không đủ tuổi';
        }

        if (element.value === true && element.code === 'MO_TAI_KHOAN') {
          if (_age > element?.v2 || _age < element.v1)
            return `Chỉ mở tk từ ${element.v1} - ${element.v2} tuổi`;
        }
        if (element.value === true && element.code === 'CAN_GIAM_HO') {
          setIsCheckGiamHo(true);
        } else setIsCheckGiamHo(false);
      }
    } else setIsCheckGiamHo(false);
  };

  function handleClose() {
    setImgPreview(null);
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-cust')
                : actionName === 'approve'
                ? t('txt-appr-cust')
                : actionName === 'reject'
                ? t('txt-reject-cust')
                : ''}
            </p>
            <button
              onClick={() => {
                onClose();
                setCheckSubmit(null);
              }}
            >
              {t('txt-cancel')}
            </button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'reject':
                    handleActionReject();
                  default:
                    break;
                }
                setCheckSubmit(null);
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: false,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CUSTOMER',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: custDetail?.PK_CUST_CUSTOMER,
      },
    };

    dispatch(custDeleteRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CUSTOMER',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record.PK_CUST_CUSTOMER,
      },
    };

    dispatch(custApproveRequest(params));
  }

  function handleActionReject() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CUSTOMER',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record.PK_CUST_CUSTOMER,
      },
    };

    dispatch(custRejectRequest(params));
  }

  function handleActionAddBenAcc(values) {
    let _bankAccount = [];
    values?.banks?.forEach((element) => {
      _bankAccount.push({
        BANK_CODE: element.bankName, // mã tk ngân hàng
        BANK_ACCOUNT_CODE: element.bankAccount, // số tk ngân hàng
        BANK_ACCOUNT_NAME: removeAccent(element.bankAccountName), // tên tài khoản ngân hàng
        BANK_BRANCH_CODE: element.bankBranch, // chi nhánh online
        BANK_BRANCH_NAME: element.bankBranchHand, //  chi nhánh nhập tay
        ACCOUNT_TYPE: element.accountType,
        // CHANNEL_CODE: element.channel,
        PROVINCE_CODE: element.bankProvince,
      });
    });
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACC_BEN',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: formCustCode,
        OPEN_DATE: formatDate(new Date(), '/', 'dmy'),
        CONTENT: values.formContent,
        LIST_BANK_ACCOUNT: _bankAccount,
      },
    };
    dispatch(accBenUpdRequest(params));
  }

  function handleDetailMarketingId() {
    if (!formMktId) return;
    setDetailMarketingId(formMktId);
  }

  // thêm mới nơi cấp
  function fnAddCallback() {
    setCreateIssuePlace(true);
  }

  function setIssuePlace(code) {
    dispatch(change('detailCustomerModalform', 'formIssuePlace', code));
  }
console.log(props.xacthucTK)
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <div className="d-flex">
            <b className="fz-16 pl-3 mr-5">{t('txt-detail-cust')}</b>
            <div className="d-flex align-items-center">
              <Form.Group>
                <div>
                  <label>
                    <Field
                      name="customerType"
                      component="input"
                      type="radio"
                      className="cursor-pointer"
                      value={'CA_NHAN'}
                      disabled
                    />{' '}
                    {t('txt-individual-1')}
                  </label>
                  <label className="ml-3">
                    <Field
                      name="customerType"
                      component="input"
                      type="radio"
                      className="cursor-pointer"
                      value={'TO_CHUC'}
                      disabled
                    />{' '}
                    {t('txt-organization-1')}
                  </label>
                </div>
              </Form.Group>
            </div>
          </div>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <FormAdd onSubmit={handleSubmit(submit)}>
            <Form.Group>
              <Form.Label>{t('txt-cust-code')}</Form.Label>
              <Field
                name="formCustCode"
                className="form-control input-order"
                component={RenderInput}
                disabled
                space
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>ID Sale</Form.Label>
              <div className="d-flex justify-content-between">
                <div className="w-100">
                  <Field
                    name="formMktId"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_MARKETING_ID') > -1
                        ? ' hasChange'
                        : '')
                    }
                    classParent="w-100"
                    component={RenderNewInputMkt}
                  />
                </div>
                <BtnDetail
                  type="button"
                  onClick={() => handleDetailMarketingId()}
                />
              </div>
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-marketing-name')}</Form.Label>
              <Form.Control
                value={singleUserFront?.C_FRONT_USER_NAME || ''}
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-company-employee')}</Form.Label>
              <div>
                <label>
                  <Field
                    name="formStaffFlag"
                    component="input"
                    type="radio"
                    value="1"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_STAFF_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                  />{' '}
                  {t('txt-yes')}
                </label>
                <label className="ml-3">
                  <Field
                    name="formStaffFlag"
                    component="input"
                    type="radio"
                    value="0"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_STAFF_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                  />{' '}
                  {t('txt-no')}
                </label>
              </div>
            </Form.Group>
            <Form.Group style={{ gridColumn: '1/3' }}>
              <Form.Label>
                {customerType === 'CA_NHAN'
                  ? `${t('txt-cust-name')}`
                  : `${t('txt-organization-name')}`}
              </Form.Label>
              <Field
                name="formCustName"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_CUSTOMER_NAME') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderInput}
              />
            </Form.Group>
            {customerType === 'CA_NHAN' ? (
              <>
                <Form.Group>
                  <Form.Label>{t('txt-gender')}</Form.Label>
                  <div>
                    <label>
                      <Field
                        name="formCustGender"
                        component="input"
                        type="radio"
                        className={
                          'cursor-pointer' +
                          (arrProperty?.indexOf('C_CUST_GENDER') > -1
                            ? ' hasChange'
                            : '')
                        }
                        value="M"
                      />{' '}
                      {t('txt-male')}
                    </label>
                    <label className="ml-3">
                      <Field
                        name="formCustGender"
                        component="input"
                        type="radio"
                        className={
                          'cursor-pointer' +
                          (arrProperty?.indexOf('C_CUST_GENDER') > -1
                            ? ' hasChange'
                            : '')
                        }
                        value="F"
                      />{' '}
                      {t('txt-female')}
                    </label>
                  </div>
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-of-birth')}</Form.Label>
                  <Field
                    name="formBirthDate"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_BIRTH_DAY') > -1
                        ? ' hasChange'
                        : '')
                    }
                    classParentName="w-100"
                    component={RenderSelectDate}
                  />
                </Form.Group>
              </>
            ) : (
              <>
                <Form.Group>
                  <Form.Label>{t('txt-short-name')}</Form.Label>
                  <Field
                    name="formCustShortName"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_CUST_SHORT_NAME') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-business-type')}</Form.Label>
                  <Field
                    name="formBussinessType"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_BUSINESS_TYPE') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                  />
                </Form.Group>
              </>
            )}
            <Form.Group>
              <Form.Label>{t('txt-card-type')}</Form.Label>
              <Field
                name="formCardIdType"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_CARD_ID_TYPE') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderNormalSelect}
                required
                opts={
                  customerType === 'CA_NHAN' ? glCardIDType : glCardIDTypeOrg
                }
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-card-id')}</Form.Label>
              <Field
                name="formCardId"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_CARD_ID') > -1 ? ' hasChange' : '')
                }
                component={RenderInput}
                validate={[required, maxLength20]}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-issue-date')}</Form.Label>
              <Field
                name="formIssueDate"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_ISSUE_DATE') > -1
                    ? ' hasChange'
                    : '')
                }
                classParentName="w-100"
                component={RenderSelectDate}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label>{t('txt-expire-date')}</Form.Label>
              <Field
                name="formExpireDate"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_EXPIRE_DATE') > -1
                    ? ' hasChange'
                    : '')
                }
                classParentName="w-100"
                component={RenderSelectDate}
                validate={validateTTHH}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-issue-place')}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formIssuePlace"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_ISSUE_PLACE') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderSelectIssuePlace}
                opts={glIssuePlace}
                validate={required}
                actionAdd
                fnAddCallback={fnAddCallback}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-tax-code')}</Form.Label>
              <Field
                name="formTaxCode"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_TAX_CODE') > -1 ? ' hasChange' : '')
                }
                component={RenderInput}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-national')}</Form.Label>
              <Field
                name="formNationality"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_NATIONAL_CODE') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderSuggestNational}
                required
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-resident-vn')}</Form.Label>
              <div>
                <label>
                  <Field
                    name="formResidentInVN"
                    component="input"
                    type="radio"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_VN_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                    value="1"
                  />{' '}
                  {t('txt-yes')}
                </label>
                <label className="ml-3">
                  <Field
                    name="formResidentInVN"
                    component="input"
                    type="radio"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_VN_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                    value="0"
                  />{' '}
                  {t('txt-no')}
                </label>
              </div>
            </Form.Group>
            {/* <Form.Group>
                  <Form.Label>
                    VSD SID
                  </Form.Label>
                  <Field
                    name="formVsdSid"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_VSD_SID') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                    
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Mã NĐT
                  </Form.Label>
                  <Field
                    name="formInvestorCode"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_INVESTOR_CODE') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                    
                  />
                </Form.Group> */}

            <TabsSectionHeader>
              <ul>
                <li
                  onClick={() => setTabActive('THONG_TIN_LIEN_HE')}
                  className={tabActive === 'THONG_TIN_LIEN_HE' ? 'active ' : ''}
                >
                  {t('txt-contact-info')}
                </li>
                {customerType === 'TO_CHUC' && (
                  <li
                    onClick={() => setTabActive('THONG_TIN_DAI_DIEN')}
                    className={
                      tabActive === 'THONG_TIN_DAI_DIEN' ? 'active ' : ''
                    }
                  >
                    {t('txt-representative')}
                  </li>
                )}
                {customerType !== 'TO_CHUC' && (
                  <li
                    onClick={() => setTabActive('NGUOI_GIAM_HO')}
                    className={tabActive === 'NGUOI_GIAM_HO' ? 'active ' : ''}
                  >
                    {t('txt-guardian')}
                  </li>
                )}
                <li
                  onClick={() => setTabActive('XAC_THUC_KH')}
                  className={tabActive === 'XAC_THUC_KH' ? 'active ' : ''}
                >
                  {t('txt-cust-authentication')}
                </li>
                <li
                  onClick={() => setTabActive('TAI_KHOAN_NGAN_HANG')}
                  className={
                    tabActive === 'TAI_KHOAN_NGAN_HANG' ? 'active ' : ''
                  }
                >
                  {t('txt-ben-acc')}
                </li>
              </ul>
            </TabsSectionHeader>
            <FormSection name="thongTinLienHe">
              <ThongTinLienHe1
                t={t}
                data={thongTinKhachHang}
                className={tabActive === 'THONG_TIN_LIEN_HE' ? 'active' : ''}
                customerType={customerType}
                arrProperty={arrProperty}
              />
            </FormSection>
            <FormSection name="nguoiGiamHo">
              <NguoiGiamHo1
                t={t}
                className={tabActive === 'NGUOI_GIAM_HO' ? 'active' : ''}
                data={thongTinKhachHang}
                arrProperty={arrProperty}
                glIssuePlace={glIssuePlace}
              />
            </FormSection>
            <FormSection name="thongTinDaiDien">
              <ThongTinDaiDien1
                t={t}
                className={tabActive === 'THONG_TIN_DAI_DIEN' ? 'active' : ''}
                glNational={glNational}
                data={thongTinKhachHang}
                customerType={customerType}
                disable
                glCardIDType={glCardIDType}
                arrProperty={arrProperty}
                glIssuePlace={glIssuePlace}
              />
            </FormSection>
            <div
              style={{
                gridColumn: '1/5',
                display: tabActive === 'XAC_THUC_KH' ? 'block' : 'none',
              }}
            >
              <FieldArray
                name="xacthucTK"
                component={XacThucAccount1}
                disable
                onPreview={setImgPreview}
                t={t}
              />
            </div>
            <div
              style={{
                gridColumn: '1/5',
                display: tabActive === 'TAI_KHOAN_NGAN_HANG' ? 'block' : 'none',
              }}
            >
              {/* <BanksAccount accBenSingle={accBenSingle} t={t} /> */}
              <FieldArray
                name="banks"
                glAllBank={glAllBank}
                glProvince={glProvince}
                glAllSubBranch={glAllSubBranch}
                glAccBenType={glAccBenType}
                glChannelType={glChannelType}
                component={BanksAccount1}
                custName={formCustName}
                handleToast={_handleToast}
                accBenSingle={accBenSingle}
                checkAdd={checkAdd}
                setCheckAdd={setCheckAdd}
                custDetail={custDetail}
                // validate={validateAddBen}
                t={t}
              />
            </div>
            <Form.Label>
              {t('txt-creator')}
              {': '}
              {custDetail?.C_CREATOR_CODE}
            </Form.Label>
            <Form.Label>
              {t('txt-create-time')}
              {': '}
              {custDetail?.C_CREATE_TIME || ''}
            </Form.Label>
            <Form.Label>
              {t('txt-updator')}
              {': '} {custDetail?.C_UPDATOR_CODE}
            </Form.Label>
            <Form.Label>
              {t('txt-upd-time')}
              {': '}
              {custDetail?.C_UPDATE_TIME || ''}
            </Form.Label>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>

              {accRight?.C_APPROVE === 1 &&
                (custDetail?.C_STATUS === 'CHUA_DUYET' ||
                  custDetail?.C_STATUS === 'DANG_SUA_DOI') && (
                  <BtnSubmit
                    className={`success`}
                    onClick={() => {
                      handleConfirm('approve');
                      setCheckAdd(false);
                      setCheckSubmit('approve');
                    }}
                  >
                    {t('txt-appr')}
                  </BtnSubmit>
                )}

              {accRight?.C_UPDATE === 1 && (
                <>
                  {custDetail?.C_STATUS === 'DANG_SUA_DOI' && (
                    <BtnSubmit
                      className="danger mr-3 ml-2"
                      onClick={() => {
                        handleConfirm('reject');
                      }}
                    >
                      {t('txt-reject')}
                    </BtnSubmit>
                  )}
                  {action !== 'Approve' && (
                    <BtnSubmit
                      className=" ml-2"
                      type="submit"
                      disabled={submitting}
                    >
                      {t('txt-update')}
                    </BtnSubmit>
                  )}

                  {custDetail?.C_STATUS === 'CHUA_DUYET' && custDetail?.C_APPROVER_CODE === '' && readonly && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="w_100 danger ml-2"
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                  )}
                </>
              )}
            </div>
          </FormAdd>
        </StyleContainer>
      </div>
      {imgPreview && <ImagesViewer onClose={handleClose} imgs={[imgPreview]} />}
      {detailMarketingId && (
        <DetailMarketingId
          id={detailMarketingId}
          onClose={() => setDetailMarketingId(null)}
        />
      )}
      {createIssuePlace && (
        <CreateIssuePlace
          onClose={() => setCreateIssuePlace(false)}
          setIssuePlace={setIssuePlace}
        />
      )}
    </ReactModal>
  );
}

DetailCustChangeInfoModal = reduxForm({
  form: 'detailCustChangeInfoModalForm',
  enableReinitialize: true,
  warn,
})(DetailCustChangeInfoModal);

const selector = formValueSelector('detailCustChangeInfoModalForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getNationalList = makeGetNationalList();
  const getCustomerDetail = makeGetCustomerDetail();
  const getSingleUserFront = makeGetSingleUserFront();
  const getAccBenSingle = makeGetAccBenSingle();
  const getGlobalCardIDType = makeGetGlobalCardIDType();
  const getGlobalCardIDTypeOrg = makeGetGlobalCardIDTypeOrg();
  const getGlIssuePlace = makeGetGlIssuePlace();
  const getAllSubBranch = makeGetAllSubBranch();
  const getAllBank = makeGetAllBank();
  const getAccBenType = makeGetAccBenType();
  const getProvinceList = makeGetProvinceList();
  const getCustomerApprove = makeGetCustomerApprove();
  const getCustomerReject = makeGetCustomerReject();
  const getCustomerDel = makeGetCustomerDelete();
  const getAccountBeneficaryUpdate = makeGetAccBenUpdate();
  const getCustomerUpdate = makeGetCustomerUpdate();

  const {
    customerType,
    formCustCode,
    formCustName,
    formCustShortName,
    formMktId,
    formBussinessType,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formVsdSid,
    formInvestorCode,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formTaxCode,
    formNationality,
    formResidentInVN,
    formStaffFlag,

    thongTinLienHe,
    nguoiGiamHo,
    thongTinDaiDien,
    banks,
    xacthucTK,
  } = selector(
    state,
    'customerType',
    'formCustCode',
    'formCustName',
    'formCustShortName',
    'formMktId',
    'formBussinessType',
    'formCustGender',
    'formBirthDate',
    'formCardIdType',
    'formCardId',
    'formInvestorCode',
    'formVsdSid',
    'formIssueDate',
    'formExpireDate',
    'formIssuePlace',
    'formTaxCode',
    'formNationality',
    'formResidentInVN',
    'formStaffFlag',

    'thongTinLienHe',
    'nguoiGiamHo',
    'thongTinDaiDien',
    'banks',
    'xacthucTK'
  );

  const custDetail = getCustomerDetail(state);

  return {
    token: getToken(state),
    glNational: getNationalList(state),
    singleUserFront: getSingleUserFront(state),
    accBenSingle: getAccBenSingle(state),
    glCardIDType: getGlobalCardIDType(state),
    glCardIDTypeOrg: getGlobalCardIDTypeOrg(state),
    glAllSubBranch: getAllSubBranch(state),
    glProvince: getProvinceList(state),
    glAccBenType: getAccBenType(state),
    glAllBank: getAllBank(state),
    accBenUpd: getAccountBeneficaryUpdate(state),
    glIssuePlace: getGlIssuePlace(state),
    custAppr: getCustomerApprove(state),
    custReject: getCustomerReject(state),
    custDel: getCustomerDel(state),
    custUpd: getCustomerUpdate(state),
    custDetail,

    customerType,
    formCustCode,
    formCustName,
    formCustShortName,
    formMktId,
    formBussinessType,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formVsdSid,
    formInvestorCode,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formTaxCode,
    formNationality,
    formResidentInVN,
    formStaffFlag,

    thongTinLienHe,
    nguoiGiamHo,
    thongTinDaiDien,
    banks,
    xacthucTK,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailCustChangeInfoModal)
);
