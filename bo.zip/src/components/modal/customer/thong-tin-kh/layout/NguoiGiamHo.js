import React from 'react';
import RenderInput from 'components/input/renderInput';
import { Form } from 'react-bootstrap';
import styled from 'styled-components';
import { Field } from 'redux-form';
import { required } from 'utils/validation';
import * as _ from 'lodash';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderSelectIssuePlace from 'components/input/inputSelectIssuePlace';
import { validatePhone } from 'utils/validation';

const FormContent = styled.div`
  grid-column: 1/5;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  display: none;

  &.active {
    display: grid;
  }

  img {
    max-height: 75px;
    max-width: -webkit-fill-available;
  }
`;

function NguoiGiamHo(props) {
  const { className, isCheckGiamHo, bpmGiamHo, readonly, t, arrProperty, glIssuePlace } =
    props;
  console.log(isCheckGiamHo);
  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {t('txt-repre_name')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhName"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_NAME') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-repre-relation')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhRelation"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_POSITION') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-id')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhCardId"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_CARD_ID') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-date')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhIssueDate"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_DATE') > -1
              ? ' hasChange'
              : '')
          }
          classParentName="w-100"
          component={RenderSelectDate}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-expire-date')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhExpireDate"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_EXPIRE_DATE') > -1
              ? ' hasChange'
              : '')
          }
          classParentName="w-100"
          component={RenderSelectDate}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-place')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhIssuePlace"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_PLACE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderSelectIssuePlace}
          opts={glIssuePlace}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_MOBILE && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhMobile"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_MOBILE') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          // validate={
          //   isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_MOBILE ? required : null
          // }
          validate={[ validatePhone]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-email')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_EMAIL && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhEmail"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_EMAIL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_EMAIL ? required : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-contact-address')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_ADDRESS && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhAddress"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ADDRESS') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_ADDRESS ? required : null
          }
          disabled={readonly}
        />
      </Form.Group>
    </FormContent>
  );
}

export default NguoiGiamHo;
