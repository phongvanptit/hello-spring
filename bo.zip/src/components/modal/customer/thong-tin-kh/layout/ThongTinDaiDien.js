import React from 'react';
import RenderInput from 'components/input/renderInput';
import { Form } from 'react-bootstrap';
import styled from 'styled-components';
import { Field } from 'redux-form';
import { required , validateTT} from 'utils/validation';
import * as _ from 'lodash';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSelectDate from 'components/input/renderDatePicker';
import { formatDate, _diff2Date } from 'utils';
import { arrAuthenSign } from 'utils/const';
import RenderSelectIssuePlace from 'components/input/inputSelectIssuePlace';
import RenderSuggestNational from 'components/input/renderSuggestNationalNew';
const FormContent = styled.div`
  grid-column: 1/5;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  display: none;

  &.active {
    display: grid;
  }

  img {
    max-height: 75px;
    max-width: -webkit-fill-available;
  }
`;


function ThongTinDaiDien(props) {
  const {
    glNational,
    className,
    customerType,
    bpmDaiDien,
    readonly,
    t,
    glCardIDType,
    arrProperty,
    glIssuePlace
  } = props;

  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {t('txt-full-name')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddName"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_NAME') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_NAME
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-national')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddNationality"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_NATIONAL_CODE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderSuggestNational}
          required
          validate={customerType === 'TO_CHUC' ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-resident-vn')}
          <span className="text-danger">*</span>
        </Form.Label>
        <div>
          <label>
            <Field
              name="ttddResidentInVN"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_VN_FLAG') > -1
                  ? ' hasChange'
                  : '')
              }
              value="1"
              disabled={readonly}
            />{' '}
            {t('txt-yes')}
          </label>
          <label className="ml-3">
            <Field
              name="ttddResidentInVN"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_VN_FLAG') > -1
                  ? ' hasChange'
                  : '')
              }
              value="0"
              disabled={readonly}
            />{' '}
            {t('txt-no')}
          </label>
        </div>
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-type')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddCardIdType"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_CARD_ID_TYPE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderNormalSelect}
          opts={glCardIDType}
          validate={customerType === 'TO_CHUC' ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-id')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddCardID"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_CARD_ID') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_CARDID
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-date')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddIssueDate"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_DATE') > -1
              ? ' hasChange'
              : '')
          }
          classParentName="w-100"
          component={RenderSelectDate}
          startDate={formatDate(new Date(), '/', 'dmy')}
          validate={
            (customerType === 'TO_CHUC' )
              ? validateTT
              : null
          }
          // validate={[required,validateTT]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-place')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddIssuePlace"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_PLACE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderSelectIssuePlace}
          opts={glIssuePlace}
          validate={customerType === 'TO_CHUC' ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-position')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddPosition"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_POSITION') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_POSITION
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '2/4' }}>
        <Form.Label>{t('txt-contact-address')}</Form.Label>
        <Field
          name="ttddAddress"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ADDRESS') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-gender')}</Form.Label>
        <div>
          <label>
            <Field
              name="ttddGender"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_GENDER') > -1
                  ? ' hasChange'
                  : '')
              }
              value="M"
              disabled={readonly}
            />{' '}
            {t('txt-male')}
          </label>
          <label className="ml-3">
            <Field
              name="ttddGender"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_GENDER') > -1
                  ? ' hasChange'
                  : '')
              }
              value="F"
              disabled={readonly}
            />{' '}
            {t('txt-female')}
          </label>
        </div>
      </Form.Group>

      <Form.Group>
        <Form.Label>
          {t('txt-tel')}
          {bpmDaiDien?.CHECK_REPRE_TEL && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttddTel"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_TEL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_TEL
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile')}
          {bpmDaiDien?.CHECK_REPRE_MOBILE && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttddMobile"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_MOBILE') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_MOBILE
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-email')}</Form.Label>
        <Field
          name="ttddEmail"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_EMAIL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-authen-sign')}</Form.Label>
        <Field
          name="ttddAuthenSign"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_AUTHEN_SIGN') > -1 ? ' hasChange' : '')
          }
          component={RenderNormalSelect}
          opts={arrAuthenSign}
          validate={required}
          disabled={readonly}
        />
      </Form.Group>
    </FormContent>
  );
}

export default ThongTinDaiDien;
