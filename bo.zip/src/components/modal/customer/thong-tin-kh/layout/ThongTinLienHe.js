import React from 'react';
import RenderInput from 'components/input/renderInput';
import { Form } from 'react-bootstrap';
import styled from 'styled-components';
import { Field } from 'redux-form';
import { minLength, required } from 'utils/validation';
import * as _ from 'lodash';
import RenderArea from 'components/input/renderArea';

const FormContent = styled.div`
  grid-column: 1/5;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  display: none;

  &.active {
    display: grid;
  }

  img {
    max-height: 75px;
    max-width: -webkit-fill-available;
  }
`;

const minLength14 = minLength(14);

const validateLocalMobile = (value, _allValues, props) => {
  /*const { sysBpm } = props;
  const isValidMobile =
    _.find(sysBpm, (o) => o.step === 'check_mobile')?.status === 1;
  if (!isValidMobile) return undefined;*/

  if (!value) return 'Trường không được để trống';

  let vnf_regex = /(((\+|)84)|0)(3|5|7|8|9)+([0-9]{8})\b/;
  const _value = value.replace(/ /g, '');
  if (!_value || (vnf_regex.test(_value) && _value.indexOf('_') < 0))
    return undefined;

  return 'Định dạng SĐT không đúng';
};

const validateLocalEmail = (value, _allValues, props) => {
  // const { sysBpm } = props;
  // const isValidEmail =
  //   _.find(sysBpm, (o) => o.step === 'check_email')?.status === 1;
  // if (!isValidEmail) return undefined;

  var re =
    /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

  if (!value || re.test(value)) return undefined;

  return 'Định dạng Email không đúng';
};

function ThongTinLienHe(props) {
  const { className, customerType, bpmLienHe, readonly, t, arrProperty } =
    props;

  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {customerType === 'CA_NHAN'
            ? `${t('txt-residence-address')}`
            : `${t('txt-office')}`}
          {/* {bpmLienHe?.CHECK_RESEDENCE_ADDR ? (
              <span className="text-danger">*</span>
            ) : null} */}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhResedenceAddr"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_RESEDENCE_ADDRESS') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderInput}
          //validate={bpmLienHe?.CHECK_RESEDENCE_ADDR ? required : null}
          validate={required}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-contact-address')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhContactAddr"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_ADDRESS') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={[required, minLength14]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-tel')}</Form.Label>
        <Field
          name="ttkhTel"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_TEL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile-1')}{' '}
          {/* {bpmLienHe?.CHECK_MOBILE ? (
              <span className="text-danger">*</span>
            ) : null} */}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhMobile"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_MOBILE') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={[validateLocalMobile, required]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          Email{' '}
          {/* {bpmLienHe?.CHECK_EMAIL ? (
              <span className="text-danger">*</span>
            ) : null} */}
        </Form.Label>
        <Field
          name="ttkhEmail"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_EMAIL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={[validateLocalEmail, required]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>Fax</Form.Label>
        <Field
          name="ttkhFax"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_FAX') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '1/5' }}>
        <Form.Label>{t('txt-note')}</Form.Label>
        <Field
          name="ttkhNote"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CONTENT') > -1 ? ' hasChange' : '')
          }
          component={RenderArea}
          rows={2}
          disabled={readonly}
        />
      </Form.Group>
    </FormContent>
  );
}

export default ThongTinLienHe;
