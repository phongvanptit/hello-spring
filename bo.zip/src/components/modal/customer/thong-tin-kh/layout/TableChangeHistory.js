import React from 'react';
import { Table } from 'react-bootstrap';

function TableChangeHistory(props) {
  const { t } = props;
  return (
    <Table bordered>
      <thead>
        <tr>
          <th>{t('txt-date')}</th>
          <th>{t('txt-content')}</th>
          <th>{t('txt-approver')}</th>
        </tr>
      </thead>
    </Table>
  );
}

export default TableChangeHistory;
