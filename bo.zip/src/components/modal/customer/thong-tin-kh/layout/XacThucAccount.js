import React from 'react';
import { Table } from 'react-bootstrap';
import styled from 'styled-components';
import { Field } from 'redux-form';
import { required } from 'utils/validation';
import * as _ from 'lodash';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { _diff2Date } from 'utils';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BsTrash } from 'react-icons/bs';
import { BtnSubmit } from 'utils/styledComponent';
import RenderFileInput from 'components/input/renderFileInput';
import { FaEye } from 'react-icons/fa';

const arrTypeXT = [
  { value: 'ANH_MAT_TRUOC', label: 'CMT/CCCD (mặt trước)' },
  { value: 'ANH_MAT_SAU', label: 'CMT/CCCD (mặt sau)' },
  { value: 'ANH_CHAN_DUNG', label: 'Ảnh chân dung' },
  { value: 'ANH_CHU_KY', label: 'Chữ ký' },
];

const FormBanksAccount = styled.div`
  grid-column: 1/5;
  display: flex;
  flex-direction: column;

  .table td,
  .table th {
    padding: 6px 7px;
  }
`;
function XacThucAccount({
  t,
  fields,
  readonly,
  onPreview,
  meta: { error, submitFailed },
}) {
  function previewImage(record) {
    // readurl from type file
    onPreview(readurl(record));
  }

  function readurl(file) {
    if (typeof file === 'string') return file;
    // file reader
    return URL.createObjectURL(file);
  }

  return (
    <FormBanksAccount>
      {submitFailed && error && <small className="text-danger">{error}</small>}
      <PerfectScrollbar>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-file-type')}</th>
              <th>Tên file</th>
              <th>{t('txt-chose-file')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {fields.map((xt, index) => (
              <tr key={index}>
                <td className="text-center">
                  <Field
                    name={`${xt}.xtAccountType`}
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={arrTypeXT}
                    validate={required}
                    disabled={readonly}
                  />
                </td>
                <td>{ fields.get(index)?.xtImageName}</td>
                <td className="text-center">
                {
                ( !fields.get(index)?.xtImageName) &&
                  <Field
                    name={`${xt}.xtAccountImage`}
                    className="fz-13"
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    component={RenderFileInput}
                    validate={required}
                    disabled={readonly}
                  />
                }
                </td>
                <td className="text-center">
                  <a
                    onClick={() => {
                      if (fields.get(index)?.xtAccountImage)
                        return previewImage(fields.get(index)?.xtAccountImage);
                      return;
                    }}
                    className={
                      'mx-1 ' +
                      (!fields.get(index)?.xtAccountImage ? 'disabled' : '')
                    }
                    title="Xem"
                  >
                    <FaEye />
                  </a>
                  {!readonly && (
                    <a
                      onClick={() => fields.remove(index)}
                      className="mx-1"
                      title="Xóa"
                    >
                      <BsTrash />
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
      {!readonly && (
        <div
          className="d-flex"
          style={{
            height: '30px',
            whiteSpace: 'nowrap',
            gridColumn: '1/4',
          }}
        >
          <BtnSubmit
            type="button"
            className="w_125 info"
            onClick={() => {
              if (fields.length > arrTypeXT.length) return;

              fields.push({});
            }}
          >
            {t('txt-add-file')}
          </BtnSubmit>

          <BtnSubmit
            type="button"
            onClick={() => fields.removeAll()}
            className="w_125 ml-2 danger"
          >
            {t('bnt-del-entry')}
          </BtnSubmit>
        </div>
      )}
    </FormBanksAccount>
  );
}

export default XacThucAccount;
