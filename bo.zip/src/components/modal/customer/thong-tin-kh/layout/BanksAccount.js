import React from 'react';
import RenderInput from 'components/input/renderInput';
import { Table } from 'react-bootstrap';
import styled from 'styled-components';
import { Field } from 'redux-form';
import { required } from 'utils/validation';
import * as _ from 'lodash';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { _diff2Date } from 'utils';
import PerfectScrollbar from 'react-perfect-scrollbar';
import renderSelectBank from 'components/input/renderSelectBank';
import RenderSelectSubBranch from 'components/input/renderSelectSubBranch';
import { BsTrash } from 'react-icons/bs';
import { BtnSubmit } from 'utils/styledComponent';
import ToggleButton from 'react-toggle-button';
const FormBanksAccount = styled.div`
  grid-column: 1/5;
  display: flex;
  flex-direction: column;

  .table td,
  .table th {
    padding: 6px 7px;
  }
`;

function convert_vi_to_en(str) {
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
  str = str.replace(/đ/g, 'd');
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
  str = str.replace(/Đ/g, 'D');
  str = str.replace(
    /!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g,
    ' '
  );
  str = str.replace(/  +/g, ' ');
  return str;
}

function BanksAccount({
  fields,
  glAllBank,
  glProvince,
  glAllSubBranch,
  glAccBenType,
  glChannelType,
  custName,
  handleToast,
  meta: { error, touched, submitFailed },
  t,
  accBenSingle,
  checkAdd,
  setCheckAdd,
  custDetail,
}) {
  const [checkVaildate, setCheckValidata] = React.useState(false);
  const [checkInfor, setCheckInfor] = React.useState(null);
  React.useEffect(() => {
    if (!checkAdd) {
      fields.removeAll();
    }
  }, [checkAdd]);

  React.useEffect(() => {
    if (fields?.length === 0) {
      setCheckAdd(false);
    }
    validateAddBen(fields.getAll());
  }, [fields]);

  // const validateAddBen = (values) => {
  //   const errors = [];
  //   // Lặp qua mỗi bank trong danh sách banks
  //   Array.isArray(values) &&
  //     values.forEach((bank, index) => {
  //       const bankBranchHand = bank.bankBranchHand;
  //       const bankBranch = bank.bankBranch;
  //       // Kiểm tra nếu cả hai trường đều trống
  //       if (!bankBranchHand && !bankBranch) {
  //         setCheckValidata(true);
  //       } else setCheckValidata(false);
  //     });
  // };

  const validateAddBen = (values) => {
    const errors = [];
    // Lặp qua mỗi bank trong danh sách banks
    Array.isArray(values) &&
    values.forEach((bank, index) => {
        const accountType = bank.accountType;
       //console.log('account-type',bank.accountType);
        // Kiểm tra nếu cả hai trường đều trống
        if (accountType !== 'OTHER') {
          setCheckInfor(true);
        } else setCheckInfor(false);
      });
  };

  return (
    <FormBanksAccount>
      <PerfectScrollbar>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-acc-number')}</th>
              <th>{t('txt-acc-name')}</th>
              <th>{t('txt-bank')}</th>
              <th>{t('txt-province-city')}</th>
              <th>{t('txt-branch')}</th>
              <th>{t('txt-branch-hand')}</th>
              <th>{t('txt-acc-type')}</th>
              <th>{t('txt-open-date')}</th>
              <th>{t('txt-active')}</th>
              <th>{t('txt-status')}</th>
              {checkAdd && <th>{t('txt-action')}</th>}
            </tr>
          </thead>
          <tbody>
            {accBenSingle &&
              accBenSingle.map((item, index) => (
                <tr key={index}>
                  <td className="text-center">{item.C_BANK_ACCOUNT_CODE}</td>
                  <td className="text-center">{item.C_BANK_ACCOUNT_NAME}</td>
                  <td className="text-center">{item.C_BANK_NAME}</td>
                  <td className="text-center">{item.C_PROVINCE_NAME}</td>
                  <td className="text-center">{item.C_BANK_BRANCH_NAME}</td>
                  <td className="text-center">{item.C_BANK_BRANCH_HAND}</td>
                  <td className="text-center">{item.C_ACCOUNT_TYPE_NAME}</td>
                  <td className="text-center">{item.C_OPEN_DATE}</td>
                  <td>
                            <span class="d-flex justify-content-center">
                              <ToggleButton
                                value={item.C_ACTIVE === 1 ? true : false}
                              />
                            </span>
                          </td>
                  <td className="text-center">{item.C_STATUS}</td>
                </tr>
              ))}
            {fields.map((bank, index) => (
              <tr key={index}>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.bankAccount`}
                    className="form-control"
                    component={RenderInput}
                    validate={required}
                  />
                </td>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.bankAccountName`}
                    className="form-control"
                    component={RenderInput}
                    validate={required}
                    disabled={checkInfor}
                  />
                </td>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.bankName`}
                    className="form-control"
                    component={renderSelectBank}
                    opts={glAllBank}
                    validate={required}
                  />
                </td>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.bankProvince`}
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glProvince}
                    validate={required}
                  />
                </td>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.bankBranch`}
                    className="form-control"
                    classParent="w-100"
                    component={RenderSelectSubBranch}
                    bankCode={fields.get(index)?.bankName}
                    provinceCode={fields.get(index)?.bankProvince}
                    opts={glAllSubBranch}
                    //validate={checkVaildate ? required : undefined}
                  />
                </td>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.bankBranchHand`}
                    className="form-control "
                    classParent="w-100"
                    component={RenderInput}
                    //validate={checkVaildate ? required : undefined}
                  />
                </td>
                <td className="text-center align-baseline">
                  <Field
                    name={`${bank}.accountType`}
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glAccBenType}
                    required
                  />
                </td>
                <td></td>
                <td></td>
                <td className="text-center align-baseline">
                  <a
                    onClick={() => {
                      fields.remove(index);
                    }}
                  >
                    <BsTrash />
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
      <div
        className="d-flex"
        style={{
          height: '30px',
          whiteSpace: 'nowrap',
          gridColumn: '1/4',
        }}
      >
        {custDetail?.C_STATUS === 'CHUA_DUYET' && (
          <BtnSubmit
            type="button"
            className="w_100 info"
            onClick={() => {
              if (fields?.length > 4) {
                handleToast(`${t('txt-add-5-acc-beneficiary')}`, 'warning');
                return;
              }
              if (!custName) {
                handleToast(`${t('txt-no-data-cust')}`, 'warning');
                return;
              }

              fields.push({
                bankAccountName: convert_vi_to_en(custName).toUpperCase(),
                accountType: 'BANK',
                channel: 'I',
              });
              setCheckAdd(true);
            }}
          >
            {t('txt-add-acc')}
          </BtnSubmit>
        )}

        {checkAdd && (
          <>
            <BtnSubmit
              type="button"
              className="w_100 ml-2 danger"
              onClick={() => {
                fields.removeAll();
                setCheckAdd(false);
              }}
            >
              {t('bnt-del-entry')}
            </BtnSubmit>
          </>
        )}
      </div>
    </FormBanksAccount>
  );
}

export default BanksAccount;
