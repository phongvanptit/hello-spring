import React, { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Form } from 'react-bootstrap';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import ReactModal from 'react-modal';
import RenderArea from 'components/input/renderArea';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import * as _ from 'lodash';
import { required } from 'utils/validation';
import { setToast } from 'containers/client/actions';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';

import {
  typeUpdListInTypeRequest,
  typeUpdListInTypeSuccess,
} from 'containers/category/actions';

import { makeGetToken, makeGetUpdListInType } from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateDanhMucConModal(props) {
  const dispatch = useDispatch();

  const { token, onClose, updListInType, setIssuePlace } = props;

  const preUpdListInType = usePrevious(updListInType);
  useEffect(() => {
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (updListInType && !_.isEqual(updListInType, preUpdListInType)) {
      _handleToast(t('txt-add-issue-place-success'), 'success');
      dispatch(typeUpdListInTypeSuccess(null));
      setIssuePlace(props.formCode);
      onClose();
    }
  }, [updListInType]);

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_LIST',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        LISTTYPE_ID: '',
        LISTTYPE_CODE: 'ISSUE_PLACE',
        CODE: values?.formCode,
        NAME: values?.formName,
        ENGLISH_NAME: values?.formEngName,
        VALUE: values?.formValue,
        NOTE: values?.formNote,
      },
    };

    dispatch(typeUpdListInTypeRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3"> {t('txt-add-issue-place')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-issue-place-code')}
                  </Form.Label>
                  <Field
                    name="formCode"
                    className="form-control"
                    placeholder={t('txt-issue-place-code')}
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-issue-place-name')}
                  </Form.Label>
                  <Field
                    name="formName"
                    className="form-control"
                    placeholder={t('txt-issue-place-name')}
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-english-name')}
                  </Form.Label>
                  <Field
                    name="formEngName"
                    className="form-control"
                    placeholder={t('txt-english-name')}
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-value')}</Form.Label>
                  <Field
                    name="formValue"
                    className="form-control"
                    placeholder={t('txt-value')}
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label className="fz-13">{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control"
                    placeholder={t('txt-note')}
                    component={RenderArea}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateDanhMucConModal = reduxForm({
  form: 'createIssuePlaceModalForm',
  enableReinitialize: true,
})(CreateDanhMucConModal);

const selector = formValueSelector('createIssuePlaceModalForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getUpdListInType = makeGetUpdListInType();
  const { formCode, formName, formEngName, formValue, formNote } = selector(
    state,
    'formCode',
    'formName',
    'formEngName',
    'formValue',
    'formNote'
  );
  return {
    token: getToken(state),
    updListInType: getUpdListInType(state),
    formCode,
    formName,
    formEngName,
    formValue,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateDanhMucConModal)
);
