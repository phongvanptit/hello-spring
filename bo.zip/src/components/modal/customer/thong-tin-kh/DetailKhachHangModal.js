import React from 'react';
import { connect, useDispatch } from 'react-redux';

import { Form, Table } from 'react-bootstrap';
import {
  Field,
  FieldArray,
  FormSection,
  change,
  formValueSelector,
  getFormSyncErrors,
  reduxForm,
  updateSyncErrors,
} from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { BsTrash } from 'react-icons/bs';
import { FaEye, FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { StringToInt, _diff2Date, formatDate } from 'utils';
import { arrAuthenSign } from 'utils/const';
import { BtnClose, BtnSubmit, TabsSectionHeader } from 'utils/styledComponent';
import { maxLength, minLength, required } from 'utils/validation';

import RenderSelectIssuePlace from 'components/input/inputSelectIssuePlace';
import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderFileInput from 'components/input/renderFileInput';
import RenderInput from 'components/input/renderInput';
import RenderNewInputMkt from 'components/input/renderNewInputMkt';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestNational from 'components/input/renderSuggestNationalNew';
import {
  makeGetAllBank,
  makeGetAllSubBranch,
  makeGetCustomerDetail,
  makeGetCustomerUpdate,
  makeGetNationalList,
  makeGetProvinceList,
  makeGetSingleUserFront,
  makeGetToken,
} from 'lib/selector';

import {
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
  custUpdateRequest,
  custUpdateSuccess,
} from 'containers/customer/actions';

import Spinner from 'assets/img/spinner.gif';
import { accBenSingleRequest } from 'containers/account/actions';
import {
  makeGetAccBenSingle,
  makeGetAccBenType,
  makeGetChannelType,
  makeGetGlobalCardIDType,
  makeGetSysBpmByType,
  makeGetGlIssuePlace,
  makeGetGlobalCardIDTypeOrg,
} from 'lib/selector';
import { getAge, removeAccent } from 'utils';

import ImagesViewer from 'components/images-viewer/imageViewer';
import DetailMarketingId from 'components/modal/detail-pop-up/detailMarketingId';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnDetail } from 'utils/styledComponent';
import CreateIssuePlace from './layout/CreateIssuePlace';
ReactModal.setAppElement('#root');

const arrTypeXT = [
  { value: 'ANH_MAT_TRUOC', label: 'CMT/CCCD (mặt trước)' },
  { value: 'ANH_MAT_SAU', label: 'CMT/CCCD (mặt sau)' },
  { value: 'ANH_CHAN_DUNG', label: 'Ảnh chân dung' },
  { value: 'ANH_CHU_KY', label: 'Chữ ký' },
];

const appUrl = `${process.env.REACT_APP_API_URL}`;
const fileUrl = `${process.env.REACT_APP_FILE_URL}/upload`;

const maxLength20 = maxLength(12);
const minLength14 = minLength(14);

//#region styled

const customStyles = {
  content: {
    inset: '40px 200px auto',
    height: 'auto',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.form`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;

  input.form-control,
  label {
    font-size: 13px;
  }
`;

const FormContent = styled.div`
  grid-column: 1/5;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  display: none;

  &.active {
    display: grid;
  }

  img {
    max-height: 75px;
    max-width: -webkit-fill-available;
  }
`;

const FormBanksAccount = styled.div`
  grid-column: 1/5;
  display: flex;
  flex-direction: column;

  .table td,
  .table th {
    padding: 6px 7px;
  }
`;

//#endregion

const validateLocalMobile = (value, _allValues, props) => {
  const { sysBpm } = props;
  const isValidMobile =
    _.find(sysBpm, (o) => o.step === 'check_mobile')?.status === 1;
  if (!isValidMobile) return undefined;

  if (!value) return 'Trường không được để trống';

  let vnf_regex = /(((\+|)84)|0)(3|5|7|8|9)+([0-9]{8})\b/;
  const _value = value.replace(/ /g, '');
  if (!_value || (vnf_regex.test(_value) && _value.indexOf('_') < 0))
    return undefined;

  return 'Định dạng SĐT không đúng';
};

const validateLocalEmail = (value, _allValues, props) => {
  // const { sysBpm } = props;
  // const isValidEmail =
  //   _.find(sysBpm, (o) => o.step === 'check_email')?.status === 1;
  // if (!isValidEmail) return undefined;

  var re =
    /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

  if (!value || re.test(value)) return undefined;

  return 'Định dạng Email không đúng';
};

const validateMktId = (value, _allValues, props) => {
  const { sysBpm } = props;
  const isValidEmail =
    _.find(sysBpm, (o) => o.step === 'CHECK_MKTID')?.value === true;
  if (!isValidEmail) return undefined;

  if (!value) return 'Trường không được để trống';

  if (value.length !== 4) return 'Độ dài 4 ký tự';
  if (isNaN(Number(value))) return 'Hãy nhập số';

  return undefined;
};
const validateExpireDate = (value, allValues, props) => {
  console.log(allValues);
  const { sysBpm } = props;
  const { formIssueDate, formBirthDate, formCardIdType } = allValues;
  const isValidEmail =
    _.find(sysBpm, (o) => o.step === 'CHECK_EXPIRE')?.value === true;
  if (!isValidEmail) return undefined;
  if (!value) return 'Trường không được để trống';

  const _diff1 = _diff2Date(value, formIssueDate);
  const _diff2 = _diff2Date(value, formatDate(new Date(), '/', 'dmy'));

  if (_diff1 < 0 || _diff2 < 0) return 'Ngày hết hạn không đúng';

  return undefined;
};

const warn = (values) => {
  const warns = {};
  var format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  const { formCustName } = values;
  console.log(formCustName, format.test(formCustName));
  let _arr = [];
  if (formCustName) {
    if (format.test(formCustName)) {
      _arr.push('Tên khách hàng có ký tự đặc biệt');
    }
    if (/[0-9]/.test(formCustName)) _arr.push('Tên khách hàng có ký tự số');
  }
  warns.formCustName = _arr;
  return warns;
};

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function ThongTinLienHe(props) {
  const { className, customerType, bpmLienHe, readonly, t, arrProperty } =
    props;

  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {customerType === 'CA_NHAN'
            ? `${t('txt-residence-address')}`
            : `${t('txt-office')}`}
          {/* {bpmLienHe?.CHECK_RESEDENCE_ADDR ? (
            <span className="text-danger">*</span>
          ) : null} */}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhResedenceAddr"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_RESEDENCE_ADDRESS') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderInput}
          //validate={bpmLienHe?.CHECK_RESEDENCE_ADDR ? required : null}
          validate={required}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-contact-address')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhContactAddr"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_ADDRESS') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={[required, minLength14]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-tel')}</Form.Label>
        <Field
          name="ttkhTel"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_TEL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile-1')}{' '}
          {/* {bpmLienHe?.CHECK_MOBILE ? (
            <span className="text-danger">*</span>
          ) : null} */}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttkhMobile"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_MOBILE') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={[validateLocalMobile, required]}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          Email{' '}
          {/* {bpmLienHe?.CHECK_EMAIL ? (
            <span className="text-danger">*</span>
          ) : null} */}
        </Form.Label>
        <Field
          name="ttkhEmail"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_EMAIL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={validateLocalEmail}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>Fax</Form.Label>
        <Field
          name="ttkhFax"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CUST_FAX') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '1/5' }}>
        <Form.Label>{t('txt-note')}</Form.Label>
        <Field
          name="ttkhNote"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_CONTENT') > -1 ? ' hasChange' : '')
          }
          component={RenderArea}
          rows={2}
          disabled={readonly}
        />
      </Form.Group>
    </FormContent>
  );
}

function NguoiGiamHo(props) {
  const { className, isCheckGiamHo, bpmGiamHo, readonly, t, arrProperty } =
    props;
  console.log(isCheckGiamHo);
  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {t('txt-repre_name')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhName"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_NAME') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-repre-relation')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhRelation"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_POSITION') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-id')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhCardId"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_CARD_ID') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-date')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhIssueDate"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_DATE') > -1
              ? ' hasChange'
              : '')
          }
          classParentName="w-100"
          component={RenderSelectDate}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-expire-date')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhExpireDate"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_EXPIRE_DATE') > -1
              ? ' hasChange'
              : '')
          }
          classParentName="w-100"
          component={RenderSelectDate}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-place')}
          {isCheckGiamHo && <span className="text-danger">*</span>}
        </Form.Label>
        <Field
          name="ttlhIssuePlace"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_PLACE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderInput}
          validate={isCheckGiamHo ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_MOBILE && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhMobile"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_MOBILE') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_MOBILE ? required : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-email')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_EMAIL && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhEmail"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_EMAIL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_EMAIL ? required : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }}>
        <Form.Label>
          {t('txt-contact-address')}
          {isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_ADDRESS && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttlhAddress"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ADDRESS') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            isCheckGiamHo && bpmGiamHo?.CHECK_CONTACT_ADDRESS ? required : null
          }
          disabled={readonly}
        />
      </Form.Group>
    </FormContent>
  );
}

function ThongTinDaiDien(props) {
  const {
    glNational,
    className,
    customerType,
    bpmDaiDien,
    readonly,
    t,
    glCardIDType,
    arrProperty,
  } = props;

  return (
    <FormContent className={className}>
      <Form.Group style={{ gridColumn: '1/3' }}>
        <Form.Label>
          {t('txt-full-name')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddName"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_NAME') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_NAME
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-national')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddNationality"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_NATIONAL_CODE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderSuggestNational}
          required
          validate={customerType === 'TO_CHUC' ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-resident-vn')}
          <span className="text-danger">*</span>
        </Form.Label>
        <div>
          <label>
            <Field
              name="ttddResidentInVN"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_VN_FLAG') > -1
                  ? ' hasChange'
                  : '')
              }
              value="1"
              disabled={readonly}
            />{' '}
            {t('txt-yes')}
          </label>
          <label className="ml-3">
            <Field
              name="ttddResidentInVN"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_VN_FLAG') > -1
                  ? ' hasChange'
                  : '')
              }
              value="0"
              disabled={readonly}
            />{' '}
            {t('txt-no')}
          </label>
        </div>
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-type')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddCardIdType"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_CARD_ID_TYPE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderNormalSelect}
          opts={glCardIDType}
          validate={customerType === 'TO_CHUC' ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-card-id')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddCardID"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_CARD_ID') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_CARDID
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-date')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddIssueDate"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_DATE') > -1
              ? ' hasChange'
              : '')
          }
          classParentName="w-100"
          component={RenderSelectDate}
          startDate={formatDate(new Date(), '/', 'dmy')}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_ISSUE_DATE
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-issue-place')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddIssuePlace"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ISSUE_PLACE') > -1
              ? ' hasChange'
              : '')
          }
          component={RenderInput}
          validate={customerType === 'TO_CHUC' ? required : null}
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-position')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          name="ttddPosition"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_POSITION') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_POSITION
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '2/4' }}>
        <Form.Label>{t('txt-contact-address')}</Form.Label>
        <Field
          name="ttddAddress"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_ADDRESS') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-gender')}</Form.Label>
        <div>
          <label>
            <Field
              name="ttddGender"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_GENDER') > -1
                  ? ' hasChange'
                  : '')
              }
              value="M"
              disabled={readonly}
            />{' '}
            {t('txt-male')}
          </label>
          <label className="ml-3">
            <Field
              name="ttddGender"
              component="input"
              type="radio"
              className={
                'cursor-pointer' +
                (arrProperty?.indexOf('C_REPRE_GENDER') > -1
                  ? ' hasChange'
                  : '')
              }
              value="F"
              disabled={readonly}
            />{' '}
            {t('txt-female')}
          </label>
        </div>
      </Form.Group>

      <Form.Group>
        <Form.Label>
          {t('txt-tel')}
          {bpmDaiDien?.CHECK_REPRE_TEL && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttddTel"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_TEL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_TEL
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-mobile')}
          {bpmDaiDien?.CHECK_REPRE_MOBILE && (
            <span className="text-danger">*</span>
          )}
        </Form.Label>
        <Field
          name="ttddMobile"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_MOBILE') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          validate={
            customerType === 'TO_CHUC' && bpmDaiDien?.CHECK_REPRE_MOBILE
              ? required
              : null
          }
          disabled={readonly}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-email')}</Form.Label>
        <Field
          name="ttddEmail"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_REPRE_EMAIL') > -1 ? ' hasChange' : '')
          }
          component={RenderInput}
          disabled={readonly}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-authen-sign')}</Form.Label>
        <Field
          name="ttddAuthenSign"
          className={
            'form-control input-order' +
            (arrProperty?.indexOf('C_AUTHEN_SIGN') > -1 ? ' hasChange' : '')
          }
          component={RenderNormalSelect}
          opts={arrAuthenSign}
          validate={required}
          disabled={readonly}
        />
      </Form.Group>
    </FormContent>
  );
}

function BanksAccount({ accBenSingle, t }) {
  return (
    <FormBanksAccount>
      <PerfectScrollbar>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-acc-number')}</th>
              <th>{t('txt-acc-name')}</th>
              <th>{t('txt-bank')}</th>
              <th>{t('txt-province-city')}</th>
              <th>{t('txt-branch')}</th>
              <th>{t('txt-acc-type')}</th>
              <th>{t('txt-open-date')}</th>
              <th>{t('txt-status')}</th>
            </tr>
          </thead>
          <tbody>
            {accBenSingle &&
              accBenSingle.map((item, index) => (
                <tr key={index}>
                  <td className="text-center">{item.C_BANK_ACCOUNT_CODE}</td>
                  <td className="text-center">{item.C_BANK_ACCOUNT_NAME}</td>
                  <td className="text-center">{item.C_BANK_NAME}</td>
                  <td className="text-center">{item.C_PROVINCE_NAME}</td>
                  <td className="text-center">{item.C_BANK_BRANCH_NAME}</td>
                  <td className="text-center">{item.C_ACCOUNT_TYPE_NAME}</td>
                  <td className="text-center">{item.C_OPEN_DATE}</td>

                  <td className={'text-center orderStt_' + item.C_STATUS}>
                    {item.C_STATUS}
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
    </FormBanksAccount>
  );
}

function XacThucAccount({
  t,
  fields,
  readonly,
  onPreview,
  meta: { error, submitFailed },
}) {
  console.log('fields', fields);
  function previewImage(record) {
    // readurl from type file
    onPreview(readurl(record));
  }

  function readurl(file) {
    if (typeof file === 'string') return file;
    // file reader
    return URL.createObjectURL(file);
  }

  return (
    <FormBanksAccount>
      {submitFailed && error && <small className="text-danger">{error}</small>}
      <PerfectScrollbar>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-file-type')}</th>
              <th>{t('txt-chose-file')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {fields.map((xt, index) => (
              <tr key={index}>
                <td className="text-center">
                  <Field
                    name={`${xt}.xtAccountType`}
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={arrTypeXT}
                    validate={required}
                    disabled={readonly}
                  />
                </td>
                <td className="text-center">
                  <Field
                    name={`${xt}.xtAccountImage`}
                    className="fz-13"
                    type="file"
                    accept=".jpg, .png, .jpeg"
                    component={RenderFileInput}
                    validate={required}
                    disabled={readonly}
                  />
                </td>
                <td className="text-center">
                  <a
                    onClick={() => {
                      if (fields.get(index)?.xtAccountImage)
                        return previewImage(fields.get(index)?.xtAccountImage);
                      return;
                    }}
                    className={
                      'mx-1 ' +
                      (!fields.get(index)?.xtAccountImage ? 'disabled' : '')
                    }
                    title="Xem"
                  >
                    <FaEye />
                  </a>
                  {!readonly && (
                    <a
                      onClick={() => fields.remove(index)}
                      className="mx-1"
                      title="Xóa"
                    >
                      <BsTrash />
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </PerfectScrollbar>
      {!readonly && (
        <div
          className="d-flex"
          style={{
            height: '30px',
            whiteSpace: 'nowrap',
            gridColumn: '1/4',
          }}
        >
          <BtnSubmit
            type="button"
            className="w_125 info"
            onClick={() => {
              if (fields.length > arrTypeXT.length) return;

              fields.push({});
            }}
          >
            {t('txt-add-file')}
          </BtnSubmit>

          <BtnSubmit
            type="button"
            onClick={() => fields.removeAll()}
            className="w_125 ml-2 danger"
          >
            {t('bnt-del-entry')}
          </BtnSubmit>
        </div>
      )}
    </FormBanksAccount>
  );
}

function DetailKhachHangModal(props) {
  const abortController = new AbortController();

  const dispatch = useDispatch();
  const [tabActive, setTabActive] = React.useState('THONG_TIN_LIEN_HE');
  const [isLoading, setIsLoading] = React.useState(false);
  const [isCheckGiamHo, setIsCheckGiamHo] = React.useState(false);
  const [bpmLienHe, setBpmLienHe] = React.useState(null);
  const [bpmGiamHo, setBpmGiamHo] = React.useState(null);
  const [bpmDaiDien, setBpmDaiDien] = React.useState(null);
  const [imgPreview, setImgPreview] = React.useState(null);
  const [detailMarketingId, setDetailMarketingId] = React.useState(null);
  const [arrProperty, setArrProperty] = React.useState([]);
  const [createIssuePlace, setCreateIssuePlace] = React.useState(false);

  const {
    token,
    id,
    formMktId,
    custUpd,
    custDetail,
    formBirthDate,
    formCardId,
    errors,
    sysBpm,
    readonly,
    customerType,
    accRight,
    glIssuePlace,
  } = props;

  const preCustUpdate = usePrevious(custUpd);
  const preSysBpm = usePrevious(sysBpm);
  const preCustomerType = usePrevious(customerType);
  const preFormBirthDate = usePrevious(formBirthDate);
  const preCustDetail = usePrevious(custDetail);
  let _filePaths = {};

  React.useEffect(() => {
    handleGetSingleCustomer();
    handleGetDetailBen();

    return () => {
      abortController.abort();

      dispatch(custDetailSuccess(null));
      dispatch(custUpdateSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (custUpd && !_.isEqual(custUpd, preCustUpdate)) {
      onClose();
    }
  }, [custUpd]);

  React.useEffect(() => {
    if (sysBpm && !_.isEqual(sysBpm, preSysBpm)) {
      let checkLienHe = {},
        checkGiamHo = {},
        checkDaiDien = {};
      checkLienHe.CHECK_CUST_ADDR =
        _.find(sysBpm, (o) => o.step === 'CHECK_CUST_ADDR')?.value || false;
      checkLienHe.CHECK_RESEDENCE_ADDR =
        _.find(sysBpm, (o) => o.step === 'CHECK_RESEDENCE_ADDR')?.value ||
        false;
      checkLienHe.CHECK_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_MOBILE')?.value || false;
      checkLienHe.CHECK_EMAIL =
        _.find(sysBpm, (o) => o.step === 'CHECK_EMAIL')?.value || false;

      checkGiamHo.CHECK_CONTACT_NAME =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_NAME')?.value || false;
      checkGiamHo.CHECK_CONTACT_RELATION =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_RELATION')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_CARDID =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_CARDID')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ISSUE_DATE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ISSUE_DATE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ISSUE_PLACE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ISSUE_PLACE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_ADDRESS =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_ADDRESS')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_MOBILE')?.value ||
        false;
      checkGiamHo.CHECK_CONTACT_EMAIL =
        _.find(sysBpm, (o) => o.step === 'CHECK_CONTACT_EMAIL')?.value || false;

      checkDaiDien.CHECK_REPRE_NAME =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_NAME')?.value || false;
      checkDaiDien.CHECK_REPRE_CARDID =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_CARDID')?.value || false;
      checkDaiDien.CHECK_REPRE_ISSUE_DATE =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_ISSUE_DATE')?.value ||
        false;
      checkDaiDien.CHECK_REPRE_POSITION =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_POSITION')?.value ||
        false;
      checkDaiDien.CHECK_REPRE_TEL =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_TEL')?.value || false;
      checkDaiDien.CHECK_REPRE_MOBILE =
        _.find(sysBpm, (o) => o.step === 'CHECK_REPRE_MOBILE')?.value || false;

      setBpmLienHe(checkLienHe);
      setBpmGiamHo(checkGiamHo);
      setBpmDaiDien(checkDaiDien);
    }
  }, [sysBpm]);

  React.useEffect(() => {
    if (custDetail && !_.isEqual(custDetail, preCustDetail)) {
      initForm();
      if (custDetail?.C_STATUS === 'DANG_SUA_DOI') {
        handleGetPropertyChange();
      }
    }
  }, [custDetail]);

  React.useEffect(() => {
    if (customerType && !_.isEqual(customerType, preCustomerType)) {
      if (customerType === 'CA_NHAN' && tabActive === 'THONG_TIN_DAI_DIEN')
        setTabActive('THONG_TIN_LIEN_HE');
    }
  }, [customerType]);

  React.useEffect(() => {
    if (formMktId && formMktId.length === 4) {
      _handleCheckMKT();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMktId]);

  React.useEffect(() => {
    if (formBirthDate && !_.isEqual(formBirthDate, preFormBirthDate)) {
      const _errText = validateBirthDate(formBirthDate);

      dispatch(
        updateSyncErrors('detailCustomerModalform', {
          ...errors,
          formBirthDate: _errText,
        })
      );
    }
  }, [formBirthDate]);

  function handleGetSingleCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: id?.C_CUSTOMER_CODE,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function handleGetDetailBen() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACC_BEN',
      group: 'LIST',
      data: {
        ITEM_ID: id?.C_CUSTOMER_CODE,
      },
    };

    dispatch(accBenSingleRequest(params));
  }

  function initForm() {
    const custSingle =
      custDetail.C_STATUS === 'DANG_SUA_DOI' && custDetail?.C_DATA
        ? JSON.parse(custDetail?.C_DATA)
        : custDetail;

    dispatch(
      change(
        'detailCustomerModalform',
        'customerType',
        custDetail?.C_CUSTOMER_TYPE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formCustCode',
        custDetail?.C_CUSTOMER_CODE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formCustName',
        custSingle?.C_CUSTOMER_NAME
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formCustShortName',
        custSingle?.C_CUST_SHORT_NAME
      )
    );
    dispatch(
      change('detailCustomerModalform', 'formMktId', custSingle?.C_MARKETING_ID)
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formBussinessType',
        custSingle?.C_BUSINESS_TYPE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formCustGender',
        custSingle?.C_CUST_GENDER
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formBirthDate',
        custSingle?.C_BIRTH_DAY
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formCardIdType',
        custSingle?.C_CARD_ID_TYPE
      )
    );
    dispatch(
      change('detailCustomerModalform', 'formCardId', custSingle?.C_CARD_ID)
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formIssueDate',
        custSingle?.C_ISSUE_DATE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formExpireDate',
        custSingle?.C_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formIssuePlace',
        custSingle?.C_ISSUE_PLACE
      )
    );
    dispatch(
      change('detailCustomerModalform', 'formTaxCode', custSingle?.C_TAX_CODE)
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formNationality',
        custSingle?.C_NATIONAL_CODE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formResidentInVN',
        custSingle?.C_VN_FLAG + ''
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formVsdSid',
        custSingle?.C_VSD_SID 
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formInvestorCode',
        custSingle?.C_INVESTOR_CODE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'formStaffFlag',
        custSingle?.C_STAFF_FLAG + ''
      )
    );
    // thông tin liên hệ
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhResedenceAddr',
        custSingle?.C_RESEDENCE_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhContactAddr',
        custSingle?.C_CUST_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhProvince',
        custSingle?.C_PROVINCE_CODE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhTel',
        custSingle?.C_CUST_TEL
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhFax',
        custSingle?.C_CUST_FAX
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhMobile',
        custSingle?.C_CUST_MOBILE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhEmail',
        custSingle?.C_CUST_EMAIL
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinLienHe.ttkhNote',
        custSingle?.C_CONTENT
      )
    );
    // nguoi giam ho
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhName',
        custSingle?.C_REPRE_NAME
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhRelation',
        custSingle?.C_REPRE_POSITION
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhCardId',
        custSingle?.C_REPRE_CARD_ID
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhIssueDate',
        custSingle?.C_REPRE_ISSUE_DATE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhExpireDate',
        custSingle?.C_REPRE_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhIssuePlace',
        custSingle?.C_REPRE_ISSUE_PLACE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhAddress',
        custSingle?.C_REPRE_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhMobile',
        custSingle?.C_REPRE_MOBILE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'nguoiGiamHo.ttlhEmail',
        custSingle?.C_REPRE_EMAIL
      )
    );
    //Thong tin dai dien
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddName',
        custSingle?.C_REPRE_NAME
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddNationality',
        custSingle?.C_REPRE_NATIONAL_CODE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddResidentInVN',
        custSingle?.C_REPRE_VN_FLAG + ''
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddCardIdType',
        custSingle?.C_REPRE_CARD_ID_TYPE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddCardID',
        custSingle?.C_REPRE_CARD_ID
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddIssueDate',
        custSingle?.C_REPRE_ISSUE_DATE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddIssuePlace',
        custSingle?.C_REPRE_ISSUE_PLACE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddPosition',
        custSingle?.C_REPRE_POSITION
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddAddress',
        custSingle?.C_REPRE_ADDRESS
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddGender',
        custSingle?.C_REPRE_GENDER
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddEmail',
        custSingle?.C_REPRE_EMAIL
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddMobile',
        custSingle?.C_REPRE_MOBILE
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddTel',
        custSingle?.C_REPRE_TEL
      )
    );
    dispatch(
      change(
        'detailCustomerModalform',
        'thongTinDaiDien.ttddAuthenSign',
        custSingle?.C_AUTHEN_SIGN
      )
    );
    //Xác thực khách hàng
    let _xts = [];

    if (custDetail.C_FRONT_CARD_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_MAT_TRUOC',
        xtAccountImage: custDetail.C_FRONT_CARD_IMAGE,
      });
    }
    if (custDetail.C_BACK_CARD_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_MAT_SAU',
        xtAccountImage: custDetail.C_BACK_CARD_IMAGE,
      });
    }
    if (custDetail.C_FACE_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_CHAN_DUNG',
        xtAccountImage: custDetail.C_FACE_IMAGE,
      });
    }
    if (custDetail.C_SIGN_IMAGE) {
      _xts.push({
        xtAccountType: 'ANH_CHU_KY',
        xtAccountImage: custDetail.C_SIGN_IMAGE,
      });
    }
    dispatch(change('detailCustomerModalform', 'xacthucTK', _xts));
  }

  function handleGetPropertyChange() {
    const _arrProperty = [];
    const _dest = Object.assign({}, custDetail);
    delete _dest.C_DATA;
    const _source = custDetail?.C_DATA ? JSON.parse(custDetail?.C_DATA) : [];
    if (_dest && _source)
      Object.keys(_dest).forEach((element) => {
        if (!_.isEqual(_dest[element.trim()] + '', _source[element.trim()])) {
          _arrProperty.push(element.trim());
        }
      });

    setArrProperty(_arrProperty);
  }

  function _handleBlurCardId() {
    if (
      formCardId &&
      _.find(sysBpm, (o) => o.step === 'CHECK_CARDID')?.value === true
    ) {
      _handleCheckCustomer('formCardId', 10);
    }
  }

  function _handleCheckCustomer(name, times = 1000) {
    if (!props[name]) {
      // dispatch(touch('addAccountInfoform', 'custCode'))
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: props[name],
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        if (res.code == 1 && res.data.length > 0) {
          _handleToast(`${t('txt-exists')}`, 'error');

          setTimeout(() => {
            dispatch(change('detailCustomerModalform', name, '', false));
          }, times);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function submit(values) {
    setIsLoading(true);

    if (values.xacthucTK && values.xacthucTK) {
      var iterator = asyncIterator(values.xacthucTK);
      handleUploadAnh(values, iterator);
    } else {
      handleNextProcess(values, null);
    }
  }

  function asyncIterator(_array) {
    return {
      next: function () {
        if (_array.length) {
          return {
            value: _array.shift(),
            done: false,
          };
        } else {
          return {
            done: true,
          };
        }
      },
    };
  }

  function handleUploadAnh(values, iterator) {
    const _iterator = iterator.next();
    console.log(_iterator);
    if (_iterator.done) {
      // next process
      handleNextProcess(values, _filePaths);
    } else {
      // upload
      // check file
      if (typeof _iterator.value.xtAccountImage === 'string') {
        // next
        handleUploadAnh(values, iterator);
      } else {
        // upload
        fileUpload(_iterator.value.xtAccountImage).then((response) => {
          if (response.code > 0) {
            // create request
            switch (_iterator.value.xtAccountType) {
              case 'ANH_MAT_TRUOC':
                _filePaths.pathAnhMt = response.FILE_DIR;
                break;
              case 'ANH_MAT_SAU':
                _filePaths.pathAnhMs = response.FILE_DIR;
                break;
              case 'ANH_CHAN_DUNG':
                _filePaths.pathAnhCD = response.FILE_DIR;
                break;
              case 'ANH_CHU_KY':
                _filePaths.pathAnhCK = response.FILE_DIR;
                break;

              default:
                break;
            }
            handleUploadAnh(values, iterator);
          } else {
            setIsLoading(false);
            _handleToast(response.re);
          }
        });
      }
    }
  }

  function fileUpload(file) {
    console.log('file', file);
    const formData = new FormData();
    formData.append('file', file);
    console.log('formdata', formData);
    const request = fetch(fileUrl, {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    return request
      .then((response) => response.json())
      .then((json) => json)
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
  }

  function handleNextProcess(values, filePaths) {
    let _params;
    if (customerType === 'CA_NHAN') {
      _params = renderParamCaNhan(values);
    } else {
      _params = renderParamToChuc(values);
    }

    let _bankAccount = [];
    values.banks?.forEach((element) => {
      _bankAccount.push({
        BANK_CODE: element.bankName, // mã tk ngân hàng
        BANK_ACCOUNT_CODE: element.bankAccount, // số tk ngân hàng
        BANK_ACCOUNT_NAME: removeAccent(element.bankAccountName), // tên tài khoản ngân hàng
        BANK_BRANCH_CODE: element.bankBranch, // chi nhánh online
        BANK_BRANCH_NAME: element.bankBranchHand, //  chi nhánh nhập tay
        ACCOUNT_TYPE: element.accountType,
        CHANNEL_CODE: element.channel,
        PROVINCE_CODE: element.bankProvince,
      });
    });

    if (_params) {
      _params.data.FRONT_CARD_IMAGE = filePaths.pathAnhMt;
      _params.data.BACK_CARD_IMAGE = filePaths.pathAnhMs;
      _params.data.SIGN_IMAGE = filePaths.pathAnhCK;
      _params.data.FACE_IMAGE = filePaths.pathAnhCD;
      // tài khoản thụ hưởng
      _params.data.LIST_BANK_ACCOUNT = _bankAccount;
      {
        /* console.log(_params, filePaths); */
      }
      dispatch(custUpdateRequest(_params));
      setIsLoading(false);
    }
  }

  function renderParamCaNhan(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custDetail?.PK_CUST_CUSTOMER,
        MARKETING_ID: values.formMktId,
        CHANNEL_CODE: 'D',
        CUSTOMER_TYPE: 'CA_NHAN',
        CUSTOMER_CODE: values.formCustCode, // mã khách hàng
        CUSTOMER_NAME: values.formCustName?.toUpperCase(),
        CUST_PRE_NAME: '', // Tên tiền tố Mrs/Mr/Ms
        CARD_ID_TYPE: values.formCardIdType, // loại đăng ký sở hữu
        CARD_ID: values.formCardId,
        VSD_SID: values.formVsdSid,
        INVESTOR_CODE: values.formInvestorCode,
        BIRTH_DAY: values.formBirthDate,
        ISSUE_DATE: values.formIssueDate,
        EXPIRE_DATE: values.formExpireDate,
        ISSUE_PLACE: values.formIssuePlace,
        CUST_GENDER: values.formCustGender,
        CUST_EMAIL: values.thongTinLienHe?.ttkhEmail,
        CUST_MOBILE: values.thongTinLienHe?.ttkhMobile,
        CUST_TEL: values.thongTinLienHe?.ttkhTel,
        CUST_FAX: values.thongTinLienHe?.ttkhFax,
        // CUST_WEBSITE: values.thongTinKhachHang?.ttkhWebsite,
        CUST_ADDRESS: values.thongTinLienHe?.ttkhContactAddr,
        RESEDENCE_ADDRESS: values.thongTinLienHe?.ttkhResedenceAddr,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        PROVINCE_CODE: '',
        VN_FLAG: StringToInt(values.formResidentInVN),
        STAFF_FLAG: StringToInt(values.formStaffFlag),
        CONTENT: values.thongTinLienHe?.ttkhNote,
        AUTHEN_SIGN: values.thongTinDaiDien?.ttddAuthenSign,

        REPRE_NAME: values.nguoiGiamHo?.ttlhName,
        // REPRE_GENDER: values.nguoiGiamHo?.ttlhName,
        REPRE_POSITION: values.nguoiGiamHo?.ttlhRelation,
        REPRE_CARD_ID: values.nguoiGiamHo?.ttlhCardId,
        // REPRE_BIRTH_DAY: values.nguoiGiamHo?.ttlhName,
        REPRE_ISSUE_DATE: values.nguoiGiamHo?.ttlhIssueDate,
        REPRE_EXPIRE_DATE: values.nguoiGiamHo?.ttlhExpireDate,
        REPRE_ISSUE_PLACE: values.nguoiGiamHo?.ttlhIssuePlace,
        REPRE_ADDRESS: values.nguoiGiamHo?.ttlhAddress,
        REPRE_MOBILE: values.nguoiGiamHo?.ttlhMobile,
        // REPRE_TEL: values.nguoiGiamHo?.ttlhName,
        // REPRE_FAX: values.nguoiGiamHo?.ttlhName,
        REPRE_EMAIL: values.nguoiGiamHo?.ttlhEmail,
        // REPRE_VN_FLAG: values.nguoiGiamHo?.ttlhName,
        // REPRE_NATIONAL_CODE : values.nguoiGiamHo?.ttlhName,
      },
    };

    return params;
  }

  function renderParamToChuc(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custDetail?.PK_CUST_CUSTOMER,
        MARKETING_ID: values.formMktId,
        CHANNEL_CODE: 'D',
        CUSTOMER_TYPE: 'TO_CHUC',
        CUSTOMER_CODE: values.formCustCode,
        CUSTOMER_NAME: values.formCustName?.toUpperCase(),
        CUST_SHORT_NAME: values.formCustShortName?.toUpperCase(),
        BUSINESS_TYPE: values.formBussinessType,
        CARD_ID_TYPE: values.formCardIdType,
        CARD_ID: values.formCardId,
        VSD_SID: values.formVsdSid,
        INVESTOR_CODE: values.formInvestorCode,
        ISSUE_DATE: values.formIssueDate,
        EXPIRE_DATE: values.formExpireDate,
        ISSUE_PLACE: values.formIssuePlace,
        CUST_EMAIL: values.thongTinLienHe?.ttkhEmail,
        CUST_MOBILE: values.thongTinLienHe?.ttkhMobile,
        CUST_TEL: values.thongTinLienHe?.ttkhTel,
        CUST_FAX: values.thongTinLienHe?.ttkhFax,
        CUST_ADDRESS: values.thongTinLienHe?.ttkhContactAddr,
        RESEDENCE_ADDRESS: values.thongTinLienHe?.ttkhResedenceAddr,
        // CUST_WEBSITE: values.thongTinLienHe?.ttkhWebsite,
        TAX_CODE: values.formTaxCode,
        NATIONAL_CODE: values.formNationality,
        PROVINCE_CODE: '',
        VN_FLAG: StringToInt(values.formResidentInVN),
        STAFF_FLAG: StringToInt(values.formStaffFlag),
        CONTENT: values.thongTinLienHe?.ttkhNote,
        AUTHEN_SIGN: values.thongTinDaiDien?.ttddAuthenSign,

        REPRE_NAME: values.thongTinDaiDien?.ttddName,
        REPRE_GENDER: values.thongTinDaiDien?.ttddGender,
        REPRE_POSITION: values.thongTinDaiDien?.ttddPosition,
        REPRE_CARD_ID_TYPE: values.thongTinDaiDien?.ttddCardIdType,
        REPRE_CARD_ID: values.thongTinDaiDien?.ttddCardID,
        // REPRE_BIRTH_DAY: values.thongTinDaiDien?.C_REPRE_BIRTH_DAY,
        REPRE_ISSUE_DATE: values.thongTinDaiDien?.ttddIssueDate,
        // REPRE_EXPIRE_DATE: values.thongTinDaiDien?.REPRE_EXPIRE_DATE,
        REPRE_ISSUE_PLACE: values.thongTinDaiDien?.ttddIssuePlace,
        REPRE_ADDRESS: values.thongTinDaiDien?.ttddAddress,
        REPRE_MOBILE: values.thongTinDaiDien?.ttddMobile,
        REPRE_TEL: values.thongTinDaiDien?.ttddTel,
        REPRE_FAX: '',
        REPRE_EMAIL: values.thongTinDaiDien?.ttddEmail,
        REPRE_VN_FLAG: StringToInt(values.thongTinDaiDien?.ttddResidentInVN),
        REPRE_NATIONAL_CODE: values.thongTinDaiDien?.ttddNationality,
      },
    };

    return params;
  }

  function _handleCheckMKT() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const validateBirthDate = (value) => {
    if (!value) return 'Trường không được để trống';

    const _isValidBirth = _.find(sysBpm, (o) => o.step === 'CHECK_AGE');
    if (_isValidBirth && _isValidBirth?.value === true) {
      //check ngày sinh ko lơn hơn ngày hiện tại
      const _diff = _diff2Date(value, formatDate(new Date(), '/', 'dmy'));
      if (_diff > 0) return 'Ngày sinh không đúng';
      const _age = getAge(value);
      for (let index = 0; index < _isValidBirth.data.length; index++) {
        const element = _isValidBirth.data[index];
        if (element.value === true && element.code === 'KHONG_DU_TUOI') {
          if (_age <= element?.v2 && _age >= element.v1) return 'Không đủ tuổi';
        }

        if (element.value === true && element.code === 'MO_TAI_KHOAN') {
          if (_age > element?.v2 || _age < element.v1)
            return `Chỉ mở tk từ ${element.v1} - ${element.v2} tuổi`;
        }
        if (element.value === true && element.code === 'CAN_GIAM_HO') {
          setIsCheckGiamHo(true);
        } else setIsCheckGiamHo(false);
      }
    } else setIsCheckGiamHo(false);
  };

  function handleClose() {
    setImgPreview(null);
  }

  const {
    handleSubmit,
    submitting,
    onClose,
    t,
    glNational,

    thongTinKhachHang,
    glCardIDType,
    glCardIDTypeOrg,
    singleUserFront,
    accBenSingle,
  } = props;

  function handleDetailMarketingId() {
    if (!formMktId) return;
    setDetailMarketingId(formMktId);
  }

  // thêm mới nơi cấp
  function fnAddCallback() {
    setCreateIssuePlace(true);
  }

  function setIssuePlace(code) {
    dispatch(change('detailCustomerModalform', 'formIssuePlace', code));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      {isLoading && (
        <div className="loading">
          <img src={Spinner} alt="" />
        </div>
      )}
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <div className="d-flex">
            <b className="fz-16 pl-3 mr-5">{t('txt-edit-cust-info')}</b>
            <div className="d-flex align-items-center">
              <Form.Group>
                <div>
                  <label>
                    <Field
                      name="customerType"
                      component="input"
                      type="radio"
                      className="cursor-pointer"
                      value={'CA_NHAN'}
                      disabled
                    />{' '}
                    {t('txt-individual-1')}
                  </label>
                  <label className="ml-3">
                    <Field
                      name="customerType"
                      component="input"
                      type="radio"
                      className="cursor-pointer"
                      value={'TO_CHUC'}
                      disabled
                    />{' '}
                    {t('txt-organization-1')}
                  </label>
                </div>
              </Form.Group>
            </div>
          </div>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <FormAdd onSubmit={handleSubmit(submit)}>
            <Form.Group>
              <Form.Label>
                {t('txt-cust-code')}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formCustCode"
                className="form-control input-order"
                component={RenderInput}
                disabled
                space
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                ID Sale
                <span className="text-danger">*</span>
              </Form.Label>
              <div className="d-flex justify-content-between">
                <div className="w-100">
                  <Field
                    name="formMktId"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_MARKETING_ID') > -1
                        ? ' hasChange'
                        : '')
                    }
                    classParent="w-100"
                    component={RenderNewInputMkt}
                    validate={[required, validateMktId]}
                    disabled={readonly}
                  />
                </div>
                <BtnDetail
                  type="button"
                  onClick={() => handleDetailMarketingId()}
                />
              </div>
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-marketing-name')}</Form.Label>
              <Form.Control
                value={singleUserFront?.C_FRONT_USER_NAME || ''}
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-company-employee')}</Form.Label>
              <div>
                <label>
                  <Field
                    name="formStaffFlag"
                    component="input"
                    type="radio"
                    value="1"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_STAFF_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                    disabled={readonly}
                  />{' '}
                  {t('txt-yes')}
                </label>
                <label className="ml-3">
                  <Field
                    name="formStaffFlag"
                    component="input"
                    type="radio"
                    value="0"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_STAFF_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                    disabled={readonly}
                  />{' '}
                  {t('txt-no')}
                </label>
              </div>
            </Form.Group>
            <Form.Group style={{ gridColumn: '1/3' }}>
              <Form.Label>
                {customerType === 'CA_NHAN'
                  ? `${t('txt-cust-name')}`
                  : `${t('txt-organization-name')}`}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formCustName"
                className={
                  'form-control input-order text-uppercase' +
                  (arrProperty?.indexOf('C_CUSTOMER_NAME') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderInput}
                validate={required}
                disabled={readonly}
              />
            </Form.Group>
            {customerType === 'CA_NHAN' ? (
              <>
                <Form.Group>
                  <Form.Label>
                    {t('txt-gender')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <div>
                    <label>
                      <Field
                        name="formCustGender"
                        component="input"
                        type="radio"
                        className={
                          'cursor-pointer' +
                          (arrProperty?.indexOf('C_CUST_GENDER') > -1
                            ? ' hasChange'
                            : '')
                        }
                        value="M"
                        disabled={readonly}
                      />{' '}
                      {t('txt-male')}
                    </label>
                    <label className="ml-3">
                      <Field
                        name="formCustGender"
                        component="input"
                        type="radio"
                        className={
                          'cursor-pointer' +
                          (arrProperty?.indexOf('C_CUST_GENDER') > -1
                            ? ' hasChange'
                            : '')
                        }
                        value="F"
                        disabled={readonly}
                      />{' '}
                      {t('txt-female')}
                    </label>
                  </div>
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-date-of-birth')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBirthDate"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_BIRTH_DAY') > -1
                        ? ' hasChange'
                        : '')
                    }
                    classParentName="w-100"
                    component={RenderSelectDate}
                    validate={required}
                    disabled={readonly}
                  />
                </Form.Group>
              </>
            ) : (
              <>
                <Form.Group>
                  <Form.Label>{t('txt-short-name')}t</Form.Label>
                  <Field
                    name="formCustShortName"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_CUST_SHORT_NAME') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                    disabled={readonly}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-business-type')}</Form.Label>
                  <Field
                    name="formBussinessType"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_BUSINESS_TYPE') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                  />
                </Form.Group>
              </>
            )}
            <Form.Group>
              <Form.Label>
                {t('txt-card-type')}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formCardIdType"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_CARD_ID_TYPE') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderNormalSelect}
                required
                opts={
                  customerType === 'CA_NHAN' ? glCardIDType : glCardIDTypeOrg
                }
                validate={required}
                disabled={readonly}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-card-id')}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formCardId"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_CARD_ID') > -1 ? ' hasChange' : '')
                }
                component={RenderInput}
                validate={[required, maxLength20]}
                onBlur={_handleBlurCardId}
                disabled={readonly}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-issue-date')}
                {_.find(sysBpm, (o) => o.step === 'CHECK_ISSUE_DATE')
                  ?.value && <span className="text-danger">*</span>}
              </Form.Label>
              <Field
                name="formIssueDate"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_ISSUE_DATE') > -1
                    ? ' hasChange'
                    : '')
                }
                classParentName="w-100"
                component={RenderSelectDate}
                validate={required}
                disabled={readonly}
              />
            </Form.Group>

            <Form.Group>
              <Form.Label>
                {t('txt-expire-date')}
                {_.find(sysBpm, (o) => o.step === 'CHECK_EXPIRE')?.value && (
                  <span className="text-danger">*</span>
                )}
              </Form.Label>
              <Field
                name="formExpireDate"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_EXPIRE_DATE') > -1
                    ? ' hasChange'
                    : '')
                }
                classParentName="w-100"
                component={RenderSelectDate}
                validate={validateExpireDate}
                disabled={readonly}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-issue-place')}
                <span className="text-danger">*</span>
                {/* {_.find(sysBpm, (o) => o.step === 'CHECK_ISSUE_PLACE')
                  ?.value && <span className="text-danger">*</span>} */}
              </Form.Label>
              <Field
                name="formIssuePlace"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_ISSUE_PLACE') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderSelectIssuePlace}
                opts={glIssuePlace}
                validate={required}
                disabled={readonly}
                actionAdd
                fnAddCallback={fnAddCallback}
                // validate={
                //   _.find(sysBpm, (o) => o.step === 'CHECK_ISSUE_PLACE')?.value
                //     ? required
                //     : null
                // }
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-tax-code')}
                {_.find(sysBpm, (o) => o.step === 'CHECK_TAX_CODE')?.value && (
                  <span className="text-danger">*</span>
                )}
              </Form.Label>
              <Field
                name="formTaxCode"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_TAX_CODE') > -1 ? ' hasChange' : '')
                }
                component={RenderInput}
                validate={
                  _.find(sysBpm, (o) => o.step === 'CHECK_TAX_CODE')?.value
                    ? required
                    : null
                }
                disabled={readonly}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-national')}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formNationality"
                className={
                  'form-control input-order' +
                  (arrProperty?.indexOf('C_NATIONAL_CODE') > -1
                    ? ' hasChange'
                    : '')
                }
                component={RenderSuggestNational}
                required
                validate={required}
                disabled={readonly}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-resident-vn')}
                <span className="text-danger">*</span>
              </Form.Label>
              <div>
                <label>
                  <Field
                    name="formResidentInVN"
                    component="input"
                    type="radio"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_VN_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                    value="1"
                    disabled={readonly}
                  />{' '}
                  {t('txt-yes')}
                </label>
                <label className="ml-3">
                  <Field
                    name="formResidentInVN"
                    component="input"
                    type="radio"
                    className={
                      'cursor-pointer' +
                      (arrProperty?.indexOf('C_VN_FLAG') > -1
                        ? ' hasChange'
                        : '')
                    }
                    value="0"
                    disabled={readonly}
                  />{' '}
                  {t('txt-no')}
                </label>
              </div>
            </Form.Group>
            <Form.Group>
                  <Form.Label>
                    VSD SID
                  </Form.Label>
                  <Field
                    name="formVsdSid"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_VSD_SID') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                    
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Mã NĐT
                  </Form.Label>
                  <Field
                    name="formInvestorCode"
                    className={
                      'form-control input-order' +
                      (arrProperty?.indexOf('C_INVESTOR_CODE') > -1
                        ? ' hasChange'
                        : '')
                    }
                    component={RenderInput}
                    
                  />
                </Form.Group>

            {/* TODO: Tabs Section  */}
            <TabsSectionHeader>
              <ul>
                <li
                  onClick={() => setTabActive('THONG_TIN_LIEN_HE')}
                  className={
                    (tabActive === 'THONG_TIN_LIEN_HE' ? 'active ' : '') +
                    (errors?.thongTinLienHe &&
                    Object.keys(errors?.thongTinLienHe)?.length > 0
                      ? 'error'
                      : '')
                  }
                >
                  {t('txt-contact-info')}
                </li>
                {customerType === 'TO_CHUC' && (
                  <li
                    onClick={() => setTabActive('THONG_TIN_DAI_DIEN')}
                    className={
                      (tabActive === 'THONG_TIN_DAI_DIEN' ? 'active ' : '') +
                      (errors?.thongTinDaiDien &&
                      Object.keys(errors?.thongTinDaiDien)?.length > 0
                        ? 'error'
                        : '')
                    }
                  >
                    {t('txt-representative')}
                  </li>
                )}
                {customerType !== 'TO_CHUC' && (
                  <li
                    onClick={() => setTabActive('NGUOI_GIAM_HO')}
                    className={
                      (tabActive === 'NGUOI_GIAM_HO' ? 'active ' : '') +
                      (errors?.nguoiGiamHo &&
                      Object.keys(errors?.nguoiGiamHo)?.length > 0
                        ? 'error'
                        : '')
                    }
                  >
                    {t('txt-guardian')}
                  </li>
                )}
                <li
                  onClick={() => setTabActive('XAC_THUC_KH')}
                  className={
                    (tabActive === 'XAC_THUC_KH' ? 'active ' : '') +
                    (errors?.xacthucTK &&
                    _.some(
                      errors?.xacthucTK,
                      (o) => o && Object.keys(o)?.length > 0
                    )
                      ? 'error'
                      : '')
                  }
                >
                  {t('txt-cust-authentication')}
                </li>
                <li
                  onClick={() => setTabActive('TAI_KHOAN_NGAN_HANG')}
                  className={
                    (tabActive === 'TAI_KHOAN_NGAN_HANG' ? 'active ' : '') +
                    (errors?.banks &&
                    _.some(
                      errors?.banks,
                      (o) => o && Object.keys(o)?.length > 0
                    )
                      ? 'error'
                      : '')
                  }
                >
                  {t('txt-ben-acc')}
                </li>
              </ul>
            </TabsSectionHeader>
            <FormSection name="thongTinLienHe">
              <ThongTinLienHe
                t={t}
                data={thongTinKhachHang}
                className={tabActive === 'THONG_TIN_LIEN_HE' ? 'active' : ''}
                customerType={customerType}
                bpmLienHe={bpmLienHe}
                readonly={readonly}
                arrProperty={arrProperty}
              />
            </FormSection>
            <FormSection name="nguoiGiamHo">
              <NguoiGiamHo
                t={t}
                className={tabActive === 'NGUOI_GIAM_HO' ? 'active' : ''}
                isCheckGiamHo={isCheckGiamHo}
                bpmGiamHo={bpmGiamHo}
                readonly={readonly}
                arrProperty={arrProperty}
              />
            </FormSection>
            <FormSection name="thongTinDaiDien">
              <ThongTinDaiDien
                t={t}
                glNational={glNational}
                className={tabActive === 'THONG_TIN_DAI_DIEN' ? 'active' : ''}
                customerType={customerType}
                bpmDaiDien={bpmDaiDien}
                readonly={readonly}
                glCardIDType={glCardIDType}
                arrProperty={arrProperty}
              />
            </FormSection>
            <div
              style={{
                gridColumn: '1/5',
                display: tabActive === 'XAC_THUC_KH' ? 'block' : 'none',
              }}
            >
              <FieldArray
                name="xacthucTK"
                component={XacThucAccount}
                readonly={readonly}
                onPreview={setImgPreview}
                t={t}
              />
            </div>
            <div
              style={{
                gridColumn: '1/5',
                display: tabActive === 'TAI_KHOAN_NGAN_HANG' ? 'block' : 'none',
              }}
            >
              <BanksAccount accBenSingle={accBenSingle} t={t} />
            </div>
            <Form.Label>
              {t('txt-creator')}
              {': '}
              {custDetail?.C_CREATOR_CODE}
            </Form.Label>
            <Form.Label>
              {t('txt-create-time')}
              {': '}
              {custDetail?.C_CREATE_TIME || ''}
            </Form.Label>
            <Form.Label>
              {t('txt-updator')}
              {': '} {custDetail?.C_UPDATOR_CODE}
            </Form.Label>
            <Form.Label>
              {t('txt-upd-time')}
              {': '}
              {custDetail?.C_UPDATE_TIME || ''}
            </Form.Label>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex justify-content-between"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose}>
                {t('txt-close')}
              </BtnClose>
              {accRight.C_UPDATE === 1 && (
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-confirm')}
                </BtnSubmit>
              )}
            </div>
          </FormAdd>
        </StyleContainer>
      </div>

      {imgPreview && <ImagesViewer onClose={handleClose} imgs={[imgPreview]} />}
      {detailMarketingId && (
        <DetailMarketingId
          id={detailMarketingId}
          onClose={() => setDetailMarketingId(null)}
        />
      )}
      {createIssuePlace && (
        <CreateIssuePlace
          onClose={() => setCreateIssuePlace(false)}
          setIssuePlace={setIssuePlace}
        />
      )}
    </ReactModal>
  );
}

DetailKhachHangModal = reduxForm({
  form: 'detailCustomerModalform',
  enableReinitialize: true,
  warn,
})(DetailKhachHangModal);

const selector = formValueSelector('detailCustomerModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCustomerUpdate = makeGetCustomerUpdate();
  const getProvinceList = makeGetProvinceList();
  const getNationalList = makeGetNationalList();
  const getAllBank = makeGetAllBank();
  const getAllSubBranch = makeGetAllSubBranch();
  const getCustomerDetail = makeGetCustomerDetail();
  const getSingleUserFront = makeGetSingleUserFront();
  const getSysBpmByType = makeGetSysBpmByType();
  const getAccBenType = makeGetAccBenType();
  const getChannelType = makeGetChannelType();
  const getAccBenSingle = makeGetAccBenSingle();
  const getGlobalCardIDType = makeGetGlobalCardIDType();
  const getGlobalCardIDTypeOrg = makeGetGlobalCardIDTypeOrg();
  const getGlIssuePlace = makeGetGlIssuePlace();

  const {
    customerType,
    formCustCode,
    formCustName,
    formCustShortName,
    formMktId,
    formBussinessType,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formVsdSid,
    formInvestorCode,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formTaxCode,
    formNationality,
    formResidentInVN,
    formStaffFlag,

    thongTinLienHe,
    nguoiGiamHo,
    thongTinDaiDien,
    banks,
    xacthucTK,
  } = selector(
    state,
    'customerType',
    'formCustCode',
    'formCustName',
    'formCustShortName',
    'formMktId',
    'formBussinessType',
    'formCustGender',
    'formBirthDate',
    'formCardIdType',
    'formCardId',
    'formInvestorCode',
    'formVsdSid',
    'formIssueDate',
    'formExpireDate',
    'formIssuePlace',
    'formTaxCode',
    'formNationality',
    'formResidentInVN',
    'formStaffFlag',

    'thongTinLienHe',
    'nguoiGiamHo',
    'thongTinDaiDien',
    'banks',
    'xacthucTK'
  );

  const custDetail = getCustomerDetail(state);

  return {
    token: getToken(state),
    glProvince: getProvinceList(state),
    glNational: getNationalList(state),
    glAllBank: getAllBank(state),
    glAllSubBranch: getAllSubBranch(state),
    custUpd: getCustomerUpdate(state),
    singleUserFront: getSingleUserFront(state),
    sysBpm: getSysBpmByType(
      state,
      customerType === 'CA_NHAN' ? 'INDIVIDUAL' : 'ORGANIZATION'
    ),
    glAccBenType: getAccBenType(state),
    glChannelType: getChannelType(state),
    accBenSingle: getAccBenSingle(state),
    glCardIDType: getGlobalCardIDType(state),
    glCardIDTypeOrg: getGlobalCardIDTypeOrg(state),
    glIssuePlace: getGlIssuePlace(state),
    custDetail,

    customerType,
    formCustCode,
    formCustName,
    formCustShortName,
    formMktId,
    formBussinessType,
    formCustGender,
    formBirthDate,
    formCardIdType,
    formCardId,
    formVsdSid,
    formInvestorCode,
    formIssueDate,
    formExpireDate,
    formIssuePlace,
    formTaxCode,
    formNationality,
    formResidentInVN,
    formStaffFlag,

    thongTinLienHe,
    nguoiGiamHo,
    thongTinDaiDien,
    banks,
    xacthucTK,

    errors: getFormSyncErrors('detailCustomerModalform')(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailKhachHangModal)
);
