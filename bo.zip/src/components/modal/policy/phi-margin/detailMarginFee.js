import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import {
  marginFeeDelRequest,
  marginFeeDetailDelRequest,
  marginFeeDetailDelSuccess,
  marginFeeDetailUpdateSuccess,
  marginFeeListDetailRequest,
  marginFeeListDetailSuccess,
  marginFeeSingleRequest,
  marginFeeSingleSuccess,
  marginFeeUpdRequest
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeDelDetailMarginFee,
  makeDelMarginFee,
  makeGetToken,
  makeListDetailMarginFee,
  makeSingleMarginFee,
  makeUpdDetailMarginFee,
  makeUpdMarginFee
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Button, Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import { HiViewGridAdd } from 'react-icons/hi';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToDouble } from 'utils';
import { BtnClose, BtnSubmit, GroupButton } from 'utils/styledComponent';
import { required } from 'utils/validation';
import CreateDetailMarginFeeModal from './createDetailMarginFee';
import RenderSelectDate from 'components/input/renderDatePicker';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailMarginFeeModal(props) {
  const dispatch = useDispatch();
  const [showAddList, setShowAddList] = React.useState(false);
  const {
    token,
    onClose,
    id,
    marginFeeSingle,
    marginFeeUpd,
    marginFeeListDetail,
    marginFeeDetailDel,
    pristine,
    submitting,
    accRight,
    marginFeeDel,
    marginFeeDetailUpd,
  } = props;

  console.log(accRight);


  const preComboFeeDetailUpd = usePrevious(marginFeeDetailUpd);
  const preComboFeeDetailDel = usePrevious(marginFeeDetailDel);
  const preComboFeeUpd = usePrevious(marginFeeUpd);
  const premarginFeeSingle = usePrevious(marginFeeSingle);
  const preComboFeeDel = usePrevious(marginFeeDel);

  useEffect(() => {
    getMarginSingle();

    return () => {
      dispatch(marginFeeSingleSuccess(null));
      dispatch(marginFeeListDetailSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (
      marginFeeSingle &&
      !_.isEqual(marginFeeSingle, premarginFeeSingle)
    ) {
      initForm();
      getAllListDetailComboFee();
    }
  }, [marginFeeSingle]);

  useEffect(() => {
    if (
      marginFeeDetailUpd &&
      !_.isEqual(marginFeeDetailUpd, preComboFeeDetailUpd)
    ) {
      _handleToast(`${t('txt-upd-fee-margin-detail-success')}`, 'success');
      dispatch(marginFeeDetailUpdateSuccess(null));
      getAllListDetailComboFee();
    }
  }, [marginFeeDetailUpd]);

  useEffect(() => {
    if (marginFeeUpd && !_.isEqual(marginFeeUpd, preComboFeeUpd)) {
      _handleToast(`${t('txt-upd-fee-margin-success')}`, 'success');
      dispatch(marginFeeUpdRequest(null));
      getMarginSingle();
    }
  }, [marginFeeUpd]);

  useEffect(() => {
    if (
      marginFeeDetailDel &&
      !_.isEqual(marginFeeDetailDel, preComboFeeDetailDel)
    ) {
      _handleToast(`${t('txt-del-fee-margin-detail-success')}`, 'success');
      dispatch(marginFeeDetailDelSuccess(null));
      getAllListDetailComboFee();
    }
  }, [marginFeeDetailDel]);

  useEffect(() => {
    if (marginFeeDel && !_.isEqual(marginFeeDel, preComboFeeDel)) {
      onClose();
    }
  }, [marginFeeDel]);

  function initForm() {
    dispatch(
      change('detailMarginFeeModalform', 'formCode', marginFeeSingle?.C_CODE)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formName', marginFeeSingle?.C_NAME)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formOverdueInterest', marginFeeSingle?.C_OVER_RATE)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formExcessInterest', marginFeeSingle?.C_PEN_RATE)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formNote', marginFeeSingle?.C_CONTENT)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formActive', marginFeeSingle?.C_ACTIVE === 1)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formFromDate', marginFeeSingle?.C_EFFECT_DATE)
    );
    dispatch(
      change('detailMarginFeeModalform', 'formToDate', marginFeeSingle?.C_EXPIRE_DATE)
    );
  }

  function getAllListDetailComboFee() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST_MARGIN_RATE',
      group: 'LIST',
      data: {
        CODE: marginFeeSingle?.C_CODE,
      },
    };

    dispatch(marginFeeListDetailRequest(params));
  }

  function getMarginSingle() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_MARGIN_FEE',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(marginFeeSingleRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_LIST_MARGIN_FEE',
      group: 'LIST',
      data: {
        ITEM_ID: marginFeeSingle?.PK_MARGIN_FEE,
        CODE: props?.formCode,
        NAME: props?.formName,
        EFFECT_DATE: props?.formFromDate,
        EXPIRE_DATE: props?.formToDate,
        //PEN_RATE: StringToDouble(props?.formExcessInterest),
        //OVER_RATE: StringToDouble(props?.formOverdueInterest),
        CONTENT: props?.formNote,
        ACTIVE: props?.formActive ? 1 : 0,
      },
    };

    dispatch(marginFeeUpdRequest(params));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-margin')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDelCommPackage();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDel(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-margin-detail')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDelCommPackage() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_LIST_MARGIN_FEE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: marginFeeSingle?.PK_MARGIN_FEE,
      },
    };

    dispatch(marginFeeDelRequest(params));
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_LIST_MARGIN_RATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(marginFeeDetailDelRequest(params));
  }

  function showAddListInType() {
    setShowAddList(true);
  }

  function onCloseAdd() {
    setShowAddList(false);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Phí margin ưu đãi</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-fee-margin-code')}{' '}
                </Form.Label>
                <Field
                  name="formCode"
                  className="form-control"
                  classParent="w-100"
                  component={RenderInput}
                  validate={[required]}
                  disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">
                  {t('txt-fee-margin-name')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control"
                  component={RenderInput}
                  validate={[required]}
                  //disabled
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>
                  Từ ngày
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Đến ngày <span className="text-danger">*</span></Form.Label>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                  //validate={required}
                />
              </Form.Group>
              {/* <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-over-interest-rate')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formOverdueInterest"
                  className="form-control"
                  classParent="w-100"
                  component={RenderInputMask}
                  validate={[required]}
                  allowDecimal
                />
              </Form.Group> */}

              {/* <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-pen-interest-rate')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formExcessInterest"
                  className="form-control"
                  component={RenderInputMask}
                  validate={[required]}
                  allowDecimal
                  decimalLimit
                  allowNegative
                />
              </Form.Group> */}
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control"
                  component={RenderArea}
                  rows="3"
                />
              </Form.Group>
              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto">
                  {t('txt-interest-rate-info')}
                </span>
                {accRight?.C_UPDATE === 1 && (
                  <Button
                    variant="outline-primary"
                    className="text-white fz-13"
                    onClick={showAddListInType}
                  >
                    <HiViewGridAdd />
                    {t('txt-add-new')}
                  </Button>
                )}
              </div>
              <div style={{ gridColumn: '1/4' }}>
                <Table bordered className="mb-0 table-fixed">
                  <colgroup>
                    <col width="15%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="10%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>Sản phẩm</th>
                      <th>{t('txt-sounce-code')}</th>
                      <th>{t('txt-from-value-1')}</th>
                      <th>{t('txt-to-value-1')}</th>
                      <th>{t('txt-interest-rate')}</th>
                      <th>{t('txt-action')}</th>

                    </tr>
                  </thead>
                </Table>
                <div>
                  <PerfectScrollbar style={{ maxHeight: '350px' }}>
                    <Table bordered className="mt-0 table-fixed">
                      <colgroup>
                        <col width="15%" />
                        <col width="15%" />
                        <col width="15%" />
                        <col width="15%" />
                        <col width="15%" />
                        <col width="10%" />
                      </colgroup>
                      <tbody>
                        {marginFeeListDetail &&
                          marginFeeListDetail.map((item) => (
                            <tr key={item.PK_MARGIN_RATE}>
                              <td className="text-center">
                                {item.C_PRODUCT_CODE}
                              </td>
                              <td className="text-center">
                                {item.C_BANK_CODE}
                              </td>
                              <td className="text-center">
                                {item.C_FROM_VALUE}
                              </td>
                              <td className="text-center">
                                {item.C_TO_VALUE}
                              </td>
                              <td className="text-center">
                                {item.C_RATE}
                              </td>
                              <td className="text-center">
                                <GroupButton>
                                  {accRight?.C_UPDATE === 1 && (
                                    <a
                                      title={t('txt-del')}
                                      onClick={() =>
                                        handleDel(item.PK_MARGIN_RATE)
                                      }
                                    >
                                      <IconTrash />
                                    </a>
                                  )}
                                </GroupButton>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </Table>
                    {(!marginFeeListDetail || !marginFeeListDetail.length) && (
                      <p className="fz-13 text-center">{t('txt-no-data')}</p>
                    )}
                  </PerfectScrollbar>
                </div>
                <div>
                  <label
                    style={{
                      paddingTop: '10px',
                      alignSelf: 'end',
                      gridColumn: '1/2',
                    }}
                    className="form-label"
                  >
                    <Field
                      name="formActive"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </div>
              </div>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <div className="d-flex">
                  {accRight?.C_UPDATE === 1 && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 danger"
                      >
                        {t('txt-del')}
                      </BtnSubmit>
                      <BtnSubmit
                        type="submit"
                        disabled={pristine || submitting}
                        className="w_125 ml-2"
                      >
                        {t('txt-accept')}
                      </BtnSubmit>
                    </>
                  )}
                </div>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {showAddList && (
        <CreateDetailMarginFeeModal
          onClose={onCloseAdd}
          code={marginFeeSingle?.C_CODE}
        />
      )}
    </ReactModal>
  );
}

DetailMarginFeeModal = reduxForm({
  form: 'detailMarginFeeModalform',
  enableReinitialize: true,
})(DetailMarginFeeModal);

const selector = formValueSelector('detailMarginFeeModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getMarginFeeSingle = makeSingleMarginFee();
  const getMarginFeeUpdate = makeUpdMarginFee();
  const getMarginFeeListDetail = makeListDetailMarginFee();
  const getMarginFeeDetailDel = makeDelDetailMarginFee();
  const getMarginFeeDetailUpd = makeUpdDetailMarginFee();
  const getMarginFeeDelete = makeDelMarginFee();

  const {
    formCode,
    formName,
    formActive,
    formNote,
    formOverdueInterest,
    formExcessInterest,
    formFromDate,
    formToDate
  } = selector(
    state,
    'formCode',
    'formName',
    'formActive',
    'formNote',
    'formOverdueInterest',
    'formExcessInterest',
    'formFromDate',
    'formToDate'
  );


  return {
    token: getToken(state),
    marginFeeSingle: getMarginFeeSingle(state),
    marginFeeUpd: getMarginFeeUpdate(state),
    marginFeeListDetail: getMarginFeeListDetail(state),
    marginFeeDetailDel: getMarginFeeDetailDel(state),
    marginFeeDetailUpd: getMarginFeeDetailUpd(state),
    marginFeeDel: getMarginFeeDelete(state),

    formCode,
    formName,
    formNote,
    formActive,
    formOverdueInterest,
    formExcessInterest,
    formFromDate,
    formToDate
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailMarginFeeModal)
);
