import RenderInputMask from 'components/input/renderInputMask';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  marginFeeDetailUpdateRequest,
  marginFeeDetailUpdateSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  muSingleBankRequest,
  muSingleBankSuccess
} from 'containers/product/actions';
import {
  makeGetDisbusermentCode,
  makeGetMuSingleBank,
  makeGetToken,
  makeUpdDetailMarginFee
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import RenderSuggestProduct from 'components/input/renderSuggestProduct';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateDetailMarginFeeModal(props) {
  const dispatch = useDispatch();
  const {
    token,
    onClose,
    code,
    marginFeeDetailUpd,
    formSounceCode,
    handleSubmit,
    glDisbusermentCode,
    t,
    muSingleBank
  } = props;

  const preComboFeeDetailUpd = usePrevious(marginFeeDetailUpd);
  const preFormSounceCode = usePrevious(formSounceCode);

  useEffect(() => {
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (
      marginFeeDetailUpd &&
      !_.isEqual(marginFeeDetailUpd, preComboFeeDetailUpd)
    ) {
      _handleToast(`${t('txt-add-fee-margin-detail-success')}`, 'success');
      dispatch(marginFeeDetailUpdateSuccess(null));
      onClose();
    }
  }, [marginFeeDetailUpd]);

  useEffect(() => {
    if (
      formSounceCode &&
      !_.isEqual(formSounceCode, preFormSounceCode)
    ) {
      _handleCheckTN();
    }
    else {
      dispatch(muSingleBankSuccess(null));
    }
  }, [formSounceCode]);

  console.log(formSounceCode);

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-new-fee-margin-detail')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionMarginFeeUpd();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionMarginFeeUpd() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_LIST_MARGIN_RATE',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        CODE: code,
        BANK_CODE: props?.formSounceCode,
        PRODUCT_CODE: props?.formProdCode,
        FROM_VALUE: props?.formFromValue,
        TO_VALUE: props?.formToValue,
        RATE: props?.formInterestRate,
      },
    };
    dispatch(marginFeeDetailUpdateRequest(params));
  }

  function _handleCheckTN() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_MU_BANK_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: formSounceCode,
      },
    };
    dispatch(muSingleBankRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-fee-margin-detail')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
              <Form.Group>
                <Form.Label>
                  {t('txt-prod-code')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formProdCode"
                  className="form-control "
                  classParent="w-100"
                  component={RenderSuggestProduct}
                  validate={[required]}
                />
              </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-sounce-code')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formSounceCode"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glDisbusermentCode}
                    classParent="w-100"
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-source-name')}</Form.Label>
                  <Form.Control
                    value={muSingleBank?.C_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-from-value-1')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFromValue"
                    className="form-control"
                    classParent="w-100"
                    validate={[required]}
                    component={RenderInputMask}
                    allowDecimal
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-to-value-1')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formToValue"
                    className="form-control"
                    classParent="w-100"
                    validate={[required]}
                    component={RenderInputMask}
                    allowDecimal
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-interest-rate')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formInterestRate"
                    className="form-control"
                    classParent="w-100"
                    validate={[required]}
                    component={RenderInputMask}
                    allowDecimal
                    decimalLimit
                    allowNegative
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" className="w_100 ml-2">
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateDetailMarginFeeModal = reduxForm({
  form: 'createDetailMarginFeeModalform',
  enableReinitialize: true,
})(CreateDetailMarginFeeModal);

const selector = formValueSelector('createDetailMarginFeeModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getUpdDetailMarginFee = makeUpdDetailMarginFee();
  const getGlobalDisbusermentCode = makeGetDisbusermentCode();
  const getMuSingleBank = makeGetMuSingleBank();

  const {
    formCode,
    formSounceCode,
    formFromValue,
    formToValue,
    formInterestRate,
    formProdCode
  } = selector(
    state,
    'formCode',
    'formSounceCode',
    'formFromValue',
    'formToValue',
    'formInterestRate',
    'formProdCode'
  );

  return {
    token: getToken(state),
    marginFeeDetailUpd: getUpdDetailMarginFee(state),
    glDisbusermentCode: getGlobalDisbusermentCode(state),
    muSingleBank: getMuSingleBank(state),

    formCode,
    formSounceCode,
    formFromValue,
    formToValue,
    formInterestRate,
    formProdCode
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateDetailMarginFeeModal)
);
