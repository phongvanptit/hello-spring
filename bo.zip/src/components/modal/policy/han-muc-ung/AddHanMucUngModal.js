import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderSuggestBank from 'components/input/renderSuggestBank';
import {
  typeSingleBankRequest,
  typeSingleBankSuccess,
} from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { replaceAll } from 'utils';
import { required, validateNumberExact } from 'utils/validation';

import {
  makeGetCashUpdateHMU,
  makeGetToken,
  makeGetTypeSingleBank,
} from 'lib/selector';

import {
  cashHMUUpdateRequest,
  cashHMUUpdateSuccess,
} from 'containers/cash/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;
//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddHanMucUngModal(props) {
  const dispatch = useDispatch();

  const { token, formBankCode, typeSingleBank, cashUpdateHMU } = props;
  const preCashUpdateHMU = usePrevious(cashUpdateHMU);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(cashHMUUpdateSuccess(null));
      dispatch(typeSingleBankSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formBankCode) {
      _handleCheckBank();
    } else dispatch(typeSingleBankSuccess(null));
  }, [formBankCode]);

  useEffect(() => {
    if (cashUpdateHMU && !_.isEqual(cashUpdateHMU, preCashUpdateHMU)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashHMUUpdateSuccess(null));
      onClose();
    }
  }, [cashUpdateHMU]);

  function initForm() {
    dispatch(
      change('openHanMucUngModalform', 'formChkStatus', true)
    );
  }

  function _handleCheckBank() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BANK',
      group: 'LIST',
      data: {
        BANK_ID: formBankCode,
      },
    };
    dispatch(typeSingleBankRequest(params));
  }

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ADV_CREDIT_LIMIT',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        BANK_CODE: props?.formBankCode,
        BANK_NAME: typeSingleBank?.C_BANK_NAME || '',
        CASH_VALUE: Number(replaceAll(props?.formLimitAmount, ',', '')),
        CONTENT: props?.formNote,
        ACTIVE: props?.formChkStatus ? '1' : '0',
        STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(cashHMUUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
      ariaHideApp={false}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-limit-advance-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-bank')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankCode"
                    className="form-control "
                    classParent="w-100"
                    validate={[required]}
                    component={RenderSuggestBank}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-bank-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={typeSingleBank?.C_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advance-limit')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formLimitAmount"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13 mr-4">
                    {t('txt-status')}
                  </Form.Label>
                  <div>
                    <label className="form-label">
                      <Field
                        name="formChkStatus"
                        component="input"
                        type="checkbox"
                      />{' '}
                      {t('txt-active')}
                    </label>
                  </div>
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label className="fz-13">{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddHanMucUngModal = reduxForm({
  form: 'openHanMucUngModalform',
  enableReinitialize: true,
})(AddHanMucUngModal);

const selector = formValueSelector('openHanMucUngModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCashUpdateHMU = makeGetCashUpdateHMU();
  const getTypeSingleBank = makeGetTypeSingleBank();

  const { formBankCode, formLimitAmount, formNote, formChkStatus } = selector(
    state,
    'formBankCode',
    'formLimitAmount',
    'formNote',
    'formChkStatus'
  );

  return {
    token: getToken(state),
    cashUpdateHMU: getCashUpdateHMU(state),
    typeSingleBank: getTypeSingleBank(state),
    formBankCode,
    formLimitAmount,
    formNote,
    formChkStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddHanMucUngModal)
);
