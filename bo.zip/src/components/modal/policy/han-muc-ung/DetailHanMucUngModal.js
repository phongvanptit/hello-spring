import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderSuggestBank from 'components/input/renderSuggestBank';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';

import {
  typeSingleBankRequest,
  typeSingleBankSuccess,
} from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { replaceAll } from 'utils';
import { required, validateNumberExact } from 'utils/validation';

import {
  makeGetCashApproveHMU,
  makeGetCashDelHMU,
  makeGetCashSingleHMU,
  makeGetCashUpdateHMU,
  makeGetToken,
  makeGetTypeSingleBank,
} from 'lib/selector';

import {
  cashHMUApproveRequest,
  cashHMUApproveSuccess,
  cashHMUDelRequest,
  cashHMUDelSuccess,
  cashHMUSingleRequest,
  cashHMUSingleSuccess,
  cashHMUUpdateRequest,
  cashHMUUpdateSuccess,
} from 'containers/cash/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailHanMucUngModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    formBankCode,
    typeSingleBank,
    cashUpdateHMU,
    singleHMU,
    cashDelHMU,
    cashApproveHMU,
    record,
    accRight,
  } = props;
  const preCashDelHMU = usePrevious(cashDelHMU);
  const preCashUpdateHMU = usePrevious(cashUpdateHMU);
  const preCashApproveHMU = usePrevious(cashApproveHMU);
  const preSingleHMU = usePrevious(singleHMU);

  useEffect(() => {
    if (singleHMU && !_.isEqual(singleHMU, preSingleHMU)) {
      initForm();
    }
  }, [singleHMU]);

  useEffect(() => {
    if (record) handleGetDetail();
    return () => {
      dispatch(cashHMUUpdateSuccess(null));
      dispatch(typeSingleBankSuccess(null));
      dispatch(cashHMUSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formBankCode) {
      _handleCheckBank();
    } else dispatch(typeSingleBankSuccess(null));
  }, [formBankCode]);

  useEffect(() => {
    if (cashUpdateHMU && !_.isEqual(cashUpdateHMU, preCashUpdateHMU)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashHMUUpdateSuccess(null));
      handleGetDetail();
    }
  }, [cashUpdateHMU]);

  useEffect(() => {
    if (cashDelHMU && !_.isEqual(cashDelHMU, preCashDelHMU)) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashHMUDelSuccess(null));
      onClose();
    }
  }, [cashDelHMU]);

  useEffect(() => {
    if (cashApproveHMU && !_.isEqual(cashApproveHMU, preCashApproveHMU)) {
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      dispatch(cashHMUApproveSuccess(null));
      handleGetDetail();
    }
  }, [cashApproveHMU]);

  function initForm() {
    dispatch(
      change('detailHanMucUngModalform', 'formBankCode', singleHMU?.C_BANK_CODE)
    );
    dispatch(
      change('detailHanMucUngModalform', 'formLimitAmount', '' + singleHMU?.C_CASH_VALUE)
    );
    dispatch(
      change('detailHanMucUngModalform', 'formNote', singleHMU?.C_CONTENT)
    );
    dispatch(
      change('detailHanMucUngModalform', 'formChkStatus', singleHMU?.C_ACTIVE === 1 ? true : false)
    );
  }

  function _handleCheckBank() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BANK',
      group: 'LIST',
      data: {
        BANK_ID: formBankCode,
      },
    };
    dispatch(typeSingleBankRequest(params));
  }

  function handleGetDetail() {
    if (!record) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ADV_CREDIT_LIMIT',
      group: 'LIST',
      data: {
        ITEM_ID: record?.PK_ADVANCE_CREDIT_LIMIT,
      },
    };

    dispatch(cashHMUSingleRequest(params));
  }

  function submit(values) {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ADV_CREDIT_LIMIT',
      group: 'LIST',
      data: {
        ITEM_ID: singleHMU?.PK_ADVANCE_CREDIT_LIMIT || '',
        BANK_CODE: values?.formBankCode,
        BANK_NAME: typeSingleBank?.C_BANK_NAME || '',
        CASH_VALUE: Number(replaceAll(values?.formLimitAmount, ',', '')),
        CONTENT: values?.formNote,
        ACTIVE: values?.formChkStatus ? '1' : '0',
        STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(cashHMUUpdateRequest(params));
  }

  function _handleApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ADV_CREDIT_LIMIT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleHMU?.PK_ADVANCE_CREDIT_LIMIT,
      },
    };

    dispatch(cashHMUApproveRequest(params));
  }

  function _handleDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ADV_CREDIT_LIMIT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleHMU?.PK_ADVANCE_CREDIT_LIMIT,
      },
    };

    dispatch(cashHMUDelRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
      ariaHideApp={false}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-limit-advance-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-bank')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankCode"
                    className="form-control "
                    classParent="w-100"
                    validate={[required]}
                    component={RenderSuggestBank}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-bank-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={typeSingleBank?.C_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advance-limit')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formLimitAmount"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13 mr-4">
                    {t('txt-status')}
                  </Form.Label>
                  <div>
                    <label>
                      <Field
                        name="formChkStatus"
                        component="input"
                        type="checkbox"
                      />{' '}
                      {t('txt-active')}
                    </label>
                  </div>
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label className="fz-13">{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_APPROVE === 1 &&
                  singleHMU?.C_STATUS === 'CHUA_DUYET' && (
                    <>
                      <BtnSubmit
                        type="button"
                        disabled={submitting}
                        onClick={_handleApprove}
                        className="w_125 ml-2 info"
                      >
                        {t('bnt-appr-entry')}
                      </BtnSubmit>
                      {!singleHMU?.C_APPROVER_CODE && (
                        <BtnSubmit
                          type="button"
                          disabled={submitting}
                          onClick={_handleDel}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                      )}
                    </>
                  )}
                {accRight?.C_UPDATE === 1 && singleHMU && (
                  <BtnSubmit
                    type="submit"
                    disabled={submitting}
                    className="w_125 ml-2"
                  >
                    {t('bnt-edit-entry')}
                  </BtnSubmit>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailHanMucUngModal = reduxForm({
  form: 'detailHanMucUngModalform',
  enableReinitialize: true,
})(DetailHanMucUngModal);

const selector = formValueSelector('detailHanMucUngModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCashUpdateHMU = makeGetCashUpdateHMU();
  const getTypeSingleBank = makeGetTypeSingleBank();
  const getCashSingleHMU = makeGetCashSingleHMU();
  const getCashDelHMU = makeGetCashDelHMU();
  const getCashApproveHMU = makeGetCashApproveHMU();

  const { formBankCode, formLimitAmount, formNote, formChkStatus } = selector(
    state,
    'formBankCode',
    'formLimitAmount',
    'formNote',
    'formChkStatus'
  );
  const singleHMU = getCashSingleHMU(state);
  return {
    token: getToken(state),
    cashUpdateHMU: getCashUpdateHMU(state),
    typeSingleBank: getTypeSingleBank(state),
    singleHMU,
    cashDelHMU: getCashDelHMU(state),
    cashApproveHMU: getCashApproveHMU(state),
    formBankCode,
    formLimitAmount,
    formNote,
    formChkStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailHanMucUngModal)
);


