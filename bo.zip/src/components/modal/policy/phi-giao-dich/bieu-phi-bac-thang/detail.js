import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Button, Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import { HiViewGridAdd } from 'react-icons/hi';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { numberFormat } from 'utils';
import { BtnClose, BtnSubmit, GroupButton } from 'utils/styledComponent';
import { required } from 'utils/validation';
import CreateMucPhi from './CreateMucPhi';

import {
  commBaseDelRequest,
  commBaseSingleRequest,
  commBaseSingleSuccess,
  commBaseUpdRequest,
  commBaseUpdSuccess,
  commRateDelRequest,
  commRateDelSuccess,
  commRateSearchRequest,
} from 'containers/account/actions';

import { commRateSearchSuccess } from 'containers/account/actions';
import {
  makeCommRateListSearch,
  makeGetCommBaseDel,
  makeGetCommBaseSingle,
  makeGetCommBaseUpdate,
  makeGetCommRateDel,
  makeGetCommRateUpdate,
  makeGetToken,
} from 'lib/selector';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailBieuPhiModal(props) {
  const dispatch = useDispatch();
  const [showAddList, setShowAddList] = React.useState(false);

  const {
    token,
    onClose,
    id,
    commRateDel,
    commBaseSingle,
    commBaseUpdate,
    listCommRate,
    commBaseDel,
    commRateUpd,
    accRight,
  } = props;

  const preCommRateDel = usePrevious(commRateDel);
  const preCommBaseUpD = usePrevious(commBaseUpdate);
  const preCommBaseSingle = usePrevious(commBaseSingle);
  const preCommBaseDelete = usePrevious(commBaseDel);
  const preCommRateUpD = usePrevious(commRateUpd);

  useEffect(() => {
    if (commBaseSingle && !_.isEqual(commBaseSingle, preCommBaseSingle)) {
      initForm();
      getAllListCommRate();
    }
  }, [commBaseSingle]);

  useEffect(() => {
    getCommBaseSingle();
    return () => {
      dispatch(commBaseSingleSuccess(null));
      dispatch(commRateSearchSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (commRateUpd && !_.isEqual(commRateUpd, preCommRateUpD)) {
      getAllListCommRate();
    }
  }, [commRateUpd]);

  useEffect(() => {
    if (commBaseUpdate && !_.isEqual(commBaseUpdate, preCommBaseUpD)) {
      _handleToast(`${t('txt-upd-tariff-success')}`, 'success');
      dispatch(commBaseUpdSuccess(null));
      getCommBaseSingle();
    }
  }, [commBaseUpdate]);

  useEffect(() => {
    if (commRateDel && !_.isEqual(commRateDel, preCommRateDel)) {
      _handleToast(`${t('txt-del-tax-rate-success')}`, 'success');
      dispatch(commRateDelSuccess(null));
      getAllListCommRate();
    }
  }, [commRateDel]);

  useEffect(() => {
    if (commBaseDel && !_.isEqual(commBaseDel, preCommBaseDelete)) {
      onClose();
    }
  }, [commBaseDel]);

  function initForm() {
    dispatch(
      change('detailBieuPhiBacThangModalform', 'formCode', commBaseSingle?.C_CODE)
    );
    dispatch(
      change('detailBieuPhiBacThangModalform', 'formName', commBaseSingle?.C_NAME)
    );
    dispatch(
      change('detailBieuPhiBacThangModalform', 'formNote', commBaseSingle?.C_DESCRIPTION)
    );
    dispatch(
      change('detailBieuPhiBacThangModalform', 'formStatus', commBaseSingle?.C_STATUS)
    );
  }

  function getCommBaseSingle() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_COMM_BASE',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(commBaseSingleRequest(params));
  }

  function getAllListCommRate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_COMM_RATE',
      group: 'LIST',
      data: {
        COMM_CODE: commBaseSingle?.C_CODE,
      },
    };

    dispatch(commRateSearchRequest(params));
  }

  function showAddListInType() {
    setShowAddList(true);
  }

  function onCloseAdd() {
    setShowAddList(false);
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_BASE',
      group: 'LIST',
      data: {
        ID: commBaseSingle?.PK_COMM_BASE,
        COMM_CODE: props?.formCode,
        COMM_NAME: props?.formName,
        CONTENT: props?.formNote,
        STATUS: props?.formStatus ? 1 : 0,
      },
    };

    dispatch(commBaseUpdRequest(params));
  }

  function handleDel(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-tax-rate')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-tariff')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDelCommBase();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_COMM_RATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(commRateDelRequest(params));
  }

  function handleActionDelCommBase() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_COMM_BASE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: commBaseSingle?.PK_COMM_BASE,
      },
    };

    dispatch(commBaseDelRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t, pristine } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-tariff-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-fee-package-code')}{' '}
                </Form.Label>
                <Field
                  name="formCode"
                  className="form-control"
                  classParent="w-100"
                  component={RenderInput}
                  validate={[required]}
                  disabled
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">
                  {t('txt-fee-package-name')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control"
                  component={RenderInput}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label className="fz-13">{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control"
                  component={RenderArea}
                  rows="3"
                />
              </Form.Group>
              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto">
                  {t('txt-list-tax-rate')}
                </span>

                {accRight?.C_UPDATE === 1 && (
                  <Button
                    variant="outline-primary"
                    className="text-white fz-13"
                    onClick={showAddListInType}
                  >
                    <HiViewGridAdd />
                    {t('txt-add-new')}
                  </Button>
                )}
              </div>
              <div style={{ gridColumn: '1/4' }}>
                <Table bordered className="w-100 mb-0 table-fixed">
                  <colgroup>
                    <col width="25%" />
                    <col width="30%" />
                    <col width="25%" />
                    <col width="10%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>{t('txt-from-value')}</th>
                      <th>{t('txt-to-value')}</th>
                      <th>{t('txt-interest-rate')}</th>
                      <th>{t('txt-action')}</th>
                    </tr>
                  </thead>
                </Table>
                <PerfectScrollbar style={{ maxHeight: '350px' }}>
                  <div>
                    <Table bordered className="w-100 mb-0 table-fixed">
                      <colgroup>
                        <col width="25%" />
                        <col width="30%" />
                        <col width="25%" />
                        <col width="10%" />
                      </colgroup>
                      <tbody>
                        {listCommRate &&
                          listCommRate.map((item, index) => (
                            <tr key={item.PK_COMM_RATE}>
                              <td className="text-right">
                                {numberFormat(item.C_FROM_VALUE, 0, '0')}
                              </td>
                              <td className="text-right">
                                {numberFormat(item.C_TO_VALUE, 0, '0')}
                              </td>
                              <td className="text-right">{item.C_RATE}</td>
                              <td className="text-center">
                                <GroupButton>
                                  {accRight?.C_UPDATE === 1 && (
                                    <a
                                      title={t('txt-del')}
                                      onClick={() =>
                                        handleDel(item.PK_COMM_RATE)
                                      }
                                    >
                                      <IconTrash />
                                    </a>
                                  )}
                                </GroupButton>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </Table>
                    {(!listCommRate || !listCommRate.length) && (
                      <p className="fz-13 text-center">{t('txt-no-data')}</p>
                    )}
                  </div>
                  <div>
                    <label
                      style={{
                        paddingTop: '10px',
                        alignSelf: 'end',
                        gridColumn: '1/2',
                      }}
                      className="form-label"
                    >
                      <Field
                        name="formStatus"
                        component="input"
                        type="checkbox"
                      />{' '}
                      {t('txt-active')}
                    </label>
                  </div>
                </PerfectScrollbar>
              </div>
            </FormAdd>

            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_UPDATE === 1 && (
                  <>
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="w_125 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                    <BtnSubmit
                      type="submit"
                      disabled={pristine || submitting}
                      className="w_125 ml-2"
                    >
                      {t('txt-accept')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {showAddList && (
        <CreateMucPhi onClose={onCloseAdd} code={commBaseSingle?.C_CODE} />
      )}
    </ReactModal>
  );
}

DetailBieuPhiModal = reduxForm({
  form: 'detailBieuPhiBacThangModalform',
  enableReinitialize: true,
})(DetailBieuPhiModal);

const selector = formValueSelector('detailBieuPhiBacThangModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getCommRateDel = makeGetCommRateDel();
  const getCommBaseSingle = makeGetCommBaseSingle();
  const getAllListCommRate = makeCommRateListSearch();
  const getCommRateUpdate = makeGetCommRateUpdate();
  const getCommBaseUpdate = makeGetCommBaseUpdate();
  const getCommBaseDel = makeGetCommBaseDel();
  const {
    formCode,
    formName,
    formNote,
    formStatus,
    formValue,
    formToValue,
    formRate,
  } = selector(
    state,
    'formCode',
    'formName',
    'formNote',
    'formStatus',
    'formValue',
    'formToValue',
    'formRate'
  );
  const commBaseSingle = getCommBaseSingle(state);

  return {
    token: getToken(state),
    listCommRate: getAllListCommRate(state),
    commRateUpd: getCommRateUpdate(state),
    commBaseUpdate: getCommBaseUpdate(state),
    commBaseSingle,
    commRateDel: getCommRateDel(state),
    commBaseDel: getCommBaseDel(state),
    commRateUpd: getCommRateUpdate(state),
    formCode,
    formName,
    formNote,
    formStatus,
    formValue,
    formToValue,
    formRate,

  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailBieuPhiModal)
);

