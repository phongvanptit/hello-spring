import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import {
  commBaseUpdRequest,
  commBaseUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetCommBaseUpdate, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.form`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;

  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
function CreateBieuPhiBacThangModal(props) {
  const dispatch = useDispatch();
  const { token, commBaseUpdate } = props;
  const preCommBaseUpdate = usePrevious(commBaseUpdate);

  useEffect(() => {
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (commBaseUpdate && !_.isEqual(commBaseUpdate, preCommBaseUpdate)) {
      _handleToast(`${t('txt-add-tariff-success')}`, 'success');
      dispatch(commBaseUpdSuccess(null));
      onClose();
    }
  }, [commBaseUpdate]);

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-tariff')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_BASE',
      group: 'LIST',
      data: {
        ID: '',
        COMM_CODE: props?.formCode,
        COMM_NAME: props?.formName,
        CONTENT: props?.formNote,
        STATUS: props?.formStatus ? 1 : 0,
      },
    };

    dispatch(commBaseUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-tariff-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <FormAdd onSubmit={handleSubmit(submit)}>
            <Form.Group>
              <Form.Label className="fz-13">
                {t('txt-fee-package-code')}{' '}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formCode"
                className="form-control"
                classParent="w-100"
                component={RenderInput}
                validate={[required]}
              />
            </Form.Group>

            <Form.Group style={{ gridColumn: '2/4' }}>
              <Form.Label className="fz-13">
                {t('txt-fee-package-name')}{' '}
                <span className="text-danger">*</span>
              </Form.Label>
              <Field
                name="formName"
                className="form-control"
                component={RenderInput}
                validate={[required]}
              />
            </Form.Group>
            <Form.Group style={{ gridColumn: '1/4' }}>
              <Form.Label className="fz-13">{t('txt-note')}</Form.Label>
              <Field
                name="formNote"
                className="form-control"
                component={RenderArea}
                rows="3"
              />
            </Form.Group>
            <label
              style={{
                paddingTop: '10px',
                alignSelf: 'end',
                gridColumn: '1/2',
              }}
              className="form-label"
            >
              <Field name="formStatus" component="input" type="checkbox" />{' '}
              {t('txt-active')}
            </label>

            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </FormAdd>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateBieuPhiBacThangModal = reduxForm({
  form: 'addLaddedFeeform',
  enableReinitialize: true,
})(CreateBieuPhiBacThangModal);

const selector = formValueSelector('addLaddedFeeform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCommBaseUpdate = makeGetCommBaseUpdate();
  const { formCode, formName, formStatus, formNote } = selector(
    state,
    'formCode',
    'formName',
    'formStatus',
    'formNote'
  );

  return {
    token: getToken(state),
    commBaseUpdate: getCommBaseUpdate(state),
    formCode,
    formName,
    formStatus,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateBieuPhiBacThangModal)
);
