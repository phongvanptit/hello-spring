import RenderInputMask from 'components/input/renderInputMask';
import {
  commRateUpdRequest,
  commRateUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetCommRateUpdate, makeGetToken } from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToDouble, StringToInt } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formValue, formToValue, formRate } = values;

  if (
    formValue &&
    formToValue &&
    StringToDouble(formValue) > StringToDouble(formToValue)
  ) {
    errors.formToValue = `Giá trị không hợp lệ`;
  }

  if (formRate > 100) {
    errors.formRate = `Nhập số <= 100`;
  }

  return errors;
};

function CreateMucPhiModal(props) {
  const dispatch = useDispatch();
  const { token, onClose, code, commRateUpd, handleSubmit, t } = props;
  const preCommRateUpD = usePrevious(commRateUpd);

  useEffect(() => {
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (commRateUpd && !_.isEqual(commRateUpd, preCommRateUpD)) {
      _handleToast(`${t('txt-add-tax-rate-success')}`, 'success');
      dispatch(commRateUpdSuccess(null));
      onClose();
    }
  }, [commRateUpd]);

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-tax-rate')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionCommRateUpD();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionCommRateUpD() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_RATE',
      group: 'LIST',
      data: {
        ID: '',
        BASE_CODE: code,
        FROM_VALUE: StringToInt(props?.formValue),
        TO_VALUE: StringToInt(props?.formToValue),
        RATE: props?.formRate,
      },
    };

    dispatch(commRateUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-tax-rate')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-from-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formValue"
                    className="form-control"
                    classParent="w-100"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-to-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formToValue"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-interest-rate')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formRate"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                    allowDecimal
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" className="w_100 ml-2">
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateMucPhiModal = reduxForm({
  form: 'createMucPhiModalform',
  enableReinitialize: true,
  validate,
})(CreateMucPhiModal);

const selector = formValueSelector('createMucPhiModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCommRateUpdate = makeGetCommRateUpdate();

  const { formValue, formToValue, formRate } = selector(
    state,
    'formValue',
    'formToValue',
    'formRate'
  );

  return {
    token: getToken(state),
    commRateUpd: getCommRateUpdate(state),
    formValue,
    formToValue,
    formRate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateMucPhiModal)
);
