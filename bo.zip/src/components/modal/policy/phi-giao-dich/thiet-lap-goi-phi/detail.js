import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import { numberFormat } from 'utils';
import {
  commPackageBaseDelRequest,
  commPackageBaseDelSuccess,
  commPackageBaseSearchRequest,
  commPackageBaseSearchSuccess,
  commPackageDelRequest,
  commPackageSingleRequest,
  commPackageSingleSuccess,
  commPackageUpdRequest,
  commPackageUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeCommPackageBaseListSearch,
  makeGetCommPackageBaseDel,
  makeGetCommPackageBaseUpdate,
  makeGetCommPackageDel,
  makeGetCommPackageSingle,
  makeGetCommPackageUpdate,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Button, Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import { HiViewGridAdd } from 'react-icons/hi';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit, GroupButton } from 'utils/styledComponent';
import { required } from 'utils/validation';
import CreateBacPhiModal from './CreateBacPhiModal';
import { StringToDouble, StringToInt } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailGoiPhiModal(props) {
  const dispatch = useDispatch();
  const [showAddList, setShowAddList] = React.useState(false);
  const {
    token,
    onClose,
    id,
    commPackageSingle,
    commPackageUpdate,
    commPackageBaseUpdate,
    listCommPackageBase,
    commPackageBaseDel,
    commPackageDel,
    pristine,
    submitting,
    accRight,
  } = props;

  const preCommPackageBaseDel = usePrevious(commPackageBaseDel);
  const preCommPackageBaseUpD = usePrevious(commPackageBaseUpdate);
  const preCommBaseUpD = usePrevious(commPackageUpdate);
  const preCommPackageSingle = usePrevious(commPackageSingle);
  const preCommPackageDelete = usePrevious(commPackageDel);

  useEffect(() => {
    if (
      commPackageSingle &&
      !_.isEqual(commPackageSingle, preCommPackageSingle)
    ) {
      initForm();
      getAllListCommPackageBase();
    }
  }, [commPackageSingle]);

  useEffect(() => {
    getCommPackageSingle();
    dispatch(
      change('detailGoiPhiModalform', 'formShareCommGroup', '1')
    );
    return () => {
      dispatch(commPackageSingleSuccess(null));
      dispatch(commPackageBaseSearchSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (
      commPackageBaseUpdate &&
      !_.isEqual(commPackageBaseUpdate, preCommPackageBaseUpD)
    ) {
      getAllListCommPackageBase();
    }
  }, [commPackageBaseUpdate]);

  useEffect(() => {
    if (commPackageUpdate && !_.isEqual(commPackageUpdate, preCommBaseUpD)) {
      _handleToast(`${t('txt-upd-fee-package-success')}`, 'success');
      dispatch(commPackageUpdSuccess(null));
      getCommPackageSingle();
    }
  }, [commPackageUpdate]);

  useEffect(() => {
    if (
      commPackageBaseDel &&
      !_.isEqual(commPackageBaseDel, preCommPackageBaseDel)
    ) {
      _handleToast(`${t('txt-del-fee-package-success')}`, 'success');
      dispatch(commPackageBaseDelSuccess(null));
      getAllListCommPackageBase();
    }
  }, [commPackageBaseDel]);

  useEffect(() => {
    if (commPackageDel && !_.isEqual(commPackageDel, preCommPackageDelete)) {
      onClose();
    }
  }, [commPackageDel]);

  function initForm() {
    dispatch(
      change('detailGoiPhiModalform', 'formCode', commPackageSingle?.C_CODE)
    );
    dispatch(
      change('detailGoiPhiModalform', 'formName', commPackageSingle?.C_NAME)
    );
    dispatch(
      change('detailGoiPhiModalform', 'formNote', commPackageSingle?.C_DESCRIPTION)
    );
    dispatch(
      change('detailGoiPhiModalform', 'formStatus', commPackageSingle?.C_STATUS)
    );
  }

  function getAllListCommPackageBase() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_COMM_PACKAGE_BASE',
      group: 'LIST',
      data: {
        PACKAGE_CODE: commPackageSingle?.C_CODE,
      },
    };

    dispatch(commPackageBaseSearchRequest(params));
  }

  function getCommPackageSingle() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_COMM_PACKAGE',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(commPackageSingleRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_PACKAGE',
      group: 'LIST',
      data: {
        ID: commPackageSingle?.PK_COMM_PACKAGE,
        CODE: props?.formCode,
        NAME: props?.formName,
        CONTENT: props?.formNote,
        STATUS: props?.formStatus ? 1 : 0,
      },
    };

    dispatch(commPackageUpdRequest(params));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-package')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDelCommPackage();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDel(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-tier')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDelCommPackage() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_COMM_PACKAGE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: commPackageSingle?.PK_COMM_PACKAGE,
      },
    };

    dispatch(commPackageDelRequest(params));
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_COMM_PACKAGE_BASE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(commPackageBaseDelRequest(params));
  }

  function showAddListInType() {
    setShowAddList(true);
  }

  function onCloseAdd() {
    setShowAddList(false);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-fee-package')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-fee-com-code')}{' '}
                </Form.Label>
                <Field
                  name="formCode"
                  className="form-control"
                  classParent="w-100"
                  component={RenderInput}
                  validate={[required]}
                  disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">
                  {t('txt-fee-com-name')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control"
                  component={RenderInput}
                  validate={[required]}
                  //disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control"
                  component={RenderArea}
                  rows="3"
                />
              </Form.Group>
              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto">
                  {t('txt-detail-fee-com')}
                </span>
                {accRight?.C_UPDATE === 1 && (
                  <Button
                    variant="outline-primary"
                    className="text-white fz-13"
                    onClick={showAddListInType}
                  >
                    <HiViewGridAdd />
                    {t('txt-add-new')}
                  </Button>
                )}
              </div>
              <div style={{ gridColumn: '1/4' }}>
                <Table bordered className="mb-0 table-fixed">
                  <colgroup>
                    <col width="20%" />
                    <col width="20%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="10%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>{t('txt-charge-group')}</th>
                      <th>{t('txt-channel')}{' '}</th>
                      <th>{t('txt-from-value')}</th>
                      <th>{t('txt-to-value')}</th>
                      <th>{t('txt-interest-rate')}</th>
                      <th>Thao tác</th>
                    </tr>
                  </thead>
                </Table>
                <div>
                  <PerfectScrollbar style={{ maxHeight: '350px' }}>
                    <Table bordered className="mb-0 table-fixed">
                      <colgroup>
                        <col width="20%" />
                        <col width="20%" />
                        <col width="15%" />
                        <col width="15%" />
                        <col width="15%" />
                        <col width="10%" />
                      </colgroup>
                      <tbody>
                        {listCommPackageBase &&
                          listCommPackageBase.map((item) => (
                            <tr key={item.PK_PACKAGE_RATE}>
                              <td className="text-center">
                                {item.C_SHARE_GROUP_NAME}
                              </td>
                              <td className="text-center">
                                {item.C_CHANNEL_NAME}
                              </td>
                              <td className="text-center">
                                {numberFormat(item.C_FROM_VALUE,0,'0')} 
                              </td>
                              <td className="text-center">
                                {numberFormat(item.C_TO_VALUE,0,'0')}
                              </td>
                              <td className="text-center">
                                {item.C_RATE}
                              </td>
                              <td className="text-center">
                                <GroupButton>
                                  {accRight?.C_UPDATE === 1 && (
                                    <a
                                      title={t('txt-del')}
                                      onClick={() =>
                                        handleDel(item.PK_PACKAGE_RATE)
                                      }
                                    >
                                      <IconTrash />
                                    </a>
                                  )}
                                </GroupButton>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </Table>
                    {(!listCommPackageBase || !listCommPackageBase.length) && (
                      <p className="fz-13 text-center">{t('txt-no-data')}</p>
                    )}
                  </PerfectScrollbar>
                </div>
                <div>
                  <label
                    style={{
                      paddingTop: '10px',
                      alignSelf: 'end',
                      gridColumn: '1/2',
                    }}
                    className="form-label"
                  >
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </div>
              </div>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <div className="d-flex">
                  {accRight?.C_UPDATE === 1 && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 danger"
                      >
                        {t('txt-del')}
                      </BtnSubmit>
                      <BtnSubmit
                        type="submit"
                        disabled={pristine || submitting}
                        className="w_125 ml-2"
                      >
                        {t('txt-accept')}
                      </BtnSubmit>
                    </>
                  )}
                </div>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {showAddList && (
        <CreateBacPhiModal
          onClose={onCloseAdd}
          code={commPackageSingle?.PK_COMM_PACKAGE}
        />
      )}
    </ReactModal>
  );
}

DetailGoiPhiModal = reduxForm({
  form: 'detailGoiPhiModalform',
  enableReinitialize: true,
})(DetailGoiPhiModal);

const selector = formValueSelector('detailGoiPhiModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getCommPackageBaseDel = makeGetCommPackageBaseDel();
  const getCommPackageSingle = makeGetCommPackageSingle();
  const getAllListCommPackageBase = makeCommPackageBaseListSearch();
  const getCommPackageBaseUpdate = makeGetCommPackageBaseUpdate();
  const getCommPackageUpdate = makeGetCommPackageUpdate();
  const getCommPackageDel = makeGetCommPackageDel();
  const {
    formCode,
    formName,
    formNote,
    formStatus,
    formShareCommGroup,
    formFeeBaseCode,
  } = selector(
    state,
    'formCode',
    'formName',
    'formNote',
    'formStatus',
    'formShareCommGroup',
    'formChannelType',
    'formFeeBaseCode'
  );
  const commPackageSingle = getCommPackageSingle(state);

  return {
    token: getToken(state),
    listCommPackageBase: getAllListCommPackageBase(state),
    commPackageUpdate: getCommPackageUpdate(state),
    commPackageBaseUpdate: getCommPackageBaseUpdate(state),
    commPackageSingle,
    commPackageBaseDel: getCommPackageBaseDel(state),
    commPackageDel: getCommPackageDel(state),
    formCode,
    formName,
    formNote,
    formStatus,
    formShareCommGroup,
    formFeeBaseCode,

  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailGoiPhiModal)
);


