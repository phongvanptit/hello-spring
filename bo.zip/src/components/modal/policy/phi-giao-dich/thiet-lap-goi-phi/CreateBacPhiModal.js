import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  commPackageBaseUpdRequest,
  commPackageBaseUpdSuccess,
} from 'containers/account/actions';
import RenderInputMask from 'components/input/renderInputMask';
import { setToast } from 'containers/client/actions';
import {
  makeGetCommBase,
  makeGetCommPackageBaseUpdate,
  makeGetShareCommGroup,
  makeGetChannelCode,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
import { StringToDouble, StringToInt } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateBacPhiModal(props) {
  const dispatch = useDispatch();
  const {
    token,
    onClose,
    code,
    commPackageBaseUpdate,
    handleSubmit,
    glShareCommGroup,
    t,
    glCommBase,
    glChannelCode,
  } = props;
  const preCommPackageBaseUpdate = usePrevious(commPackageBaseUpdate);

  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (
      commPackageBaseUpdate &&
      !_.isEqual(commPackageBaseUpdate, preCommPackageBaseUpdate)
    ) {
      _handleToast(`${t('txt-add-fee-tier-success')}`, 'success');
      dispatch(commPackageBaseUpdSuccess(null));
      onClose();
    }
  }, [commPackageBaseUpdate]);

  function initForm() {
    dispatch(
      change('createBacPhiModalform', 'formShareCommGroup', '1')
    );
    dispatch(
      change('createBacPhiModalform', 'formFeeBaseCode', 'T00')
    );
    dispatch(
      change('createBacPhiModalform', 'formChannelCode', 'I')
    );
  }

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-fee-tier')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionCommPackageBaseUpD();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionCommPackageBaseUpD() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_PACKAGE_BASE',
      group: 'LIST',
      data: {
        //ID: '',
        PACKAGE_ID: code,
        SHARE_GROUP: props?.formShareCommGroup,
        CHANNEL: props?.formChannelCode,
        FROM_VALUE: StringToInt(props?.formValue), 
        TO_VALUE: StringToInt(props?.formToValue),
        COMM_RATE: props?.formRate,
      },
    };

    dispatch(commPackageBaseUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-fee-tier')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-charge-group')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formShareCommGroup"
                    className="form-control"
                    component={RenderNormalSelect}
                    classParent="w-100"
                    required
                    opts={glShareCommGroup}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                  {t('txt-channel')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formChannelCode"
                    className="form-control"
                    component={RenderNormalSelect}
                    classParent="w-100"
                    required
                    opts={glChannelCode}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-from-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formValue"
                    className="form-control"
                    classParent="w-100"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-to-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formToValue"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-interest-rate')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formRate"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                    allowDecimal
                  />
                </Form.Group>
               
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/6' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/6',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" className="w_100 ml-2">
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateBacPhiModal = reduxForm({
  form: 'createBacPhiModalform',
  enableReinitialize: true,
})(CreateBacPhiModal);

const selector = formValueSelector('createBacPhiModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCommPackageBaseUpdate = makeGetCommPackageBaseUpdate();
  const getShareCommGroup = makeGetShareCommGroup();
  const getChannelCode = makeGetChannelCode();
  const getGlobalCommBase = makeGetCommBase();
  const { formShareCommGroup, formFeeBaseCode,formToValue ,formRate,formValue,formChannelCode} = selector(
    state,
    'formShareCommGroup',
    'formFeeBaseCode',
    'formToValue',
    'formValue',
    'formRate',
    'formChannelCode',
    
  );

  return {
    token: getToken(state),
    commPackageBaseUpdate: getCommPackageBaseUpdate(state),
    glShareCommGroup: getShareCommGroup(state),
    glChannelCode: getChannelCode(state),
    glCommBase: getGlobalCommBase(state),
    formShareCommGroup,
    formChannelCode,
    formFeeBaseCode,
    formToValue,
    formValue,
    formRate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateBacPhiModal)
);

