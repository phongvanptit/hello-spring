import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  comboFeeDetailUpdateRequest,
  comboFeeDetailUpdateSuccess
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  globalAdvPackageRequest
} from 'containers/global/actions';
import {
  makeGetAdvPackage,
  makeGetCommBase,
  makeGetCommPackage,
  makeGetCommType,
  makeGetMarginCode,
  makeGetToken,
  makeUpdDetailComboFee,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateDetailComboFeeModal(props) {
  const dispatch = useDispatch();
  const {
    token,
    onClose,
    code,
    comboFeeDetailUpd,
    handleSubmit,
    glCommType,
    t,
    glCommBase,
    glCommPackage,
    formCommType,
    glAdvPackage,
    glMarginFee
  } = props;

  const preComboFeeDetailUpd = usePrevious(comboFeeDetailUpd);
  const preFormCommType = usePrevious(formCommType);

  useEffect(() => {
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (
      comboFeeDetailUpd &&
      !_.isEqual(comboFeeDetailUpd, preComboFeeDetailUpd)
    ) {
      _handleToast(`${t('txt-add-fee-combo-detail-success')}`, 'success');
      dispatch(comboFeeDetailUpdateSuccess(null));
      onClose();
    }
  }, [comboFeeDetailUpd]);

  useEffect(() => {
    if (
      formCommType &&
      !_.isEqual(formCommType, preFormCommType)
    ) {
      changeComboFeeType();
    }
  }, [formCommType]);

  function changeComboFeeType() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_COMM_ADV',
      group: 'LIST',
      data: {
        TYPE: formCommType,
        ACTIVE: 1,

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };
    dispatch(globalAdvPackageRequest(params));
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-new-fee-combo-detail')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionCommPackageBaseUpD();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionCommPackageBaseUpD() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_LIST_POLICY_DETAIL',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        FK_LIST_POLICY: code,
        COMM_TYPE: props?.formCommType,
        COMM_CODE: props?.formCommPackage,
      },
    };
    dispatch(comboFeeDetailUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-fee-combo-detail')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-type-fee')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCommType"
                    className="form-control"
                    component={RenderNormalSelect}
                    classParent="w-100"
                    opts={glCommType}
                    validate={[required]}

                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-package-fee')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCommPackage"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={
                      formCommType === 'MARGIN' ? glMarginFee : formCommType === 'COMM' ? glCommPackage :
                        formCommType === 'ADV' || 'SMS' ? glAdvPackage :
                          ''}
                    classParent="w-100"
                    validate={[required]}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" className="w_100 ml-2">
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateDetailComboFeeModal = reduxForm({
  form: 'createDetailComboFeeModalform',
  enableReinitialize: true,
})(CreateDetailComboFeeModal);

const selector = formValueSelector('createDetailComboFeeModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getUpdDetailComboFee = makeUpdDetailComboFee();

  const getGlobalCommType = makeGetCommType();
  const getCommPackage = makeGetCommPackage();
  const getCommBase = makeGetCommBase();
  const getAdvPackage = makeGetAdvPackage();
  const getMarginFee = makeGetMarginCode();

  const { formCommType, formCommPackage } = selector(
    state,
    'formCommType',
    'formCommPackage'
  );

  return {
    token: getToken(state),
    comboFeeDetailUpd: getUpdDetailComboFee(state),
    glCommPackage: getCommPackage(state),
    glCommType: getGlobalCommType(state),
    glCommBase: getCommBase(state),
    glCommPackage: getCommPackage(state),
    glMarginFee: getMarginFee(state),
    glAdvPackage: getAdvPackage(state),

    formCommType,
    formCommPackage,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateDetailComboFeeModal)
);
