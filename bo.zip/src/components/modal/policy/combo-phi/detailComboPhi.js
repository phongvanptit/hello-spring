import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import {
  comboFeeDelRequest,
  comboFeeDetailDelRequest,
  comboFeeDetailDelSuccess,
  comboFeeDetailUpdateSuccess,
  comboFeeListDetailRequest,
  comboFeeListDetailSuccess,
  comboFeeSingleRequest,
  comboFeeSingleSuccess,
  comboFeeUpdRequest,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeDelComboFee,
  makeDelDetailComboFee,
  makeGetToken,
  makeListDetailComboFee,
  makeSingleComboFee,
  makeUpdComboFee,
  makeUpdDetailComboFee,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Button, Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import { HiViewGridAdd } from 'react-icons/hi';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit, GroupButton } from 'utils/styledComponent';
import { required } from 'utils/validation';
import CreateDetailComboFeeModal from './createDetailComboPhi';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailComboPhiModal(props) {
  const dispatch = useDispatch();
  const [showAddList, setShowAddList] = React.useState(false);
  const {
    token,
    onClose,
    id,
    comboFeeSingle,
    comboFeeUpd,
    comboFeeListDetail,
    comboFeeDetailDel,
    pristine,
    submitting,
    accRight,
    comboFeeDel,
    comboFeeDetailUpd,
  } = props;

  const preComboFeeDetailUpd = usePrevious(comboFeeDetailUpd);
  const preComboFeeDetailDel = usePrevious(comboFeeDetailDel);
  const preComboFeeUpd = usePrevious(comboFeeUpd);
  const precomboFeeSingle = usePrevious(comboFeeSingle);
  const preComboFeeDel = usePrevious(comboFeeDel);

  useEffect(() => {
    getComboSingle();

    dispatch(change('detailComboPhiModalform', 'formShareCommGroup', '1'));
    return () => {
      dispatch(comboFeeSingleSuccess(null));
      dispatch(comboFeeListDetailSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (comboFeeSingle && !_.isEqual(comboFeeSingle, precomboFeeSingle)) {
      initForm();
      getAllListDetailComboFee();
    }
  }, [comboFeeSingle]);

  useEffect(() => {
    if (
      comboFeeDetailUpd &&
      !_.isEqual(comboFeeDetailUpd, preComboFeeDetailUpd)
    ) {
      _handleToast(`${t('txt-upd-fee-combo-detail-success')}`, 'success');
      dispatch(comboFeeDetailUpdateSuccess(null));
      getAllListDetailComboFee();
    }
  }, [comboFeeDetailUpd]);

  useEffect(() => {
    if (comboFeeUpd && !_.isEqual(comboFeeUpd, preComboFeeUpd)) {
      _handleToast(`${t('txt-upd-fee-combo-success')}`, 'success');
      dispatch(comboFeeUpdRequest(null));
      getComboSingle();
    }
  }, [comboFeeUpd]);

  useEffect(() => {
    if (
      comboFeeDetailDel &&
      !_.isEqual(comboFeeDetailDel, preComboFeeDetailDel)
    ) {
      _handleToast(`${t('txt-del-fee-combo-detail-success')}`, 'success');
      dispatch(comboFeeDetailDelSuccess(null));
      getAllListDetailComboFee();
    }
  }, [comboFeeDetailDel]);

  useEffect(() => {
    if (comboFeeDel && !_.isEqual(comboFeeDel, preComboFeeDel)) {
      onClose();
    }
  }, [comboFeeDel]);

  function initForm() {
    dispatch(
      change('detailComboPhiModalform', 'formCode', comboFeeSingle?.C_CODE)
    );
    dispatch(
      change('detailComboPhiModalform', 'formName', comboFeeSingle?.C_NAME)
    );
    dispatch(
      change('detailComboPhiModalform', 'formNote', comboFeeSingle?.C_CONTENT)
    );
    dispatch(
      change('detailComboPhiModalform', 'formActive', comboFeeSingle?.C_ACTIVE === 1)
    );
  }

  function getAllListDetailComboFee() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST_POLICY_DETAIL',
      group: 'LIST',
      data: {
        ITEM_ID: comboFeeSingle?.PK_LIST_POLICY,
      },
    };

    dispatch(comboFeeListDetailRequest(params));
  }

  function getComboSingle() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_POLICY',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(comboFeeSingleRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_LIST_POLICY',
      group: 'LIST',
      data: {
        ID: comboFeeSingle?.PK_LIST_POLICY,
        CODE: props?.formCode,
        NAME: props?.formName,
        CONTENT: props?.formNote,
        ACTIVE: props?.formActive ? 1 : 0,
      },
    };
    dispatch(comboFeeUpdRequest(params));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-combo')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDelCommPackage();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleDel(pk) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-combo')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(pk);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDelCommPackage() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_LIST_POLICY',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: comboFeeSingle?.PK_LIST_POLICY,
      },
    };

    dispatch(comboFeeDelRequest(params));
  }

  function handleActionDel(pk) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_LIST_POLICY_DETAIL',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: pk,
      },
    };

    dispatch(comboFeeDetailDelRequest(params));
  }

  function showAddListInType() {
    setShowAddList(true);
  }

  function onCloseAdd() {
    setShowAddList(false);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-fee-combo')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-fee-combo-code')}{' '}
                </Form.Label>
                <Field
                  name="formCode"
                  className="form-control"
                  classParent="w-100"
                  component={RenderInput}
                  validate={[required]}
                  disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">
                  {t('txt-fee-combo-name')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control"
                  component={RenderInput}
                  validate={[required]}
                  //disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control"
                  component={RenderArea}
                  rows="3"
                />
              </Form.Group>
              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto">
                  {t('txt-list-detail-fee-combo')}
                </span>
                {accRight?.C_UPDATE === 1 && (
                  <Button
                    variant="outline-primary"
                    className="text-white fz-13"
                    onClick={showAddListInType}
                  >
                    <HiViewGridAdd />
                    {t('txt-add-new')}
                  </Button>
                )}
              </div>
              <div style={{ gridColumn: '1/4' }}>
                <Table bordered className="mb-0 table-fixed">
                  <colgroup>
                    <col width="50%" />
                    <col width="40%" />
                    <col width="10%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>{t('txt-type-fee')}</th>
                      <th>{t('txt-package-fee')}</th>
                      <th>{t('txt-action')}</th>
                    </tr>
                  </thead>
                </Table>
                <div>
                  <PerfectScrollbar style={{ maxHeight: '350px' }}>
                    <Table bordered className="mt-0 table-fixed">
                      <colgroup>
                        <col width="50%" />
                        <col width="40%" />
                        <col width="10%" />
                      </colgroup>
                      <tbody>
                        {comboFeeListDetail &&
                          comboFeeListDetail.map((item) => (
                            <tr key={item.PK_POLICY_DETAIL}>
                              <td className="text-center">
                                {item.C_COMM_TYPE_NAME}
                              </td>
                              <td className="text-center">
                                {item.C_COMM_CODE} -  {item.C_COMM_NAME}
                              </td>
                              <td className="text-center">
                                <GroupButton>
                                  {accRight?.C_UPDATE === 1 && (
                                    <a
                                      title={t('txt-del')}
                                      onClick={() =>
                                        handleDel(item.PK_POLICY_DETAIL)
                                      }
                                    >
                                      <IconTrash />
                                    </a>
                                  )}
                                </GroupButton>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </Table>
                    {(!comboFeeListDetail || !comboFeeListDetail.length) && (
                      <p className="fz-13 text-center">{t('txt-no-data')}</p>
                    )}
                  </PerfectScrollbar>
                </div>
                <div>
                  <label
                    style={{
                      paddingTop: '10px',
                      alignSelf: 'end',
                      gridColumn: '1/2',
                    }}
                    className="form-label"
                  >
                    <Field
                      name="formActive"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </div>
              </div>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <div className="d-flex">
                  {accRight?.C_UPDATE === 1 && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 danger"
                      >
                        {t('txt-del')}
                      </BtnSubmit>
                      <BtnSubmit
                        type="submit"
                        disabled={pristine || submitting}
                        className="w_125 ml-2"
                      >
                        {t('txt-accept')}
                      </BtnSubmit>
                    </>
                  )}
                </div>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {showAddList && (
        <CreateDetailComboFeeModal
          onClose={onCloseAdd}
          code={comboFeeSingle?.PK_LIST_POLICY}
        />
      )}
    </ReactModal>
  );
}

DetailComboPhiModal = reduxForm({
  form: 'detailComboPhiModalform',
  enableReinitialize: true,
})(DetailComboPhiModal);

const selector = formValueSelector('detailComboPhiModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getComboFeeSingle = makeSingleComboFee();
  const getComboFeeUpdate = makeUpdComboFee();
  const getComboFeeListDetail = makeListDetailComboFee();
  const getComboFeeDetailDel = makeDelDetailComboFee();
  const getComboFeeDetailUpd = makeUpdDetailComboFee();
  const getComboFeeDelete = makeDelComboFee();

  const {
    formCode,
    formName,
    formNote,
    formActive,
    formShareCommGroup,
    formFeeBaseCode,
  } = selector(
    state,
    'formCode',
    'formName',
    'formNote',
    'formActive',
    'formShareCommGroup',
    'formChannelType',
    'formFeeBaseCode'
  );

  return {
    token: getToken(state),
    comboFeeSingle: getComboFeeSingle(state),
    comboFeeUpd: getComboFeeUpdate(state),
    comboFeeListDetail: getComboFeeListDetail(state),
    comboFeeDetailDel: getComboFeeDetailDel(state),
    comboFeeDetailUpd: getComboFeeDetailUpd(state),
    comboFeeDel: getComboFeeDelete(state),

    formCode,
    formName,
    formNote,
    formActive,
    formShareCommGroup,
    formFeeBaseCode,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailComboPhiModal)
);
