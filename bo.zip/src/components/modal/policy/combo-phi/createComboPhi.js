import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import {
  comboFeeUpdRequest,
  comboFeeUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetFeeCalMethod,
  makeGetToken,
  makeUpdComboFee,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
function CreateComboPhiModal(props) {
  const dispatch = useDispatch();

  const { token, comboFeeUpd } = props;
  const preComboFeeUpd = usePrevious(comboFeeUpd);

  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (comboFeeUpd && !_.isEqual(comboFeeUpd, preComboFeeUpd)) {
      _handleToast(`${t('txt-add-fee-combo-success')}`, 'success');
      dispatch(comboFeeUpdSuccess(null));
      onClose();
    }
  }, [comboFeeUpd]);

  function initForm() {
    dispatch(change('addComboPhiModal', 'formActive', true));
  }

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-fee-combo')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_LIST_POLICY',
      group: 'LIST',
      data: {
        ID: '',
        CODE: props?.formCode,
        NAME: props?.formName,
        CONTENT: props?.formNote,
        ACTIVE: props?.formActive ? 1 : 0,
      },
    };

    dispatch(comboFeeUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, onClose, submitting, t, reset } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-fee-combo')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)} className="form-add">
            <div
              className="info d-grid"
              style={{
                gridTemplateColumns: 'auto auto',
                gap: '10px',
              }}
            >
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-fee-combo-code')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formCode"
                  className="form-control"
                  classParent="w-100"
                  component={RenderInput}
                  validate={[required]}
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">
                  {t('txt-fee-combo-name')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control"
                  component={RenderInput}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control"
                  component={RenderArea}
                  rows="3"
                />
              </Form.Group>
              <label
                style={{
                  paddingTop: '10px',
                  alignSelf: 'end',
                  gridColumn: '1/2',
                }}
                className="form-label"
              >
                <Field name="formActive" component="input" type="checkbox" />{' '}
                {t('txt-active')}
              </label>
              <hr style={{ gridColumn: '1/4' }} />
              <div
                className="d-flex"
                style={{
                  height: '30px',
                  whiteSpace: 'nowrap',
                  gridColumn: '1/4',
                }}
              >
                <BtnClose type="button" onClick={onClose} className="mr-auto">
                  {t('txt-close')}
                </BtnClose>
                <div className="d-flex">
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-accept')}
                  </BtnSubmit>
                </div>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateComboPhiModal = reduxForm({
  form: 'addComboPhiModal',
  enableReinitialize: true,
})(CreateComboPhiModal);

const selector = formValueSelector('addComboPhiModal');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getFeeCalMethod = makeGetFeeCalMethod();
  const getComboFeeUpdate = makeUpdComboFee();
  const { formCode, formName, formOrder, formActive, formNote } = selector(
    state,
    'formCode',
    'formName',
    'formOrder',
    'formActive',
    'formNote'
  );

  return {
    token: getToken(state),
    feeCalMethod: getFeeCalMethod(state),
    comboFeeUpd: getComboFeeUpdate(state),
    formCode,
    formName,
    formOrder,
    formActive,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateComboPhiModal)
);
