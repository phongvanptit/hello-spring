import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';

import RenderInputMask from 'components/input/renderInputMask';
import {
  updShareManagementPackageRequest,
  updShareManagementPackageSuccess,
} from 'containers/category/actions';
import { makeGetToken, makeGetShareType, makeGetUpdShareManagementPackage } from 'lib/selector';
import { StringToDouble, StringToInt } from 'utils';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateGoiPhiChungKhoanModal(props) {
  const dispatch = useDispatch();
  const { token, onClose, glShareType, updShareManagementPackage } = props;

  const preUpd = usePrevious(updShareManagementPackage);

  useEffect(() => {
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (updShareManagementPackage && !_.isEqual(updShareManagementPackage, preUpd)) {
      _handleToast('Thêm mới bút toán thành công', 'success');
      dispatch(updShareManagementPackageSuccess(null));
      onClose();
    }
  }, [updShareManagementPackage]);

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn thêm mới phí nghiệp vụ chứng khoán?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_ADV',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        TYPE: 'SHARE_MANAGEMENT',
        SHARE_TYPE: props.formShareType,
        CODE: props?.formCode,
        NAME: props?.formName,
        MIN_VALUE: StringToInt(props.formMinValue) || 0,
        MAX_VALUE: StringToInt(props.formMaxValue) || 999999999999,
        RATE: StringToDouble(props.formRate),
        ACTIVE: props.formStatus ? 1 : 0,
        CONTENT: props?.formNote,
      },
    };

    dispatch(updShareManagementPackageRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới gói phí nghiệp vụ chứng khoán</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>
                  Mã gói phí
                  <span className="text-danger">*</span>
                </Form.Label>
                <div className="w-100 d-flex flex-row">
                  <Field
                    name="formCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </div>
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Tên gói phí
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control input-order fz-13"
                  component={RenderInput}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Mức phí tối thiểu (VND)

                </Form.Label>
                <Field
                  name="formMinValue"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                //validate={required}
                //allowDecimal
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Mức phí tối đa (VND)

                </Form.Label>
                <Field
                  name="formMaxValue"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                //validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Tỉ lệ phí

                </Form.Label>
                <Field
                  name="formRate"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  //validate={required}
                  allowDecimal
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Nhóm tính phí

                </Form.Label>
                <Field
                  name="formShareType"
                  type="text"
                  className="form-control"
                  component={RenderNormalSelect}
                  opts={glShareType}
                //validate={required}
                //placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group className="d-flex flex-column">
                <Form.Label>{t('txt-status')}</Form.Label>
                <label style={{ paddingTop: '10px' }}>
                  <Field name="formStatus" component="input" type="checkbox" />{' '}
                  {t('txt-active')}
                </label>
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/3' }}>
                <Form.Label>
                  {t('txt-note')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                  validate={[required]}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateGoiPhiChungKhoanModal = reduxForm({
  form: 'createGoiPhiForm',
  enableReinitialize: true,
})(CreateGoiPhiChungKhoanModal);

const selector = formValueSelector('createGoiPhiForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getUpdShareManagementPackage = makeGetUpdShareManagementPackage();
  const getShareType = makeGetShareType();
  const { formCode, formName, formMinValue, formMaxValue, formRate, formShareType, formStatus, formNote } =
    selector(
      state,
      'formCode',
      'formName',
      'formMinValue',
      'formMaxValue',
      'formRate',
      'formShareType',
      'formStatus',
      'formNote'
    );
  return {
    token: getToken(state),
    glShareType: getShareType(state),
    updShareManagementPackage: getUpdShareManagementPackage(state),
    formCode,
    formName,
    formMinValue,
    formMaxValue,
    formRate,
    formShareType,
    formStatus,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateGoiPhiChungKhoanModal)
);
