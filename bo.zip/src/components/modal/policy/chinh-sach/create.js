import RenderArea from 'components/input/renderArea';
import RenderChoseArray from 'components/input/renderChoseArray';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderSuggestProduct from 'components/input/renderSuggestProduct';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, change, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';
import RenderSuggestBranch from 'components/input/renderSuggestBranch2';
import RenderSuggestSubBranch from 'components/input/renderSuggestSubBranch2';
import {
  updPolicyRequest,
  updPolicySuccess,
} from 'containers/category/actions';

import RenderInputMask from 'components/input/renderInputMask';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  makeGetAdvPackage,
  makeGetCommPackage,
  makeGetGlMarketingID,
  makeGetGlObjCustomer,
  makeGetToken,
  makeGetUpdPolicy,
  makeGetGlobalSubBranchList,
  makeGetAllBranch,
  makeGetCustType,
  makeGetGlComboFee,
  makeGetSystemInfo,
} from 'lib/selector';
import {
  StringToDouble,
  formatDate,
  StringToInt,
  stringToDate,
  _diff2Date,
} from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled
const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formFromDate, formToDate } = values;

  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function CreateChinhSachModal(props) {
  const dispatch = useDispatch();
  const {
    token,
    onClose,
    updPolicy,
    glMarketingID,
    glCommPackage,
    glAdvPackage,
    glObjCustomer,
    glAllBranch,
    glAllSubBranch,
    formBranchCode,
    sysSystemInfo,
    glCustType,
    glComboFee,
  } = props;

  const preUpdPolicy = usePrevious(updPolicy);
  const preFormBranch = usePrevious(formBranchCode);
  const _date = sysSystemInfo
    ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
    : new Date();
  _date?.setDate(_date?.getDate() + 1);

  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (updPolicy && !_.isEqual(updPolicy, preUpdPolicy)) {
      _handleToast(t('txt-add-policy-success'), 'success');
      dispatch(updPolicySuccess(null));
      onClose();
    }
  }, [updPolicy]);

  function initForm() {
    dispatch(
      change(
        'createChinhSachForm',
        'formFromDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(
      change('createChinhSachForm', 'formPolicy', glComboFee[0]?.value || '')
    );
    dispatch(
      change(
        'createChinhSachForm',
        'formPolicyBack',
        glComboFee[0]?.value || ''
      )
    );
  }

  React.useEffect(() => {
    if (formBranchCode && !_.isEqual(formBranchCode, preFormBranch)) {
      dispatch(change('createChinhSachForm', 'formSubBranchCode', ' '));
      dispatch(change('createChinhSachForm', 'formMarketingId', ' '));

      //dispatch(change('createChinhSachForm', 'formStaffFlag', '0'.toString()));
    }
  }, [formBranchCode]);

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-policy')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_POLICY_PACKAGE',
      group: 'LIST',
      data: {
        ID: '',
        CODE: props?.formCode,
        NAME: props?.formName,
        EFFECT_DATE: props?.formFromDate,
        EXPIRE_DATE: props?.formToDate,
        COUNT_DAY: StringToInt(props.formDuration),
        BRANCH_CODE: props.formBranchCode,
        SUB_BRANCH_CODE: props.formSubBranchCode,
        MARKETING_ID: props.formMarketingId,
        CUSTOMER_TYPE: props.formCustType,
        GENDER: props.formGender,
        BIRTH_FROM: props.formSFromDate,
        BIRTH_TO: props.formSToDate,
        POLICY_CODE: props.formPolicy,
        POLICY_BACK: props.formPolicyBack,
        STAFF_FLAG: props.formStaffFlag || -1,
        CONTENT: props?.formNote,
      },
    };

    dispatch(updPolicyRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-create-new-policy-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>
                  {t('txt-policy-code')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <div className="w-100 d-flex flex-row">
                  <Field
                    name="formCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </div>
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label>
                  {t('txt-policy-name')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control input-order fz-13"
                  component={RenderInput}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Áp dụng từ
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Đến ngày</Form.Label>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  //validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-duration')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formDuration"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  validate={required}
                />
              </Form.Group>
              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto fz-13">
                  Điều kiện khách hàng thỏa mãn
                </span>
              </div>
              <Form.Group>
                <Form.Label>{t('lab-branch')}</Form.Label>
                <Field
                  name="formBranchCode"
                  className="form-control input-order"
                  component={RenderSuggestBranch}
                  index={3}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <Field
                  name="formSubBranchCode"
                  className="form-control input-order"
                  component={RenderSuggestSubBranch}
                  branchCode={formBranchCode}
                  index={3}
                />
              </Form.Group>
              {/* <Form.Group>
                <Form.Label className="fz-13">{t('txt-marketing-id')}</Form.Label>
                <Field
                  name="formMarketingId"
                  type="text"
                  className="form-control"
                  placeholder={t('txt-marketing-id')}
                  component={RenderInput}
                />
              </Form.Group> */}
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Field
                  name="formMarketingId"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-gender')}</Form.Label>
                <Field
                  name="formGender"
                  className="form-control w_170"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="M">Nam</option>
                  <option value="F">Nữ</option>
                </Field>
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-s-from-date')}
                </Form.Label>
                <Field
                  name="formSFromDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formSToDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-type')}</Form.Label>
                <Field
                  name="formCustType"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glCustType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-company-employee')}</Form.Label>
                <Field
                  name="formStaffFlag"
                  className="form-control w-100"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="1">Có</option>
                  <option value="0">Không</option>
                </Field>
              </Form.Group>

              <Table bordered className="mt-2" style={{ gridColumn: '1/4' }}>
                <thead>
                  <tr>
                    <td className="text-center">{t('txt-apply')}</td>
                    <td className="text-center">{t('txt-before')}</td>
                    <td className="text-center">{t('txt-after')}</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Combo phí</th>
                    <th>
                      <Field
                        name="formPolicy"
                        className="form-control input-order "
                        component={RenderNormalSelect}
                        opts={glComboFee}
                        //placeholder="-- Tất cả --"
                        required
                      />
                    </th>
                    <th>
                      <Field
                        name="formPolicyBack"
                        className="form-control input-order "
                        component={RenderNormalSelect}
                        opts={glComboFee}
                        //placeholder="-- Tất cả --"
                        required
                      />
                    </th>
                  </tr>
                </tbody>
              </Table>
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>
                  {t('txt-note')}
                  {/* <span className="text-danger">*</span> */}
                </Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                  //validate={[required]}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateChinhSachModal = reduxForm({
  form: 'createChinhSachForm',
  enableReinitialize: true,
  validate,
})(CreateChinhSachModal);

const selector = formValueSelector('createChinhSachForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getUpdPolicy = makeGetUpdPolicy();
  const getGlMarketingID = makeGetGlMarketingID();
  const getCommPackage = makeGetCommPackage();
  const getAdvPackage = makeGetAdvPackage();
  const getGlObjCustomer = makeGetGlObjCustomer();
  const getAllBranch = makeGetAllBranch();
  const getAllSubBranch = makeGetGlobalSubBranchList();
  const getCustType = makeGetCustType();
  const getGlComboFee = makeGetGlComboFee();
  const getSystemInfo = makeGetSystemInfo();

  const {
    formCode,
    formName,
    formFromDate,
    formToDate,
    formObject,
    formData,
    formDuration,
    formNote,
    formBranchCode,
    formSubBranchCode,
    formSFromDate,
    formSToDate,
    formGender,
    formCustType,
    formStaffFlag,
    formPolicy,
    formPolicyBack,
    formMarketingId,
  } = selector(
    state,
    'formCode',
    'formName',
    'formFromDate',
    'formToDate',
    'formObject',
    'formData',
    'formDuration',
    'formNote',
    'formSubBranchCode',
    'formBranchCode',
    'formSFromDate',
    'formSToDate',
    'formGender',
    'formCustType',
    'formStaffFlag',
    'formPolicy',
    'formPolicyBack',
    'formMarketingId'
  );
  return {
    token: getToken(state),
    glMarketingID: getGlMarketingID(state),
    glCommPackage: getCommPackage(state),
    glAdvPackage: getAdvPackage(state),
    glObjCustomer: getGlObjCustomer(state),
    glAllBranch: getAllBranch(state),
    glAllSubBranch: getAllSubBranch(state),
    glComboFee: getGlComboFee(state),
    glCustType: getCustType(state),
    updPolicy: getUpdPolicy(state),
    sysSystemInfo: getSystemInfo(state),
    formCode,
    formName,
    formFromDate,
    formToDate,
    formObject,
    formData,
    formDuration,
    formNote,
    formSubBranchCode,
    formBranchCode,
    formSFromDate,
    formSToDate,
    formCustType,
    formGender,
    formStaffFlag,
    formPolicy,
    formPolicyBack,
    formMarketingId,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateChinhSachModal)
);
