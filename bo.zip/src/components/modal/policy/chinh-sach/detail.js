import RenderArea from 'components/input/renderArea';
import RenderChoseArray from 'components/input/renderChoseArray';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderSuggestProduct from 'components/input/renderSuggestProduct';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';
import RenderSuggestBranch from 'components/input/renderSuggestBranch2';
import RenderSuggestSubBranch from 'components/input/renderSuggestSubBranch2';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import {
  updPolicyRequest,
  updPolicySuccess,
} from 'containers/category/actions';

import RenderInputMask from 'components/input/renderInputMask';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  apprPolicyRequest,
  delPolicyRequest,
  singlePolicyRequest,
  singlePolicySuccess,
  unApprPolicyRequest,
} from 'containers/category/actions';
import {
  makeGetAdvPackage,
  makeGetApprPolicy,
  makeGetCommPackage,
  makeGetDelPolicy,
  makeGetGlMarketingID,
  makeGetGlObjCustomer,
  makeGetSinglePolicy,
  makeGetToken,
  makeGetUnApprPolicy,
  makeGetUpdPolicy,
  makeGetCustType,
  makeGetGlComboFee,
} from 'lib/selector';
import { StringToDouble, StringToInt, _diff2Date } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formFromDate, formToDate } = values;

  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function DetailChinhSachModal(props) {
  const dispatch = useDispatch();
  const {
    pristine,
    token,
    id,
    accRight,
    onClose,
    glMarketingID,
    glCommPackage,
    glAdvPackage,
    glObjCustomer,

    updPolicy,
    singlePolicy,
    delPolicy,
    apprPolicy,
    unApprPolicy,
    formBranchCode,
    glCustType,
    glComboFee,
  } = props;

  const preUpdPolicy = usePrevious(updPolicy);
  const preDelPolicy = usePrevious(delPolicy);
  const preApprPolicy = usePrevious(apprPolicy);
  const preUnApprPolicy = usePrevious(unApprPolicy);
  const preSinglePolicy = usePrevious(singlePolicy);
  const preFormBranch = usePrevious(formBranchCode);

  useEffect(() => {
    getSinglePolicy();
    return () => {
      dispatch(singlePolicySuccess(null));
    };
  }, []);

  useEffect(() => {
    if (updPolicy && !_.isEqual(updPolicy, preUpdPolicy)) {
      _handleToast(t('txt-upd-policy-success'), 'success');
      dispatch(updPolicySuccess(null));
      //getSinglePolicy();
      onClose();
    }
  }, [updPolicy]);

  React.useEffect(() => {
    if (formBranchCode && !_.isEqual(formBranchCode, preFormBranch)) {
      // dispatch(change('detailChinhSachForm', 'formSubBranchCode', ' '));
      //dispatch(change('createChinhSachForm', 'formStaffFlag', '0'.toString()));
    }
  }, [formBranchCode]);

  useEffect(() => {
    if (
      (delPolicy && !_.isEqual(delPolicy, preDelPolicy)) ||
      (apprPolicy && !_.isEqual(apprPolicy, preApprPolicy)) ||
      (unApprPolicy && !_.isEqual(unApprPolicy, preUnApprPolicy))
    ) {
      onClose();
    }
  }, [delPolicy, apprPolicy, unApprPolicy]);

  useEffect(() => {
    if (singlePolicy && !_.isEqual(singlePolicy, preSinglePolicy)) {
      initForm();
    }
  }, [singlePolicy]);

  function getSinglePolicy() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_POLICY_PACKAGE',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(singlePolicyRequest(params));
  }

  function initForm() {
    dispatch(change('detailChinhSachForm', 'formName', singlePolicy?.C_NAME));
    dispatch(
      change('detailChinhSachForm', 'formFromDate', singlePolicy?.C_EFFECT_DATE)
    );
    dispatch(
      change('detailChinhSachForm', 'formToDate', singlePolicy?.C_EXPIRE_DATE)
    );
    dispatch(
      change(
        'detailChinhSachForm',
        'formBranchCode',
        singlePolicy?.C_BRANCH_CODE
      )
    );
    dispatch(
      change(
        'detailChinhSachForm',
        'formSubBranchCode',
        singlePolicy?.C_SUB_BRANCH_CODE
      )
    );
    dispatch(
      change('detailChinhSachForm', 'formDuration', singlePolicy?.C_COUNT_DAY)
    );
    dispatch(
      change(
        'detailChinhSachForm',
        'formMarketingId',
        singlePolicy?.C_MARKETING_ID
      )
    );
    dispatch(
      change(
        'detailChinhSachForm',
        'formCustType',
        singlePolicy?.C_CUSTOMER_TYPE
      )
    );
    dispatch(
      change('detailChinhSachForm', 'formGender', singlePolicy?.C_GENDER)
    );
    dispatch(
      change('detailChinhSachForm', 'formSFromDate', singlePolicy?.C_BIRTH_FROM)
    );
    dispatch(
      change('detailChinhSachForm', 'formSToDate', singlePolicy?.C_BIRTH_TO)
    );
    dispatch(
      change('detailChinhSachForm', 'formPolicy', singlePolicy?.C_POLICY_CODE)
    );
    dispatch(
      change(
        'detailChinhSachForm',
        'formPolicyBack',
        singlePolicy?.C_POLICY_BACK
      )
    );
    dispatch(
      change('detailChinhSachForm', 'formNote', singlePolicy?.C_CONTENT)
    );
    dispatch(change('detailChinhSachForm', 'formCode', singlePolicy?.C_CODE));
    dispatch(
      change(
        'detailChinhSachForm',
        'formStaffFlag',
        singlePolicy?.C_STAFF_FLAG + ''
      )
    );
  }

  function submit(values) {
    handleConfirm('update');
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'update'
                ? t('txt-upd-policy')
                : actionName === 'delete'
                ? t('txt-del-policy')
                : actionName === 'approve'
                ? t('txt-appr-policy')
                : actionName === 'unApprove'
                ? t('txt-un-appr-policy')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'update':
                    handleActionUpdate();
                    break;
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_POLICY_PACKAGE',
      group: 'LIST',
      data: {
        ID: id,
        CODE: props?.formCode,
        NAME: props?.formName,
        EFFECT_DATE: props?.formFromDate,
        EXPIRE_DATE: props?.formToDate,
        COUNT_DAY: StringToInt(props.formDuration),
        BRANCH_CODE: props.formBranchCode,
        SUB_BRANCH_CODE: props.formSubBranchCode,
        MARKETING_ID: props.formMarketingId,
        CUSTOMER_TYPE: props.formCustType,
        GENDER: props.formGender,
        BIRTH_FROM: props.formSFromDate,
        BIRTH_TO: props.formSToDate,
        POLICY_CODE: props.formPolicy,
        POLICY_BACK: props.formPolicyBack,
        STAFF_FLAG: props.formStaffFlag || -1,
        CONTENT: props?.formNote,
      },
    };

    dispatch(updPolicyRequest(params));
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_POLICY_PACKAGE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
      },
    };
    dispatch(delPolicyRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_POLICY_PACKAGE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
        NEW_STATUS: 'DA_DUYET',
      },
    };
    dispatch(apprPolicyRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_POLICY_PACKAGE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
        NEW_STATUS: 'CHUA_DUYET',
      },
    };
    dispatch(unApprPolicyRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-policy-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>
                  {t('txt-policy-code')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <div className="w-100 d-flex flex-row">
                  <Field
                    name="formCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                    disabled
                  />
                </div>
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label>
                  {t('txt-policy-name')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formName"
                  className="form-control input-order fz-13"
                  component={RenderInput}
                  validate={[required]}
                  //disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  Áp dụng từ
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>Đến ngày</Form.Label>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  //validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-duration')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formDuration"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  validate={required}
                />
              </Form.Group>
              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto fz-13">
                  Điều kiện khách hàng thỏa mãn
                </span>
              </div>
              <Form.Group>
                <Form.Label>{t('lab-branch')}</Form.Label>
                <Field
                  name="formBranchCode"
                  className="form-control input-order"
                  component={RenderSuggestBranch}
                  index={3}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <Field
                  name="formSubBranchCode"
                  className="form-control input-order"
                  component={RenderSuggestSubBranch}
                  branchCode={formBranchCode}
                  index={3}
                />
              </Form.Group>
              {/* <Form.Group>
                <Form.Label className="fz-13">{t('txt-marketing-id')}</Form.Label>
                <Field
                  name="formMarketingId"
                  type="text"
                  className="form-control"
                  placeholder={t('txt-marketing-id')}
                  component={RenderInput}
                />
              </Form.Group> */}
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Field
                  name="formMarketingId"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-gender')}</Form.Label>
                <Field
                  name="formGender"
                  className="form-control w_170"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="M">Nam</option>
                  <option value="F">Nữ</option>
                </Field>
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-s-from-date')}
                </Form.Label>
                <Field
                  name="formSFromDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formSToDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-type')}</Form.Label>
                <Field
                  name="formCustType"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glCustType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-company-employee')}</Form.Label>
                <Field
                  name="formStaffFlag"
                  className="form-control w-100"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="1">Có</option>
                  <option value="0">Không</option>
                </Field>
              </Form.Group>

              <Table bordered className="mt-2" style={{ gridColumn: '1/4' }}>
                <thead>
                  <tr>
                    <td className="text-center">{t('txt-apply')}</td>
                    <td className="text-center">{t('txt-before')}</td>
                    <td className="text-center">{t('txt-after')}</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Combo phí</th>
                    <th>
                      <Field
                        name="formPolicy"
                        className="form-control input-order "
                        component={RenderNormalSelect}
                        opts={glComboFee}
                        //placeholder="-- Tất cả --"
                        required
                      />
                    </th>
                    <th>
                      <Field
                        name="formPolicyBack"
                        className="form-control input-order "
                        component={RenderNormalSelect}
                        opts={glComboFee}
                        //placeholder="-- Tất cả --"
                        required
                      />
                    </th>
                  </tr>
                </tbody>
              </Table>
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>
                  {t('txt-note')}
                  {/* <span className="text-danger">*</span> */}
                </Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                  //validate={[required]}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              {
                accRight?.C_APPROVE === 1 &&
                singlePolicy?.C_STATUS === 'CHUA_DUYET' && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('approve')}
                    className="fz-13 mr-2 success"
                  >
                    {t('txt-appr')}
                  </BtnSubmit>
                )
              }
              {
                accRight?.C_APPROVE === 1 &&
                singlePolicy?.C_STATUS === 'DA_DUYET' && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('unApprove')}
                    className="fz-13 mr-2 success"
                  >
                    Hủy duyệt
                  </BtnSubmit>
                )
              }
             <div className="d-flex">
                {
                accRight?.C_UPDATE === 1 &&
                singlePolicy?.C_STATUS === 'CHUA_DUYET' && (
                  <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
                )
              }
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailChinhSachModal = reduxForm({
  form: 'detailChinhSachForm',
  enableReinitialize: true,
  validate,
})(DetailChinhSachModal);

const selector = formValueSelector('detailChinhSachForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getGlMarketingID = makeGetGlMarketingID();
  const getCommPackage = makeGetCommPackage();
  const getAdvPackage = makeGetAdvPackage();
  const getGlObjCustomer = makeGetGlObjCustomer();

  const getUpdPolicy = makeGetUpdPolicy();
  const getSinglePolicy = makeGetSinglePolicy();
  const getDelPolicy = makeGetDelPolicy();
  const getApprPolicy = makeGetApprPolicy();
  const getUnApprPolicy = makeGetUnApprPolicy();
  const getCustType = makeGetCustType();
  const getGlComboFee = makeGetGlComboFee();

  const {
    formCode,
    formName,
    formFromDate,
    formToDate,
    formObject,
    formData,
    formDuration,
    formNote,
    formBranchCode,
    formSubBranchCode,
    formSFromDate,
    formSToDate,
    formGender,
    formCustType,
    formStaffFlag,
    formPolicy,
    formPolicyBack,
    formMarketingId,
  } = selector(
    state,
    'formCode',
    'formName',
    'formFromDate',
    'formToDate',
    'formObject',
    'formData',
    'formDuration',
    'formSubBranchCode',
    'formBranchCode',
    'formSFromDate',
    'formSToDate',
    'formGender',
    'formCustType',
    'formStaffFlag',
    'formPolicy',
    'formPolicyBack',
    'formMarketingId',
    'formNote'
  );
  const singlePolicy = getSinglePolicy(state);
  return {
    token: getToken(state),
    glMarketingID: getGlMarketingID(state),
    glCommPackage: getCommPackage(state),
    glAdvPackage: getAdvPackage(state),
    glObjCustomer: getGlObjCustomer(state),
    glCustType: getCustType(state),

    updPolicy: getUpdPolicy(state),
    delPolicy: getDelPolicy(state),
    apprPolicy: getApprPolicy(state),
    unApprPolicy: getUnApprPolicy(state),
    glComboFee: getGlComboFee(state),
    singlePolicy,
    formCode,
    formName,
    formFromDate,
    formToDate,
    formObject,
    formData,
    formDuration,
    formNote,
    formSubBranchCode,
    formBranchCode,
    formSFromDate,
    formSToDate,
    formCustType,
    formGender,
    formStaffFlag,
    formPolicy,
    formPolicyBack,
    formMarketingId,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailChinhSachModal)
);
