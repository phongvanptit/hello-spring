import RenderSearchShort from 'components/input/inputSearchShort';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  accountListChangeInforDelSuccess,
} from 'containers/account/actions';
import {
  listPolicyAccountRequest,
  delPolicyAccountSuccess
} from 'containers/category/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetListAccountChangeInforDel,
  makeGetDelPolicyAccount,
  
} from 'lib/selector';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';
function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    delPolicyAccount,
  } = props;

  const preListAccountDel = usePrevious(delPolicyAccount);

  useEffect(() => {
    setTimeout(() => {
      dispatch(listPolicyAccountRequest(dataSearch));
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (delPolicyAccount && !_.isEqual(delPolicyAccount, preListAccountDel))
    ) {
      _handleBlur();
      _handleToast('Xóa tài khoản thành công', 'success');
      dispatch(delPolicyAccountSuccess(null));
    }
  }, [delPolicyAccount]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = props?.formCode;

    dispatch(listPolicyAccountRequest(_params));
    setDataSearch && setDataSearch(_params);
  }

  return (
    <FormFlexCenter className="w-100">
      <div className="d-flex align-items-center mr-auto">
      </div>
      <Form.Group>
        <Field
          name="formCode"
          className="form-control"
          placeholder={t('txt-acc-code')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDSAP',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDSAP');

const makeMapStateToProps = () => {
  const getDelPolicyAccount = makeGetDelPolicyAccount();
  const mapStateToProps = (state) => {

    const { formCode, formMarIdReceiveCode, } = selector(state, 'formCode', 'formMarIdReceiveCode',);

    return {
      delPolicyAccount: getDelPolicyAccount(state),
      formCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
