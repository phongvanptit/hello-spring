import { useEffect } from 'react';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import styled from 'styled-components';

import {
  detailTradingHistoryRequest,
  detailTradingHistorySuccess,
} from 'containers/dashboard/actions';
import { makeGetDetailTradingHistory, makeGetToken } from 'lib/selector';
import { numberFormat } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion

function DetailCkThuong(props) {
  const dispatch = useDispatch();

  const { token, onClose, id, t, eqSumById } = props;

  useEffect(() => {
    getListTradingHistory();
    return () => {
      dispatch(detailTradingHistorySuccess(null));
    };
  }, []);

  function getListTradingHistory() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        cmd: 'BD.EQ_BrokerSumByID',
        type: 'string',
        p1: id,
        p2: '1',
      },
    };
    dispatch(detailTradingHistoryRequest(params));
  }
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-acc-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>STT</th>
                <th>{t('txt-acc')}</th>
                <th>{t('txt-name')}</th>
                <th>{t('txt-buy-total')}</th>
                <th>{t('txt-sell-total')}</th>
                <th>{t('txt-trading-total')}</th>
                <th>{t('txt-fee-total')}</th>
                <th>%</th>
              </tr>
            </thead>
            <tbody>
              {eqSumById &&
                eqSumById.map((item, i) => {
                  if (item.rn === '0') {
                    return (
                      <tr key={'broker_' + i}>
                        <td></td>
                        <td className="text-center text-primary font-weight-bold">
                          {item.account}
                        </td>
                        <td className="text-left text-primary font-weight-bold">
                          {item.name}
                        </td>
                        <td className="text-right text-primary font-weight-bold">
                          {numberFormat(item.total_buy)}
                        </td>
                        <td className="text-right text-primary font-weight-bold">
                          {numberFormat(item.total_sell)}
                        </td>
                        <td className="text-right text-primary font-weight-bold">
                          {numberFormat(item.total_trade)}
                        </td>
                        <td className="text-right text-primary font-weight-bold">
                          {numberFormat(item.total_fee)}
                        </td>
                        <td className="text-right text-primary font-weight-bold">
                          {item.per}
                        </td>
                      </tr>
                    );
                  } else {
                    return (
                      <tr key={'broker_' + i}>
                        <td className="text-center ">{item.rn}</td>
                        <td className="text-center ">{item.account}</td>
                        <td className="text-left ">{item.name}</td>
                        <td className="text-right ">
                          {numberFormat(item.total_buy, 0)}
                        </td>
                        <td className="text-right ">
                          {numberFormat(item.total_sell, 0)}
                        </td>
                        <td className="text-right ">
                          {numberFormat(item.total_trade, 0)}
                        </td>
                        <td className="text-right ">
                          {numberFormat(item.total_fee, 0)}
                        </td>
                        <td className="text-right ">{item.per}</td>
                      </tr>
                    );
                  }
                })}
            </tbody>
          </table>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getDetailTradingHistory = makeGetDetailTradingHistory();
  return {
    token: getToken(state),
    eqSumById: getDetailTradingHistory(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailCkThuong)
);
