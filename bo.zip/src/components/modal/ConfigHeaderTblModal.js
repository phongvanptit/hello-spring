import React, { useCallback, useState, useEffect } from 'react';
import ReactModal from 'react-modal';
import { Field, reduxForm, formValueSelector } from 'redux-form';
import { translate } from 'react-i18next';
import styled from 'styled-components';
import { makeGetToken } from 'lib/selector';
import { connect, useDispatch } from 'react-redux';

import PerfectScrollbar from 'react-perfect-scrollbar';

import * as _ from 'lodash';
import { setToast } from 'containers/client/actions';
import { sysSingleUserCfgRequest } from 'containers/system/actions';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { makeGetListCfg } from 'lib/selector';
import { makeGetUserCfg } from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import RenderSearchShort from 'components/input/inputSearchShort';
ReactModal.setAppElement('#root');

const appUrl = `${process.env.REACT_APP_API_URL}`;

const ContainerBody = styled.div`
  padding: 0 16px;
  margin-bottom: 16px;
  overflow: hidden;
`;

const CardBody = styled.div`
  background: #f5f5f5;
  border-radius: 12px;
  padding: 16px 8px 16px 16px;
  height: calc(100vh - 105px);

  .drag-list {
    padding-right: 8px;

    .drag-content {
      background: #ffffff;
      border-radius: 8px;
      padding: 11px;
      display: grid;
      grid-template-columns: auto 15px;
      gap: 10px;
      border: 1px solid #ffffff;
      font-size: 13px;

      &:not(:first-of-type) {
        margin-top: 8px;
      }

      .li-content {
        display: flex;
        flex-direction: column;

        span {
          font-weight: 600;
          font-size: 14px;
          line-height: 20px;

          color: #3c3c3c;
        }
      }
    }
  }
`;

const customStyles = {
  content: {
    top: '0px',
    bottom: '0px',
    left: 'calc( 100% - 600px )',
    width: '600px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const DragHeader = styled.div`
  background: #ffffff;
  border-radius: 8px;
  padding: 11px;
  display: grid;
  grid-template-columns: auto 15px;
  gap: 10px;
  border: 1px solid #ffffff;
  font-size: 13px;
  margin-bottom: 8px;
  width: 536px;
  span {
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    color: #3c3c3c;
  }
`;

const FormSearch = styled.form`
  display: flex;
  align-items: left;
  margin-bottom: 8px;
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function escapeRegexCharacters(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function ConfigHeaderTblModal(props) {
  const abortController = new AbortController();
  const [loading, setLoading] = React.useState(false);
  const [allData, setAllData] = React.useState([]);
  const [checkAll, setCheckAll] = useState([]);
  const [data, setData] = useState([]);
  const { onClose, t, token, bizCode, listCfg, userCfg, tblDef, formName } =
    props;

  const preListCfg = usePrevious(listCfg);
  const preFormName = usePrevious(formName);
  const dispatch = useDispatch();

  useEffect(() => {
    if (!_.isEqual(formName, preFormName)) {
      if (formName) {
        getSuggestions(formName);
      } else setData(allData);
    }
  });

  useEffect(() => {
    if (listCfg && !_.isEqual(listCfg, preListCfg)) {
      const _userCfg = userCfg && !!userCfg.length ? userCfg : tblDef;
      let _newData = [];
      listCfg.forEach((element) => {
        const objClone = _.cloneDeep(element);
        objClone.value =
          _.find(_userCfg, (o) => o.code === element.code)?.status === '1'
            ? true
            : false;
        _newData.push(objClone);
      });
      setData(_newData);
      setAllData(_newData);
    }
  }, [listCfg]);

  function getUserConfig() {
    if (!token) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_CONFIG',
      group: 'LIST',
      data: {
        BUSINESS_CODE: bizCode,
      },
    };

    dispatch(sysSingleUserCfgRequest(params));
  }

  function onSubmit() {
    if (loading) return;
    setLoading(true);

    const _userCfg = [];

    allData.forEach((element) => {
      _userCfg.push({
        code: element.code,
        status: element.value ? '1' : '0',
      });
    });

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_USER_CONFIG',
      group: 'LIST',
      data: {
        BUSINESS_CODE: bizCode,
        DATA: _userCfg,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        setLoading(false);
        console.log(res);
        if (res.code == 1) {
          _handleToast('Cập nhật thông tin thành công', 'success');
          getUserConfig();
          onClose();
        } else {
          _handleToast(res.re, 'error');
        }
      })
      .catch((error) => {
        setLoading(false);
        console.log(error);
        _handleToast(error?.message, 'error');
      });
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function getSuggestions(value) {
    const escapedValue = escapeRegexCharacters(value.trim());

    if (escapedValue === '') {
      setData(allData);
    }

    // const regex = new RegExp(escapedValue, 'igm');
    setData(
      allData.filter((o) =>
        o.name?.toLowerCase().includes(escapedValue?.toLowerCase())
      )
    );
  }

  function _handleChange(e) {
    const { name, checked } = e.target;
    //change all data
    const objClone = _.cloneDeep(allData);
    objClone.map((element) => {
      if (element.code === name) element.value = checked;
      return element;
    });
    setAllData(objClone);
    //change data
    const obj = _.cloneDeep(data);
    obj.map((element) => {
      if (element.code === name) element.value = checked;
      return element;
    });
    setData(obj);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    setCheckAll(checked);
    //change all data
    const objClone = _.cloneDeep(allData);
    objClone.map((element) => {
      if (
        (bizCode === 'BACK.GET_ALL_CUSTOMER' &&
          element.code !== 'C_CUSTOMER_CODE' &&
          element.code !== 'C_CUSTOMER_NAME') ||
        (bizCode === 'BACK.GET_ALL_ACCOUNT' &&
          element.code !== 'C_ACCOUNT_CODE' &&
          element.code !== 'C_ACCOUNT_NAME')
      )
        element.value = checked;
      return element;
    });
    setAllData(objClone);
    //change all data
    const obj = _.cloneDeep(data);
    obj.map((element) => {
      if (
        (bizCode === 'BACK.GET_ALL_CUSTOMER' &&
          element.code !== 'C_CUSTOMER_CODE' &&
          element.code !== 'C_CUSTOMER_NAME') ||
        (bizCode === 'BACK.GET_ALL_ACCOUNT' &&
          element.code !== 'C_ACCOUNT_CODE' &&
          element.code !== 'C_ACCOUNT_NAME')
      )
        element.value = checked;
      return element;
    });
    setData(obj);
  }

  const memoizedCallback = useCallback((state) => onDragEnd(state), [allData]);

  const onDragEnd = (result) => {
    const { destination, source, reason } = result;
    // console.log(result);
    // Not a thing to do...
    if (!destination || reason === 'CANCEL') {
      return;
    }

    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    const _starredProjects = _.clone(allData);
    const project = allData[source.index];
    _starredProjects.splice(source.index, 1);
    _starredProjects.splice(destination.index, 0, project);

    setAllData(_starredProjects);
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0"
        style={{ height: '100vh', overflow: 'hidden' }}
      >
        <p className="p-header font-weight-bold py-2 text-center">
          {t('txt-field-manage')}
        </p>
        <ContainerBody>
          <CardBody>
            <FormSearch>
              <Field
                name="formName"
                type="text"
                className="form-control"
                placeholder={t('txt-search')}
                component={RenderSearchShort}
              />
            </FormSearch>
            <DragHeader>
              <span>{t('txt-data-col-name')}</span>
              <input
                type={'checkbox'}
                value={checkAll}
                onChange={_handleChangeCheckAll}
                checked={checkAll}
              />
            </DragHeader>
            <DragDropContext onDragEnd={memoizedCallback}>
              <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 225px)' }}>
                <Droppable droppableId="droppable">
                  {(provided, snapshot) => (
                    <div
                      className="drag-list"
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                    >
                      {data &&
                        data.map((item, index) => {
                          if (
                            (bizCode === 'BACK.GET_ALL_CUSTOMER' &&
                              (item.code === 'C_CUSTOMER_CODE' ||
                                item.code === 'C_CUSTOMER_NAME')) ||
                            (bizCode === 'BACK.GET_ALL_ACCOUNT' &&
                              (item.code === 'C_ACCOUNT_CODE' ||
                                item.code === 'C_ACCOUNT_NAME'))
                          )
                            return (
                              <div className="drag-content" key={index}>
                                <span>{item.name}</span>
                                <input
                                  type={'checkbox'}
                                  checked={item.value}
                                  name={item.code}
                                  onChange={_handleChange}
                                  disabled={
                                    (bizCode === 'BACK.GET_ALL_CUSTOMER' &&
                                      (item.code === 'C_CUSTOMER_CODE' ||
                                        item.code === 'C_CUSTOMER_NAME')) ||
                                    (bizCode === 'BACK.GET_ALL_ACCOUNT' &&
                                      (item.code === 'C_ACCOUNT_CODE' ||
                                        item.code === 'C_ACCOUNT_NAME'))
                                  }
                                />
                              </div>
                            );
                          return (
                            <Draggable
                              draggableId={item.code + '_' + index}
                              index={index}
                              key={index}
                            >
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className="drag-content"
                                >
                                  <span>{item.name}</span>
                                  <input
                                    type={'checkbox'}
                                    checked={item.value}
                                    name={item.code}
                                    onChange={_handleChange}
                                  />
                                </div>
                              )}
                            </Draggable>
                          );
                        })}
                    </div>
                  )}
                </Droppable>
              </PerfectScrollbar>
            </DragDropContext>
          </CardBody>
        </ContainerBody>
        <div
          className="d-flex"
          style={{ height: '30px', whiteSpace: 'nowrap', padding: '0 16px' }}
        >
          <BtnClose onClick={onClose} className="mr-auto">
            {t('txt-cancel')}
          </BtnClose>
          <BtnSubmit className="accept" disabled={loading} onClick={onSubmit}>
            {t('txt-confirm')}
          </BtnSubmit>
        </div>
      </div>
    </ReactModal>
  );
}

ConfigHeaderTblModal = reduxForm({
  form: 'formConfigHeaderTblModal',
  enableReinitialize: true,
})(ConfigHeaderTblModal);

const selector = formValueSelector('formConfigHeaderTblModal');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getListCfg = makeGetListCfg();
  const getUserCfg = makeGetUserCfg();
  const mapStateToProps = (state) => {
    const { formCode, formName } = selector(state, 'formCode', 'formName');

    return {
      token: getToken(state),
      listCfg: getListCfg(state),
      userCfg: getUserCfg(state),

      formCode,
      formName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(ConfigHeaderTblModal)
);
