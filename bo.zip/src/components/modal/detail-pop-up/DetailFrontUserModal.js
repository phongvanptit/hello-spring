import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderNewInputMkt from 'components/input/renderNewInputMkt';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { setToast } from 'containers/client/actions';
import { handleApiErrors } from 'lib/api-errors';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { formatDate } from 'utils';
import { required, validateEmail, validatePhone } from 'utils/validation';

import {
  frontDelUserRequest,
  frontDelUserSuccess,
  frontUpdUserRequest,
  frontUpdUserSuccess,
  frontUserSingleRequest,
  frontUserSingleSuccess,
} from 'containers/user-management/actions';

import {
  makeGetAllBranch,
  makeGetFrontDelUser,
  makeGetFrontUpdUser,
  makeGetFrontUserSingle,
  makeGetGlobalFrontDataRight,
  makeGetGlobalFrontFuncRight,
  makeGetGlobalSubBranchList,
  makeGetToken,
} from 'lib/selector';
import { _diff2Date } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formIssueDate } = values;

  if (
    formIssueDate &&
    _diff2Date(formatDate(new Date(), '/', 'dmy'), formIssueDate) < 0
  ) {
    errors.formIssueDate = `Ngày không hợp lệ`;
  }

  return errors;
};

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function DetailFrontUserModal(props) {
  const dispatch = useDispatch();
  const [accUser, setAccUser] = useState(null);

  const {
    token,
    onClose,
    glAllBranch,
    formManagerCode,
    glSubBranchList,
    glFrontFuncRight,
    glFrontDataRight,
    frontUpdUser,
    id,
    frontDelUser,
    frontUserSingle,
    accRight,
  } = props;
  const preFrontUpdUser = usePrevious(frontUpdUser);
  const preFrontDelUser = usePrevious(frontDelUser);
  const preFrontUserSingle = usePrevious(frontUserSingle);

  useEffect(() => {
    if (frontUserSingle && !_.isEqual(frontUserSingle, preFrontUserSingle)) {
      initForm();
    }
  }, [frontUserSingle]);

  useEffect(() => {
    getSingleFrontUser();
    return () => {
      dispatch(frontUserSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formManagerCode) {
      _handleCheckAccountUser();
    } else setAccUser(null);
  }, [formManagerCode]);

  useEffect(() => {
    if (frontUpdUser && !_.isEqual(frontUpdUser, preFrontUpdUser)) {
      _handleToast(t('txt-upd-user-success'), 'success');
      dispatch(frontUpdUserSuccess(null));
      getSingleFrontUser();
    }
  }, [frontUpdUser]);

  useEffect(() => {
    if (frontDelUser && !_.isEqual(frontDelUser, preFrontDelUser)) {
      _handleToast(t('txt-del-user-success'), 'success');
      dispatch(frontDelUserSuccess(null));
      onClose();
    }
  }, [frontDelUser]);


  function initForm() {
    dispatch(
      change('detailFrontUserModalform', 'formBranchCode', frontUserSingle?.C_BRANCH_CODE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formSubBranchCode', frontUserSingle?.C_SUB_BRANCH_CODE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formUserCode', frontUserSingle?.C_FRONT_USER_CODE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formUserName', frontUserSingle?.C_FRONT_USER_NAME)
    )
    dispatch(
      change('detailFrontUserModalform', 'formCardId', frontUserSingle?.C_CARD_ID)
    )
    dispatch(
      change('detailFrontUserModalform', 'formIssueDate', frontUserSingle?.C_ID_ISSUE_DATE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formIssuePlace', frontUserSingle?.C_ISSUE_PLACE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formPhone', frontUserSingle?.C_PHONE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formEmail', frontUserSingle?.C_EMAIL)
    )
    dispatch(
      change('detailFrontUserModalform', 'formResetPassFlag', frontUserSingle?.C_RESET_PWD_FLAG === 1)
    )
    dispatch(
      change('detailFrontUserModalform', 'formManagerCode', frontUserSingle?.C_MANAGER_CODE)
    )
    dispatch(
      change('detailFrontUserModalform', 'formFuncRightGroup', frontUserSingle?.C_FUNC_RIGHT_GROUP)
    )
    dispatch(
      change('detailFrontUserModalform', 'formDataRightGroup', frontUserSingle?.C_DATA_RIGHT_GROUP)
    )
    dispatch(
      change('detailFrontUserModalform', 'formDataRightList', frontUserSingle?.C_DATA_RIGHT_LIST)
    )
    dispatch(
      change('detailFrontUserModalform', 'formBizRightList', frontUserSingle?.C_BIZ_RIGHT_LIST)
    )
    dispatch(
      change('detailFrontUserModalform', 'formStatus', frontUserSingle?.C_STATUS === 1)
    )
  }

  function getSingleFrontUser() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: id,
      },
    };

    dispatch(frontUserSingleRequest(params));
  }

  function _handleCheckAccountUser() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formManagerCode,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
    })
      .then(handleApiErrors)
      .then((response) => response.json())
      .then((json) => {
        console.log(json);
        if (json.code === '1') {
          setAccUser(json.data[0]);
        } else {
          setAccUser(null);
          _handleToast(json.re, 'error');
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function submit(values) {
    console.log(values);

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_USER_FRONT',
      group: 'LIST',
      data: {
        FRONT_USER_ID: frontUserSingle?.PK_FRONT_USER,
        BRANCH_CODE: values?.formBranchCode,
        SUB_BRANCH_CODE: values?.formSubBranchCode,
        FRONT_USER_CODE: values?.formUserCode,
        FRONT_USER_NAME: values?.formUserName,
        FRONT_USER_PWD: values?.formPass,
        RESET_PWD_FLAG: values?.formResetPassFlag ? 1 : 0,
        MANAGER_CODE: values?.formManagerCode,
        FUNC_RIGHT_GROUP: values?.formFuncRightGroup,
        DATA_RIGHT_GROUP: values?.formDataRightGroup,
        DATA_RIGHT_LIST: values?.formDataRightGroup,
        BIZ_RIGHT_LIST: values?.formBizRightList,
        PHONE: values?.formPhone,
        EMAIL: values?.formEmail,
        STATUS: values?.formStatus ? 1 : 0,
        ID_CARD: values?.formCardId,
        ID_ISSUE_DATE: values?.formIssueDate,
        ID_ISSUE_PLACE: values?.formIssuePlace,
        // CONTACT_ADDRESS: values?.formContactAddress,
        // RESEDENCE_ADDRESS: values?.formResidenceAddress,
      },
    };

    dispatch(frontUpdUserRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{actionName === 'delete' ? t('txt-del-user') : ''}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;

                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_USER_FRONT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: frontUserSingle?.PK_FRONT_USER,
      },
    };

    dispatch(frontDelUserRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t, pristine } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3"> {t('txt-user-front-detail')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-detail')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-branch')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchCode"
                    className="form-control input-order fz-13"
                    opts={glAllBranch}
                    component={RenderNormalSelect}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-subBranch')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formSubBranchCode"
                    className="form-control input-order fz-13"
                    opts={glSubBranchList}
                    component={RenderNormalSelect}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-front-user-code')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formUserCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-user-name')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formUserName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-identification-card')}</Form.Label>
                  <Field
                    name="formCardId"
                    className="form-control"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <Field
                    name="formIssueDate"
                    className="form-control input-order fz-13"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-place')}</Form.Label>
                  <Field
                    name="formIssuePlace"
                    className="form-control"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-mobile')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPhone"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    validate={[required, validatePhone]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {' '}
                    {t('txt-email')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formEmail"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    validate={[validateEmail, required]}
                  />
                </Form.Group>
                {/* <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label> {t('txt-residence-address')} </Form.Label>
                  <Field
                    name="formResidenceAddress"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label> {t('txt-contact-address')} </Form.Label>
                  <Field
                    name="formContactAddress"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                  />
                </Form.Group> */}
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label> {t('txt-pass-login')}</Form.Label>
                  <Field
                    name="formPass"
                    type="password"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group className="d-grid align-items-end">
                  <Form.Label>
                    <Field
                      name="formResetPassFlag"
                      component={'input'}
                      type="checkbox"
                      className="mr-2"
                    />
                    {t('txt-request-change-password')}
                  </Form.Label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-manager-code')}</Form.Label>
                  <Field
                    name="formManagerCode"
                    className="form-control"
                    component={RenderNewInputMkt}
                    token={token}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-manager-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control"
                    value={accUser?.C_FRONT_USER_NAME || ''}
                    disabled
                  />
                </Form.Group>
               
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailFrontUserModal = reduxForm({
  form: 'detailFrontUserModalform',
  enableReinitialize: true,
  validate,
})(DetailFrontUserModal);

const selector = formValueSelector('detailFrontUserModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getAllBranch = makeGetAllBranch();
  const getGlobalSubBranchList = makeGetGlobalSubBranchList();
  const getGlobalFrontFuncRight = makeGetGlobalFrontFuncRight();
  const getGlobalFrontDataRight = makeGetGlobalFrontDataRight();
  const getFrontUpdUser = makeGetFrontUpdUser();
  const getFrontDelUser = makeGetFrontDelUser();
  const getFrontUserSingle = makeGetFrontUserSingle();

  const {
    formBranchCode,
    formSubBranchCode,
    formUserCode,
    formUserName,
    formCardId,
    formIssueDate,
    formIssuePlace,
    formPhone,
    formEmail,
    formResidenceAddress,
    formContactAddress,
    formPass,
    formResetPassFlag,
    formManagerCode,
    formFuncRightGroup,
    formDataRightGroup,
    formDataRightList,
    formBizRightList,
    formOrderFlag,
    formStatus,
  } = selector(
    state,
    'formBranchCode',
    'formSubBranchCode',
    'formUserCode',
    'formUserName',
    'formCardId',
    'formIssueDate',
    'formIssuePlace',
    'formPhone',
    'formEmail',
    'formResidenceAddress',
    'formContactAddress',
    'formPass',
    'formResetPassFlag',
    'formManagerCode',
    'formFuncRightGroup',
    'formDataRightGroup',
    'formDataRightList',
    'formBizRightList',
    'formOrderFlag',
    'formStatus'
  );
  const frontUserSingle = getFrontUserSingle(state);
  return {
    token: getToken(state),
    glAllBranch: getAllBranch(state),
    glSubBranchList: getGlobalSubBranchList(state),
    glFrontFuncRight: getGlobalFrontFuncRight(state),
    glFrontDataRight: getGlobalFrontDataRight(state),
    frontUpdUser: getFrontUpdUser(state),
    frontUserSingle,
    frontDelUser: getFrontDelUser(state),

    formBranchCode,
    formSubBranchCode,
    formUserCode,
    formUserName,
    formCardId,
    formIssueDate,
    formIssuePlace,
    formPhone,
    formEmail,
    formResidenceAddress,
    formContactAddress,
    formPass,
    formResetPassFlag,
    formManagerCode,
    formFuncRightGroup,
    formDataRightGroup,
    formDataRightList,
    formBizRightList,
    formOrderFlag,
    formStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailFrontUserModal)
);

