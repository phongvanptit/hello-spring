import {
  frontUserSingleRequest,
  frontUserSingleSuccess,
} from 'containers/user-management/actions';
import { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { reduxForm } from 'redux-form';
import styled from 'styled-components';

import { makeGetFrontUserSingle, makeGetToken } from 'lib/selector';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 350px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion

function DetailMarketingIdModal(props) {
  const dispatch = useDispatch();

  const { token, onClose, t, id, frontUserSingle } = props;

  useEffect(() => {
    getSingleFrontUser();
    return () => {
      dispatch(frontUserSingleSuccess(null));
    };
  }, []);

  function getSingleFrontUser() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: id,
      },
    };

    dispatch(frontUserSingleRequest(params));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-sale-info')}</b>
          <a onClick={onClose} className="ml-auto pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <FormAdd>
            <Form.Group>
              <Form.Label>Marketing ID</Form.Label>
              <input
                type={'text'}
                value={frontUserSingle?.C_FRONT_USER_CODE || ''}
                className="form-control input-order "
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-marketing-name')}</Form.Label>
              <input
                type={'text'}
                value={frontUserSingle?.C_FRONT_USER_NAME || ''}
                className="form-control input-order "
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>
                {t('txt-branch')}
                <span className="text-danger">*</span>
              </Form.Label>
              <input
                type={'text'}
                value={` ${frontUserSingle?.C_BRANCH_CODE || ''} - ${frontUserSingle?.C_BRANCH_NAME || ''
                  }`}
                className="form-control input-order "
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-subBranch')}</Form.Label>
              <input
                type={'text'}
                value={` ${frontUserSingle?.C_SUB_BRANCH_CODE || ''} - ${frontUserSingle?.C_SUB_BRANCH_NAME || ''
                  }`}
                className="form-control input-order "
                disabled
              />
            </Form.Group>

            <Form.Group>
              <Form.Label>{t('txt-mobile')}</Form.Label>
              <input
                type={'text'}
                value={frontUserSingle?.C_PHONE || ''}
                className="form-control input-order "
                disabled
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>{t('txt-email')}</Form.Label>
              <input
                type={'text'}
                value={frontUserSingle?.C_EMAIL || ''}
                className="form-control input-order "
                disabled
              />
            </Form.Group>
          </FormAdd>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailMarketingIdModal = reduxForm({
  form: 'detailMarketingIdModalPopUp',
  enableReinitialize: true,
})(DetailMarketingIdModal);

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getFrontUserSingle = makeGetFrontUserSingle();

  return {
    token: getToken(state),
    frontUserSingle: getFrontUserSingle(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailMarketingIdModal)
);
