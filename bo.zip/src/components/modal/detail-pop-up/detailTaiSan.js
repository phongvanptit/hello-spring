import {
  frontUserSingleRequest,
  frontUserSingleSuccess,
} from 'containers/user-management/actions';
import { useEffect } from 'react';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { reduxForm } from 'redux-form';
import styled from 'styled-components';

import { makeGetFrontUserSingle, makeGetToken } from 'lib/selector';
import { StringToInt, numberFormat } from 'utils';
import { cashBdAccStatusRequest } from 'containers/cash/actions';
import { cashBdAccStatusSuccess } from 'containers/cash/actions';
import { makeGetBdAccStatus } from 'lib/selector';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 350px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

//#endregion

function DetailTaiSanModal(props) {
  const dispatch = useDispatch();

  const { token, onClose, t, acc, accountStatus } = props;

  useEffect(() => {
    if (acc) getSingleTaiSan();
    return () => {
      dispatch(cashBdAccStatusSuccess(null));
    };
  }, []);

  function getSingleTaiSan() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      group: 'Q',
      data: {
        type: 'string',
        cmd: 'BD.accountStatus',
        p1: acc,
      },
    };

    dispatch(cashBdAccStatusRequest(params));
  }
  console.log(accountStatus);
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-asset-info')}</b>
          <a onClick={onClose} className="ml-auto pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <table className="table table-bordered mt-2">
            <colgroup>
              <col width="25%" />
              <col width="25%" />
              <col width="25%" />
              <col width="25%" />
            </colgroup>
            <tbody>
              <tr>
                <td className="high-light">{t('txt-cash-balance')}</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.cash_balance, 0) || 0}
                </td>
                <td className="high-light">{t('txt-cash-advance-avai')}</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.cash_advance_avai, 0) || 0}
                </td>
              </tr>
              <tr>
                <td className="high-light">{t('txt-withdrawal-cash')}</td>
                <td className="text-right">
                  {numberFormat(accountStatus?.withdrawal_cash, 0) || 0}
                </td>
                <td className="high-light">{t('txt-current-rate')}</td>
                <td className="text-right">
                  {accountStatus?.margin_ratio || 0}
                </td>
              </tr>
            </tbody>
          </table>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailTaiSanModal = reduxForm({
  form: 'detailTaiSanModalPopUp',
  enableReinitialize: true,
})(DetailTaiSanModal);

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getBdAccStatus = makeGetBdAccStatus();

  return {
    token: getToken(state),
    accountStatus: getBdAccStatus(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailTaiSanModal)
);
