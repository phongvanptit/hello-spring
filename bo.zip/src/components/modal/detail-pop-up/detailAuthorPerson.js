import {
    accountAuthorSingleRequest,
    accountAuthorSingleSuccess,
} from 'containers/account/actions';
import { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, reduxForm, formValueSelector } from 'redux-form';
import styled from 'styled-components';
import RenderSelectDate from 'components/input/renderDatePicker';
import * as _ from 'lodash';
import {
    makeGetFrontUserSingle,
    makeGetToken,
    makeGetAccountAuthorSingle,
    makeGetAuthorContent
} from 'lib/selector';
import { formatDate } from 'utils';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
    content: {
        top: '40px',
        bottom: 'auto',
        left: 'calc( 50% - 350px )',
        height: 'auto',
        width: '550px',
        padding: '0',
        borderWidth: '0',
        borderColor: '#f3f3f3',
        overflow: 'inherit',
    },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
  `;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
      font-size: 13px;
    }
    li {
        font-size: 13px;
        list-style-type: none;
    
        input {
          margin-right: 5px;
        }
      }
  `;

//#endregion

function DetailAuthorPersonIdModal(props) {
    const dispatch = useDispatch();


    const { token, onClose, t, id, accAuthorSingle, glAuthorContent } = props;

    useEffect(() => {
        getSingleAccountAuthor();
        return () => {
            dispatch(accountAuthorSingleSuccess(null));
        };
    }, []);

    function getSingleAccountAuthor() {
        if (!id) {
            return;
        }
        const params = {
            user: token?.USER_NAME,
            session: token?.SESSION_ID,
            cmd: 'BACK.GET_SINGLE_ACCOUNT_AUTHOR',
            group: 'LIST',
            data: {
                ID: id,
            },
        };

        dispatch(accountAuthorSingleRequest(params));
    }
    const resultIncludes = glAuthorContent.filter(item => accAuthorSingle?.FUNC.includes(item.C_CODE));

    return (
        <ReactModal
            isOpen={true}
            contentLabel="onRequestClose Example"
            onRequestClose={onClose}
            shouldCloseOnOverlayClick={true}
            overlayClassName="overlay"
            style={customStyles}
        >
            <div
                className="w-100 p-0 rounded"
                style={{ maxHeight: 'calc(100vh - 120px)' }}
            >
                <div className="py-2 d-flex justify-content-between">
                    <b className="fz-16 pl-3">{t('txt-author-person-infor')}</b>
                    <a onClick={onClose} className="ml-auto pr-3">
                        <FaTimes />
                    </a>
                </div>
                <StyleContainer>
                    <FormAdd>
                        <Form.Group>
                            <Form.Label>
                                {t('txt-from-date')}
                                <span className="text-danger">*</span>
                            </Form.Label>
                            <input
                                type={'text'}
                                value={accAuthorSingle?.C_EFFECT_DATE.split(' ')[0] || ''}
                                className="form-control input-order "
                                disabled
                            />
                        </Form.Group>

                        <Form.Group>
                            <Form.Label>{t('txt-to-date')}</Form.Label>
                            <input
                                type={'text'}
                                value={accAuthorSingle?.C_EXPIRE_DATE.split(' ')[0] || ''}
                                className="form-control input-order "
                                disabled
                            />
                        </Form.Group>
                        <p
                            style={{ gridColumn: '1/5' }}
                            className="color-thm mb-0 fz-13"
                        >
                            {t('txt-author-content')}
                        </p>
                        <div className="d-grid align-self-start">
                            {resultIncludes &&
                                resultIncludes.map((item, index) => (
                                    <li key={index} className="mt-1">
                                        <label>
                                            <input
                                                name={item.C_CODE}
                                                type={'checkbox'}
                                                checked={true}
                                                disabled
                                            />
                                            {item.C_NAME}
                                        </label>
                                    </li>
                                ))}
                        </div>
                    </FormAdd>
                </StyleContainer>
            </div>
        </ReactModal >
    );
}

DetailAuthorPersonIdModal = reduxForm({
    form: 'detailAuthorPersonIdModalPopUp',
    enableReinitialize: true,
})(DetailAuthorPersonIdModal);

const selector = formValueSelector('detailAuthorPersonIdModalPopUp');


const mapStateToProps = (state) => {
    const getToken = makeGetToken();
    const getFrontUserSingle = makeGetFrontUserSingle();
    const getAccountAuthorSingle = makeGetAccountAuthorSingle();
    const getAuthorContent = makeGetAuthorContent();

    const {
        formStartDate,
        formEndDate,
    } = selector(
        state,
        'formStartDate',
        'formEndDate',
    );
    return {
        token: getToken(state),
        frontUserSingle: getFrontUserSingle(state),
        accAuthorSingle: getAccountAuthorSingle(state),
        glAuthorContent: getAuthorContent(state),

        formStartDate,
        formEndDate,
    };
};

export default connect(mapStateToProps)(
    translate('translations')(DetailAuthorPersonIdModal)
);
