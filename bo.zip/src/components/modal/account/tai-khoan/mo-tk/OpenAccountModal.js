import React from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { change, Field, formValueSelector, reduxForm } from 'redux-form';

import {
  makeGetAccGroupCus,
  makeGetAccountFrontType,
  makeGetAccountUpdate,
  makeGetCustomerDetail,
  makeGetDepositCode,
  makeGetNationalList,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { formatDate, stringToDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';

import RenderSelectDate from 'components/input/renderDatePicker';
import RenderDepositoryMember from 'components/input/RenderDepositoryMember';
import RenderInput from 'components/input/renderInput';
import RenderNewInput from 'components/input/renderNewInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestProduct from 'components/input/renderSuggestProduct';
import AddKhachHangModal from 'components/modal/customer/thong-tin-kh/AddKhachHangModal';
import RenderNewInputMkt from 'components/input/renderNewInputMkt';
import DetailMarketingId from 'components/modal/detail-pop-up/detailMarketingId';
import {
  accountUpdateRequest,
  accountUpdateSuccess,
} from 'containers/account/actions';
import { BtnDetail } from 'utils/styledComponent';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import {
  makeGetAdvPackage,
  makeGetClientDepositCode,
  makeGetGlComboFee,
  makeGetGlPolicy,
  makeGetSingleUserFront,
} from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validatePhone } from 'utils/validation';
import { accGroupCusRequest, accGroupCusSuccess } from 'containers/account/actions';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length6 = lengthRequired(6);
const length10 = lengthRequired(10);
const appUrl = `${process.env.REACT_APP_API_URL}`;

//#endregion

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};

  // tk phái sinh
  const tkmgErrors = {};

  if (values.dvInternet?.ttkhChkMargin === '1') {
    if (!values.dvInternet?.ttkhMarginNo) tkmgErrors.ttkhMarginNo = 'Required';
    if (!values.dvInternet?.ttkhMarginLimit)
      tkmgErrors.ttkhMarginLimit = 'Required';

    errors.dvInternet = tkmgErrors;
  }

  const tkpsErrors = {};
  if (values.dvDienThoai?.ttkhChkMargin === '1') {
    if (!values.dvDienThoai?.ttkhPsNo) tkpsErrors.ttkhMarginNo = 'Required';

    errors.dvDienThoai = tkpsErrors;
  }

  return errors;
};

function OpenAccountModal(props) {
  const dispatch = useDispatch();
  const [showAddKH, setShowAddKH] = React.useState(false);
  const [nameMember, setNameMember] = React.useState('');
  const abortController = new AbortController();

  const {
    token,
    custDetail,
    formCustCode,
    accountUpdate,
    formFrontType,
    formDepositCode,
    glComboFee,
    glPolicy,
    glAdvPackage,
    singleUserFront,
    _date,
    clDepositCode,
    formMktId,
  } = props;

  const preAccountUpdate = usePrevious(accountUpdate);
  const preCustDetail = usePrevious(custDetail);
  const preFormFrontType = usePrevious(formFrontType);
  const preFormDepositCode = usePrevious(formDepositCode);
  const [detailMarketingId, setDetailMarketingId] = React.useState(null);


  React.useEffect(() => {
    _handleGetMKTDef();
    getListGroupCust();
    initForm();
    return () => {
      dispatch(custDetailSuccess(null));
      dispatch(singleUserFrontSuccess(null));
      dispatch(accGroupCusSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formMktId && formMktId.length === 4) {
      _handleCheckMKT();
    } else {
      dispatch(singleUserFrontSuccess(null));
    }
  }, [formMktId]);

  React.useEffect(() => {
    if (formCustCode && formCustCode.length === 6) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formCustCode]);

  function getListGroupCust() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE: 'GROUP_ACCOUNT',
      },
    };

    dispatch(accGroupCusRequest(params));
  }


  function initForm() {
    dispatch(change('openAccountModalform', 'formFrontType', 'C'));
    dispatch(change('openAccountModalform', 'formDepositCode', clDepositCode));
    dispatch(change('openAccountModalform', 'formGroupCode', 'N'));
    dispatch(
      change(
        'openAccountModalform',
        'formOpenDate',
        formatDate(_date, '/', 'dmy')
      )
    );
    dispatch(
      change(
        'openAccountModalform',
        'formCommPackage',
        glComboFee[0]?.value || ''
      )
    );
    dispatch(change('openAccountModalform', 'chkTaxable', true));
  }

  React.useEffect(() => {
    if (custDetail && !_.isEqual(custDetail, preCustDetail)) {
      dispatch(
        change(
          'openAccountModalform',
          'formAccountCode',
          custDetail?.C_CUSTOMER_CODE + '1'
        )
      );
      dispatch(
        change(
          'openAccountModalform',
          'formPhoneOTP',
          custDetail?.C_CUST_MOBILE
        )
      );
      dispatch(
        change(
          'openAccountModalform',
          'chkTaxable',
          custDetail?.C_CUSTOMER_TYPE === 'CA_NHAN' ? 1 : 0
        )
      );
    }
  }, [custDetail]);

  React.useEffect(() => {
    if (
      custDetail &&
      formFrontType &&
      formDepositCode &&
      (!_.isEqual(custDetail, preCustDetail) ||
        !_.isEqual(formFrontType, preFormFrontType) ||
        !_.isEqual(formDepositCode, preFormDepositCode))
    ) {
      dispatch(
        change(
          'openAccountModalform',
          'formDCTermCode',
          formDepositCode + formFrontType + custDetail?.C_CUSTOMER_CODE
        )
      );
    }
  }, [custDetail, formFrontType, formDepositCode]);

  React.useEffect(() => {
    if (accountUpdate && !_.isEqual(accountUpdate, preAccountUpdate)) {
      _handleToast(t('txt-add-acc-success'), 'success');

      // clear update
      dispatch(accountUpdateSuccess(null));
      onClose();
    }
  }, [accountUpdate]);

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formCustCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleGetMKTDef() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_PARAMETER',
      group: 'LIST',
      data: {
        ITEM_ID: 'MARKETING_ID_DEFAULT',
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        if (res.code > 0 && !!res.data) {
          dispatch(
            change(
              'openAccountModalform',
              'formMktId',
              res.data[0].C_SYSTEM_PARAMETER_VALUE
            )
          );
        } else if (res.re === 'Unauthorized') {
          // logout
          dispatch({ type: 'INVALID_SESSION' });
          onClose();
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function _handleCheckMKT() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-create-new-acc')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        CUSTOMER_CODE: formCustCode,
        ACCOUNT_CODE: props.formAccountCode,
        DCTERM_CODE: props.formDCTermCode,
        DEPOSIT_CODE: props.formDepositCode,
        ACCOUNT_FRONT_TYPE: props.formFrontType,
        GROUP_CODE: props.formGroupCode,
        OPEN_DATE: props.formOpenDate,
        TAX_FLAG: props.chkTaxable ? 1 : 0,
        FATCA_FLAG: props.accountFatca ? 1 : 0,
        //DOCUMENT_FLAG: props.accountDocFlag ? 1 : 0,
        POLICY_CODE: props.formCommPackage,
        PROMOTE_CODE: props.formPolicy,
        MARGIN_FLAG: props.chkMarginAcc ? 1 : 0,
        DE_FLAG: 0,
        CHANNEL_CODE: 'D',
        //TAX_FLAG: custDetail?.C_CUSTOMER_TYPE === 'CA_NHANH' ? 1 : 0,
        DOCUMENT_FLAG: props.chkCompletedFile ? 1 : 0,
        INTERNET_FLG: props?.chkRegisTrading ? 1 : 0,
        PHONE_OTP: props?.formPhoneOTP,
        PRODUCT_CODE: props?.formProduct,
        COMM_PACKAGE: '001',
        MARKETING_ID: props?.formMktId,
      },
    };

    dispatch(accountUpdateRequest(params));
  }

  function _handleAddCallback() {
    setShowAddKH(true);
  }

  function _handleCloseModalAdd(custCode = null) {
    if (custCode && typeof custCode === 'string') {
      dispatch(change('openAccountModalform', 'formCustCode', custCode));
    }

    setShowAddKH(false);
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const {
    handleSubmit,
    submitting,
    onClose,
    t,
    glNational,
    glAccFrontType,
    glDepositCode,

    accGroupCus,
  } = props;

console.log(formCustCode);

function handleDetailMarketingId() {
  if (!formMktId) return;
  setDetailMarketingId(formMktId);
}

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-acc')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustCode"
                    className="form-control input-order"
                    classParent="w-100"
                    component={RenderNewInput}
                    validate={[required, length6]}
                    actionAdd
                    fnAddCallback={_handleAddCallback}
                    status='DA_DUYET'
                    index={4}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label> {t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-nationality')}</Form.Label>
                  <input
                    type={'text'}
                    value={
                      _.find(
                        glNational,
                        (o) => o.value === custDetail?.C_NATIONAL_CODE
                      )?.label || ''
                    }
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_CARD_ID || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_ISSUE_DATE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_EXPIRE_DATE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_ISSUE_PLACE_NAME || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Marketing ID
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <div className="w-100">
                      <Field
                        name="formMktId"
                        className="form-control input-order"
                        classParent="w-100"
                        component={RenderNewInputMkt}
                        validate={[required]}
                        index="3"
                      />
                    </div>
                    <BtnDetail
                      type="button"
                      onClick={() => handleDetailMarketingId()}
                    />
                  </div>
                </Form.Group>
                <Form.Group >
                  <Form.Label>{t('txt-marketing-name')}</Form.Label>
                  <Form.Control
                    value={singleUserFront?.C_FRONT_USER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group >
                  <Form.Label>{t('txt-branch')}</Form.Label>
                  <Form.Control
                    value={(singleUserFront?.C_BRANCH_CODE || '') + ' - ' + (singleUserFront?.C_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group >
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <Form.Control
                    value={(singleUserFront?.C_SUB_BRANCH_CODE || '') + ' - ' + (singleUserFront?.C_SUB_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-acc-type')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFrontType"
                    className="form-control input-order "
                    component={RenderNormalSelect}
                    opts={glAccFrontType}
                    validate={[required]}
                    required
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    {t('txt-depository-member-code')}{' '}*/}
                {/*    <span className="text-danger">*</span>*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formDepositCode"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderDepositoryMember}*/}
                {/*    validate={[required]}*/}
                {/*    //disabled={formFrontType === 'C'}*/}
                {/*    */}
                {/*    disabled={custDetail?.C_CUST_TYPE === 'CA_NHAN_TRONG_NUOC' || ''}*/}
                {/*    required*/}
                {/*    index={2}*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group style={{ gridColumn: '3/5' }}>*/}
                {/*  <Form.Label>{t('txt-depository-member')} </Form.Label>*/}
                {/*  <input*/}
                {/*    type={'text'}*/}
                {/*    value={*/}
                {/*      _.find(glDepositCode, (o) => o.value === formDepositCode)*/}
                {/*        ?.label || ''*/}
                {/*    }*/}
                {/*    className="form-control input-order "*/}
                {/*    disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-group')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formGroupCode"
                    className="form-control input-order "
                    component={RenderNormalSelect}
                    opts={accGroupCus}
                    validate={[required]}
                    required
                    index={2}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-trading-acc-no')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order "
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    {t('txt-acc-depository')}{' '}*/}
                {/*    <span className="text-danger">*</span>*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formDCTermCode"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderInput}*/}
                {/*    validate={[required, length10]}*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group>
                  <Form.Label>{t('txt-open-date')}</Form.Label>
                  <Field
                    name="formOpenDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    {t('txt-fee-combo')} <span className="text-danger">*</span>*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formCommPackage"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={glComboFee}*/}
                {/*    required*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    Gói chính sách*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formPolicy"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={glPolicy}*/}
                {/*    //required*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-regis-service-info')}
                </p>
                {/* <Form.Group className="align-self-center">
                  <label>
                    <Field
                      name="chkCompletedFile"
                      className="mr-2"
                      component="input"
                      type="checkbox"
                    />
                    {t('txt-completed-profile')}
                  </label>
                </Form.Group> */}
                <Form.Group className="align-self-center" style={{ gridColumn: '1/4' }}>
                  <label>
                    <Field
                      name="chkTaxable"
                      className="mr-2"
                      component="input"
                      type="checkbox"
                      //disabled
                    />
                    {t('txt-taxable')}
                  </label>
                </Form.Group>
                {/*<Form.Group*/}
                {/*  className="align-self-center"*/}
                {/*  style={{ gridColumn: '1/2' }}*/}
                {/*>*/}
                {/*  <label>*/}
                {/*    <Field*/}
                {/*      name="chkRegularAcc"*/}
                {/*      className="mr-2"*/}
                {/*      component="input"*/}
                {/*      type="checkbox"*/}
                {/*      checked*/}
                {/*      disabled*/}
                {/*    />*/}
                {/*    {t('txt-acc-regular')}*/}
                {/*  </label>*/}
                {/*</Form.Group>*/}
                {/*<Form.Group className="align-self-center">*/}
                {/*  <label>*/}
                {/*    <Field*/}
                {/*      name="chkMarginAcc"*/}
                {/*      className="mr-2"*/}
                {/*      component="input"*/}
                {/*      type="checkbox"*/}
                {/*      disabled={formFrontType === 'P'}*/}
                {/*    />*/}
                {/*    {t('txt-acc-margin')}*/}
                {/*  </label>*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    {t('txt-prod')}*/}
                {/*    {props.chkMarginAcc && (*/}
                {/*      <span className="text-danger">*</span>*/}
                {/*    )}*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formProduct"*/}
                {/*    className="form-control "*/}
                {/*    classParent="w-100"*/}
                {/*    component={RenderSuggestProduct}*/}
                {/*    validate={props.chkMarginAcc ? required : null}*/}
                {/*    disabled={formFrontType === 'P'}*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-regis-trading')}
                </p>
                <Form.Group className="align-self-center" style={{ gridColumn: '1/2' }}>
                  <label>
                    <Field
                      name="chkRegisTrading"
                      className="mr-2"
                      component="input"
                      type="checkbox"
                    />
                    {t('txt-regis-trading-agree')}
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-phone-receive-otp')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPhoneOTP"
                    className="form-control input-order "
                    component={RenderInput}
                    validate={[validatePhone, required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-contract-phone')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_CUST_MOBILE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailMarketingId && (
        <DetailMarketingId
          id={detailMarketingId}
          onClose={() => setDetailMarketingId(null)}
        />
      )}
      {showAddKH && <AddKhachHangModal onClose={_handleCloseModalAdd} />}
    </ReactModal>
  );
}

OpenAccountModal = reduxForm({
  form: 'openAccountModalform',
  enableReinitialize: true,
  validate,
})(OpenAccountModal);

const selector = formValueSelector('openAccountModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getNationalList = makeGetNationalList();
  const getGlComboFee = makeGetGlComboFee();
  const getGlPolicy = makeGetGlPolicy();
  const getAccountFrontType = makeGetAccountFrontType();
  const getDepositCode = makeGetDepositCode();
  const getAdvPackage = makeGetAdvPackage();

  const getCustomerDetail = makeGetCustomerDetail();
  const getAccountUpdate = makeGetAccountUpdate();
  const getSystemInfo = makeGetSystemInfo();
  const getAccGroupCus = makeGetAccGroupCus();
  const getSingleUserFront = makeGetSingleUserFront();
  const getClientDepositCode = makeGetClientDepositCode();

  const {
    formCustCode,
    formFrontType,
    formDepositCode,
    formGroupCode,
    formAccountCode,
    formDCTermCode,
    formOpenDate,
    formCommPackage,
    formPolicy,
    chkMarginAcc,
    formMktId,

    chkTaxable,
    chkCompletedFile,
    chkRegisTrading,
    formPhoneOTP,
    formProduct,
  } = selector(
    state,
    'formCustCode',
    'formFrontType',
    'formDepositCode',
    'formGroupCode',
    'formAccountCode',
    'formMktId',
    'formDCTermCode',
    'formOpenDate',
    'formCommPackage',
    'formPolicy',
    'chkMarginAcc',

    'chkTaxable',
    'chkCompletedFile',
    'chkRegisTrading',
    'formPhoneOTP',
    'formProduct'
  );

  const sysSystemInfo = getSystemInfo(state);
  const clDepositCode = getClientDepositCode(state);
  const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');

  return {
    token: getToken(state),
    glComboFee: getGlComboFee(state),
    glPolicy: getGlPolicy(state),
    glAccFrontType: getAccountFrontType(state),
    glDepositCode: getDepositCode(state),
    glNational: getNationalList(state),
    accGroupCus: getAccGroupCus(state),
    accountUpdate: getAccountUpdate(state),
    custDetail: getCustomerDetail(state),
    glAdvPackage: getAdvPackage(state),
    singleUserFront: getSingleUserFront(state),
    _date,

    clDepositCode,
    formMktId,

    formCustCode,
    formFrontType,
    formDepositCode,
    formGroupCode,
    formAccountCode,
    formDCTermCode,
    formOpenDate,
    formCommPackage,
    formPolicy,
    chkMarginAcc,

    chkTaxable,
    chkCompletedFile,
    chkRegisTrading,
    formPhoneOTP,
    formProduct,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(OpenAccountModal)
);
