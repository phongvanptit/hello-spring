import * as _ from 'lodash';
import React from 'react';
import { Form } from 'react-bootstrap';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';

import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accountApproveCloseRequest,
  accountApproveCloseSuccess,
  accountUnCloseRequest,
  accountUnCloseSuccess,
  accountApproveRequest,
  accountApproveSuccess,
  accountApproveVSDSuccess,
  accountCloseRequest,
  accountDeleteRequest,
  accountDeleteSuccess,
  accountRevertRequest,
  accountRevertSuccess,
  accountSingleRequest,
  accountSingleSuccess,
  accountUpdateRequest,
  accountUpdateSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import {
  globalExportFileWordRequest,
} from 'containers/report/actions';
import { accGroupCusRequest, accGroupCusSuccess } from 'containers/account/actions';

import {
  makeGetAccGroupCus,
  makeGetAccountApprove,
  makeGetAccountApproveClose,
  makeGetAccountUnClose,
  makeGetAccountDelete,
  makeGetAccountFrontType,
  makeGetAccountRevert,
  makeGetAccountSingle,
  makeGetAccountUpdate,
  makeGetAuthenType,
  makeGetCustomerDetail,
  makeGetDepositCode,
  makeGetGlComboFee,
  makeGetGlPolicy,
  makeGetInternetFunc,
  makeGetLimitedService,
  makeGetNationalList,
  makeGetSystemInfo,
  makeGetToken,
  makeGetSingleUserFront,
} from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { formatDate, stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validatePhone } from 'utils/validation';
import DetailMarketingId from 'components/modal/detail-pop-up/detailMarketingId';
import RenderNewInputMkt from 'components/input/renderNewInputMkt';
import { required } from 'utils/validation';
import { BtnDetail } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};


const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailAccountModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    custDetail,
    formCustCode,
    accountCode,
    accountDelete,
    accountApprove,
    accountRevert,
    singleAccount,
    accRight,
    accountApproveClose,
    accountUnClose,
    glPolicy,
    formMktId,
    singleUserFront,
    formFrontType
  } = props;

  function handleDetailMarketingId() {
    if (!formMktId) return;
    setDetailMarketingId(formMktId);
  }

  const preAccountDelete = usePrevious(accountDelete);
  const preAccountApprove = usePrevious(accountApprove);
  const preAccountRevert = usePrevious(accountRevert);
  const preAccountApproveClose = usePrevious(accountApproveClose);
  const preAccountUnClose = usePrevious(accountUnClose);
  const preSingleAccount = usePrevious(singleAccount);
  const [detailMarketingId, setDetailMarketingId] = React.useState(null);

  React.useEffect(() => {
    if (accountCode) {
      handleGetSingleAccount();
      getListGroupCust();
    }

    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(accountApproveSuccess(null));
      dispatch(accountDeleteSuccess(null));
      dispatch(accountApproveVSDSuccess(null));
      dispatch(accountUpdateSuccess(null));
      dispatch(accGroupCusSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formCustCode) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formCustCode]);

  React.useEffect(() => {
    if (accountDelete && !_.isEqual(accountDelete, preAccountDelete)) {
      handleGetSingleAccount();
      onClose();
    }
  }, [accountDelete]);

  React.useEffect(() => {
    if (singleAccount && !_.isEqual(singleAccount, preSingleAccount)) {
      initForm();
    }
  }, [singleAccount]);

  React.useEffect(() => {
    if (formMktId && formMktId.length === 4) {
      _handleCheckMKT();
    } else {
      dispatch(singleUserFrontSuccess(null));
    }
  }, [formMktId]);

  React.useEffect(() => {
    if (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) {
      handleGetSingleAccount();
      onClose();
    }
  }, [accountApprove]);

  function getListGroupCust() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE: 'GROUP_ACCOUNT',
      },
    };

    dispatch(accGroupCusRequest(params));
  }


  function initForm() {
    dispatch(
      change(
        'detailAccountModalform',
        'formCustCode',
        singleAccount?.C_CUSTOMER_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formFrontType',
        singleAccount?.C_ACCOUNT_FRONT_TYPE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formDepositCode',
        singleAccount?.C_DEPOSIT_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formGroupCode',
        singleAccount?.C_GROUP_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formAccountCode',
        singleAccount?.C_ACCOUNT_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formDCTermCode',
        singleAccount?.C_DCTERM_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formOpenDate',
        singleAccount?.C_OPEN_DATE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formCommPackage',
        singleAccount?.C_POLICY_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formPolicy',
        singleAccount?.C_PROMOTE_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'chkMarginAcc',
        singleAccount?.C_MG_FLAG === 1
      )
    );

    dispatch(
      change(
        'detailAccountModalform',
        'chkTaxable',
        singleAccount?.C_TAX_FLAG === 1
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'chkCompletedFile',
        singleAccount?.C_DOCUMENT_FLAG === 1
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'chkRegisTrading',
        singleAccount?.C_INTERNET_FLAG === 1
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formPhoneOTP',
        singleAccount?.C_PHONE_NUMBER || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formProduct',
        singleAccount?.C_PRODUCT_CODE || ''
      )
    );
    dispatch(
      change(
        'detailAccountModalform',
        'formMktId',
        singleAccount?.C_MARKETING_ID || ''
      )
    );
  }

  React.useEffect(() => {
    if (
      accountApproveClose &&
      !_.isEqual(accountApproveClose, preAccountApproveClose)
    ) {
      _handleToast(`${t('txt-appr-close-acc-success')}`, 'success');
      handleGetSingleAccount();
      // clear update
      dispatch(accountApproveCloseSuccess(null));
    }
  }, [accountApproveClose]);

  React.useEffect(() => {
    if (
      accountUnClose &&
      !_.isEqual(accountUnClose, preAccountUnClose)
    ) {
      _handleToast(`Hủy đóng tài khoản thành công`, 'success');
      handleGetSingleAccount();
      // clear update
      dispatch(accountUnCloseSuccess(null));
    }
  }, [accountUnClose]);

  React.useEffect(() => {
    if (accountRevert && !_.isEqual(accountRevert, preAccountRevert)) {
      _handleToast(`${t('txt-revert-acc-success')}`, 'success');
      handleGetSingleAccount();
      // clear update
      dispatch(accountRevertSuccess(null));
    }
  }, [accountRevert]);

  function submit(values) {}

  function handleGetSingleAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: accountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckMKT() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }
  
  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formCustCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-acc')
                : actionName === 'close'
                ? t('txt-close-acc')
                : actionName === 'approve'
                ? t('txt-appr-acc')
                : actionName === 'revert'
                ? t('txt-revert-acc')
                : actionName === 'appr-close'
                ? t('txt-appr-close-acc')
                : actionName === 'un-close'
                ? 'Bạn muốn hủy đóng tài khoản?'
                : actionName === 'confirm'
                ? t('txt-upd-contract')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'close':
                    handleActionClose();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'revert':
                    handleActionRevert();
                    break;
                  case 'appr-close':
                    handleActionApprClose();
                    break;
                  case 'un-close':
                    handleActionUnClose();
                    break;
                  case 'confirm':
                    handleActionConfirm();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
      },
    };

    dispatch(accountDeleteRequest(params));
  }

  function handleActionClose() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.CLOSE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
      },
    };

    dispatch(accountCloseRequest(params));
  }

  function handleActionApprClose() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APR_CLOSE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
      },
    };

    dispatch(accountApproveCloseRequest(params));
  }

  function handleActionUnClose() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UN_CLOSE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
      },
    };

    dispatch(accountUnCloseRequest(params));
  }

  function handleActionConfirm() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT',
      group: 'LIST',
      data: {
        ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
        CUSTOMER_CODE: formCustCode,
        ACCOUNT_CODE: props.formAccountCode,
        DCTERM_CODE: props.formDCTermCode,
        DEPOSIT_CODE: props.formDepositCode,
        ACCOUNT_FRONT_TYPE: props.formFrontType,
        GROUP_CODE: props.formGroupCode,
        OPEN_DATE: props.formOpenDate,
        TAX_FLAG: props.chkTaxable ? 1 : 0,
        FATCA_FLAG: props.accountFatca ? 1 : 0,
        //DOCUMENT_FLAG: props.accountDocFlag ? 1 : 0,
        POLICY_CODE: props.formCommPackage,
        PROMOTE_CODE: props.formPolicy,
        MARGIN_FLAG: props.chkMarginAcc ? 1 : 0,
        DE_FLAG: 0,
        CHANNEL_CODE: 'D',
        //TAX_FLAG: custDetail?.C_CUSTOMER_TYPE === 'CA_NHANH' ? 1 : 0,
        DOCUMENT_FLAG: props.chkCompletedFile ? 1 : 0,
        INTERNET_FLG: props?.chkRegisTrading ? 1 : 0,
        PHONE_OTP: props?.formPhoneOTP,
        PRODUCT_CODE: props?.formProduct,
        MARKETING_ID: props?.formMktId,
        //COMM_PACKAGE: '001',
      },
    };

    dispatch(accountUpdateRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
      },
    };

    dispatch(accountApproveRequest(params));
  }

  function handleActionRevert() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REVERT_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: singleAccount?.PK_BACK_ACCOUNT,
      },
    };

    dispatch(accountRevertRequest(params));
  }

  function handlePrinter() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: accountCode,
      },
    };
    params.data.TEMPLATE_CODE = 'HD_MO_TAI_KHOAN';
    dispatch(globalExportFileWordRequest(params));
  }

  const {
    handleSubmit,
    onClose,
    t,
    glNational,
    glComboFee,
    glAccFrontType,
    glDepositCode,

    accGroupCus,
  } = props;

  function handleDetailMarketingId() {
    if (!formMktId) return;
    setDetailMarketingId(formMktId);
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-acc-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustCode"
                    className="form-control input-order"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-nationality')}</Form.Label>
                  <input
                    type={'text'}
                    value={
                      _.find(
                        glNational,
                        (o) => o.value === custDetail?.C_NATIONAL_CODE
                      )?.label || ''
                    }
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_CARD_ID || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_ISSUE_DATE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_EXPIRE_DATE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_ISSUE_PLACE_NAME || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Marketing ID
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <div className="w-100">
                      <Field
                        name="formMktId"
                        className="form-control input-order"
                        classParent="w-100"
                        component={RenderNewInputMkt}
                        validate={[required]}
                        disabled
                      />
                    </div>
                    <BtnDetail
                      type="button"
                      onClick={() => handleDetailMarketingId()}
                    />
                  </div>
                </Form.Group>
                <Form.Group >
                  <Form.Label>{t('txt-marketing-name')}</Form.Label>
                  <Form.Control
                    value={singleUserFront?.C_FRONT_USER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group >
                  <Form.Label>{t('txt-branch')}</Form.Label>
                  <Form.Control
                    value={(singleUserFront?.C_BRANCH_CODE || '') + ' - ' + (singleUserFront?.C_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group >
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <Form.Control
                    value={(singleUserFront?.C_SUB_BRANCH_CODE || '') + ' - ' + (singleUserFront?.C_SUB_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-type')}</Form.Label>
                  <Field
                    name="formFrontType"
                    className="form-control input-order "
                    component={RenderNormalSelect}
                    opts={glAccFrontType}
                    //disabled
                  />
                </Form.Group>
                {/*<Form.Group style={{ gridColumn: '2/5' }}>*/}
                {/*  <Form.Label>{t('txt-depository-member')}</Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formDepositCode"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={glDepositCode}*/}
                {/*    disabled={formFrontType === 'C'}*/}
                {/*    //disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group>
                  <Form.Label>{t('txt-cust-group')}</Form.Label>
                  <Field
                    name="formGroupCode"
                    className="form-control input-order "
                    component={RenderNormalSelect}
                    opts={accGroupCus}
                    //disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-trading-acc-no')} </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order "
                    component={RenderInput}
                    //disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-acc-depository')} </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formDCTermCode"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderInput}*/}
                {/*    //disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group>
                  <Form.Label>{t('txt-open-date')}</Form.Label>
                  <Field
                    name="formOpenDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-fee-combo')}</Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formCommPackage"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={glComboFee}*/}
                {/*    //disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    Gói chính sách*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formPolicy"*/}
                {/*    className="form-control input-order "*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={glPolicy}*/}
                {/*    //required*/}
                {/*  />*/}
                {/*</Form.Group>*/}

                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-regis-service-info')}
                </p>
                {/* <Form.Group className="align-self-center">
                  <label>
                    <Field
                      name="chkCompletedFile"
                      className="mr-2"
                      component="input"
                      type="checkbox"
                      disabled
                    />
                    {t('txt-completed-profile')}
                  </label>
                </Form.Group> */}
                <Form.Group className="align-self-center" style={{ gridColumn: '1/4' }}>
                  <label>
                    <Field
                      name="chkTaxable"
                      className="mr-2"
                      component="input"
                      type="checkbox"
                      //disabled
                    />
                    {t('txt-taxable')}
                  </label>
                </Form.Group>
                {/*<Form.Group*/}
                {/*  className="align-self-center"*/}
                {/*  style={{ gridColumn: '1/2' }}*/}
                {/*>*/}
                {/*  <label>*/}
                {/*    <Field*/}
                {/*      name="chkRegularAcc"*/}
                {/*      className="mr-2"*/}
                {/*      component="input"*/}
                {/*      type="checkbox"*/}
                {/*      checked*/}
                {/*      disabled*/}
                {/*    />*/}
                {/*    {t('txt-acc-regular')}*/}
                {/*  </label>*/}
                {/*</Form.Group>*/}
                {/*<Form.Group className="align-self-center">*/}
                {/*  <label>*/}
                {/*    <Field*/}
                {/*      name="chkMarginAcc"*/}
                {/*      className="mr-2"*/}
                {/*      component="input"*/}
                {/*      type="checkbox"*/}
                {/*      disabled*/}
                {/*    />*/}
                {/*    {t('txt-acc-margin')}*/}
                {/*  </label>*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    {t('txt-prod')}*/}
                {/*    {props.chkMarginAcc && (*/}
                {/*      <span className="text-danger">*</span>*/}
                {/*    )}*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formProduct"*/}
                {/*    className="form-control "*/}
                {/*    classParent="w-100"*/}
                {/*    component="input"*/}
                {/*    disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-regis-trading')}
                </p>
                <Form.Group className="align-self-center" style={{ gridColumn: '1/2' }}>
                  <label>
                    <Field
                      name="chkRegisTrading"
                      className="mr-2"
                      component="input"
                      type="checkbox"
                      //disabled
                    />
                    {t('txt-regis-trading-agree')}
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-phone-receive-otp')}</Form.Label>
                  <Field
                    name="formPhoneOTP"
                    className="form-control input-order "
                    component={RenderInput}
                    validate={[validatePhone]}
                    //disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-contract-phone')}</Form.Label>
                  <input
                    type={'text'}
                    value={custDetail?.C_CUST_MOBILE || ''}
                    className="form-control input-order "
                    disabled
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                 <BtnSubmit
                      type="button"
                      onClick={handlePrinter}
                      className="w_125 success"
                    >
                      {t('lab-print-contact')}
                    </BtnSubmit>
                {accRight?.C_UPDATE === 1 &&
                  singleAccount?.C_STATUS === 'CHUA_DUYET' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="w_125 ml-2 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                  )}
                {accRight?.C_APPROVE === 1 &&
                  singleAccount?.C_STATUS === 'CHUA_DUYET' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('approve')}
                      className="ml-2 success"
                    >
                      {t('txt-appr')}
                    </BtnSubmit>
                  )}
                {accRight?.C_UPDATE === 1 &&
                  singleAccount?.C_STATUS === 'DA_DONG' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('revert')}
                      className="w_125 ml-2 info"
                    >
                      {t('txt-revert-account')}
                    </BtnSubmit>
                  )}
                {accRight?.C_APPROVE === 1 &&
                  singleAccount?.C_STATUS === 'CHO_DONG' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('un-close')}
                      className="w_125 ml-2 danger"
                    >
                      Hủy đóng
                    </BtnSubmit>
                  )}
                {accRight?.C_APPROVE === 1 &&
                  singleAccount?.C_STATUS === 'CHO_DONG' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('appr-close')}
                      className="w_125 ml-2 info"
                    >
                      {t('txt-appr-close-account')}
                    </BtnSubmit>
                  )}
                {accRight?.C_UPDATE === 1 &&
                  singleAccount?.C_STATUS === 'CHUA_DUYET' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('confirm')}
                      className="w_125 ml-2"
                    >
                      {t('txt-edit')}
                    </BtnSubmit>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailMarketingId && (
        <DetailMarketingId
          id={detailMarketingId}
          onClose={() => setDetailMarketingId(null)}
        />
      )}
    </ReactModal>
  );
}

DetailAccountModal = reduxForm({
  form: 'detailAccountModalform',
  enableReinitialize: true,
})(DetailAccountModal);

const selector = formValueSelector('detailAccountModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getNationalList = makeGetNationalList();
  const getGlComboFee = makeGetGlComboFee();
  const getAccountFrontType = makeGetAccountFrontType();
  const getDepositCode = makeGetDepositCode();
  const getAuthenType = makeGetAuthenType();
  const getInternetFunc = makeGetInternetFunc();
  const getLimitedService = makeGetLimitedService();

  const getCustomerDetail = makeGetCustomerDetail();
  const getAccountUpdate = makeGetAccountUpdate();

  const getAccountSingle = makeGetAccountSingle();

  const getAccountApprove = makeGetAccountApprove();
  const getAccountRevert = makeGetAccountRevert();
  const getAccountDelete = makeGetAccountDelete();
  const getSystemInfo = makeGetSystemInfo();
  const getAccGroupCus = makeGetAccGroupCus();
  const getAccountApproveClose = makeGetAccountApproveClose();
  const getAccountUnClose = makeGetAccountUnClose();
  const getSingleUserFront = makeGetSingleUserFront();
  const getGlPolicy = makeGetGlPolicy();

  const {
    formCustCode,
    formFrontType,
    formDepositCode,
    formGroupCode,
    formAccountCode,
    formDCTermCode,
    formOpenDate,
    formCommPackage,
    formPolicy,
    chkMarginAcc,
    formMktId,

    chkTaxable,
    chkCompletedFile,
    chkRegisTrading,
    formPhoneOTP,
    formProduct,
  } = selector(
    state,
    'formCustCode',
    'formFrontType',
    'formDepositCode',
    'formGroupCode',
    'formAccountCode',
    'formDCTermCode',
    'formOpenDate',
    'formCommPackage',
    'formPolicy',

    'chkMarginAcc',

    'chkTaxable',
    'chkCompletedFile',
    'chkRegisTrading',
    'formPhoneOTP',
    'formProduct',
    'formMktId',
  );

  const singleAccount = getAccountSingle(state);
  const sysSystemInfo = getSystemInfo(state);
  const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');

  return {
    token: getToken(state),
    glComboFee: getGlComboFee(state),
    glAccFrontType: getAccountFrontType(state),
    glDepositCode: getDepositCode(state),
    glNational: getNationalList(state),
    glAuthenType: getAuthenType(state),
    glInternetFunc: getInternetFunc(state),
    glLimitedService: getLimitedService(state),
    glPolicy: getGlPolicy(state),
    accGroupCus: getAccGroupCus(state),
    accountUpdate: getAccountUpdate(state),
    custDetail: getCustomerDetail(state),
    accountDelete: getAccountDelete(state),
    accountApprove: getAccountApprove(state),
    accountRevert: getAccountRevert(state),
    accountApproveClose: getAccountApproveClose(state),
    accountUnClose: getAccountUnClose(state),
    singleUserFront: getSingleUserFront(state),
    singleAccount,
    _date,
    formCustCode,
    formFrontType,
    formDepositCode,
    formGroupCode,
    formAccountCode,
    formDCTermCode,
    formOpenDate,
    formCommPackage,
    formPolicy,
    chkMarginAcc,

    chkTaxable,
    chkCompletedFile,
    chkRegisTrading,
    formPhoneOTP,
    formProduct,
    formMktId
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailAccountModal)
);
