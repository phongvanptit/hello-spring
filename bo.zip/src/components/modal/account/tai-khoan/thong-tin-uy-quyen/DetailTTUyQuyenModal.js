import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, FormSection, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import { Form, Button } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { formatDate } from 'utils';
import { required, validateFT } from 'utils/validation';
import { _diff2Date } from 'utils';
import {
  accAuthorApproveRequest,
  accAuthorDelRequest,
  accountAuthorSingleRequest,
  accountAuthorSingleSuccess,
  accountAuthorUpdRequest,
  accountAuthorUpdSuccess,
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';

import {
  makeGetAccountAuthorApprove,
  makeGetAccountAuthorDelete,
  makeGetAccountAuthorSingle,
  makeGetAccountAuthorUpd,
  makeGetAccountSingle,
  makeGetAuthorContent,
  makeGetAuthorType,
  makeGetCustomerDetail,
  makeGetToken,
} from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderFileInput from 'components/input/renderFileInput';
import RenderInput from 'components/input/renderInput';
import renderNewInput from 'components/input/renderNewInput';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit, TabsSectionHeader } from 'utils/styledComponent';
import RenderAuthorContent from './layout/renderAuthorContent';
ReactModal.setAppElement('#root');
const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 475px )',
    height: 'auto',
    width: '950px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
        font-size: 13px;
    }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
const tmp = validateFT(formatDate(new Date(), '/', 'dmy'))
const fileUrl = `${process.env.REACT_APP_FILE_URL}/upload`;

function ThongTinUyQuyen(props) {
  const { data, t, accAuthorSingle } = props;

  return (
    <>
      <Form.Group>
        <Form.Label>
          {t('txt-from-date')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          className="form-control"
          classParentName="w-100"
          name="ttuqStartDate"
          startDate={formatDate(new Date(), '/', 'dmy')}
          component={RenderSelectDate}
          validate={[required]}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-to-date')}</Form.Label>
        <Field
          className="form-control"
          classParentName="w-100"
          name="ttuqEndDate"
          // startDate={formatDate(new Date(), '/', 'dmy')}
          component={RenderSelectDate}
          validate={tmp}
        />
      </Form.Group>
      <Form.Group style={{ gridColumn: '3/5' }} className="d-grid">
        <Form.Label>{t('txt-acc-holder-right')}</Form.Label>
        <Form.Label>
          <Field
            name="ttuqChkGrand"
            component={'input'}
            type="checkbox"
            className="mr-2"
          />
          {t('txt-perform-author')}
        </Form.Label>
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-author-letter')}</Form.Label>
        <Form.Label>
          <Field
            name="ttuqChkNotary"
            component={'input'}
            type="checkbox"
            className="mr-2"
          />
          {t('txt-notarized')}
        </Form.Label>
      </Form.Group>
      <Form.Group>
        <Form.Label>
          {t('txt-author-date')}
          <span className="text-danger">*</span>
        </Form.Label>
        <Field
          className="form-control"
          classParentName="w-100"
          name="ttuqNotarialAuthorDate"
          startDate={formatDate(new Date(), '/', 'dmy')}
          component={RenderSelectDate}
          validate={[required]}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-author-no')}</Form.Label>
        <Field
          name="ttuqNotarialAuthorNo"
          className="form-control input-order fz-13"
          component={RenderInput}
          validate={data?.chkNotary ? required : null}
        />
      </Form.Group>
      <Form.Group className="d-grid" style={{ gridColumn: '1/2' }}>
        <Form.Label>
          {t('txt-author-file')}
          {/* <span className="text-danger">*</span> */}
        </Form.Label>
        <Field
          name="formFile"
          className="fz-13"
          type="file"
          accept=".jpg, .png, .jpeg, .pdf"
          component={RenderFileInput}
          //validate={[required]}
        />
      </Form.Group>

      <Form.Group className="d-flex mt-4">
        {accAuthorSingle && accAuthorSingle?.C_FILE_NAME && (
          <Button
            className=""
            style={{
              width: '60px',
              height: '30px',
              fontSize: '0.8rem',
            }}
          >
            <a
              href={accAuthorSingle?.C_FILE_NAME || ''}
              target="_blank"
              style={{
                color: '#fff',
              }}
            >
              Tải File
            </a>
          </Button>
        )}
      </Form.Group>

      <Form.Group className="d-grid" style={{ gridColumn: '1/5' }}>
        <Form.Label>{t('txt-status')}</Form.Label>
        <Form.Label>
          <Field
            name="gcActive"
            component={'input'}
            type="checkbox"
            className="mr-2"
          />
          {t('txt-active')}
        </Form.Label>
      </Form.Group>
    </>
  );
}

function NoiDungUyQuyen(props) {
  const { glAuthorContent } = props;
  return (
    <>
      <Field
        name="nduqFunc"
        component={RenderAuthorContent}
        validate={[required]}
        glAuthorContent={glAuthorContent}
      />
    </>
  );
}

function GhiChuUyQuyen(props) {
  const { t } = props;
  return (
    <>
      <Form.Group style={{ gridColumn: '1/5' }}>
        <Form.Label>{t('txt-note')}</Form.Label>
        <Field
          className="form-control"
          name="gcNote"
          rows={2}
          component={RenderArea}
        />
      </Form.Group>

      <Form.Group>
        <Form.Label>{t('txt-cancel-author')}</Form.Label>
        <Field
          name={'gcCloser'}
          type="text"
          className="form-control"
          component={RenderInput}
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-approver')}</Form.Label>
        <Field
          name={'gcEditorCode'}
          type="text"
          className="form-control"
          component={RenderInput}
          disabled
        />
      </Form.Group>
      <Form.Group>
        <Form.Label>{t('txt-creator')}</Form.Label>
        <Field
          name={'gcCreatorCode'}
          type="text"
          className="form-control"
          component={RenderInput}
          disabled
        />
      </Form.Group>
    </>
  );
}

function DetailTTUyQuyenModal(props) {
  const dispatch = useDispatch();
  const [tabActive, setTabActive] = React.useState('THONG_TIN_UY_QUYEN');
  const [isLoading, setIsLoading] = React.useState(false);
  const abortController = new AbortController();
  const [validateCom,setValidateCom] = React.useState();
  const {
    token,
    custDetail,
    glAuthorContent,
    glAuthorType,
    thongtinuyquyen,
    id,
    accRight,
    accountCode,

    accAuthorUpd,
    accAuthorSingle,
    accAuthorDel,
    accAuthorAppr,
    custCode,
  } = props;

  const preAccAuthorUpd = usePrevious(accAuthorUpd);
  const preAccAuthorDel = usePrevious(accAuthorDel);
  const preAccAuthorAppr = usePrevious(accAuthorAppr);
  const preToDate = usePrevious(thongtinuyquyen?.ttuqEndDate);
  const preFromDate = usePrevious(thongtinuyquyen?.ttuqStartDate);

  React.useEffect(() => {
    if (id) {
      getSingleAuthor();
    }

    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(accountAuthorSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (accountCode && accountCode.length === 7) {
      // load account info
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [accountCode]);

  React.useEffect(() => {
    if (custCode && custCode.length === 6) {
      // load customer info
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [custCode]);

  React.useEffect(() => {
    if (accAuthorUpd && !_.isEqual(accAuthorUpd, preAccAuthorUpd)) {
      _handleToast(`${t('txt-upd-author-info-success')}`, 'success');
      getSingleAuthor();
      // clear update
      dispatch(accountAuthorUpdSuccess(null));
    }
  }, [accAuthorUpd]);

  React.useEffect(() => {
    if (accAuthorAppr && !_.isEqual(accAuthorAppr, preAccAuthorAppr)) {
      getSingleAuthor();
    }
  }, [accAuthorAppr]);

  React.useEffect(() => {
    if (accAuthorDel && !_.isEqual(accAuthorDel, preAccAuthorDel)) {
      onClose();
    }
  }, [accAuthorDel]);

  function submit(values) {
    if (
      !values.noidunguyquyen.nduqFunc ||
      !values.noidunguyquyen.nduqFunc.length
    ) {
      _handleToast(`${t('txt-select-authorization-content')}`, 'error');
      return;
    }
    // const params = {
    //   user: token?.USER_NAME,
    //   session: token?.SESSION_ID,
    //   cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_AUTHOR',
    //   group: 'LIST',
    //   data: {
    //     ID: accAuthorSingle?.PK_ACCOUNT_AUTHOR,
    //     AUTHOR_TYPE: values.authorType,
    //     ACCOUNT_CODE: values.accountCode,
    //     CUSTOMER_CODE: values.custCode,
    //     EFFECT_DATE: values.thongtinuyquyen.ttuqStartDate,
    //     EXPIRE_DATE: values.thongtinuyquyen.ttuqEndDate,
    //     NOTARIAL_FLAG: values.thongtinuyquyen.ttuqChkNotary ? 1 : 0,
    //     NOTARIAL_AUTHOR_NO: values.thongtinuyquyen.ttuqNotarialAuthorNo,
    //     NOTARIAL_AUTHOR_DATE: values.thongtinuyquyen.ttuqNotarialAuthorDate,
    //     GRAND_ACCOUNT: values.thongtinuyquyen.ttuqChkGrand ? 1 : 0,
    //     RELATION: values.authorRelation,
    //     CLOSER: values.ghichu.gcCloser,
    //     ACTIVE: values.thongtinuyquyen.gcActive ? 1 : 0,
    //     CONTENT: values.ghichu.gcNote,
    //     FUNC: values.noidunguyquyen.nduqFunc,
    //     FILE_AUTHOR: _filePaths,
    //   },
    // };
    // dispatch(accountAuthorUpdRequest(params));x

    setIsLoading(true);
    if (values.thongtinuyquyen.ttuqFile) {
      handleUploadAnh(values, values.thongtinuyquyen.ttuqFile);
    } else {
      handleNextProcess(values, null);
    }
  }

  function handleNextProcess(values, _filePaths) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ID: id,
        AUTHOR_TYPE: values.authorType,
        ACCOUNT_CODE: values.accountCode,
        CUSTOMER_CODE: values.custCode,
        EFFECT_DATE: values.thongtinuyquyen.ttuqStartDate,
        EXPIRE_DATE: values.thongtinuyquyen.ttuqEndDate || '31/12/9999',
        NOTARIAL_FLAG: values.thongtinuyquyen.ttuqChkNotary ? 1 : 0,
        NOTARIAL_AUTHOR_NO: values.thongtinuyquyen.ttuqNotarialAuthorNo,
        NOTARIAL_AUTHOR_DATE: values.thongtinuyquyen.ttuqNotarialAuthorDate,
        GRAND_ACCOUNT: values.thongtinuyquyen.ttuqChkGrand ? 1 : 0,
        RELATION: values.authorRelation,
        CLOSER: values.ghichu.gcCloser,
        ACTIVE: values.thongtinuyquyen.gcActive ? 1 : 0,
        CONTENT: values.ghichu.gcNote,
        FUNC: values.noidunguyquyen.nduqFunc,
        FILE_AUTHOR: _filePaths,
      },
    };

    dispatch(accountAuthorUpdRequest(params));
    setIsLoading(false);
  }

  function handleUploadAnh(values, file) {
    fileUpload(file).then((response) => {
      if (response.code > 0) {
        const _filePaths = response.FILE_DIR;
        handleNextProcess(values, _filePaths);
      } else {
        _handleToast(response.re);
      }
    });
  }

  function fileUpload(file) {
    const formData = new FormData();
    formData.append('file', file);
    const request = fetch(fileUrl, {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    return request
      .then((response) => response.json())
      .then((json) => json)
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
  }

  function getSingleAuthor() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(accountAuthorSingleRequest(params));
  }

  function _handleAddCallback() {}

  function _handleCheckAccount(_accCode) {
    if (!_accCode && !accountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: _accCode || accountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: custCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-author-info')
                : actionName === 'approve'
                  ? t('txt-appr-author-info')
                  : ''}
            </p>

            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ID: accAuthorSingle?.PK_ACCOUNT_AUTHOR,
      },
    };

    dispatch(accAuthorDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_SINGLE_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ID: accAuthorSingle?.PK_ACCOUNT_AUTHOR,
      },
    };

    dispatch(accAuthorApproveRequest(params));
  }

  const {
    handleSubmit,
    submitting,
    pristine,
    onClose,
    t,
    accDetail,

    //thongtinuyquyen,
  } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-author')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-author')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="accountCode"
                    className="form-control input-order"
                    classParent="w-100"
                    component={renderNewInputAccount}
                    validate={[required]}
                    fnAddCallback={_handleAddCallback}
                    index={2}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    value={accDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-cust-code')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUSTOMER_CODE || ''}
                    disabled
                  />
                </Form.Group>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-authorized')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="custCode"
                    className="form-control input-order"
                    classParent="w-100"
                    component={renderNewInput}
                    validate={[required]}
                    fnAddCallback={_handleAddCallback}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-full-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_CARD_ID || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_ISSUE_DATE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_EXPIRE_DATE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_ISSUE_PLACE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-relationship-acc')} </Form.Label>
                  <Field
                    name="authorRelation"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group style={{ display: 'none' }}>
                  <Form.Label>{t('txt-author-type')}</Form.Label>
                  <Field
                    name="authorType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glAuthorType}
                    validate={[required]}
                    required
                  />
                </Form.Group>

                {/* TODO: Tabs Section  */}
                <TabsSectionHeader style={{ gridColumn: '1/5' }}>
                  <ul style={{ backgroundColor: 'rgba(28, 28, 28, 0.12)'}}>
                    <li
                      onClick={() => setTabActive('THONG_TIN_UY_QUYEN')}
                      className={
                        tabActive === 'THONG_TIN_UY_QUYEN' ? 'active' : ''
                      }
                    >
                      {t('txt-author-info')}
                    </li>
                    <li
                      //style={{ backgroundColor: 'rgba(28, 28, 28, 0.12)'}}
                      onClick={() => setTabActive('NOI_DUNG_UY_QUYEN')}
                      className={
                        tabActive === 'NOI_DUNG_UY_QUYEN' ? 'active' : ''
                      }
                    >
                      {t('txt-author-content')}
                    </li>
                    <li
                      //style={{ backgroundColor: 'rgba(28, 28, 28, 0.5)'}}
                      onClick={() => setTabActive('GHI_CHU')}
                      className={tabActive === 'GHI_CHU' ? 'active' : ''}
                    >
                      {t('txt-note')}
                    </li>
                  </ul>
                </TabsSectionHeader>
                {tabActive === 'THONG_TIN_UY_QUYEN' && (
                  <FormSection name="thongtinuyquyen">
                    <ThongTinUyQuyen
                      t={t}
                      data={thongtinuyquyen}
                      accAuthorSingle={accAuthorSingle}
                      validateCom={validateCom}
                    />
                  </FormSection>
                )}
                {tabActive === 'NOI_DUNG_UY_QUYEN' && (
                  <FormSection name="noidunguyquyen">
                    <NoiDungUyQuyen glAuthorContent={glAuthorContent} />
                  </FormSection>
                )}
                {tabActive === 'GHI_CHU' && (
                  <FormSection name="ghichu">
                    <GhiChuUyQuyen t={t} />
                  </FormSection>
                )}
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>

              <div className="d-flex">
                {/* <BtnSubmit type="submit" disabled={submitting}>
                    Xác nhận
                  </BtnSubmit> */}
                {accAuthorSingle?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    {accRight?.C_UPDATE === 1 && accAuthorSingle?.C_APPROVER_CODE === '' && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 danger"
                      >
                        {t('txt-del')}
                      </BtnSubmit>
                    )}
                    {accRight?.C_APPROVE === 1 && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('approve')}
                        className="w_125 ml-2 success"
                      >
                        {t('txt-appr')}
                      </BtnSubmit>
                    )}
                  </>
                )}
                {
                  <>
                    {accRight?.C_UPDATE === 1 && (
                      <BtnSubmit
                        type="submit"
                        disabled={pristine || submitting}
                        className="w_125 ml-2"
                      >
                        {t('txt-edit')}
                      </BtnSubmit>
                    )}
                  </>
                }
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailTTUyQuyenModal = reduxForm({
  form: 'detailTTUyQuyenModalform',
  enableReinitialize: true,
})(DetailTTUyQuyenModal);

const selector = formValueSelector('detailTTUyQuyenModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCustomerDetail = makeGetCustomerDetail();
  const getAuthorType = makeGetAuthorType();
  const getAuthorContent = makeGetAuthorContent();
  const getAccountAuthorUpd = makeGetAccountAuthorUpd();
  const getAccountAuthorDelete = makeGetAccountAuthorDelete();
  const getAccountAuthorApprove = makeGetAccountAuthorApprove();
  const getAccountAuthorSingle = makeGetAccountAuthorSingle();

  const {
    accountCode,
    custCode,
    authorRelation,
    authorType,
    formNotarialAuthorDate,
    formNotarialAuthorNo,

    thongtinuyquyen,
    noidunguyquyen,
    ghichu,
  } = selector(
    state,
    'accountCode',
    'custCode',
    'authorRelation',
    'authorType',
    'formNotarialAuthorDate',
    'formNotarialAuthorNo',

    'thongtinuyquyen',
    'noidunguyquyen',
    'ghichu'
  );

  const accAuthorSingle = getAccountAuthorSingle(state);
  const token = getToken(state);

  return {
    token,
    accDetail: getAccountSingle(state),
    custDetail: getCustomerDetail(state),
    glAuthorType: getAuthorType(state),
    glAuthorContent: getAuthorContent(state),
    accAuthorUpd: getAccountAuthorUpd(state),
    accAuthorDel: getAccountAuthorDelete(state),
    accAuthorAppr: getAccountAuthorApprove(state),
    accAuthorSingle,

    accountCode,
    custCode,
    authorRelation,
    authorType,
    formNotarialAuthorDate,
    formNotarialAuthorNo,

    thongtinuyquyen,
    noidunguyquyen,
    ghichu,

    initialValues: {
      accountCode: accAuthorSingle?.C_ACCOUNT_CODE,
      custCode: accAuthorSingle?.C_CUSTOMER_CODE,
      authorRelation: accAuthorSingle?.C_RELATION,
      authorType: accAuthorSingle?.C_AUTHOR_TYPE,

      thongtinuyquyen: {
        ttuqStartDate: accAuthorSingle?.C_EFFECT_DATE
          ? accAuthorSingle?.C_EFFECT_DATE.split(' ')[0]
          : null,
        ttuqEndDate: accAuthorSingle?.C_EXPIRE_DATE
          ? accAuthorSingle?.C_EXPIRE_DATE.split(' ')[0]
          : null,
        ttuqChkGrand: accAuthorSingle?.C_GRAND_ACCOUNT === 1 ? true : false,
        ttuqChkNotary: accAuthorSingle?.C_NOTARIAL_FLAG === 1 ? true : false,
        ttuqNotarialAuthorDate: accAuthorSingle?.C_NOTARIAL_AUTHOR_DATE
          ? accAuthorSingle?.C_NOTARIAL_AUTHOR_DATE.split(' ')[0]
          : null,
        ttuqNotarialAuthorNo: accAuthorSingle?.C_NOTARIAL_AUTHOR_NO,
        ttuqFile: null,
        gcActive: accAuthorSingle?.C_ACTIVE === 1 ? true : false,
        formFile: accAuthorSingle?.C_FILE_NAME,
      },
      noidunguyquyen: {
        nduqFunc: accAuthorSingle?.FUNC ? accAuthorSingle?.FUNC.split(',') : [],
      },
      ghichu: {
        gcNote: accAuthorSingle?.C_CONTENT,
        gcCloser: accAuthorSingle?.C_CLOSER,
        gcEditorCode: accAuthorSingle?.C_APPROVER_CODE,
        gcCreatorCode: accAuthorSingle?.C_CREATOR_CODE,
      },
    },
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailTTUyQuyenModal)
);
