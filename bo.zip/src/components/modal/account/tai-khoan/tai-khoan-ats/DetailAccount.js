import React, { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Form } from 'react-bootstrap';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderInput from 'components/input/renderInput';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import * as _ from 'lodash';
import { required } from 'utils/validation';
import { setToast } from 'containers/client/actions';
import { translate } from 'react-i18next';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import renderNewInputAccount from 'components/input/renderNewInputAccount';

import renderSelectBank from 'components/input/renderSelectBank';
import { makeGetAllBank } from 'lib/selector';
import {
  accountSingleRequest,
  accountSingleSuccess,
  accAtsUpdSuccess,
  accMarketDelRequest,
  accMarketDelSuccess,
  accAtsUpdRequest,
} from 'containers/account/actions';
import {
  makeGetToken,
  makeAccAtsUpdate,
  makeAccMarketDel,
  makeGetAccountSingle,
} from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    onClose,
    accAtsUpd,
    id,
    accRight,
    accMarketDel,
    accountSingle,
  } = props;

  const preAccUpd = usePrevious(accAtsUpd);
  const preDel = usePrevious(accMarketDel);
  const preAccountSingle = usePrevious(accountSingle);

  useEffect(() => {
    getSingleAcc();
    return () => {
      dispatch(accountSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (accountSingle && !_.isEqual(accountSingle, preAccountSingle)) {
      initForm();
    }
  }, [accountSingle]);
  function initForm() {
    dispatch(
      change(
        'detailTkAstModalform',
        'formAccountCode',
        accountSingle?.C_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formAccountName',
        accountSingle?.C_ACCOUNT_NAME
      )
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formMarketCode',
        accountSingle?.C_MARKET_CODE
      )
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formStartDate',
        accountSingle?.C_OPEN_DATE
      )
    );
    dispatch(
      change('detailTkAstModalform', 'formNote', accountSingle?.C_CONTENT)
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formBranchCode',
        accountSingle?.C_BRANCH_CODE + '-' + accountSingle?.C_BRANCH_NAME
      )
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formSubBranchCode',
        accountSingle?.C_SUB_BRANCH_CODE + '-' + accountSingle?.C_SUB_BRANCH_NAME
      )
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formCustomerCode',
        accountSingle?.C_CUSTOMER_CODE
      )
    );
    dispatch(
      change('detailTkAstModalform', 'formCardId', accountSingle?.C_CARD_ID)
    );
    dispatch(
      change('detailTkAstModalform', 'formIssDate', accountSingle?.C_ISSUE_DATE)
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formIssPlace',
        accountSingle?.C_ISSUE_PLACE_NAME
      )
    );
    dispatch(
      change(
        'detailTkAstModalform',
        'formBankAccountCode',
        accountSingle?.C_ATS_BANK_ACCOUNT
      )
    );
    dispatch(
      change('detailTkAstModalform', 'formBankCode', accountSingle?.C_ATS_BANK)
    );
  }
  useEffect(() => {
    if (accAtsUpd && !_.isEqual(accAtsUpd, preAccUpd)) {
      _handleToast(t('Cập nhật thành công'), 'success');
      dispatch(accAtsUpdSuccess(null));
      onClose();
    }
  }, [accAtsUpd]);

  useEffect(() => {
    if (accMarketDel && !_.isEqual(accMarketDel, preDel)) {
      _handleToast('Xóa thành công', 'success');
      dispatch(accMarketDelSuccess(null));
      onClose();
    }
  }, [accMarketDel]);

  function getSingleAcc() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: id,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_ATS',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: values?.formAccountCode,
        BANK_CODE: values?.formBankCode,
        ATS_FLAG: 1,
        BANK_ACCOUNT: values?.formBankAccountCode,
      },
    };

    dispatch(accAtsUpdRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p> {actionName === 'delete' ? t('txt-del-cmd') : ''}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;

                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: accountSingle?.PK_ACCOUNT_MARKET,
      },
    };

    dispatch(accMarketDelRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const {
    handleSubmit,
    submitting,
    glAllBank,
    reset,
    formStartDate,
    t,
    pristine,
  } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết tài khoản @</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>

        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    Tài khoản<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control "
                    classParent="w-100"
                    validate={[required]}
                    component={renderNewInputAccount}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Tên tài khoản</Form.Label>
                  <Field
                    name="formAccountName"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Chi nhánh</Form.Label>
                  <Field
                    name="formBranchCode"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Phòng Giao dịch</Form.Label>
                  <Field
                    name="formSubBranchCode"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Mã khách hàng</Form.Label>
                  <Field
                    name="formCustomerCode"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Số ĐKSH</Form.Label>
                  <Field
                    name="formCardId"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Ngày cấp</Form.Label>
                  <Field
                    name="formIssDate"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Nơi cấp</Form.Label>
                  <Field
                    name="formIssPlace"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  Thông tin
                </p>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    Ngân hàng<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankCode"
                    className="form-control input-order fz-13"
                    component={renderSelectBank}
                    opts={glAllBank}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    Số tài khoản ngân hàng
                  </Form.Label>
                  <Field
                    name="formBankAccountCode"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_UPDATE === 1 && (
                  <>
                    {/* <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="w_125 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit> */}
                    <BtnSubmit
                      type="submit"
                      disabled={pristine || submitting}
                      className="w_125 ml-2"
                    >
                      {t('txt-edit')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailModal = reduxForm({
  form: 'detailTkAstModalform',
  enableReinitialize: true,
})(DetailModal);

const selector = formValueSelector('detailTkAstModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getAccAtsUpdate = makeAccAtsUpdate();
  const getAccMarketDel = makeAccMarketDel();
  const getAccountSingle = makeGetAccountSingle();
  const getAllBank = makeGetAllBank();
  const {
    formAccountCode,
    formBankCode,
    formBankAccountCode,
    formIssPlace,
    formIssDate,
    formCardId,
    formCustomerCode,
    formSubBranchCode,
    formBranchCode,
    formMarketCode,
    formToDate,
    formStartDate,
    formAccountName,
    formNote,
  } = selector(
    state,
    'formShareCode',
    'formAccountCode',
    'formAccountName',

    'formStartDate',
    'formToDate',
    'formNote',
    'formMarketCode',
    'formBranchCode',
    'formSubBranchCode',
    'formCustomerCode',
    'formCardId',
    'formIssDate',
    'formIssPlace',
    'formBankAccountCode',
    'formBankCode'
  );
  const accountSingle = getAccountSingle(state);

  return {
    token: getToken(state),
    accAtsUpd: getAccAtsUpdate(state),
    accountSingle,
    accMarketDel: getAccMarketDel(state),
    glAllBank: getAllBank(state),
    formAccountCode,
    formAccountName,

    formStartDate,
    formToDate,
    formNote,
    formMarketCode,
    formBranchCode,
    formSubBranchCode,
    formCustomerCode,
    formCardId,
    formIssDate,
    formIssPlace,
    formBankAccountCode,
    formBankCode,
  };
};

export default connect(mapStateToProps)(translate('translations')(DetailModal));
