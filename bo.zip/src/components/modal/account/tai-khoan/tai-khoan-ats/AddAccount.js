import React, { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import { accountSingleSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';

import { makeGetAccountSingle, makeGetToken } from 'lib/selector';
import { makeGetAllBank } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  accountSingleRequest,
  accAtsUpdRequest,
} from 'containers/account/actions';
import {
  makeAccAtsUpdate,
  makeGetPhoneFunc,
  makeGetShareSingle,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import renderSelectBank from 'components/input/renderSelectBank';

ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddAccountModal(props) {
  const dispatch = useDispatch();
  const [orderCheck, setOrderCheck] = React.useState([]);

  const {
    token,
    formAccountCode,
    formShareCode,
    accDetail,
    accAtsUpd,

    glAllBank,
  } = props;

  //const preAccDetail = usePrevious(custDetail);
  const preCustomerCode = usePrevious(formAccountCode);
  const preAccUpd = usePrevious(accAtsUpd);
  const preFormShareCode = usePrevious(formShareCode);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  useEffect(() => {
    if (
      formAccountCode &&
      formAccountCode.length === 7 &&
      !_.isEqual(formAccountCode, preCustomerCode)
    ) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  function initForm() {
    dispatch(
      change(
        'detailAccountModalform',
        'formStartDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(change('detailAccountModalform', 'formNote', ''));
    dispatch(change('detailAccountModalform', 'formBankAccountCode', ''));
    dispatch(change('detailAccountModalform', 'formBankCode', ''));
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  React.useEffect(() => {
    if (accAtsUpd && !_.isEqual(accAtsUpd, preAccUpd)) {
      _handleToast(t('Thêm mới tài khoản @ thành công'), 'success');
      onClose();
    }
  }, [accAtsUpd]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
  }

  function submit(values) {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_ATS',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: values?.formAccountCode,
        BANK_CODE: values?.formBankCode,
        ATS_FLAG: 1,
        BANK_ACCOUNT: values?.formBankAccountCode,
      },
    };

    dispatch(accAtsUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t, formStartDate } = props;

  //   console.log(custDetail, glNational)

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới tài khoản @</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>Tài khoản</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tên tài khoản</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Chi nhánh</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(accDetail?.C_BRANCH_CODE || '') + ' - ' + (accDetail?.C_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Phòng giao dịch</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(accDetail?.C_SUB_BRANCH_CODE || '') + ' - ' + (accDetail?.C_SUB_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Mã khách hàng</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUSTOMER_CODE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số ĐKSH</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CARD_ID || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Ngày cấp</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ISSUE_DATE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Nơi cấp</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ISSUE_PLACE_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  Thông tin
                </p>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    Ngân hàng<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankCode"
                    className="form-control input-order fz-13"
                    component={renderSelectBank}
                    opts={glAllBank}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Số tài khoản ngân hàng{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankAccountCode"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />

                {/* <Form.Group className="d-flex flex-column">
                  <Form.Label>{t('txt-status')}</Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group> */}
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddAccountModal = reduxForm({
  form: 'addTkAtsModalform',
  enableReinitialize: true,
})(AddAccountModal);

const selector = formValueSelector('addTkAtsModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getPhoneFunc = makeGetPhoneFunc();
  const getAccountSingle = makeGetAccountSingle();
  const getAccAtsUpdate = makeAccAtsUpdate();
  const getShareSingle = makeGetShareSingle();
  const getAllBank = makeGetAllBank();

  const {
    formAccountCode,
    formStartDate,
    formToDate,
    formNote,
    formMarketCode,
    formBankAccountCode,
    formBankCode,
  } = selector(
    state,
    'formAccountCode',
    'formShareCode',
    'formMarketCode',
    'formStartDate',
    'formNote',
    'formBankAccountCode',
    'formBankCode'
  );

  return {
    token: getToken(state),
    glPhoneFunc: getPhoneFunc(state),
    accDetail: getAccountSingle(state),
    accAtsUpd: getAccAtsUpdate(state),
    shareSingle: getShareSingle(state),
    glAllBank: getAllBank(state),
    formAccountCode,
    formMarketCode,
    formStartDate,
    formBankAccountCode,
    formBankCode,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddAccountModal)
);
