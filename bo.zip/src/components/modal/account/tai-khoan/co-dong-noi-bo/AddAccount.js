import React, { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import { accountSingleSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';

import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import renderNewInput from 'components/input/renderNewInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestShare from 'components/input/renderSuggestShare';
import { accHolderUpdRequest } from 'containers/account/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  shareSingleRequest,
  shareSingleSuccess,
} from 'containers/stock/actions';
import {
  makeAccHolderUpdate,
  makeGetCustomerDetail,
  makeGetGlobalHolderType,
  makeGetPhoneFunc,
  makeGetShareSingle,
  makeGetToken,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { StringToInt, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import {
  validateTTHH
} from 'utils/validation';
ReactModal.setAppElement('#root');
const length6 = lengthRequired(6);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddCoDongNoiBoModal(props) {
  const dispatch = useDispatch();
  const [orderCheck, setOrderCheck] = React.useState([]);

  const {
    token,
    formAccountCode,
    formShareCode,
    custDetail,
    accHolderUpd,
    shareSingle,
  } = props;

  //const preAccDetail = usePrevious(custDetail);
  const preCustomerCode = usePrevious(formAccountCode);
  const preAccHolderUpd = usePrevious(accHolderUpd);
  const preFormShareCode = usePrevious(formShareCode);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(shareSingleSuccess(null));
    };
  }, []);

  function initForm() {
    dispatch(
      change(
        'addCoDongNoiBoModalform',
        'formStartDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(change('addCoDongNoiBoModalform', 'formToDate', '31/12/9999'));
    dispatch(change('addCoDongNoiBoModalform', 'formStatus', true));
    dispatch(change('addCoDongNoiBoModalform', 'formNote', ''));
    dispatch(change('addCoDongNoiBoModalform', 'formTradeSide', 'BUY'));
  }

  useEffect(() => {
    if (
      formAccountCode &&
      formAccountCode.length === 6 &&
      !_.isEqual(formAccountCode, preCustomerCode)
    ) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formAccountCode]);

  useEffect(() => {
    if (formShareCode) {
      _handleCheckShare();
    } else dispatch(shareSingleSuccess(null));
  }, [formShareCode]);

  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAccountCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckShare() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_SHARE',
      group: 'LIST',
      data: {
        SHARE_ID: formShareCode,
      },
    };

    dispatch(shareSingleRequest(params));
  }

  React.useEffect(() => {
    if (custDetail && !_.isEqual(custDetail, preCustomerCode)) {
      dispatch(change('addAccMobileModalform', custDetail?.C_CUST_MOBILE));
    }
  }, [custDetail]);

  React.useEffect(() => {
    if (accHolderUpd && !_.isEqual(accHolderUpd, preAccHolderUpd)) {
      _handleToast(t('txt-add-service-success'), 'success');
      onClose();
    }
  }, [accHolderUpd]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_HOLDER',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        CUSTOMER_CODE: values?.formAccountCode,
        SHARE_CODE: values?.formShareCode,
        HOLDER_TYPE: values?.formAccountType,
        POSITION: values?.formPosition,
        RELATION: values?.formRelation,
        SHARE_VOL: StringToInt(values?.formShareVol),
        SHARE_RATE: values?.formShareRate,
        FROM_DATE: values?.formStartDate,
        TO_DATE: values?.formToDate,
        NORMAL_STATUS: props?.formNormalStatus ? 1 : 0,
        RIGHT_REGISTER_STATUS: props?.formRightStatus ? 1 : 0,
        RIGHT_TRANSFER_STATUS: props?.formRightTransferStatus ? 1 : 0,
        TRADE_SIDE: values?.formTradeSide,
        TRADE_VOLUME: StringToInt(values?.formTradeVol),
        RIGHT_REGISTER_VOL: StringToInt(values?.formRightRegisterVol),
        CONTENT: values?.formPosition,
      },
    };

    dispatch(accHolderUpdRequest(params));
  }

  function _handleAddCallback() {}

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, glHolderType, onClose, t, formStartDate } =
    props;

  //   console.log(custDetail, glNational)

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới cổ đông NB/CĐ lớn</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>Mã khách hàng</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInput}
                    validate={[required, length6]}
                    fnAddCallback={_handleAddCallback}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tên khách hàng</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Maketing ID</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(custDetail?.C_MARKETING_ID || '') + ' - ' + (custDetail?.C_MARKETING_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(custDetail?.C_SUB_BRANCH_CODE || '') + ' - ' + (custDetail?.C_SUB_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_CARD_ID || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_ISSUE_DATE || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_EXPIRE_DATE || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label> {t('txt-issue-place')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={custDetail?.C_ISSUE_PLACE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  Thông tin cổ đông
                </p>
                <Form.Group>
                  <Form.Label>
                    Nhóm cổ đông<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={glHolderType}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>Chức vụ</Form.Label>
                  <Field
                    name="formPosition"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>Quan hệ với CD nội bộ</Form.Label>
                  <Field
                    name="formRelation"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-share-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formShareCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestShare}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-share-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={shareSingle?.C_SHARE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số lượng sở hữu</Form.Label>
                  <Field
                    name="formShareVol"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tỉ lệ sở hữu</Form.Label>
                  <Field
                    name="formShareRate"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group
                  className="d-flex flex-column"
                  style={{ gridColumn: '1/5' }}
                >
                  <Form.Label></Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formNormalStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    Bỏ chặn GD
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Loại GD</Form.Label>
                  {/* <Field
                    name="formTradeSide"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                    
                  /> */}
                  <Field
                    name="formTradeSide"
                    className="form-control w-100"
                    component="select"
                  >
                    <option value="BUY">Mua</option>
                    <option value="SELL">Bán</option>
                  </Field>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Khối lượng GD</Form.Label>
                  <Field
                    name="formTradeVol"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formStartDate"
                    startDate={formStartDate}
                    component={RenderSelectDate}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-to-date')}<span className="text-danger">*</span></Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formToDate"
                    component={RenderSelectDate}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group className="d-flex flex-column">
                  <Form.Label></Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formRightStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    Bỏ chặn đăng ký quyền mua
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Khối lượng được đăng ký</Form.Label>
                  <Field
                    name="formRightRegisterVol"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group
                  className="d-flex flex-column"
                  style={{ gridColumn: '1/5' }}
                >
                  <Form.Label></Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formRightTransferStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    Bỏ chặn chuyển nhượng quyền mua
                  </label>
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddCoDongNoiBoModal = reduxForm({
  form: 'addCoDongNoiBoModalform',
  enableReinitialize: true,
})(AddCoDongNoiBoModal);

const selector = formValueSelector('addCoDongNoiBoModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getPhoneFunc = makeGetPhoneFunc();
  const getCustomerDetail = makeGetCustomerDetail();
  const getAccHolderUpdate = makeAccHolderUpdate();
  const getShareSingle = makeGetShareSingle();
  const getGlobalHolderType = makeGetGlobalHolderType();

  const {
    formAccountCode,
    formShareCode,
    formAccountType,
    formPosition,
    formRelation,
    formShareVol,
    formShareRate,
    formCustomerPass,
    formTelephoneNum,
    formStartDate,
    formToDate,
    formNormalStatus,
    formRightStatus,
    formRightTransferStatus,
    formTradeSide,
    formTradeVol,
    formRightRegisterVol,
    formNote,
    formStatus,
  } = selector(
    state,
    'formAccountCode',
    'formShareCode',
    'formAccountType',
    'formPosition',
    'formRelation',
    'formShareVol',
    'formShareRate',
    'formCustomerPass',
    'formTelephoneNum',
    'formStartDate',
    'formToDate',
    'formNormalStatus',
    'formRightStatus',
    'formRightTransferStatus',
    'formTradeSide',
    'formTradeVol',
    'formRightRegisterVol',
    'formNote',
    'formStatus'
  );

  return {
    token: getToken(state),
    glPhoneFunc: getPhoneFunc(state),
    custDetail: getCustomerDetail(state),
    accHolderUpd: getAccHolderUpdate(state),
    shareSingle: getShareSingle(state),
    glHolderType: getGlobalHolderType(state),
    formAccountCode,
    formPosition,
    formRelation,
    formShareVol,
    formShareRate,
    formShareCode,
    formAccountType,
    formCustomerPass,
    formTelephoneNum,
    formStartDate,
    formToDate,
    formNormalStatus,
    formRightStatus,
    formRightTransferStatus,
    formTradeSide,
    formTradeVol,
    formRightRegisterVol,
    formNote,
    formStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddCoDongNoiBoModal)
);
