import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestShare from 'components/input/renderSuggestShare';
import {
  accHolderSingleRequest,
  accHolderSingleSuccess,
  accHolderUpdRequest,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  shareSingleRequest,
  shareSingleSuccess,
} from 'containers/stock/actions';
import { backDelCmdSuccess } from 'containers/user-management/actions';
import {
  makeAccHolderSingle,
  makeAccHolderUpdate,
  makeGetGlobalHolderType,
  makeGetShareSingle,
  makeGetToken,
} from 'lib/selector';
import {
  validateTTHH
} from 'utils/validation';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import styled from 'styled-components';
import { StringToInt } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    onClose,
    backCmdSave,
    accHolderUpd,
    id,
    accRight,
    glApiType,
    backDelCmd,
    backCmdSingle,
    accHolderSingle,
    shareSingle,
    formShareCode,
  } = props;

  const preAccHodelUpd = usePrevious(accHolderUpd);
  const preBackDelCmd = usePrevious(backDelCmd);
  const preFormShareCode = usePrevious(formShareCode);
  const preAccHolderSingle = usePrevious(accHolderSingle);

  useEffect(() => {
    getSingleAccHolder();
    return () => {
      dispatch(accHolderSingleSuccess(null));
      dispatch(shareSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (accHolderSingle && !_.isEqual(accHolderSingle, preAccHolderSingle)) {
      initForm();
    }
  }, [accHolderSingle]);

  useEffect(() => {
    if (accHolderUpd && !_.isEqual(accHolderUpd, preAccHodelUpd)) {
      _handleToast(t('Cập nhật thành công'), 'success');
      //dispatch(accHolderUpdSuccess(null));
      onClose();
    }
  }, [accHolderUpd]);

  useEffect(() => {
    if (backDelCmd && !_.isEqual(backDelCmd, preBackDelCmd)) {
      _handleToast('Xóa thành công', 'success');
      dispatch(backDelCmdSuccess(null));
      onClose();
    }
  }, [backDelCmd]);

  useEffect(() => {
    if (formShareCode) {
      _handleCheckShare();
    } else dispatch(shareSingleSuccess(null));
  }, [formShareCode]);

  function initForm() {
    dispatch(
      change('detailCoDongNoiBoModalform', 'formAccountCode', accHolderSingle?.C_CUSTOMER_CODE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formAccountName', accHolderSingle?.C_CUSTOMER_NAME)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formMktId', accHolderSingle?.C_MARKETING_ID + ' - ' + accHolderSingle?.C_MARKETING_NAME)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formSubBranch', accHolderSingle?.C_SUB_BRANCH_CODE + ' - ' + accHolderSingle?.C_SUB_BRANCH_NAME)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formCardID', accHolderSingle?.C_CARD_ID)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formIssDate', accHolderSingle?.C_ISSUE_DATE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formExpireDate', accHolderSingle?.C_EXPIRE_DATE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formIssuePlace', accHolderSingle?.C_ISSUE_PLACE_NAME)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formNote', accHolderSingle?.C_CONTENT)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formShareCode', accHolderSingle?.C_SHARE_CODE)
    );
    /////
    dispatch(
      change('detailCoDongNoiBoModalform', 'formAccountType', accHolderSingle?.C_HODLER_TYPE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formPosition', accHolderSingle?.C_POSITION)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formRelation', accHolderSingle?.C_RELATION)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formShareVol', accHolderSingle?.C_SHARE_VOLUME)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formShareRate', accHolderSingle?.C_SHARE_RATE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formNormalStatus', accHolderSingle?.C_STATUS === 1)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formTradeSide', accHolderSingle?.C_TRADE_SIDE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formTradeVol', accHolderSingle?.C_TRADE_VOLUME)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formStartDate', accHolderSingle?.C_FROM_DATE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formToDate', accHolderSingle?.C_TO_DATE)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formRightStatus', accHolderSingle?.C_RIGHT_REGISTER_STATUS === 1)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formRightRegisterVol', accHolderSingle?.C_RIGHT_REGISTER_VOL)
    );
    dispatch(
      change('detailCoDongNoiBoModalform', 'formRightTransferStatus', accHolderSingle?.C_RIGHT_TRANSFER_STATUS === 1)
    );
  }

  function getSingleAccHolder() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_HOLDER',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accHolderSingleRequest(params));
  }

  function submit(values) {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_HOLDER',
      group: 'LIST',
      data: {
        ITEM_ID: accHolderSingle.PK_ACCOUNT_HOLDER,
        CUSTOMER_CODE: values?.formAccountCode,
        SHARE_CODE: values?.formShareCode,
        HOLDER_TYPE: values?.formAccountType,
        POSITION: values?.formPosition,
        RELATION: values?.formRelation,
        SHARE_VOL: StringToInt(values?.formShareVol),
        SHARE_RATE: values?.formShareRate,
        FROM_DATE: values?.formStartDate,
        TO_DATE: values?.formToDate,
        NORMAL_STATUS: props?.formNormalStatus ? 1 : 0,
        RIGHT_REGISTER_STATUS: props?.formRightStatus ? 1 : 0,
        RIGHT_TRANSFER_STATUS: props?.formRightTransferStatus ? 1 : 0,
        TRADE_SIDE: values?.formTradeSide,
        TRADE_VOLUME: StringToInt(values?.formTradeVol),
        RIGHT_REGISTER_VOL: StringToInt(values?.formRightRegisterVol),
        CONTENT: values?.formNote,
      },
    };

    dispatch(accHolderUpdRequest(params));
  }

  function _handleCheckShare() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_SHARE',
      group: 'LIST',
      data: {
        SHARE_ID: formShareCode,
      },
    };

    dispatch(shareSingleRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const {
    handleSubmit,
    submitting,
    glHolderType,
    reset,
    formStartDate,
    t,
    pristine,
  } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết cổ đông NB/CĐ lớn</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>

        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    Mã khách hàng<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control "
                    classParent="w-100"
                    validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Tên khách hàng</Form.Label>
                  <Field
                    name="formAccountName"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">Maketing ID</Form.Label>
                  <Field
                    name="formMktId"
                    className="form-control "
                    classParent="w-100"
                    // value={(shareSingle?.C_MARKETING_ID || '') + ' - ' + (shareSingle?.C_MARKETING_NAME || '')}
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-subBranch')}
                  </Form.Label>
                  <Field
                    name="formSubBranch"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-card-id')}</Form.Label>
                  <Field
                    name="formCardID"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-issue-date')}
                  </Form.Label>
                  <Field
                    name="formIssDate"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-expire-date')}
                  </Form.Label>
                  <Field
                    name="formExpireDate"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-issue-place')}
                  </Form.Label>
                  <Field
                    name="formIssuePlace"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  Thông tin cổ đông
                </p>
                <Form.Group>
                  <Form.Label>
                    Nhóm cổ đông<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={glHolderType}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>Chức vụ</Form.Label>
                  <Field
                    name="formPosition"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>Quan hệ với CD nội bộ</Form.Label>
                  <Field
                    name="formRelation"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-share-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formShareCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestShare}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-share-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={shareSingle?.C_SHARE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số lượng sở hữu</Form.Label>
                  <Field
                    name="formShareVol"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tỉ lệ sở hữu</Form.Label>
                  <Field
                    name="formShareRate"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    required
                  />
                </Form.Group>
                <Form.Group
                  className="d-flex flex-column"
                  style={{ gridColumn: '1/5' }}
                >
                  <Form.Label></Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formNormalStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    Bỏ chặn GD
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Loại GD</Form.Label>

                  <Field
                    name="formTradeSide"
                    className="form-control w-100"
                    component="select"
                  >
                    <option value="BUY">Mua</option>
                    <option value="SELL">Bán</option>
                  </Field>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Khối lượng GD</Form.Label>
                  <Field
                    name="formTradeVol"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formStartDate"
                    startDate={formStartDate}
                    component={RenderSelectDate}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-to-date')}</Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formToDate"
                    component={RenderSelectDate}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group className="d-flex flex-column">
                  <Form.Label></Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formRightStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    Bỏ chặn đăng ký quyền mua
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Khối lượng được đăng ký</Form.Label>
                  <Field
                    name="formRightRegisterVol"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    required
                  />
                </Form.Group>
                <Form.Group
                  className="d-flex flex-column"
                  style={{ gridColumn: '1/5' }}
                >
                  <Form.Label></Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formRightTransferStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    Bỏ chặn chuyển nhượng quyền mua
                  </label>
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                    validate={[required]}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_UPDATE === 1 && (
                  <>
                    <BtnSubmit
                      type="submit"
                      disabled={pristine || submitting}
                      className="w_125 ml-2"
                    >
                      {t('txt-edit')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailModal = reduxForm({
  form: 'detailCoDongNoiBoModalform',
  enableReinitialize: true,
})(DetailModal);

const selector = formValueSelector('detailCoDongNoiBoModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getAccHolderUpdate = makeAccHolderUpdate();
  const getAccHolderSingle = makeAccHolderSingle();
  const getShareSingle = makeGetShareSingle();
  const {
    formAccountCode,
    formRightTransferStatus,
    formRightRegisterVol,
    formRightStatus,
    formToDate,
    formStartDate,
    formTradeVol,
    formTradeSide,
    formNormalStatus,
    formShareRate,
    formAccountType,
    formShareVol,
    formRelation,
    formPosition,
    formShareCode,
    formAccountName,
    formIssuePlace,
    formExpireDate,
    formIssDate,
    formCardID,
    formSubBranch,
    formMktId,
    formCmdType,
    formAuthrityCode,
    formNote,
  } = selector(
    state,
    'formShareCode',
    'formAccountCode',
    'formAccountName',
    'formCmdType',
    'formAuthrityCode',
    'formMktId',
    'formSubBranch',
    'formCardID',
    'formIssDate',
    'formExpireDate',
    'formIssuePlace',
    'formAccountType',
    'formPosition',
    'formRelation',
    'formShareVol',
    'formShareRate',
    'formNormalStatus',
    'formTradeSide',
    'formTradeVol',
    'formStartDate',
    'formToDate',
    'formRightStatus',
    'formRightRegisterVol',
    'formRightTransferStatus',
    'formNote'
  );
  const accHolderSingle = getAccHolderSingle(state);
  const getGlobalHolderType = makeGetGlobalHolderType();
  return {
    token: getToken(state),
    accHolderUpd: getAccHolderUpdate(state),
    accHolderSingle,
    shareSingle: getShareSingle(state),
    glHolderType: getGlobalHolderType(state),
    formAccountCode,
    formAccountName,
    formCmdType,
    formAuthrityCode,
    formMktId,
    formSubBranch,
    formCardID,
    formIssDate,
    formExpireDate,
    formIssuePlace,
    formShareCode,
    formAccountType,
    formPosition,
    formRelation,
    formShareVol,
    formShareRate,
    formNormalStatus,
    formTradeSide,
    formTradeVol,
    formStartDate,
    formToDate,
    formRightStatus,
    formRightRegisterVol,
    formRightTransferStatus,
    formNote,
  };
};

export default connect(mapStateToProps)(translate('translations')(DetailModal));

