import React from 'react';
import { Form, Table } from 'react-bootstrap';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { FormSection, reduxForm } from 'redux-form';
import styled from 'styled-components';

import {
  accountCashInfoListRequest,
  accountCashInfoListSuccess,
  accountCloseRequest,
  accountRightInfoListRequest,
  accountRightInfoListSuccess,
  accountShareInfoListRequest,
  accountShareInfoListSuccess,
  accountSingleRequest,
  accountSingleSuccess,
  accountTradingInfoListRequest,
  accountTradingInfoListSuccess,
  processCloseAccountRequest,
} from 'containers/account/actions';
import { custDetailSuccess } from 'containers/customer/actions';
import {
  makeGetAccCashInfoList,
  makeGetAccRightInfoList,
  makeGetAccShareInfoList,
  makeGetAccTradingInfoList,
  makeGetAccountClose,
  makeGetAccountSingle,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { formatDate } from 'utils';
import { BtnClose, BtnSubmit, TabsSectionHeader } from 'utils/styledComponent';
import { numberFormat } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function ThongTinTKTien(props) {
  const { t, data } = props;
  return (
    <>
      <PerfectScrollbar style={{ gridColumn: '1/5' }}>
        <Table bordered>
          <thead>
            <tr>
              <th>Số dư</th>
              <th>{t('txt-buy-wait-pay')}</th>
              <th>{t('txt-sell-wait-return')}</th>
              <th>{t('txt-fee-deposit')}</th>
              <th>Lãi tiền gửi</th>
              <th>{t('txt-principal-debt')}</th>
              <th>{t('txt-interest-debt')}</th>
            </tr>
          </thead>
          <tbody>
            {data &&
              !!data.length &&
              data.map((item, index) => {
                return (
                  <tr key={index}>
                    <th className="text-right">
                      {numberFormat(item?.C_CASH_BALANCE, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_CASH_TEMP_OUT, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_CASH_TEMP_IN, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_DEPOSIT_FEE, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_INTEREST_VALUE, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_LOAN_BALANCE, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_FEE_BALANCE, 0, '0')}
                    </th>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </PerfectScrollbar>
    </>
  );
}

function ThongTinTKChungKhoan(props) {
  const { t, data } = props;
  return (
    <>
      <PerfectScrollbar style={{ gridColumn: '1/5' }}>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-stock')}</th>
              <th>{t('txt-status')}</th>
              <th>{t('txt-balance')}</th>
              <th>{t('txt-will-transfer')}</th>
              <th>{t('txt-will-receive')}</th>
            </tr>
          </thead>
          <tbody>
            {data &&
              !!data.length &&
              data.map((item, index) => {
                return (
                  <tr key={index}>
                    <th className="text-center">{item?.C_SHARE_CODE}</th>
                    <th className="text-center">{item?.C_SHARE_STATUS}</th>
                    <th className="text-right">
                      {numberFormat(item?.C_BALANCE, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_SHARE_TEMP_OUT, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_SHARE_TEMP_IN, 0, '0')}
                    </th>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </PerfectScrollbar>
    </>
  );
}

function ThongTinQuyen(props) {
  const { t, data } = props;
  return (
    <>
      <PerfectScrollbar style={{ gridColumn: '1/5' }}>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-acc')}</th>
              <th>{t('txt-stock')}</th>
              <th>{t('txt-stock-receive')}</th>
              <th>{t('txt-money-receive')}</th>
              <th>{t('txt-closing-date')}</th>
              <th>{t('txt-exe-date')}</th>
              <th>{t('txt-right-type')}</th>
              <th>{t('txt-status')}</th>
            </tr>
          </thead>
          <tbody>
            {data &&
              !!data.length &&
              data.map((item, index) => {
                return (
                  <tr key={index}>
                    <th className="text-center">{item?.C_ACCOUNT_CODE}</th>
                    <th className="text-center">{item?.C_SHARE_CODE}</th>
                    <th className="text-right">
                      {numberFormat(item?.C_SHARE_RECEIVE, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_CASH_RECEIVE, 0, '0')}
                    </th>
                    <th className="text-center">{item?.C_CLOSE_DATE}</th>
                    <th className="text-center">{item?.C_DUE_DATE}</th>
                    <th className="text-center">{item?.C_RIGHT_TYPE_NAME}</th>
                    <th className="text-center">{item?.C_STATUS_NAME}</th>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </PerfectScrollbar>
    </>
  );
}

function ThongTinGiaoDich(props) {
  const { t, data } = props;
  return (
    <>
      <PerfectScrollbar style={{ gridColumn: '1/5' }}>
        <Table bordered>
          <thead>
            <tr>
              <th>{t('txt-date-trading')}</th>
              <th>{t('txt-exe-date')}</th>
              <th>{t('txt-trans-no')}</th>
              <th>{t('txt-right-return')}</th>
              <th>{t('txt-will-receive')}</th>
              <th>{t('txt-content')}</th>
            </tr>
          </thead>
          <tbody>
            {data &&
              !!data.length &&
              data.map((item, index) => {
                return (
                  <tr key={index}>
                    <th className="text-center">{item?.C_TRANSACTION_DATE}</th>
                    <th className="text-center">{item?.C_DUE_DATE}</th>
                    <th className="text-center">{item?.C_TRANSACTION_NO}</th>
                    <th className="text-right">
                      {numberFormat(item?.C_CASH_OUT, 0, '0')}
                    </th>
                    <th className="text-right">
                      {numberFormat(item?.C_CASH_IN, 0, '0')}
                    </th>
                    <th>{item?.C_CONTENT}</th>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </PerfectScrollbar>
    </>
  );
}

function CreateCloseAccountModal(props) {
  const dispatch = useDispatch();
  const [tabActive, setTabActive] = React.useState('CASH');
  const {
    token,
    handleSubmit,
    onClose,
    t,
    id,

    accRight,
    accountCode,
    singleAccount,
    sysSystemInfo,
    accountClose,

    accCashInfoList,
    accShareInfoList,
    accRightInfoList,
    accTradingInfoList,
  } = props;

  const preTabActive = usePrevious(tabActive);
  const preAccountClose = usePrevious(accountClose);

  React.useEffect(() => {
    if (accountCode) {
      handleGetSingleAccount();
    }
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(accountCashInfoListSuccess(null));
      dispatch(accountShareInfoListSuccess(null));
      dispatch(accountRightInfoListSuccess(null));
      dispatch(accountTradingInfoListSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (tabActive && !_.isEqual(tabActive, preTabActive)) {
      dispatch(accountCashInfoListSuccess(null));
      dispatch(accountShareInfoListSuccess(null));
      dispatch(accountRightInfoListSuccess(null));
      dispatch(accountTradingInfoListSuccess(null));
      switch (tabActive) {
        case 'CASH':
          handleListCashInfo();
          break;
        case 'SHARE':
          handleListShareInfo();
          break;
        case 'RIGHT':
          handleListRightInfo();
          break;
        case 'TRADING':
          handleListTradingInfo();
          break;
        default:
          break;
      }
    }
  }, [tabActive]);

  React.useEffect(() => {
    if (accountClose && !_.isEqual(accountClose, preAccountClose)) {
      onClose();
    }
  }, [accountClose]);

  function handleListCashInfo() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_MONEY_ACC_CLOSE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: accountCode,
        TRADING_DATE:
          sysSystemInfo?.C_T_DATE || formatDate(new Date(), '/', 'dmy'),
      },
    };

    // dispatch(accountCashInfoListRequest(params));
  }

  function handleListShareInfo() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SHARE_ACC_CLOSE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: accountCode,
        TRADING_DATE:
          sysSystemInfo?.C_T_DATE || formatDate(new Date(), '/', 'dmy'),
      },
    };

    dispatch(accountShareInfoListRequest(params));
  }

  function handleListRightInfo() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_RIGHT_ACC_CLOSE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: accountCode,
        TRADING_DATE:
          sysSystemInfo?.C_T_DATE || formatDate(new Date(), '/', 'dmy'),
      },
    };

    dispatch(accountRightInfoListRequest(params));
  }

  function handleListTradingInfo() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_TRANS_ACC_CLOSE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: accountCode,
        TRADING_DATE:
          sysSystemInfo?.C_T_DATE || formatDate(new Date(), '/', 'dmy'),
      },
    };

    dispatch(accountTradingInfoListRequest(params));
  }

  function submit(values) {
    handleConfirm();
  }

  function handleGetSingleAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: accountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-close-acc')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionClose();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleConfirmProcessClose() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn trả lãi tiền gửi?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionProcessClose();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionClose() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.CLOSE_ACCOUNT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
      },
    };

    dispatch(accountCloseRequest(params));
  }

  function handleActionProcessClose() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.PROCESS_CLOSE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: singleAccount?.C_ACCOUNT_CODE,
      },
    };

    dispatch(processCloseAccountRequest(params));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-acc-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-acc-owner-info')}
                </p>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>
                  <input
                    value={singleAccount?.C_ACCOUNT_CODE || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-owner-name')}</Form.Label>
                  <input
                    value={singleAccount?.C_ACCOUNT_NAME || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Marketing ID</Form.Label>
                  <input
                    value={singleAccount?.C_MARKETING_ID || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    value={singleAccount?.C_SUB_BRANCH_NAME_NEW || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id-1')}</Form.Label>
                  <input
                    value={singleAccount?.C_CARD_ID || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    value={singleAccount?.C_ISSUE_DATE || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <input
                    value={singleAccount?.C_EXPIRE_DATE || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-place')}</Form.Label>
                  <input
                    value={singleAccount?.C_ISSUE_PLACE_NAME || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-close-acc-date')}
                </p>
                <Form.Group>
                  <Form.Label>{t('txt-close-date')}</Form.Label>
                  <input
                    value={
                      sysSystemInfo?.C_T_DATE ||
                      formatDate(new Date(), '/', 'dmy')
                    }
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-user-close-acc')}</Form.Label>
                  <input
                    value={token?.USER_NAME || ''}
                    type={'text'}
                    className="form-control input-order"
                    disabled
                  />
                </Form.Group>

                {/*/!* TODO: Tabs Section  *!/*/}
                {/*<TabsSectionHeader style={{ gridColumn: '1/5' }}>*/}
                {/*  <ul>*/}
                {/*    <li*/}
                {/*      onClick={() => setTabActive('CASH')}*/}
                {/*      className={tabActive === 'CASH' ? 'active' : ''}*/}
                {/*    >*/}
                {/*      {t('txt-acc-money-info')}*/}
                {/*    </li>*/}
                {/*    <li*/}
                {/*      onClick={() => setTabActive('SHARE')}*/}
                {/*      className={tabActive === 'SHARE' ? 'active' : ''}*/}
                {/*    >*/}
                {/*      {t('txt-acc-stock-info')}*/}
                {/*    </li>*/}
                {/*    <li*/}
                {/*      onClick={() => setTabActive('RIGHT')}*/}
                {/*      className={tabActive === 'RIGHT' ? 'active' : ''}*/}
                {/*    >*/}
                {/*      {t('txt-right-info')}*/}
                {/*    </li>*/}
                {/*    <li*/}
                {/*      onClick={() => setTabActive('TRADING')}*/}
                {/*      className={tabActive === 'TRADING' ? 'active' : ''}*/}
                {/*    >*/}
                {/*      {t('txt-trading-arise-info')}*/}
                {/*    </li>*/}
                {/*  </ul>*/}
                {/*</TabsSectionHeader>*/}
                {/*{tabActive === 'CASH' && (*/}
                {/*  <FormSection>*/}
                {/*    <ThongTinTKTien t={t} data={accCashInfoList} />*/}
                {/*  </FormSection>*/}
                {/*)}*/}
                {/*{tabActive === 'SHARE' && (*/}
                {/*  <FormSection>*/}
                {/*    <ThongTinTKChungKhoan t={t} data={accShareInfoList} />*/}
                {/*  </FormSection>*/}
                {/*)}*/}
                {/*{tabActive === 'RIGHT' && (*/}
                {/*  <FormSection>*/}
                {/*    <ThongTinQuyen t={t} data={accRightInfoList} />*/}
                {/*  </FormSection>*/}
                {/*)}*/}
                {/*{tabActive === 'TRADING' && (*/}
                {/*  <FormSection>*/}
                {/*    <ThongTinGiaoDich t={t} data={accTradingInfoList} />*/}
                {/*  </FormSection>*/}
                {/*)}*/}
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_APPROVE === 1 &&
                  singleAccount?.C_STATUS === 'DA_DUYET' && (
                    <>
                     <BtnSubmit
                          type="button"
                          onClick={() => handleConfirmProcessClose()}
                          className="w_125 ml-2 danger"
                        >
                          Trả lãi tiền gửi
                        </BtnSubmit>
                    <BtnSubmit type="submit" className="w_125 ml-2">
                      {t('txt-close-account')}
                    </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateCloseAccountModal = reduxForm({
  form: 'createCloseAccountModalForm',
  enableReinitialize: true,
})(CreateCloseAccountModal);

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountClose = makeGetAccountClose();

  const getAccCashInfoList = makeGetAccCashInfoList();
  const getAccShareInfoList = makeGetAccShareInfoList();
  const getAccRightInfoList = makeGetAccRightInfoList();
  const getAccTradingInfoList = makeGetAccTradingInfoList();

  return {
    token: getToken(state),
    accountClose: getAccountClose(state),
    singleAccount: getAccountSingle(state),
    sysSystemInfo: getSystemInfo(state),
    accClose: getAccountClose(state),
    accCashInfoList: getAccCashInfoList(state),
    accShareInfoList: getAccShareInfoList(state),
    accRightInfoList: getAccRightInfoList(state),
    accTradingInfoList: getAccTradingInfoList(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateCloseAccountModal)
);
