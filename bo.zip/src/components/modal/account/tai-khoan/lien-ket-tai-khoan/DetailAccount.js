import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accMarketDelRequest,
  accMarketDelSuccess,
  accMarketSingleRequest,
  accMarketSingleSuccess,
  accMarketUpdRequest,
  accMarketUpdSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeAccMarketDel,
  makeAccMarketSingle,
  makeAccMarketUpdate,
  makeGetGlobalApiType,
  makeGetGlobalVsdMarket,
  makeGetShareSingle,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    onClose,
    accMarketUpd,
    id,
    accRight,
    accMarketDel,
    accMarketSingle,
    shareSingle,
    formShareCode,
  } = props;

  const preAccMarketUpd = usePrevious(accMarketUpd);
  const preDel = usePrevious(accMarketDel);
  const preFormShareCode = usePrevious(formShareCode);
  const preAccMarketSingle = usePrevious(accMarketSingle);

  useEffect(() => {
    getSingleAccMarket();
    return () => {
      dispatch(accMarketSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (accMarketSingle && !_.isEqual(accMarketSingle, preAccMarketSingle)) {
      initForm();
    }
  }, [accMarketSingle]);
  useEffect(() => {
    if (accMarketUpd && !_.isEqual(accMarketUpd, preAccMarketUpd)) {
      _handleToast(t('Cập nhật thành công'), 'success');
      dispatch(accMarketUpdSuccess(null));
      onClose();
    }
  }, [accMarketUpd]);

  useEffect(() => {
    if (accMarketDel && !_.isEqual(accMarketDel, preDel)) {
      _handleToast('Xóa thành công', 'success');
      dispatch(accMarketDelSuccess(null));
      onClose();
    }
  }, [accMarketDel]);

  function initForm() {
    dispatch(
      change(
        'detailModalformLienKetTaiKoan',
        'formAccountCode',
        accMarketSingle?.C_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailModalformLienKetTaiKoan',
        'formAccountName',
        accMarketSingle?.C_ACCOUNT_NAME
      )
    );
    dispatch(
      change(
        'detailModalformLienKetTaiKoan',
        'formMarketCode',
        accMarketSingle?.C_MARKET_CODE
      )
    );
    dispatch(
      change(
        'detailModalformLienKetTaiKoan',
        'formStartDate',
        accMarketSingle?.C_OPEN_DATE
      )
    );
    dispatch(
      change(
        'detailModalformLienKetTaiKoan',
        'formNote',
        accMarketSingle?.C_CONTENT
      )
    );
  }

  function getSingleAccMarket() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accMarketSingleRequest(params));
  }

  function submit(values) {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: values?.formAccountCode,
        MARKET_CODE: values?.formMarketCode,
        CONTENT: values?.formNote,
      },
    };

    dispatch(accMarketUpdRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p> {actionName === 'delete' ? t('txt-del-cmd') : ''}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;

                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: accMarketSingle?.PK_ACCOUNT_MARKET,
      },
    };

    dispatch(accMarketDelRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const {
    handleSubmit,
    submitting,
    glVsdMarket,
    reset,
    formStartDate,
    t,
    pristine,
  } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết liên kết tài khoản</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>

        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">
                    Tài khoản<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control "
                    classParent="w-100"
                    validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label className="fz-13">Tên tài khoản</Form.Label>
                  <Field
                    name="formAccountName"
                    className="form-control "
                    classParent="w-100"
                    //validate={[required]}
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Thị trường</Form.Label>
                  <Field
                    name="formMarketCode"
                    className="form-control "
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={glVsdMarket}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Ngày mở<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formStartDate"
                    startDate={formStartDate}
                    component={RenderSelectDate}
                    validate={[required]}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="8"
                    validate={[required]}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_UPDATE === 1 && (
                  <>
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="w_125 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                    <BtnSubmit
                      type="submit"
                      disabled={pristine || submitting}
                      className="w_125 ml-2"
                    >
                      {t('txt-edit')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailModal = reduxForm({
  form: 'detailModalformLienKetTaiKoan',
  enableReinitialize: true,
})(DetailModal);

const selector = formValueSelector('detailModalformLienKetTaiKoan');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const getAccMarketUpdate = makeAccMarketUpdate();
  const getAccMarketDel = makeAccMarketDel();
  const getAccMarketSingle = makeAccMarketSingle();
  const getGlobalApiType = makeGetGlobalApiType();
  const getShareSingle = makeGetShareSingle();
  const getGlobalVsdMarket = makeGetGlobalVsdMarket();
  const {
    formAccountCode,
    formMarketCode,
    formToDate,
    formStartDate,
    formAccountName,
    formNote,
  } = selector(
    state,
    'formShareCode',
    'formAccountCode',
    'formAccountName',

    'formStartDate',
    'formToDate',
    'formNote',
    'formMarketCode'
  );
  const accMarketSingle = getAccMarketSingle(state);

  return {
    token: getToken(state),
    accMarketUpd: getAccMarketUpdate(state),
    accMarketSingle,
    accMarketDel: getAccMarketDel(state),
    glApiType: getGlobalApiType(state),
    glVsdMarket: getGlobalVsdMarket(state),
    formAccountCode,
    formAccountName,

    formStartDate,
    formToDate,
    formNote,
    formMarketCode,
  };
};

export default connect(mapStateToProps)(translate('translations')(DetailModal));
