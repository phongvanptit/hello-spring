import React, { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import RenderNormalSelect from 'components/input/renderNormalSelect';
import { accountSingleSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountSingle,
  makeGetGlobalVsdMarket,
  makeGetToken,
} from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  accMarketUpdRequest,
  accountSingleRequest,
} from 'containers/account/actions';
import {
  makeAccMarketUpdate,
  makeGetPhoneFunc,
  makeGetShareSingle,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddLienKetTaiKhoanModal(props) {
  const dispatch = useDispatch();
  const [orderCheck, setOrderCheck] = React.useState([]);

  const {
    token,
    formAccountCode,
    formShareCode,
    formAccountType,
    formPosition,
    formRelation,
    formShareVol,
    formShareRate,
    formNormalStatus,
    formRightStatus,
    formRightTransferStatus,
    formTradeSide,
    formTradeVol,
    formRightRegisterVol,
    accDetail,
    accPhoneUpd,
    glPhoneFunc,
    accMarketUpd,
    formTelephoneNum,
    shareSingle,
  } = props;

  //const preAccDetail = usePrevious(custDetail);
  const preCustomerCode = usePrevious(formAccountCode);
  const preAccUpd = usePrevious(accMarketUpd);
  const preFormShareCode = usePrevious(formShareCode);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  function initForm() {
    dispatch(
      change(
        'addAccLKTKModalform',
        'formStartDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
    dispatch(change('addAccLKTKModalform', 'formNote', ''));
  }

  useEffect(() => {
    if (
      formAccountCode &&
      formAccountCode.length === 7 &&
      !_.isEqual(formAccountCode, preCustomerCode)
    ) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  React.useEffect(() => {
    if (accMarketUpd && !_.isEqual(accMarketUpd, preAccUpd)) {
      _handleToast(t('Thêm mới liên kết tài khoản'), 'success');
      onClose();
    }
  }, [accMarketUpd]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_MARKET',
      group: 'LIST',
      data: {
        MARKET_CODE: values?.formMarketCode,
        ACCOUNT_CODE: values?.formAccountCode,
        CONTENT: values?.formNote,
      },
    };

    dispatch(accMarketUpdRequest(params));
  }

  function _handleAddCallback() {}

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, glVsdMarket, onClose, t, formStartDate } =
    props;

  //   console.log(custDetail, glNational)

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới liên kết tài khoản</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>Tài khoản</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                    fnAddCallback={_handleAddCallback}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>Tên tài khoản</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  Thông tin thị trường
                </p>
                <Form.Group>
                  <Form.Label>
                    Thị trường<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formMarketCode"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={glVsdMarket}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formStartDate"
                    startDate={formStartDate}
                    component={RenderSelectDate}
                    validate={[required]}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>

                {/* <Form.Group className="d-flex flex-column">
                  <Form.Label>{t('txt-status')}</Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group> */}
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddLienKetTaiKhoanModal = reduxForm({
  form: 'addAccLKTKModalform',
  enableReinitialize: true,
})(AddLienKetTaiKhoanModal);

const selector = formValueSelector('addAccLKTKModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getPhoneFunc = makeGetPhoneFunc();
  const getAccountSingle = makeGetAccountSingle();
  const getAccMarketUpdate = makeAccMarketUpdate();
  const getShareSingle = makeGetShareSingle();
  const getGlobalVsdMarket = makeGetGlobalVsdMarket();

  const {
    formAccountCode,
    formStartDate,
    formToDate,
    formNote,
    formMarketCode,
  } = selector(
    state,
    'formAccountCode',
    'formShareCode',
    'formMarketCode',
    'formStartDate',
    'formNote'
  );

  return {
    token: getToken(state),
    glPhoneFunc: getPhoneFunc(state),
    accDetail: getAccountSingle(state),
    accMarketUpd: getAccMarketUpdate(state),
    shareSingle: getShareSingle(state),
    glVsdMarket: getGlobalVsdMarket(state),
    formAccountCode,
    formMarketCode,
    formStartDate,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddLienKetTaiKhoanModal)
);
