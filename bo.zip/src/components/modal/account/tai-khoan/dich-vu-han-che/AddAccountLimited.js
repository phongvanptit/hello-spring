import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { change, Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { translate } from 'react-i18next';

import { setToast } from 'containers/client/actions';
import { accountSingleSuccess } from 'containers/account/actions';

import { makeGetToken } from 'lib/selector';
import { makeGetAccountSingle } from 'lib/selector';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { accountSingleRequest } from 'containers/account/actions';
import { Form } from 'react-bootstrap';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import { required } from 'utils/validation';
import { lengthRequired } from 'utils/validation';
import RenderArea from 'components/input/renderArea';
import { makeGetAccountLimitUpd } from 'lib/selector';
import { accountLimitUpdRequest } from 'containers/account/actions';
import { makeGetLimitedService } from 'lib/selector';
import PerfectScrollbar from 'react-perfect-scrollbar';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;x;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddAccountLimitedModal(props) {
  const dispatch = useDispatch();
  const [, setCheckAll] = React.useState(false);
  const [orderCheck, setOrderCheck] = React.useState([]);

  const { token, formAccountCode, glLimitFunc, accDetail, accLimitUpd } = props;

  const preAccInternetUpd = usePrevious(accLimitUpd);

  React.useEffect(() => {
    return () => {
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (accLimitUpd && !_.isEqual(accLimitUpd, preAccInternetUpd)) {
      _handleToast(`${t('txt-add-limit-service-success')}`, 'success');
      onClose();
    }
  }, [accLimitUpd]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeChkAll(e) {
    const { checked } = e.target;
    console.log(e);
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(glLimitFunc, 'C_CODE');
      setOrderCheck(allFunc);
    }
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!orderCheck || !orderCheck.length) {
      _handleToast(`${t('txt-select-limited-service')}`, 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: values?.formAccountCode,
        CONTENT: values?.formNote,
        FUNC: orderCheck,
      },
    };

    dispatch(accountLimitUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới dịch vụ hạn chế</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-type')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-cust-care-staff')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(accDetail?.C_MARKETING_ID || '') + ' - ' + (accDetail?.C_MARKETING_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  {t('txt-limit-server')}
                </p>
                <div
                  className="d-grid grid-2"
                  style={{ gridColumn: '1/5', gap: '5px' }}
                >
                  <Form.Label style={{ gridColumn: '1/3' }}>
                    <Field
                      name="custChkAll"
                      component="input"
                      type="checkbox"
                      onChange={_handleChangeChkAll}
                    />{' '}
                    Tất cả
                  </Form.Label>
                  <div className="d-grid">
                    {glLimitFunc &&
                      glLimitFunc.map((item, index) => (
                        <>
                          {item.C_GROUP_CODE === 'SHARE' && (
                            <label className="mt-1" key={index}>
                              <Field
                                className="mr-1"
                                name={item.C_CODE}
                                component="input"
                                type="checkbox"
                                checked={_.some(
                                  orderCheck,
                                  (o) => o === item.C_CODE
                                )}
                                onChange={_handleChange}
                              />
                              {item.C_NAME}
                            </label>
                          )}
                        </>
                      ))}
                  </div>
                  <div className="d-grid align-self-start">
                    {glLimitFunc &&
                      glLimitFunc.map((item, index) => (
                        <>
                          {item.C_GROUP_CODE === 'CASH' && (
                            <label className="mt-1" key={index}>
                              <Field
                                className="mr-1"
                                name={item.C_CODE}
                                component="input"
                                type="checkbox"
                                checked={_.some(
                                  orderCheck,
                                  (o) => o === item.C_CODE
                                )}
                                onChange={_handleChange}
                              />
                              {item.C_NAME}
                            </label>
                          )}
                        </>
                      ))}
                  </div>
                  {(!glLimitFunc || !glLimitFunc.length) && (
                    <span className="text-danger fz-13">
                      {t('txt-no-data')}
                    </span>
                  )}
                </div>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddAccountLimitedModal = reduxForm({
  form: 'addAccLimitedModalformDVHC',
  enableReinitialize: true,
})(AddAccountLimitedModal);

const selector = formValueSelector('addAccLimitedModalformDVHC');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getLimitFunction = makeGetLimitedService();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountLimitUpd = makeGetAccountLimitUpd();

  const { formAccountCode, formNote } = selector(
    state,
    'formAccountCode',
    'formNote'
  );

  return {
    token: getToken(state),
    glLimitFunc: getLimitFunction(state),
    accDetail: getAccountSingle(state),
    accLimitUpd: getAccountLimitUpd(state),

    formAccountCode,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddAccountLimitedModal)
);
