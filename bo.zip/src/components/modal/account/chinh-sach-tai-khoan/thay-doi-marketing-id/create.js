import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNewInput from 'components/input/renderNewInput';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranch from 'components/input/renderSuggestBranch';
import RenderSuggestPolicyCode from 'components/input/renderSuggestPolicyCode';
import RenderSuggestSubBranch from 'components/input/renderSuggestSubBranch';
import {
  accountChangeInforUpdRequest,
  accountChangeInforUpdSuccess,
  singleUserFrontRequest,
  singleUserFrontSuccess
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccGroup,
  makeGetAccountChangeInforUpd,
  makeGetAccountCreditType,
  makeGetAccountSingle,
  makeGetChannelType,
  makeGetCustType,
  makeGetGenderType,
  makeGetNationalType,
  makeGetSingleUserFront,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { _diff2Date, formatDate, stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '950px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const validate = (values) => {
  const errors = {};
  const { formEffDate } = values;
  const _date = formatDate(new Date(), '/', 'dmy');

  if (
    formEffDate &&
    _diff2Date(formEffDate, _date) < 0
  ) {
    errors.formEffDate = `Ngày không hợp lệ`;
  }
  return errors;
};

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateChangeMarketingId(props) {
  const {
    t,
    token,
    glAccCreditType,
    onClose,
    accChangeInforUpd,
    handleSubmit,
    submitting,
    glCustType,
    glChannelType,
    glNationalType,
    glAccGroup,
    sysSystemInfo,
    formBranch,
    formSubBranch,
    singleUserFront,
    formMKTNew,
    _date
  } = props;
  const dispatch = useDispatch();
  const preAccChangeSaleUpd = usePrevious(accChangeInforUpd);
  const preFormBranch = usePrevious(formBranch);
  const preFormSubBranch = usePrevious(formSubBranch);
  const [checkSubmit, setCheckSubmit] = React.useState(false);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(singleUserFrontSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formMKTNew && formMKTNew.length === 4) {
      _handleCheckMKTNew();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMKTNew]);


  React.useEffect(() => {
    if (accChangeInforUpd && !_.isEqual(accChangeInforUpd, preAccChangeSaleUpd)) {
      _handleToast(`${t('txt-change-marketing-id-success')}`, 'success');
      dispatch(accountChangeInforUpdSuccess(null));
      onClose();
    }
  }, [accChangeInforUpd]);

  React.useEffect(() => {
    if (formBranch && !_.isEqual(formBranch, preFormBranch)) {
      dispatch(
        change(
          'CreateChangeMarketingId', 'formSubBranch', ' '
        )
      );
      dispatch(
        change(
          'CreateChangeMarketingId', 'formMktId', ' '
        )
      );
    }
  }, [formBranch]);

  React.useEffect(() => {
    if (formSubBranch && !_.isEqual(formSubBranch, preFormSubBranch)) {
      dispatch(
        change(
          'CreateChangeMarketingId', 'formMktId', ' '
        )
      );
    }
  }, [formSubBranch]);

  function initForm() {
    const _date = sysSystemInfo
      ? stringToDate(sysSystemInfo?.C_T_DATE, 'dmy')
      : new Date();
    //_date?.setDate(_date?.getDate() + 1);

    dispatch(
      change(
        'CreateChangeMarketingId',
        'formEffDate',
        formatDate(_date, '/', 'dmy')
      )
    );
  }

  function _handleCheckMKTNew() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMKTNew,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }


  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-change-marketing-id')} </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionUpdate();
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        TYPE: 'MARKETING',
        BRANCH_CODE: props?.formBranch || "",
        SUB_BRANCH_CODE: props?.formSubBranch || "",
        MARKETING_ID: props?.formMktId || "",
        CHANNEL_CODE: props?.formChannel || "",
        CUSTOMER_TYPE: props?.formCustType || "",
        NATIONAL_TYPE: props?.formNaType || "",
        GROUP_CODE: props?.formCustGroup || "",
        STAFF_FLAG: props?.formCompany || -1,
        OPEN_FROM: props?.formOFromDate || "",
        OPEN_TO: props?.formOToDate || "",
        BIRTH_FROM: props?.formSFromDate || "",
        BIRTH_TO: props?.formSToDate || "",
        CUSTOMER_CODE: props?.formCustCode || "",
        ACCOUNT_CREDIT_TYPE: props?.formCredit || -1,
        GENDER: props?.formGender || "",
        POLICY_CODE: props?.formComboCurrent || "",
        MARKETING_NEW: props?.formMKTNew || "",
        BRANCH_NEW: singleUserFront?.C_BRANCH_CODE || "",
        SUB_BRANCH_NEW: singleUserFront?.C_SUB_BRANCH_CODE || "",
        EFFECT_DATE: props?.formEffDate || "",
        CONTENT: props?.formNote || "",
      },
    };

    dispatch(accountChangeInforUpdRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-change-marketing-id')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>

        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <div style={{ gridColumn: '1/4' }} className="my-1 d-flex mx-2">
              <span className="color-thm mr-auto fz-13">
                {t('txt-apply-info')}
              </span>
            </div>
            {
              checkSubmit && (
                <span className="color-thm mr-auto fz-13 mx-2">
                  {t('txt-apply-info-check-input')}
                </span>
              )
            }
            <FormAdd onSubmit={handleSubmit(submit)}>
              <Form.Group>
                <Form.Label>{t('lab-branch')}</Form.Label>
                <Field
                  name="formBranch"
                  className="form-control input-order"
                  component={RenderSuggestBranch}
                  index={3}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <Field
                  name="formSubBranch"
                  className="form-control input-order"
                  component={RenderSuggestSubBranch}
                  branchCode={formBranch}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Field
                  name="formMktId"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                  branchCode={formBranch}
                  subBranchCode={formSubBranch}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-channel')}</Form.Label>
                <Field
                  name="formChannel"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glChannelType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-type')}</Form.Label>
                <Field
                  name="formCustType"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glCustType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-national-type')}</Form.Label>
                <Field
                  name="formNaType"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glNationalType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-group')}</Form.Label>
                <Field
                  name="formCustGroup"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glAccGroup}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-company-employee')}</Form.Label>
                <Field
                  name="formCompany"
                  className="form-control w-100"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="1">Có</option>
                  <option value="0">Không</option>
                </Field>
              </Form.Group>

              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-open-from-date')}
                </Form.Label>
                <Field
                  name="formOFromDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formOToDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-s-from-date')}
                </Form.Label>
                <Field
                  name="formSFromDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formSToDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-cust-code')}</Form.Label>
                <Field
                  name="formCustCode"
                  className="form-control input-order"
                  component={RenderNewInput}
                  index={2}

                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-credit')}</Form.Label>
                <Field
                  name="formCredit"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glAccCreditType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-gender')}</Form.Label>
                <Field
                  name="formGender"
                  className="form-control w_170"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="M">Nam</option>
                  <option value="F">Nữ</option>
                </Field>
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-fee-combo-code-current')}</Form.Label>
                <Field
                  name="formComboCurrent"
                  className="form-control input-order"
                  component={RenderSuggestPolicyCode}
                  active={-1}
                  index={3}

                />
              </Form.Group>

              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto fz-13">
                  {t('txt-new-infor-marketing-id')}
                </span>
              </div>

              <span />
              <Form.Group>
                <Form.Label>{t('txt-new-marketing-id')}</Form.Label>
                <span className="text-danger">*</span>
                <Field
                  name="formMKTNew"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                  validate={[required]}
                  active={1}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-marketing-name')}
                </Form.Label>
                <Form.Control
                  value={singleUserFront?.C_FRONT_USER_NAME || ''}

                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-effective-date')}
                </Form.Label>
                <span className="text-danger">*</span>
                <Field
                  name="formEffDate"
                  className="w-90"
                  component={RenderSelectDate}
                  validate={[required]}
                />
              </Form.Group>

              <span />
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order"
                  component={RenderArea}
                  rows={2}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal >
  );
}

CreateChangeMarketingId = reduxForm({
  form: 'CreateChangeMarketingId',
  enableReinitialize: true,
  validate
})(CreateChangeMarketingId);

const selector = formValueSelector('CreateChangeMarketingId');

const mapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getAccountSingle = makeGetAccountSingle();
  const getSingleUserFront = makeGetSingleUserFront();
  const getAccountChangeInforUpd = makeGetAccountChangeInforUpd();
  const getChannelType = makeGetChannelType();
  const getCustType = makeGetCustType();
  const getNationalType = makeGetNationalType();
  const getAccountCreditType = makeGetAccountCreditType();
  const getAccountGroup = makeGetAccGroup();
  const getGenderType = makeGetGenderType();

  const mapStateToProps = (state) => {
    const {
      formMktId,
      formBranch,
      formSubBranch,
      formChannel,
      formCustType,
      formNaType,
      formCustGroup,
      formCompany,
      formOFromDate,
      formOToDate,
      formSFromDate,
      formSToDate,
      formCustCode,
      formCredit,
      formGender,
      formComboCurrent,
      formMKTNew,
      formEffDate,
      formMKTName,
      formNote,
    } = selector(
      state,
      'formMktId',
      'formBranch',
      'formSubBranch',
      'formChannel',
      'formCustType',
      'formNaType',
      'formCustGroup',
      'formCompany',
      'formOFromDate',
      'formOToDate',
      'formSFromDate',
      'formSToDate',
      'formCustCode',
      'formCredit',
      'formGender',
      'formComboCurrent',
      'formMKTNew',
      'formEffDate',
      'formMKTName',
      'formNote'
    );

    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
      accDetail: getAccountSingle(state),
      singleUserFront: getSingleUserFront(state),
      accChangeInforUpd: getAccountChangeInforUpd(state),
      glChannelType: getChannelType(state),
      glCustType: getCustType(state),
      glNationalType: getNationalType(state),
      glAccCreditType: getAccountCreditType(state),
      glAccGroup: getAccountGroup(state),
      genderType: getGenderType(state),
      formBranch,
      formSubBranch,
      formMktId,
      formChannel,
      formCustType,
      formNaType,
      formCustGroup,
      formCompany,
      formOFromDate,
      formOToDate,
      formSFromDate,
      formSToDate,
      formCustCode,
      formCredit,
      formGender,
      formComboCurrent,
      formMKTNew,
      formEffDate,
      formMKTName,
      formNote
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  translate('translations')(CreateChangeMarketingId)
);
