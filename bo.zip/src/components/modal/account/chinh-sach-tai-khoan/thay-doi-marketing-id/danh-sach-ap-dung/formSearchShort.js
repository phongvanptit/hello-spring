import RenderSearchShort from 'components/input/inputSearchShort';
import * as _ from 'lodash';
import { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';

import IconExcel from 'assets/img/icon/ms-excel.png';
import {
  accountListChangeInforDelSuccess,
  accountListChangeInforSearchRequest
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetListAccountChangeInforDel
} from 'lib/selector';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';
function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,

    dataSearch,
    setDataSearch,
    listAccountChangeInforDel,
  } = props;

  const preListAccountChangeInforDel = usePrevious(listAccountChangeInforDel);

  useEffect(() => {
    setTimeout(() => {
      _handleBlur();
    }, 200);
  }, []);

  useEffect(() => {
    if (
      (listAccountChangeInforDel && !_.isEqual(listAccountChangeInforDel, preListAccountChangeInforDel))
    ) {
      _handleBlur();
      _handleToast(t('txt-del-acc-change-marketing-id-success'), 'success');
      dispatch(accountListChangeInforDelSuccess(null));
    }
  }, [listAccountChangeInforDel]);

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function _handleBlur() {
    let _params = Object.assign({}, dataSearch);
    _params.data.ACCOUNT_CODE = props?.formCode;

    dispatch(accountListChangeInforSearchRequest(_params));

    setDataSearch && setDataSearch(_params);
  }

  return (
    <FormFlexCenter className="w-100">
      <div className="d-flex align-items-center mr-auto">
      </div>
      <Form.Group>
        <Field
          name="formCode"
          className="form-control"
          placeholder={t('txt-acc-code')}
          component={RenderSearchShort}
          onBlur={_handleBlur}
          clickSearch={_handleBlur}
        />
      </Form.Group>
      <ExportExcel>
        <img src={IconExcel} alt="" />
      </ExportExcel>
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortDSAP',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortDSAP');

const makeMapStateToProps = () => {
  const getListAccountChangeInforDel = makeGetListAccountChangeInforDel();
  const mapStateToProps = (state) => {

    const { formCode, formMarIdReceiveCode, } = selector(state, 'formCode', 'formMarIdReceiveCode',);

    return {
      listAccountChangeInforDel: getListAccountChangeInforDel(state),
      formCode,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
