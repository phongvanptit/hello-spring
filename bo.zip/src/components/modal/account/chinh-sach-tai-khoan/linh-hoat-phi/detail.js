import RenderInput from 'components/input/renderInput';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';

import { makeGetCashUpdFlexibleFee, makeGetToken } from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashSingleFlexibleFeeRequest,
  cashSingleFlexibleFeeSuccess,
  cashUpdFlexibleFeeRequest,
  cashUpdFlexibleFeeSuccess,
} from 'containers/cash/actions';
import { makeGetAccountSingle } from 'lib/selector';
import { StringToDouble, _diff2Date } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { cashDelFlexibleFeeRequest,cashApprFlexibleFeeRequest,cashUnApprFlexibleFeeRequest } from 'containers/cash/actions';
import { cashRejFlexibleFeeRequest } from 'containers/cash/actions';
import { makeGetCashDelFlexibleFee,makeGetCashUnApprFlexibleFee,makeGetCashApprFlexibleFee } from 'lib/selector';
import { makeGetCashRejFlexibleFee } from 'lib/selector';
import { makeGetCashSingleFlexibleFee } from 'lib/selector';
import { stringToDate } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;
//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formFromDate, formToDate } = values;

  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function DetailLinhHoatPhi(props) {
  const dispatch = useDispatch();
  const {
    token,
    cashUpdFlexibleFee,
    cashDelFlexibleFee,
    cashRejFlexibleFee,
    cashSingleFlexibleFee,
    cashApprFlexibleFee,
    cashUnApprFlexibleFee,
    accDetail,
    id,
    accRight,

    formAccountCode,
    formFromDate,
  } = props;

  const preCashUpdFlexibleFee = usePrevious(cashUpdFlexibleFee);
  const preCashDelFlexibleFee = usePrevious(cashDelFlexibleFee);
  const preCashRejFlexibleFee = usePrevious(cashRejFlexibleFee);
  const preCashSingFlexibleFee = usePrevious(cashSingleFlexibleFee);
  const preCashApprFlexibleFee = usePrevious(cashApprFlexibleFee);
  const preCashUnApprFlexibleFee = usePrevious(cashUnApprFlexibleFee);

  useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(cashSingleFlexibleFeeSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      cashSingleFlexibleFee &&
      !_.isEqual(cashSingleFlexibleFee, preCashSingFlexibleFee)
    ) {
      initForm();
    }
  }, [cashSingleFlexibleFee]);

  function initForm() {
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formAccountCode',
        cashSingleFlexibleFee?.C_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formFromDate',
        cashSingleFlexibleFee?.C_FROM_DATE
      )
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formToDate',
        cashSingleFlexibleFee?.C_TO_DATE
      )
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formRateFeeStock',
        cashSingleFlexibleFee?.C_CUSTODY_FEE_RATE_SHARE
      )
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formRateFeeBond',
        cashSingleFlexibleFee?.C_CUSTODY_FEE_RATE_BOND
      )
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formRateFeeCCQ',
        cashSingleFlexibleFee?.C_CUSTODY_FEE_RATE_FUND
      )
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formListShareCode',
        cashSingleFlexibleFee?.C_LIST_SHARE_CODE
      )
    );
    dispatch(
      change('detailLinhHoatPhiForm', 'formNote', cashSingleFlexibleFee?.C_NOTE)
    );
    dispatch(
      change(
        'detailLinhHoatPhiForm',
        'formChkStatus',
        cashSingleFlexibleFee?.C_STATUS === 1
      )
    );
  }

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else {
      dispatch(accountSingleSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (
      cashUpdFlexibleFee &&
      !_.isEqual(cashUpdFlexibleFee, preCashUpdFlexibleFee)
    ) {
      _handleToast(t('txt-upd-entry-success'), 'success');
      dispatch(cashUpdFlexibleFeeSuccess(null));
      onClose();
    }
  }, [cashUpdFlexibleFee]);

  useEffect(() => {
    if (
      (cashDelFlexibleFee &&
        !_.isEqual(cashDelFlexibleFee, preCashDelFlexibleFee)) ||
      (cashRejFlexibleFee &&
        !_.isEqual(cashRejFlexibleFee, preCashRejFlexibleFee)) ||
        (cashApprFlexibleFee &&
          !_.isEqual(cashApprFlexibleFee, preCashApprFlexibleFee)) ||
        (cashUnApprFlexibleFee &&
          !_.isEqual(cashUnApprFlexibleFee, preCashUnApprFlexibleFee))
    ) {
      onClose();
    }
  }, [cashDelFlexibleFee, cashRejFlexibleFee,cashApprFlexibleFee,cashUnApprFlexibleFee]);

  function handleGetSingle() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(cashSingleFlexibleFeeRequest(params));
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    handleConfirm('update');
  }

  function handleConfirm(actionName) {
    console.log(actionName);
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'update'
                ? t('txt-upd-entry')
                : actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                ? t('txt-appr-entry')
                : actionName === 'reject'
                ? t('txt-reject-entry')
                : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'update':
                    handleActionApprove();
                    break;
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionAppr();
                    break;
                  case 'unapprove':
                    handleActionUnAppr();
                      break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    console.log(rejectText);
                    if (!rejectText) return;
                    handleActionReject(rejectText);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        ID: id,
        ACCOUNT_CODE: props?.formAccountCode,
        CUSTODY_FEE_RATE_SHARE: StringToDouble(props?.formRateFeeStock),
        CUSTODY_FEE_RATE_BOND: StringToDouble(props?.formRateFeeBond),
        CUSTODY_FEE_RATE_FUND: StringToDouble(props?.formRateFeeCCQ),
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,
        LIST_SHARE_CODE: props?.formListShareCode,
        STATUS: props?.formChkStatus ? 1 : 0,
        APPROVE_STATUS: 'CHUA_DUYET',
        CONTENT: props?.formNote,
      },
    };

    dispatch(cashUpdFlexibleFeeRequest(params));
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
      },
    };

    dispatch(cashDelFlexibleFeeRequest(params));
  }

  function handleActionAppr() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
        STATUS: 'DA_DUYET',
      },
    };

    dispatch(cashApprFlexibleFeeRequest(params));
  }

  function handleActionUnAppr() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
        STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(cashUnApprFlexibleFeeRequest(params));
  }

  function handleActionReject() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
      },
    };

    dispatch(cashRejFlexibleFeeRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 100px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-flexible-fee')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
              {t('txt-acc-info')}
            </p>
            <FormAdd>
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-acc-number')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formAccountCode"
                  className="form-control "
                  classParent="w-100"
                  validate={[required]}
                  component={renderNewInputAccount}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_ID + ' - ' + accDetail?.C_MARKETING_NAME}
                  disabled
                />
              </Form.Group>
              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('txt-fee-deposit-info')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-from-date')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-to-date')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                  // minDate={
                  //   formFromDate && !formFromDate.includes('_')
                  //     ? formFromDate
                  //     : null
                  // }
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-deposit-stock')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formRateFeeStock"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  allowDecimal
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-deposit-bond')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formRateFeeBond"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  allowDecimal
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-deposit-ccq')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formRateFeeCCQ"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  allowDecimal
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-stock-code-not-fee')}</Form.Label>
                <Field
                  name="formListShareCode"
                  className="form-control input-order fz-13"
                  component={RenderInput}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>
                  {t('txt-note')}
                  {/* <span className="text-danger">*</span> */}
                </Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                  //validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <label style={{ paddingTop: '30px' }}>
                  <Field
                    name="formChkStatus"
                    component="input"
                    type="checkbox"
                  />
                  {t('txt-active')}
                </label>
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_APPROVE === 1 && (
                  <>
                  {cashSingleFlexibleFee?.C_APPROVE_STATUS === 'CHUA_DUYET' && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('approve')}
                        className="w_125 ml-2 info"
                      >
                        Duyệt
                      </BtnSubmit>
                    )}
                    {cashSingleFlexibleFee?.C_APPROVE_STATUS === 'DA_DUYET' && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unapprove')}
                        className="w_125 ml-2 danger"
                      >
                        Hủy duyệt
                      </BtnSubmit>
                    )}
                  </>
                )}
                {accRight?.C_UPDATE === 1 && (
                  <>
                     {cashSingleFlexibleFee?.C_APPROVE_STATUS === 'CHUA_DUYET' && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 ml-2 danger"
                      >
                        {t('bnt-del-entry')}
                      </BtnSubmit>
                    )}
                    {cashSingleFlexibleFee?.C_APPROVE_STATUS === 'CHUA_DUYET' && (
                    <BtnSubmit
                      type="submit"
                      disabled={submitting}
                      className="w_125 ml-2"
                    >
                      {t('bnt-edit-entry')}
                    </BtnSubmit>
                    )}
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailLinhHoatPhi = reduxForm({
  form: 'detailLinhHoatPhiForm',
  enableReinitialize: true,
  validate,
})(DetailLinhHoatPhi);

const selector = formValueSelector('detailLinhHoatPhiForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdFlexibleFee = makeGetCashUpdFlexibleFee();
  const getCashDelFlexibleFee = makeGetCashDelFlexibleFee();
  const getCashRejFlexibleFee = makeGetCashRejFlexibleFee();
  const getCashApprFlexibleFee = makeGetCashApprFlexibleFee();
  const getCashUnApprFlexibleFee = makeGetCashUnApprFlexibleFee();
  const getCashSingleFlexibleFee = makeGetCashSingleFlexibleFee();
  const {
    formAccountCode,
    formFromDate,
    formToDate,
    formRateFeeStock,
    formRateFeeBond,
    formRateFeeCCQ,
    formListShareCode,
    formNote,
    formChkStatus,
  } = selector(
    state,
    'formAccountCode',
    'formFromDate',
    'formToDate',
    'formRateFeeStock',
    'formRateFeeBond',
    'formRateFeeCCQ',
    'formListShareCode',
    'formNote',
    'formChkStatus'
  );
  const cashSingleFlexibleFee = getCashSingleFlexibleFee(state);
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdFlexibleFee: getCashUpdFlexibleFee(state),
    cashDelFlexibleFee: getCashDelFlexibleFee(state),
    cashRejFlexibleFee: getCashRejFlexibleFee(state),
    cashApprFlexibleFee: getCashApprFlexibleFee(state),
    cashUnApprFlexibleFee: getCashUnApprFlexibleFee(state),
    cashSingleFlexibleFee,

    formAccountCode,
    formFromDate,
    formToDate,
    formRateFeeStock,
    formRateFeeBond,
    formRateFeeCCQ,
    formListShareCode,
    formNote,
    formChkStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailLinhHoatPhi)
);
