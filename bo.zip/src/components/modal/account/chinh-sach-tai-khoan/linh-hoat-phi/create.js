import RenderInput from 'components/input/renderInput';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';

import { makeGetCashUpdFlexibleFee, makeGetToken } from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashUpdFlexibleFeeRequest,
  cashUpdFlexibleFeeSuccess,
} from 'containers/cash/actions';
import { makeGetAccountSingle } from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { StringToDouble } from 'utils';
import { _diff2Date } from 'utils';
import { stringToDate } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;
//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formFromDate, formToDate } = values;

  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function CreateLinhHoatPhi(props) {
  const dispatch = useDispatch();
  const {
    token,
    cashUpdFlexibleFee,
    accDetail,
    formAccountCode,
    formFromDate,
  } = props;

  const preCashUpdFlexibleFee = usePrevious(cashUpdFlexibleFee);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else {
      dispatch(accountSingleSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (
      cashUpdFlexibleFee &&
      !_.isEqual(cashUpdFlexibleFee, preCashUpdFlexibleFee)
    ) {
      _handleToast(t('txt-add-entry-success'), 'success');
      dispatch(cashUpdFlexibleFeeSuccess(null));
      onClose();
    }
  }, [cashUpdFlexibleFee]);

  function initForm() {
    dispatch(change('createLinhHoatPhiForm', 'formChkStatus', true));
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_DEPOSIT_FEE_PRIVATE',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: props?.formAccountCode,
        CUSTODY_FEE_RATE_SHARE: StringToDouble(props?.formRateFeeStock),
        CUSTODY_FEE_RATE_BOND: StringToDouble(props?.formRateFeeBond),
        CUSTODY_FEE_RATE_FUND: StringToDouble(props?.formRateFeeCCQ),
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,
        LIST_SHARE_CODE: props?.formListShareCode,
        STATUS: props?.formChkStatus ? 1 : 0,
        APPROVE_STATUS: 'CHUA_DUYET',
        CONTENT: props?.formNote,
      },
    };

    dispatch(cashUpdFlexibleFeeRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: t('txt-notice'),
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 100px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-create-flexible-fee')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
              {t('txt-acc-info')}
            </p>
            <FormAdd>
              <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-acc-number')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formAccountCode"
                  className="form-control "
                  classParent="w-100"
                  validate={[required]}
                  component={renderNewInputAccount}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={(accDetail?.C_MARKETING_ID || '') + ' - ' + (accDetail?.C_MARKETING_NAME || '')}
                  disabled
                />
              </Form.Group>
              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('txt-fee-deposit-info')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-from-date')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-to-date')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  validate={required}
                  // minDate={
                  //   formFromDate && !formFromDate.includes('_')
                  //     ? formFromDate
                  //     : null
                  // }
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-deposit-stock')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formRateFeeStock"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  allowDecimal
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-deposit-bond')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formRateFeeBond"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  allowDecimal
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-deposit-ccq')}{' '}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formRateFeeCCQ"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  allowDecimal
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-stock-code-not-fee')}</Form.Label>
                <Field
                  name="formListShareCode"
                  className="form-control input-order fz-13"
                  component={RenderInput}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>
                  {t('txt-note')}
                  {/* <span className="text-danger">*</span> */}
                </Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                  //validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <label style={{ paddingTop: '30px' }}>
                  <Field
                    name="formChkStatus"
                    component="input"
                    type="checkbox"
                  />
                  {t('txt-active')}
                </label>
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateLinhHoatPhi = reduxForm({
  form: 'createLinhHoatPhiForm',
  enableReinitialize: true,
  validate,
})(CreateLinhHoatPhi);

const selector = formValueSelector('createLinhHoatPhiForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdFlexibleFee = makeGetCashUpdFlexibleFee();

  const {
    formAccountCode,
    formFromDate,
    formToDate,
    formRateFeeStock,
    formRateFeeBond,
    formRateFeeCCQ,
    formListShareCode,
    formNote,
    formChkStatus,
  } = selector(
    state,
    'formAccountCode',
    'formFromDate',
    'formToDate',
    'formRateFeeStock',
    'formRateFeeBond',
    'formRateFeeCCQ',
    'formListShareCode',
    'formNote',
    'formChkStatus'
  );

  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdFlexibleFee: getCashUpdFlexibleFee(state),
    formAccountCode,
    formFromDate,
    formToDate,
    formRateFeeStock,
    formRateFeeBond,
    formRateFeeCCQ,
    formListShareCode,
    formNote,
    formChkStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateLinhHoatPhi)
);
