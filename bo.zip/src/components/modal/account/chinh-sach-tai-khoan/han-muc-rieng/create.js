import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React from 'react';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt } from 'utils';
import RenderArea from 'components/input/renderArea';
import RenderDatePicker from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accountSetLimitsUpdRequest,
  accountSetLimitsUpdSuccess,
} from 'containers/account/actions';
import {
  makeGetAccSetLimitsUpd,
  makeGetGLBusinessSetLimits,
  makeGetToken,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { _diff2Date, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import { change } from 'redux-form';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;x;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formEffectiveDate, formExpireDate } = values;

  if (
    formEffectiveDate &&
    _diff2Date(formatDate(new Date(), '/', 'dmy'), formEffectiveDate) > 0
  ) {
    errors.formEffectiveDate = `Ngày không hợp lệ`;
  }
  if (
    formEffectiveDate &&
    formExpireDate &&
    _diff2Date(formEffectiveDate, formExpireDate) > 0
  ) {
    errors.formExpireDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function AddSetLimitsModal(props) {
  const dispatch = useDispatch();

  const { token, glBusinessSetLimits, accSetLimitsUpd } = props;
  const preAccSetLimitsUpd = usePrevious(accSetLimitsUpd);

  React.useEffect(() => {
    initForm();
  }, []);

  function initForm() {
    dispatch(change('addAccSetLimitsForm', 'formActive', true));
  }

  React.useEffect(() => {
    if (accSetLimitsUpd && !_.isEqual(accSetLimitsUpd, preAccSetLimitsUpd)) {
      _handleToast(`${t('txt-add-set-limits-success')}`, 'success');
      dispatch(accountSetLimitsUpdSuccess(null));
      onClose();
    }
  }, [accSetLimitsUpd]);

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-set-limits')}</p>

            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleUpdateAction();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleUpdateAction() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        BUSINESS_CODE: props?.formBusiness,
        ACCOUNT_CODE: props?.formAccountCode,
        CASH_VALUE: StringToInt(props?.formValue),
        EFFECT_DATE: props?.formEffectiveDate,
        EXPIRE_DATE: props?.formExpireDate,
        CONTENT: props?.formNote,
        ACTIVE: props?.formActive ? 1 : 0,
      },
    };

    dispatch(accountSetLimitsUpdRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-create-new-set-limits')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>{t('txt-bus')}</Form.Label>
                <Field
                  name="formBusiness"
                  className="form-control input-order"
                  component={RenderNormalSelect}
                  opts={glBusinessSetLimits}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formAccountCode"
                  className="form-control input-order"
                  component={renderNewInputAccount}
                  validate={[required, length7]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-value')}</Form.Label>
                <Field
                  name="formValue"
                  className="form-control input-order"
                  component={RenderInputMask}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-effective-date')}<span className="text-danger">*</span></Form.Label>
                <Field
                  name="formEffectiveDate"
                  className="form-control input-order"
                  component={RenderDatePicker}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-expire-date')}</Form.Label>
                <Field
                  name="formExpireDate"
                  className="form-control input-order"
                  component={RenderDatePicker}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/3' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                />
              </Form.Group>
              <Form.Group className="d-grid" style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-status')}</Form.Label>
                  <Form.Label>
                    <Field
                      name="formActive"
                      component={'input'}
                      type="checkbox"
                      className="mr-2"
                    />
                    {t('txt-active')}
                  </Form.Label>
                </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddSetLimitsModal = reduxForm({
  form: 'addAccSetLimitsForm',
  enableReinitialize: true,
  validate,
})(AddSetLimitsModal);

const selector = formValueSelector('addAccSetLimitsForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getGLBusinessSetLimits = makeGetGLBusinessSetLimits();
  const getAccSetLimitsUpd = makeGetAccSetLimitsUpd();

  const {
    formBusiness,
    formAccountCode,
    formValue,
    formEffectiveDate,
    formExpireDate,
    formNote,
    formActive,
  } = selector(
    state,
    'formBusiness',
    'formAccountCode',
    'formValue',
    'formEffectiveDate',
    'formExpireDate',
    'formNote',
    'formActive'
  );

  return {
    token: getToken(state),
    glBusinessSetLimits: getGLBusinessSetLimits(state),
    accSetLimitsUpd: getAccSetLimitsUpd(state),

    formBusiness,
    formAccountCode,
    formValue,
    formEffectiveDate,
    formExpireDate,
    formNote,
    formActive
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddSetLimitsModal)
);
