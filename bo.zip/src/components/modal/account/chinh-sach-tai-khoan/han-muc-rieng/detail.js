import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React from 'react';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt } from 'utils';

import RenderArea from 'components/input/renderArea';
import RenderDatePicker from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accountSetLimitsUpdRequest,
  accountSetLimitsUpdSuccess,
} from 'containers/account/actions';
import {
  makeGetAccSetLimitsUpd,
  makeGetGLBusinessSetLimits,
  makeGetToken,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { _diff2Date, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import { makeGetAccSetLimitsDel } from 'lib/selector';
import { makeGetAccSetLimitsAppr } from 'lib/selector';
import { accountSetLimitsSingleSuccess } from 'containers/account/actions';
import { accountSetLimitsSingleRequest } from 'containers/account/actions';
import { makeGetAccSetLimitsSingle } from 'lib/selector';
import { accountSetLimitsDelRequest } from 'containers/account/actions';
import { accountSetLimitsApprRequest } from 'containers/account/actions';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;x;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formEffectiveDate, formExpireDate } = values;

  if (
    formEffectiveDate &&
    _diff2Date(formatDate(new Date(), '/', 'dmy'), formEffectiveDate) > 0
  ) {
    errors.formEffectiveDate = `Ngày không hợp lệ`;
  }
  if (
    formEffectiveDate &&
    formExpireDate &&
    _diff2Date(formEffectiveDate, formExpireDate) > 0
  ) {
    errors.formExpireDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function DetailSetLimitsModal(props) {
  const dispatch = useDispatch();

  const {
    id,
    token,
    accRight,
    glBusinessSetLimits,

    accSetLimitsUpd,
    accSetLimitsDel,
    accSetLimitsAppr,
    accSetLimitsSingle,
  } = props;
  const preAccSetLimitsUpd = usePrevious(accSetLimitsUpd);
  const preAccSetLimitsSingle = usePrevious(accSetLimitsSingle);
  const preAccSetLimitsDel = usePrevious(accSetLimitsDel);
  const preAccSetLimitsAppr = usePrevious(accSetLimitsAppr);

  React.useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountSetLimitsSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      accSetLimitsSingle &&
      !_.isEqual(accSetLimitsSingle, preAccSetLimitsSingle)
    ) {
      initForm();
    }
  }, [accSetLimitsSingle]);

  React.useEffect(() => {
    if (accSetLimitsUpd && !_.isEqual(accSetLimitsUpd, preAccSetLimitsUpd)) {
      _handleToast(`${t('txt-upd-set-limits-success')}`, 'success');
      dispatch(accountSetLimitsUpdSuccess(null));
      handleGetSingle();
    }
  }, [accSetLimitsUpd]);

  React.useEffect(() => {
    if (
      (accSetLimitsDel && !_.isEqual(accSetLimitsDel, preAccSetLimitsDel)) ||
      (accSetLimitsAppr && !_.isEqual(accSetLimitsAppr, preAccSetLimitsAppr))
    ) {
      onClose();
    }
  }, [accSetLimitsDel, accSetLimitsAppr]);

  function handleGetSingle() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accountSetLimitsSingleRequest(params));
  }

  function initForm() {
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formBusiness',
        accSetLimitsSingle?.C_BUSINESS_CODE
      )
    );
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formAccountCode',
        accSetLimitsSingle?.C_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formValue',
        accSetLimitsSingle?.C_CASH_VALUE
      )
    );
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formEffectiveDate',
        accSetLimitsSingle?.C_EFFECT_DATE
      )
    );
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formExpireDate',
        accSetLimitsSingle?.C_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formNote',
        accSetLimitsSingle?.C_CONTENT
      )
    );
    dispatch(
      change(
        'detailAccSetLimitsForm',
        'formActive',
        accSetLimitsSingle?.C_ACTIVE === 1 ? true : false
      )
    );
  }

  function submit(values) {
    handleConfirm('update');
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'update'
                ? t('txt-upd-set-limits')
                : actionName === 'delete'
                ? t('txt-del-set-limits')
                : actionName === 'approve'
                ? t('txt-appr-set-limits')
                : ''}
            </p>

            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'update':
                    handleActionUpdate();
                    break;
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        ITEM_ID: id,
        BUSINESS_CODE: props?.formBusiness,
        ACCOUNT_CODE: props?.formAccountCode,
        CASH_VALUE: StringToInt(props?.formValue),
        EFFECT_DATE: props?.formEffectiveDate,
        EXPIRE_DATE: props?.formExpireDate,
        CONTENT: props?.formNote,
        ACTIVE: props?.formActive ? 1 : 0,
      },
    };

    dispatch(accountSetLimitsUpdRequest(params));
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
      },
    };

    dispatch(accountSetLimitsDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_PRIVATE',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: id,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(accountSetLimitsApprRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-set-limits')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>{t('txt-bus')}</Form.Label>
                <Field
                  name="formBusiness"
                  className="form-control input-order"
                  component={RenderNormalSelect}
                  opts={glBusinessSetLimits}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formAccountCode"
                  className="form-control input-order"
                  component={renderNewInputAccount}
                  validate={[required, length7]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-value')}</Form.Label>
                <Field
                  name="formValue"
                  className="form-control input-order"
                  component={RenderInputMask}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-effective-date')}<span className="text-danger">*</span></Form.Label>
                <Field
                  name="formEffectiveDate"
                  className="form-control input-order"
                  component={RenderDatePicker}
                  validate={required}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-expire-date')}</Form.Label>
                <Field
                  name="formExpireDate"
                  className="form-control input-order"
                  component={RenderDatePicker}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/3' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                />
              </Form.Group>
              <Form.Group className="d-grid" style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-status')}</Form.Label>
                  <Form.Label>
                    <Field
                      name="formActive"
                      component={'input'}
                      type="checkbox"
                      className="mr-2"
                    />
                    {t('txt-active')}
                  </Form.Label>
                </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_APPROVE === 1 &&
                  accSetLimitsSingle?.C_STATUS === 'CHUA_DUYET' && (
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('approve')}
                      className="w_125 ml-2 info"
                    >
                      {t('txt-appr')}
                    </BtnSubmit>
                  )}
                {accRight?.C_UPDATE === 1 && (
                  <>
                    {accSetLimitsSingle?.C_STATUS === 'CHUA_DUYET' && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 ml-2 danger"
                      >
                        {t('txt-del')}
                      </BtnSubmit>
                    )}
                    <BtnSubmit
                      type="submit"
                      disabled={submitting}
                      className="w_125 ml-2"
                    >
                      {t('txt-edit')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailSetLimitsModal = reduxForm({
  form: 'detailAccSetLimitsForm',
  enableReinitialize: true,
  validate,
})(DetailSetLimitsModal);

const selector = formValueSelector('detailAccSetLimitsForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getGLBusinessSetLimits = makeGetGLBusinessSetLimits();
  const getAccSetLimitsUpd = makeGetAccSetLimitsUpd();
  const getAccSetLimitsSingle = makeGetAccSetLimitsSingle();
  const getAccSetLimitsDel = makeGetAccSetLimitsDel();
  const getAccSetLimitsAppr = makeGetAccSetLimitsAppr();

  const {
    formBusiness,
    formAccountCode,
    formValue,
    formEffectiveDate,
    formExpireDate,
    formNote,
    formActive,
  } = selector(
    state,
    'formBusiness',
    'formAccountCode',
    'formValue',
    'formEffectiveDate',
    'formExpireDate',
    'formNote',
    'formActive',
  );

  return {
    token: getToken(state),
    glBusinessSetLimits: getGLBusinessSetLimits(state),
    accSetLimitsSingle: getAccSetLimitsSingle(state),
    accSetLimitsUpd: getAccSetLimitsUpd(state),
    accSetLimitsDel: getAccSetLimitsDel(state),
    accSetLimitsAppr: getAccSetLimitsAppr(state),

    formBusiness,
    formAccountCode,
    formValue,
    formEffectiveDate,
    formExpireDate,
    formNote,
    formActive,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailSetLimitsModal)
);
