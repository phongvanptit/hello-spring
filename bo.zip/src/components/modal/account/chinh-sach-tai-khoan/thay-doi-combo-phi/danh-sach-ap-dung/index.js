import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
  accountChangeInforSingleRequest,
  accountChangeInforSingleSuccess,
  accountListChangeInforDelRequest,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountChangeInforSingle,
  makeGetListAccountChangeInfor,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { Button, Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { BtnClose, GroupButton } from 'utils/styledComponent';
import FormSearch from './formSearch';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '950px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailDSAPComboFee(props) {
  const {
    t,
    id,
    token,
    onClose,
    listAccountChangeInfor,
    accRight,
    changeAccountInforSingle
  } = props;
  const dispatch = useDispatch();
  const [checkAll, setCheckAll] = React.useState(false);
  const [orderCheck, setOrderCheck] = React.useState([]);
  const [page, setPage] = React.useState(1);
  const [recordPerPage, setRecordPerPage] = React.useState(10);
  const preChangeAccountInforSingle = usePrevious(changeAccountInforSingle);


  React.useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountChangeInforSingleSuccess(null));
    };
  }, []);


  React.useEffect(() => {
    if (
      changeAccountInforSingle &&
      !_.isEqual(changeAccountInforSingle, preChangeAccountInforSingle)
    ) {
      initForm();
    }
  }, [changeAccountInforSingle]);

  function initForm() {
    dispatch(
      change('DetailDSAPComboFee', 'formComboNew', changeAccountInforSingle?.C_POLICY_NEW)
    );

    dispatch(
      change('DetailDSAPComboFee', 'formEffDate', changeAccountInforSingle?.C_EFFECT_DATE)
    );

    dispatch(
      change('DetailDSAPComboFee', 'formEffToDate', changeAccountInforSingle?.C_EXPIRE_DATE)
    );

    dispatch(
      change('DetailDSAPComboFee', 'formComboOver', changeAccountInforSingle?.C_POLICY_BACK)
    );

  }



  function handleGetSingle() {
    if (!id) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };
    dispatch(accountChangeInforSingleRequest(params));
  }

  function _handleNextPage(step) {
    setPage(step);
  }

  function _handleChangeCheckAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(listAccountChangeInfor, 'PK_CHANGE_DETAIL');
      setOrderCheck(allFunc);
    }
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }
  function handleDel(value) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel(value);
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_CHANGE_DETAIL',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: value,
      },
    };
    dispatch(accountListChangeInforDelRequest(params));
    setCheckAll(false);
    setOrderCheck([]);
  }


  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded "
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-list-acc-change-detail-combo-fee')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <div>
          <StyleContainer>
            <FormAdd>
              <Form.Group>
                <Form.Label>{t('txt-fee-combo-code-new')}</Form.Label>
                <Field
                  name="formComboNew"
                  className="form-control input-order"
                  component={RenderInput}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-effective-date')}
                </Form.Label>
                <Field
                  name="formEffDate"
                  className="w-90"
                  component={RenderSelectDate}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formEffToDate"
                  className="w-90"
                  component={RenderSelectDate}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-fee-combo-code-over')}</Form.Label>
                <Field
                  name="formComboOver"
                  className="form-control input-order"
                  component={RenderInput}
                  disabled
                />
              </Form.Group>
            </FormAdd>
          </StyleContainer>
        </div>
        <div className="w-100 d-flex flex-column custom-tabs-content my-3">
          <FormSearch
            handleToast={_handleToast}
            page={page}
            recordPerPage={recordPerPage}
            id={id}
          />
          <StyleContainer className="w-100 mt-2">
            <PerfectScrollbar style={{ maxHeight: '550px', width: '100%' }}>
              <Table bordered>
                <thead>
                  <tr>
                    <th style={{ width: '26px' }}>
                      <input
                        type="checkbox"
                        value={checkAll}
                        onChange={_handleChangeCheckAll}
                        checked={checkAll}
                      />
                    </th>
                    <th>{t('txt-order')}</th>
                    <th>{t('txt-acc-number')}</th>
                    <th>{t('txt-cust-name')}</th>
                    <th>{t('txt-open-acc-date')}</th>
                    <th>{t('txt-fee-combo-current')}</th>
                    <th>{t('txt-action')}</th>
                  </tr>
                </thead>
                <tbody>
                  {listAccountChangeInfor &&
                    listAccountChangeInfor.map((item) => (
                      <tr
                        key={item.ROW_NUM}
                        className={
                          _.some(orderCheck, (o) => o === item.PK_CHANGE_DETAIL)
                            ? 'row-checked'
                            : ''
                        }
                      >
                        <td className="text-center">
                          <input
                            type={'checkbox'}
                            name={item.PK_CHANGE_DETAIL}
                            onChange={_handleChange}
                            checked={_.some(
                              orderCheck,
                              (o) => o === item.PK_CHANGE_DETAIL
                            )}
                          />
                        </td>
                        <td className="text-center">
                          {item.ROW_NUM}
                        </td>
                        <td>
                          {item.C_ACCOUNT_CODE}
                        </td>
                        <td className="text-center">{item.C_ACCOUNT_NAME}</td>
                        <td className="text-center">{item.C_OPEN_DATE}</td>
                        <td className="text-center">{item.C_POLICY_CODE}</td>
                        <td className="text-center p-0 w_85">
                          <GroupButton>
                          {item?.C_STATUS === 'CHUA_DUYET' && (
                            <a
                              title={t('txt-del')}
                              onClick={() => handleDel(item.PK_CHANGE_DETAIL)}
                            >
                              <IconTrash />
                            </a>
                          )}
                          </GroupButton>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </Table >
            </PerfectScrollbar>
            {(!listAccountChangeInfor || !listAccountChangeInfor.length) && (
              <NodataSearch name={t('txt-list-acc-change-detail-combo-fee')} />
            )}
            <div className="mt-3 d-flex justify-content-end">
              {orderCheck && !!orderCheck.length && (
                <Button
                  variant="danger"
                  className="mr-auto"
                  onClick={() => handleDel(orderCheck.join(','))}
                  disabled={accRight?.C_UPDATE !== 1}
                >
                  {t('bnt-del-entry')}
                </Button>
              )}
              <Paging
                page={page}
                nextPage={_handleNextPage}
                recordPerPage={recordPerPage}
                setRecordPerPage={setRecordPerPage}
                total={
                  (listAccountChangeInfor &&
                    !!listAccountChangeInfor.length &&
                    listAccountChangeInfor[0].C_TOTAL_RECORD) ||
                  0
                }
              />
            </div>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>

            </div>
          </StyleContainer>
        </div>

      </div>
    </ReactModal >
  );
}

DetailDSAPComboFee = reduxForm({
  form: 'DetailDSAPComboFee',
  enableReinitialize: true,
})(DetailDSAPComboFee);

const selector = formValueSelector('DetailDSAPComboFee');

const mapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getListAccountChangeInfor = makeGetListAccountChangeInfor();
  const getChangeAccountInforSingle = makeGetAccountChangeInforSingle();

  const mapStateToProps = (state) => {

    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
      listAccountChangeInfor: getListAccountChangeInfor(state),
      changeAccountInforSingle: getChangeAccountInforSingle(state),
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  translate('translations')(DetailDSAPComboFee)
);
