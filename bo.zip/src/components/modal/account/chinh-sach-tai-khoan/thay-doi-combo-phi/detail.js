import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNewInput from 'components/input/renderNewInput';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranch from 'components/input/renderSuggestBranch';
import RenderSuggestPolicyCode from 'components/input/renderSuggestPolicyCode';
import RenderSuggestSubBranch from 'components/input/renderSuggestSubBranch2';
import {
  accountChangeInforSingleRequest,
  accountChangeInforSingleSuccess,
  accountChangeInforUpdRequest,
  accountChangeInforUpdSuccess
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccGroup,
  makeGetAccountChangeInforSingle,
  makeGetAccountChangeInforUpd,
  makeGetAccountCreditType,
  makeGetAccountSingle,
  makeGetChannelType,
  makeGetCustType,
  makeGetGenderType,
  makeGetNationalType,
  makeGetSingleUserFront,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { _diff2Date, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import { frontListUserSearchRequest } from 'containers/user-management/actions';
import {
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
  
import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
const length7 = lengthRequired(7);
const length4 = lengthRequired(4);

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '950px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formEffDate } = values;
  const _date = formatDate(new Date(), '/', 'dmy');
  // _date?.setDate(_date?.getDate() + 1);

  if (
    formEffDate &&
    _diff2Date(formEffDate, _date) < 0
  ) {
    errors.formEffDate = `Ngày không hợp lệ`;
  }

  return errors;
};


function DetailChangeComboFeeForm(props) {
  const {
    t,
    id,
    token,
    glAccCreditType,
    onClose,
    accChangeInforUpd,
    handleSubmit,
    submitting,
    glCustType,
    glChannelType,
    glNationalType,
    glAccGroup,
    changeAccountInforSingle,
    formBranch,
    formSubBranch,
    formMktId,
  } = props;
  const dispatch = useDispatch();
  const preAccChangeSaleUpd = usePrevious(accChangeInforUpd);
  const preFormBranch = usePrevious(formBranch);
  const preFormSubBranch = usePrevious(formSubBranch);
  const preChangeAccountInforSingle = usePrevious(changeAccountInforSingle);

  React.useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountChangeInforSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formMktId) {
      _handleCheck();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMktId]);

  function _handleCheck() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };

    dispatch(singleUserFrontRequest(params));
  }

  React.useEffect(() => {
    if (
      changeAccountInforSingle &&
      !_.isEqual(changeAccountInforSingle, preChangeAccountInforSingle)
    ) {
      initForm();
    }
  }, [changeAccountInforSingle]);

  React.useEffect(() => {
    if (accChangeInforUpd && !_.isEqual(accChangeInforUpd, preAccChangeSaleUpd)) {
      _handleToast(`${t('txt-change-combo-fee-success')}`, 'success');
      dispatch(accountChangeInforUpdSuccess(null));
    }
  }, [accChangeInforUpd]);
 
  React.useEffect(() => {
    if (formBranch && !_.isEqual(formBranch, preFormBranch)) {
      dispatch(
        change(
          'DetailChangeComboFeeForm', 'formSubBranch', ''
        )
      );
      dispatch(
        change(
          'DetailChangeComboFeeForm', 'formMktId', ''
        )
      );
    }
  }, [formBranch]);

  React.useEffect(() => {
    if (formSubBranch && !_.isEqual(formSubBranch, preFormSubBranch)) {
      dispatch(
        change(
          'DetailChangeComboFeeForm', 'formMktId', ''
        )
      );
    }
  }, [formSubBranch]);

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accountChangeInforSingleRequest(params));
  }


  function initForm() {

    dispatch(
      change('DetailChangeComboFeeForm', 'formBranch', changeAccountInforSingle?.C_BRANCH_CODE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formSubBranch', changeAccountInforSingle?.C_SUB_BRANCH_CODE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formMktId', changeAccountInforSingle?.C_MARKETING_ID)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formChannel', changeAccountInforSingle?.C_CHANNEL_CODE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formCustType', changeAccountInforSingle?.C_CUSTOMER_TYPE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formNaType', changeAccountInforSingle?.C_NATIONAL_TYPE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formCustGroup', changeAccountInforSingle?.C_GROUP_CODE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formCompany', changeAccountInforSingle?.C_STAFF_FLAG)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formOFromDate', changeAccountInforSingle?.C_OPEN_FROM)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formOToDate', changeAccountInforSingle?.C_OPEN_TO)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formSFromDate', changeAccountInforSingle?.C_BIRTH_FROM)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formSToDate', changeAccountInforSingle?.C_BIRTH_TO)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formCustCode', changeAccountInforSingle?.C_CUSTOMER_CODE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formCredit', changeAccountInforSingle?.C_ACCOUNT_CREDIT_TYPE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formGender', changeAccountInforSingle?.C_GENDER)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formComboCurrent', changeAccountInforSingle?.C_POLICY_CODE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formComboNew', changeAccountInforSingle?.C_POLICY_NEW)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formEffDate', changeAccountInforSingle?.C_EFFECT_DATE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formEffToDate', changeAccountInforSingle?.C_EXPIRE_DATE)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formComboOver', changeAccountInforSingle?.C_POLICY_BACK)
    );

    dispatch(
      change('DetailChangeComboFeeForm', 'formNote', changeAccountInforSingle?.C_CONTENT)
    );
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-upd-change-combo-fee')} </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionUpdate();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: id,
        TYPE: 'POLICY',
        BRANCH_CODE: props?.formBranch || "",
        SUB_BRANCH_CODE: props?.formSubBranch || "",
        MARKETING_ID: props?.formMktId || "",
        CHANNEL_CODE: props?.formChannel || "",
        CUSTOMER_TYPE: props?.formCustType || "",
        NATIONAL_TYPE: props?.formNaType || "",
        GROUP_CODE: props?.formCustGroup || "",
        STAFF_FLAG: props?.formCompany || -1,
        OPEN_FROM: props?.formOFromDate || "",
        OPEN_TO: props?.formOToDate || "",
        BIRTH_FROM: props?.formSFromDate || "",
        BIRTH_TO: props?.formSToDate || "",
        CUSTOMER_CODE: props?.formCustCode || "",
        ACCOUNT_CREDIT_TYPE: props?.formCredit || -1,
        GENDER: props?.formGender || "",
        POLICY_CODE: props?.formComboCurrent || "",
        POLICY_NEW: props?.formComboNew || "",
        EFFECT_DATE: props?.formEffDate || "",
        EXPIRE_DATE: props?.formEffToDate || "",
        POLICY_BACK: props?.formComboOver || "",
        CONTENT: props?.formNote || "",
      },
    };

    dispatch(accountChangeInforUpdRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-change-detail-combo-fee')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>

        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <div style={{ gridColumn: '1/4' }} className="my-1 d-flex mx-2">
              <span className="color-thm mr-auto fz-13">
                {t('txt-apply-info')}
              </span>
            </div>
            <FormAdd onSubmit={handleSubmit(submit)}>
              <Form.Group>
                <Form.Label>{t('lab-branch')}</Form.Label>
                <Field
                  name="formBranch"
                  className="form-control input-order"
                  component={RenderSuggestBranch}
                  index={3}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <Field
                  name="formSubBranch"
                  className="form-control input-order"
                  component={RenderSuggestSubBranch}
                  branchCode={formBranch}
                  formChange = {formBranch}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Field
                  name="formMktId"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                  branchCode={formBranch}
                  subBranchCode={formSubBranch}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-channel')}</Form.Label>
                <Field
                  name="formChannel"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glChannelType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-type')}</Form.Label>
                <Field
                  name="formCustType"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glCustType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-national-type')}</Form.Label>
                <Field
                  name="formNaType"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glNationalType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-group')}</Form.Label>
                <Field
                  name="formCustGroup"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glAccGroup}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-company-employee')}</Form.Label>
                <Field
                  name="formCompany"
                  className="form-control w-100"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="1">Có</option>
                  <option value="0">Không</option>
                </Field>
              </Form.Group>

              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-open-from-date')}
                </Form.Label>
                <Field
                  name="formOFromDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formOToDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-s-from-date')}
                </Form.Label>
                <Field
                  name="formSFromDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix">
                  {t('txt-to-date')}
                </Form.Label>
                <Field
                  name="formSToDate"
                  className="w-90"
                  component={RenderSelectDate}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-cust-code')}</Form.Label>
                <Field
                  name="formCustCode"
                  className="form-control input-order"
                  component={RenderNewInput}
                  index={2}

                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-credit')}</Form.Label>
                <Field
                  name="formCredit"
                  className="form-control w_170 "
                  component={RenderNormalSelect}
                  opts={glAccCreditType}
                  placeholder="-- Tất cả --"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-gender')}</Form.Label>
                <Field
                  name="formGender"
                  className="form-control w_170"
                  component="select"
                >
                  <option value="">-- Tất cả --</option>
                  <option value="M">Nam</option>
                  <option value="F">Nữ</option>
                </Field>
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-fee-combo-code-current')}</Form.Label>
                <Field
                  name="formComboCurrent"
                  className="form-control input-order"
                  component={RenderSuggestPolicyCode}
                  active={-1}
                  index={3}

                />
              </Form.Group>

              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto fz-13">
                  {t('txt-new-combo-fee')}
                </span>
              </div>

              <span />
              <Form.Group>
                <Form.Label>{t('txt-fee-combo-code-new')}</Form.Label>
                <span className="text-danger">*</span>

                <Field
                  name="formComboNew"
                  className="form-control input-order"
                  component={RenderSuggestPolicyCode}
                  validate={[required]}
                  active={1}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-effective-date')}
                </Form.Label>
                <span className="text-danger">*</span>
                <Field
                  name="formEffDate"
                  className="w-90"
                  component={RenderSelectDate}
                  validate={[required]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-to-date')}
                </Form.Label>
                <span className="text-danger">*</span>

                <Field
                  name="formEffToDate"
                  className="w-90"
                  component={RenderSelectDate}
                  validate={[required]}

                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-fee-combo-code-over')}</Form.Label>
                {/* <span className="text-danger">*</span> */}

                <Field
                  name="formComboOver"
                  className="form-control input-order"
                  component={RenderSuggestPolicyCode}
                  active={1}
                  //validate={[required]}

                />
              </Form.Group>

              <span />
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order"
                  component={RenderArea}
                  rows={2}
                />
              </Form.Group>
              <span />
              <div className='d-flex mt-2' style={{ gridColumn: '1/5', gap: '5px 20px' }} >
                <div className='d-flex flex-column' >
                  <Form.Label>
                    {t('txt-creator')}
                    {': '}
                    {changeAccountInforSingle?.C_CREATOR_CODE}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-create-time')}
                    {': '}
                    {changeAccountInforSingle?.C_CREATE_TIME || ''}
                  </Form.Label>
                </div>
                <div className='d-flex flex-column'>
                  <Form.Label>
                    {t('txt-approver')}
                    {': '}
                    {changeAccountInforSingle?.C_APPROVER_CODE || ''}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-approve-time')}
                    {': '}
                    {changeAccountInforSingle?.C_APPROVE_TIME || ''}
                  </Form.Label>
                </div>
              </div>

            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal >
  );
}

DetailChangeComboFeeForm = reduxForm({
  form: 'DetailChangeComboFeeForm',
  enableReinitialize: true,
  validate
})(DetailChangeComboFeeForm);

const selector = formValueSelector('DetailChangeComboFeeForm');

const mapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getAccountSingle = makeGetAccountSingle();
  const getSingleUserFront = makeGetSingleUserFront();
  const getAccountChangeInforUpd = makeGetAccountChangeInforUpd();
  const getChannelType = makeGetChannelType();
  const getCustType = makeGetCustType();
  const getNationalType = makeGetNationalType();
  const getAccountCreditType = makeGetAccountCreditType();
  const getAccountGroup = makeGetAccGroup();
  const getGenderType = makeGetGenderType();
  const getChangeAccountInforSingle = makeGetAccountChangeInforSingle();

  const mapStateToProps = (state) => {
    const {
      formBranch,
      formSubBranch,
      formMktId,
      formChannel,
      formCustType,
      formNaType,
      formCustGroup,
      formCompany,
      formOFromDate,
      formOToDate,
      formSFromDate,
      formSToDate,
      formCustCode,
      formCredit,
      formGender,
      formComboCurrent,
      formComboNew,
      formEffDate,
      formEffToDate,
      formComboOver,
      formNote,
    } = selector(
      state,
      'formMktId',
      'formBranch',
      'formSubBranch',
      'formChannel',
      'formCustType',
      'formNaType',
      'formCustGroup',
      'formCompany',
      'formOFromDate',
      'formOToDate',
      'formSFromDate',
      'formSToDate',
      'formCustCode',
      'formCredit',
      'formGender',
      'formComboCurrent',
      'formComboNew',
      'formEffDate',
      'formEffToDate',
      'formComboOver',
      'formNote'
    );

    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
      accDetail: getAccountSingle(state),
      accChangeInforUpd: getAccountChangeInforUpd(state),
      glChannelType: getChannelType(state),
      glCustType: getCustType(state),
      glNationalType: getNationalType(state),
      glAccCreditType: getAccountCreditType(state),
      glAccGroup: getAccountGroup(state),
      genderType: getGenderType(state),
      sysSystemInfo: getSystemInfo(state),
      changeAccountInforSingle: getChangeAccountInforSingle(state),
      formBranch,
      formSubBranch,
      formMktId,
      formChannel,
      formCustType,
      formNaType,
      formCustGroup,
      formCompany,
      formOFromDate,
      formOToDate,
      formSFromDate,
      formSToDate,
      formCustCode,
      formCredit,
      formGender,
      formComboCurrent,
      formComboNew,
      formEffDate,
      formEffToDate,
      formComboOver,
      formNote
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  translate('translations')(DetailChangeComboFeeForm)
);
