import RenderAccountCreditType from 'components/input/renderAccountCreditType';
import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNewInputMkt from 'components/input/renderNewInputMkt';
import {
  accountChangeSaleUpdRequest,
  accountChangeSaleUpdSuccess,
  accountSingleRequest,
  accountSingleSuccess,
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import { makeGetSystemInfo } from 'lib/selector';
import {
  makeGetAccountChangeSaleUpd,
  makeGetAccountCreditType,
  makeGetAccountSingle,
  makeGetSingleUserFront,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { _diff2Date, formatDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';

const length7 = lengthRequired(7);
const length4 = lengthRequired(4);

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateChangeIdSaleForm(props) {
  const {
    t,
    token,
    accDetail,
    formAccountCode,
    formMktId,
    glAccCreditType,
    onClose,
    accChangeSaleUpd,
    sysSystemInfo,
  } = props;
  const dispatch = useDispatch();
  const preAccChangeSaleUpd = usePrevious(accChangeSaleUpd);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(singleUserFrontSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (formMktId && formMktId.length === 4) {
      _handleCheckMKT();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMktId]);

  React.useEffect(() => {
    if (accChangeSaleUpd && !_.isEqual(accChangeSaleUpd, preAccChangeSaleUpd)) {
      _handleToast(`${t('txt-add-change-sale-success')}`, 'success');
      dispatch(accountChangeSaleUpdSuccess(null));
      onClose();
    }
  }, [accChangeSaleUpd]);

  function initForm() {
    dispatch(
      change(
        'createChangeIdSaleForm',
        'formAccountType',
        _.map(glAccCreditType, 'value')
      )
    );
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckMKT() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function submit(values) {
    if (!values?.formAccountType || !values?.formAccountType.length) {
      _handleToast(`${t('txt-chose-subAcc-change')}`, 'warning');
      return;
    }
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-change-sale')} </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionUpdate();
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CHANGE_MARKETING_ID',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: props?.formAccountCode,
        ACCOUNT_TYPE: props?.formAccountType.join(','),
        TRADING_DATE:
          sysSystemInfo?.C_T_DATE || formatDate(new Date(), '/', 'dmy'),
        MARKETING_ID_OLD: accDetail?.C_MARKETING_ID,
        BRANCH_CODE_OLD: accDetail?.C_BRANCH_CODE,
        SUB_BRANCH_CODE_OLD: accDetail?.C_SUB_BRANCH_CODE,
        MARKETING_ID_NEW: props?.formMktId,
        BRANCH_CODE_NEW: singleUserFront?.C_BRANCH_CODE,
        SUB_BRANCH_CODE_NEW: singleUserFront?.C_SUB_BRANCH_CODE,
        CONTENT: props?.formNote,
      },
    };

    dispatch(accountChangeSaleUpdRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, singleUserFront } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-change-sale')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd onSubmit={handleSubmit(submit)}>
              <Form.Group>
                <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formAccountCode"
                  className="form-control input-order"
                  component={renderNewInputAccount}
                  validate={[required, length7]}
                  index={2}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-type')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-old-marketing-id')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_ID || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-old-marketing-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_SUB_BRANCH_CODE || ''}
                  disabled
                />
              </Form.Group>
              <span />
              <Form.Label className="color-thm">
                {t('txt-subAcc-change')}
              </Form.Label>
              <Field
                name="formAccountType"
                className="form-control"
                component={RenderAccountCreditType}
                opts={glAccCreditType}
                validate={required}
              />

              <hr style={{ gridColumn: '1/5' }} />
              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0 fz-13">
                {t('txt-new-info')}
              </p>
              <Form.Group>
                <Form.Label>{t('txt-new-marketing-id')}</Form.Label>
                <Field
                  name="formMktId"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                  validate={[required, length4]}
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label>{t('txt-new-marketing-name')}</Form.Label>
                <Form.Control
                  value={singleUserFront?.C_FRONT_USER_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-new-subBranch')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={singleUserFront?.C_SUB_BRANCH_CODE || ''}
                  disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order"
                  component={RenderArea}
                  rows={2}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateChangeIdSaleForm = reduxForm({
  form: 'createChangeIdSaleForm',
  enableReinitialize: true,
})(CreateChangeIdSaleForm);

const selector = formValueSelector('createChangeIdSaleForm');

const mapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getAccCreditType = makeGetAccountCreditType();
  const getAccountSingle = makeGetAccountSingle();
  const getSingleUserFront = makeGetSingleUserFront();
  const getAccountChangeSaleUpd = makeGetAccountChangeSaleUpd();

  const mapStateToProps = (state) => {
    const { formAccountCode, formAccountType, formMktId, formNote } = selector(
      state,
      'formAccountCode',
      'formAccountType',
      'formMktId',
      'formNote'
    );

    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
      glAccCreditType: getAccCreditType(state),
      accDetail: getAccountSingle(state),
      singleUserFront: getSingleUserFront(state),
      accChangeSaleUpd: getAccountChangeSaleUpd(state),

      formAccountCode,
      formAccountType,
      formMktId,
      formNote,
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  translate('translations')(CreateChangeIdSaleForm)
);
