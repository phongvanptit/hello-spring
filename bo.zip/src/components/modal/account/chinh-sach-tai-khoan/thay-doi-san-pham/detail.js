import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNewInput from 'components/input/renderNewInput';
import RenderNewInputMkt from 'components/input/renderNewInputMkt2';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranch from 'components/input/renderSuggestBranch';
import RenderSuggestPolicyCode from 'components/input/renderSuggestPolicyCode';
import RenderSuggestSubBranch from 'components/input/renderSuggestSubBranch';
import { StringToInt, _diff2Date, formatDate, stringToDate } from 'utils';
import {
  accountChangeInforSingleRequest,
  accountChangeInforSingleSuccess,
  accountChangeInforUpdRequest,
  accountChangeInforUpdSuccess,
  singleUserFrontRequest,
  singleUserFrontSuccess,
} from 'containers/account/actions';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccGroup,
  makeGetAccountChangeInforSingle,
  makeGetAccountChangeInforUpd,
  makeGetAccountCreditType,
  makeGetAccountSingle,
  makeGetChannelType,
  makeGetCustType,
  makeGetGenderType,
  makeGetNationalType,
  makeGetSingleUserFront,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import * as _ from 'lodash';
import React from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import RenderSuggestProduct from 'components/input/renderSuggestProduct';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formEffDate } = values;
  const _date = formatDate(new Date(), '/', 'dmy');

  if (
    formEffDate &&
    _diff2Date(formEffDate, _date) < 0
  ) {
    errors.formEffDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function DetailChangeProductForm(props) {
  const [diff, setDiff] = React.useState(false);
  const {
    t,
    id,
    token,
    glAccCreditType,
    onClose,
    accChangeInforUpd,
    handleSubmit,
    submitting,
    glCustType,
    glChannelType,
    glNationalType,
    glAccGroup,
    changeAccountInforSingle,
    formBranch,
    formSubBranch,
    formMKTNew,
    singleUserFront,
    sysSystemInfo,
    accDetail,
    formAccountCode
  } = props;
  const dispatch = useDispatch();
  const preAccChangeSaleUpd = usePrevious(accChangeInforUpd);
  const preFormBranch = usePrevious(formBranch);
  const preFormSubBranch = usePrevious(formSubBranch);
  const preChangeAccountInforSingle = usePrevious(changeAccountInforSingle);

  React.useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountChangeInforSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else {
      dispatch(accountSingleSuccess(null));
    }
  }, [formAccountCode]);

  React.useEffect(() => {
    if (changeAccountInforSingle && changeAccountInforSingle?.C_EFFECT_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          changeAccountInforSingle?.C_EFFECT_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [changeAccountInforSingle]);

  React.useEffect(() => {
    if (
      changeAccountInforSingle &&
      !_.isEqual(changeAccountInforSingle, preChangeAccountInforSingle)
    ) {
      initForm();
    }
  }, [changeAccountInforSingle]);

  React.useEffect(() => {
    if (formMKTNew && formMKTNew.length === 4) {
      _handleCheckMKTNew();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMKTNew]);

  React.useEffect(() => {
    if (accChangeInforUpd && !_.isEqual(accChangeInforUpd, preAccChangeSaleUpd)) {
      _handleToast('Cập nhật thay đổi sản phẩm DVTC thành công', 'success');
      dispatch(accountChangeInforUpdSuccess(null));
    }
  }, [accChangeInforUpd]);


  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accountChangeInforSingleRequest(params));
  }

  function _handleCheckMKTNew() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMKTNew,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function initForm() {


    dispatch(
      change('DetailChangeProductForm', 'formProductOld', changeAccountInforSingle?.C_PRODUCT_CODE)
    );
    
    dispatch(
      change('DetailChangeProductForm', 'formProduct', changeAccountInforSingle?.C_PRODUCT_NEW)
    );
    
    dispatch(
      change('DetailChangeProductForm', 'formAccountCode', changeAccountInforSingle?.C_ACCOUNT_CODE)
    );

    dispatch(
      change('DetailChangeProductForm', 'formEffDate', changeAccountInforSingle?.C_EFFECT_DATE)
    );

    dispatch(
      change('DetailChangeProductForm', 'formNote', changeAccountInforSingle?.C_CONTENT)
    );
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-upd-change-marketing-id')} </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionUpdate();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_CHANGE_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: id,
        TYPE: 'PRODUCT',
        ACCOUNT_CODE: props?.formAccountCode || "",
        EFFECT_DATE: props?.formEffDate || "",
        PRODUCT_NEW: props?.formProduct || "",
        CONTENT: props?.formNote || "",
      },
    };

    dispatch(accountChangeInforUpdRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thông tin thay đổi sản phẩm DVTC</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>

        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <div style={{ gridColumn: '1/4' }} className="my-1 d-flex mx-2">
              <span className="color-thm mr-auto fz-13">
                {t('txt-apply-info')}
              </span>
            </div>
            {/* {
              checkSubmit && (
                <span className="color-thm mr-auto fz-13 mx-2">
                  {t('txt-apply-info-check-input')}
                </span>
              )
            } */}
            <FormAdd onSubmit={handleSubmit(submit)}>

            <Form.Group>
                <Form.Label className="fz-13">
                  {t('txt-acc-number')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formAccountCode"
                  className="form-control "
                  classParent="w-100"
                  validate={[required]}
                  component={renderNewInputAccount}
                  index={3}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={(accDetail?.C_MARKETING_ID || '') + ' - ' + (accDetail?.C_MARKETING_NAME || '')}
                  disabled
                />
              </Form.Group>

              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto fz-13">
                  Thông tin sản phẩm mới
                </span>
              </div>

              <span />

              <Form.Group>
                <Form.Label>Sản phẩm cũ</Form.Label>
                <Field
                    name="formProductOld"
                    className="form-control "
                    classParent="w-100"
                    component={RenderSuggestProduct}
                    validate={[required]}
                    disabled
                    index={2}
                    
                  />
              </Form.Group>

              <Form.Group>
                  <Form.Label>
                    Sản phẩm mới             
                      <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProduct"
                    className="form-control "
                    classParent="w-100"
                    component={RenderSuggestProduct}
                    validate={[required]}
                  />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13 w-fix mx-2">
                  {t('txt-effective-date')}
                </Form.Label>
                <span className="text-danger">*</span>
                <Field
                  name="formEffDate"
                  className="w-90"
                  component={RenderSelectDate}
                  validate={[required]}
                />
              </Form.Group>

              <div style={{ gridColumn: '1/4' }} className="my-1 d-flex">
                <span className="color-thm mr-auto fz-13">
                  {t('txt-new-infor-marketing-id')}
                </span>
              </div>

              <span />
              <span />
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order"
                  component={RenderArea}
                  rows={2}
                />
              </Form.Group>
              <span />
              <div className='d-flex mt-2' style={{ gridColumn: '1/5', gap: '5px 20px' }} >
                <div className='d-flex flex-column' >
                  <Form.Label>
                    {t('txt-creator')}
                    {': '}
                    {changeAccountInforSingle?.C_CREATOR_CODE}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-create-time')}
                    {': '}
                    {changeAccountInforSingle?.C_CREATE_TIME || ''}
                  </Form.Label>
                </div>
                <div className='d-flex flex-column'>
                  <Form.Label>
                    {t('txt-approver')}
                    {': '}
                    {changeAccountInforSingle?.C_APPROVER_CODE || ''}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-approve-time')}
                    {': '}
                    {changeAccountInforSingle?.C_APPROVE_TIME || ''}
                  </Form.Label>
                </div>
              </div>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {changeAccountInforSingle?.C_STATUS === 'CHUA_DUYET' &&
                  diff && (
                    <>
                      <BtnSubmit type="submit" disabled={submitting}>
                        {t('txt-accept')}
                      </BtnSubmit>
                    </>
                  )
                }

              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal >
  );
}

DetailChangeProductForm = reduxForm({
  form: 'DetailChangeProductForm',
  enableReinitialize: true,
  validate
})(DetailChangeProductForm);

const selector = formValueSelector('DetailChangeProductForm');

const mapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getAccountSingle = makeGetAccountSingle();
  const getSingleUserFront = makeGetSingleUserFront();
  const getAccountChangeInforUpd = makeGetAccountChangeInforUpd();
  const getChannelType = makeGetChannelType();
  const getCustType = makeGetCustType();
  const getNationalType = makeGetNationalType();
  const getAccountCreditType = makeGetAccountCreditType();
  const getAccountGroup = makeGetAccGroup();
  const getGenderType = makeGetGenderType();
  const getChangeAccountInforSingle = makeGetAccountChangeInforSingle();

  const mapStateToProps = (state) => {
    const {
     
      formEffDate,
      formNote,
      formAccountCode,
      formProductOld,
      formProduct
    } = selector(
      state,
      'formOToDate',
      'formEffDate',
      'formNote',
      'formAccountCode',
      'formProductOld',
      'formProduct'
    );

    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
      accDetail: getAccountSingle(state),
      accChangeInforUpd: getAccountChangeInforUpd(state),
      glChannelType: getChannelType(state),
      glCustType: getCustType(state),
      glNationalType: getNationalType(state),
      glAccCreditType: getAccountCreditType(state),
      glAccGroup: getAccountGroup(state),
      genderType: getGenderType(state),
      sysSystemInfo: getSystemInfo(state),
      changeAccountInforSingle: getChangeAccountInforSingle(state),
      singleUserFront: getSingleUserFront(state),
      
      formEffDate,
      formNote,
      formAccountCode,
      formProductOld,
      formProduct
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  translate('translations')(DetailChangeProductForm)
);
