import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNewInputMkt from 'components/input/renderNewInputMkt';
import {
  accountChangeSaleOTNUpdRequest,
  accountChangeSaleOTNUpdSuccess,
  singleUserFrontRequest,
  singleUserFrontSuccess
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountChangeSaleOTNUpd,
  makeGetAccountCreditType,
  makeGetAccountSingle,
  makeGetSingleUserFront, makeGetSystemInfo, makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useState } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { formatDate, stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';

const length7 = lengthRequired(7);
const length4 = lengthRequired(4);

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateChangeOldToNewSaleForm(props) {
  const {
    t,
    token,
    formMktIdOld,
    formMktIdNew,
    glAccCreditType,
    onClose,
    accChangeSaleOTNUpd,
    singleUserFront,
    handleSubmit,
    submitting,
    dateSystem,
    _date
  } = props;
  const dispatch = useDispatch();
  const preAccChangeSaleUpd = usePrevious(accChangeSaleOTNUpd);
  const preFormMktIdOld = usePrevious(formMktIdOld);
  const preFormMktIdNew = usePrevious(formMktIdNew);
  const [branchCodeOld, setBranchCodeOld] = useState(null);
  const [subBranchCodeOld, setSubBranchCodeOld] = useState(null);
  const [branchCodeNew, setBranchCodeNew] = useState(null);
  const [subBranchCodeNew, setSubBranchCodeNew] = useState(null);
  const [nameFrontOld, setNameFrontOld] = useState(null);
  const [nameFrontNew, setNameFrontNew] = useState(null);
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(singleUserFrontSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formMktIdOld && formMktIdOld.length === 4) {
      _handleCheckMKTOld();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMktIdOld]);

  React.useEffect(() => {
    if (singleUserFront && singleUserFront?.C_FRONT_USER_CODE === formMktIdOld) {
      setBranchCodeOld(singleUserFront?.C_BRANCH_CODE);
      setSubBranchCodeOld(singleUserFront?.C_SUB_BRANCH_CODE);
      setNameFrontOld(singleUserFront?.C_FRONT_USER_NAME)
    }
  }, [singleUserFront, formMktIdOld]);

  React.useEffect(() => {
    if (singleUserFront && singleUserFront?.C_FRONT_USER_CODE === formMktIdNew) {
      setBranchCodeNew(singleUserFront?.C_BRANCH_CODE);
      setSubBranchCodeNew(singleUserFront?.C_SUB_BRANCH_CODE);
      setNameFrontNew(singleUserFront?.C_FRONT_USER_NAME)

    }
  }, [singleUserFront, formMktIdNew]);

  console.log(singleUserFront, branchCodeOld, subBranchCodeOld);
  console.log(branchCodeNew, subBranchCodeNew);


  React.useEffect(() => {
    if (formMktIdNew && formMktIdNew.length === 4) {
      _handleCheckMKTNew();
    } else dispatch(singleUserFrontSuccess(null));
  }, [formMktIdNew]);


  React.useEffect(() => {
    if (accChangeSaleOTNUpd && !_.isEqual(accChangeSaleOTNUpd, preAccChangeSaleUpd)) {
      _handleToast(`${t('txt-add-change-sale-otn-success')}`, 'success');
      dispatch(accountChangeSaleOTNUpdSuccess(null));
      setNameFrontNew('');
      setSubBranchCodeNew('');
      setBranchCodeNew('');
      setNameFrontOld('');
      setSubBranchCodeOld('');
      setBranchCodeOld('');
      onClose();
    }
  }, [accChangeSaleOTNUpd]);

  function initForm() {
    dispatch(
      change(
        'CreateChangeOldToNewSaleForm',
        'formTransferDate',
        formatDate(_date, '/', 'dmy')
      )
    );
  }

  function _handleCheckMKTOld() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktIdOld,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function _handleCheckMKTNew() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: formMktIdNew,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-change-sale')} </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionUpdate();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_TRANSFER_MAKETING_ID',
      group: 'LIST',
      data: {
        ID: '',
        MAKETING_ID_TRANSFER: props?.formMktIdOld,
        BRANCH_CODE_TRANSFER: branchCodeOld,
        SUB_BRANCH_CODE_TRANSFER: subBranchCodeOld,
        MAKETING_ID_RECEIVE: props?.formMktIdNew,
        BRANCH_CODE_RECEIVE: branchCodeNew,
        SUB_BRANCH_CODE_RECEIVE: subBranchCodeNew,
        TRANSFER_DATE: props?.formTransferDate,
        CONTENT: props?.formNote,
      },
    };

    dispatch(accountChangeSaleOTNUpdRequest(params));
  }

  const _handleToast = (msg, type = 'success') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-change-sale-otn')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd onSubmit={handleSubmit(submit)}>
              <Form.Group>
                <Form.Label>{t('txt-old-marketing-id')}</Form.Label>
                <Field
                  name="formMktIdOld"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                  validate={[required, length4]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-old-marketing-name')}</Form.Label>
                <Form.Control
                  name='test'
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={nameFrontOld || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={subBranchCodeOld || ''}
                  disabled
                />
              </Form.Group>
              <span />
              <Form.Group>
                <Form.Label>{t('txt-new-marketing-id')}</Form.Label>
                <Field
                  name="formMktIdNew"
                  className="form-control input-order"
                  component={RenderNewInputMkt}
                  validate={[required, length4]}
                />
              </Form.Group>
              <Form.Group >
                <Form.Label>{t('txt-new-marketing-name')}</Form.Label>
                <Form.Control
                  value={nameFrontNew || ''}

                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-new-subBranch')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={subBranchCodeNew || ''}
                  disabled
                />
              </Form.Group>
              <span />
              <Form.Group
                className='w_150'
              >
                <Form.Label className="fz-13 w-fix">
                  {t('txt-from-date')}
                </Form.Label>
                <Field
                  name="formTransferDate"
                  className="form-control"
                  component={RenderSelectDate}
                  classParentName="w-100"
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order"
                  component={RenderArea}
                  rows={2}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal >
  );
}

CreateChangeOldToNewSaleForm = reduxForm({
  form: 'CreateChangeOldToNewSaleForm',
  enableReinitialize: true,
})(CreateChangeOldToNewSaleForm);

const selector = formValueSelector('CreateChangeOldToNewSaleForm');

const mapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getAccCreditType = makeGetAccountCreditType();
  const getAccountSingle = makeGetAccountSingle();
  const getSingleUserFront = makeGetSingleUserFront();
  const getAccountChangeSaleOTNUpd = makeGetAccountChangeSaleOTNUpd();

  const mapStateToProps = (state) => {
    const { formAccountCode, formAccountType, formMktIdOld, formMktIdNew, formNote, formTransferDate } = selector(
      state,
      'formAccountCode',
      'formAccountType',
      'formMktIdOld',
      'formMktIdNew',
      'formNote',
      'formTransferDate'
    );

    const sysSystemInfo = getSystemInfo(state);
    const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');

    return {
      token: getToken(state),
      sysSystemInfo: getSystemInfo(state),
      glAccCreditType: getAccCreditType(state),
      accDetail: getAccountSingle(state),
      singleUserFront: getSingleUserFront(state),
      accChangeSaleOTNUpd: getAccountChangeSaleOTNUpd(state),

      formAccountCode,
      formAccountType,
      formNote,
      formMktIdOld,
      formMktIdNew,
      formTransferDate,
      _date,
    };
  };
  return mapStateToProps;
};

export default connect(mapStateToProps)(
  translate('translations')(CreateChangeOldToNewSaleForm)
);
