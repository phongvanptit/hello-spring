import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import { accountSingleSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';

import { makeGetAccountSingle, makeGetToken } from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  accountLimitApprRequest,
  accountLimitDelRequest,
  accountLimitSingleRequest,
  accountLimitUpdRequest,
  accountSingleRequest,
} from 'containers/account/actions';
import {
  makeGetAccountLimitAppr,
  makeGetAccountLimitDel,
  makeGetAccountLimitSingle,
  makeGetAccountLimitUpd,
  makeGetLimitedService,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
ReactModal.setAppElement('#root');

const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailAccountLimitedModal(props) {
  const dispatch = useDispatch();
  const [, setCheckAll] = React.useState(false);
  const [orderCheck, setOrderCheck] = React.useState([]);
  console.log(orderCheck);

  const {
    token,
    id,
    accRight,
    formAccountCode,
    glLimitFunc,
    accDetail,
    accLimitUpd,
    accountDelete,
    accountApprove,
    accLimitSingle,
  } = props;

  const preAccInternetUpd = usePrevious(accLimitUpd);
  const preAccountDelete = usePrevious(accountDelete);
  const preAccountApprove = usePrevious(accountApprove);
  const preAccLimitSingle = usePrevious(accLimitSingle);

  React.useEffect(() => {
    handleGetSingleLimited();
    return () => {
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (accLimitSingle && !_.isEqual(accLimitSingle, preAccLimitSingle)) {
      dispatch(
        change(
          'detailAccLimitedModalform',
          'formAccountCode',
          accLimitSingle?.C_ACCOUNT_CODE
        )
      );
      dispatch(
        change(
          'detailAccLimitedModalform',
          'formNote',
          accLimitSingle?.C_CONTENT
        )
      );
      if (accLimitSingle?.FUNC || !!accLimitSingle?.FUNC.length)
        setOrderCheck(accLimitSingle?.FUNC.split(','));
    }
  }, [accLimitSingle]);

  React.useEffect(() => {
    if (accLimitUpd && !_.isEqual(accLimitUpd, preAccInternetUpd)) {
      _handleToast(`${t('txt-upd-limit-service-success')}`, 'success');
      onClose();
    }
  }, [accLimitUpd]);

  React.useEffect(() => {
    if (accountApprove && !_.isEqual(accountApprove, preAccountApprove)) {
      handleGetSingleLimited();
    }
  }, [accountApprove]);

  React.useEffect(() => {
    if (accountDelete && !_.isEqual(accountDelete, preAccountDelete)) {
      onClose();
    }
  }, [accountDelete]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeChkAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(glLimitFunc, 'C_CODE');
      setOrderCheck(allFunc);
    }
  }

  function handleGetSingleLimited() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(accountLimitSingleRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!orderCheck || !orderCheck.length) {
      _handleToast(`${t('txt-select-limited-service')}`, 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: accLimitSingle.PK_ACCOUNT_LIMITED,
        ACCOUNT_CODE: values?.formAccountCode,
        CONTENT: values?.formNote,
        FUNC: orderCheck,
      },
    };

    dispatch(accountLimitUpdRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-limit-service')
                : actionName === 'approve'
                  ? t('txt-appr-limit-service')
                  : ''}
            </p>

            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: accLimitSingle?.PK_ACCOUNT_LIMITED,
      },
    };

    dispatch(accountLimitDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_SINGLE_ACCOUNT_LIMITED',
      group: 'LIST',
      data: {
        ID: accLimitSingle?.PK_ACCOUNT_LIMITED,
      },
    };

    dispatch(accountLimitApprRequest(params));
  }

  function _handleAddCallback() { }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t, pristine } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết dịch vụ hạn chế</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                    fnAddCallback={_handleAddCallback}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-type')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-cust-care-staff')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(accDetail?.C_MARKETING_ID || '') + ' - ' + (accDetail?.C_MARKETING_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  {t('txt-limit-server')}
                </p>

                <div
                  className="d-grid grid-2"
                  style={{ gridColumn: '1/5', gap: '5px' }}
                >
                  <Form.Label style={{ gridColumn: '1/3' }}>
                    <Field
                      name="custChkAll"
                      component="input"
                      type="checkbox"
                      onChange={_handleChangeChkAll}
                    />{' '}
                    Tất cả
                  </Form.Label>
                  <div className="d-grid align-self-start">
                    {glLimitFunc &&
                      glLimitFunc.map((item, index) => (
                        <>
                          {item.C_GROUP_CODE === 'SHARE' && (
                            <label className="mt-1" key={index}>
                              <Field
                                className="mr-1"
                                name={item.C_CODE}
                                component="input"
                                type="checkbox"
                                checked={_.some(
                                  orderCheck,
                                  (o) => o === item.C_CODE
                                )}
                                onChange={_handleChange}
                              />
                              {item.C_NAME}
                            </label>
                          )}
                        </>
                      ))}
                  </div>
                  <div className="d-grid align-self-start">
                    {glLimitFunc &&
                      glLimitFunc.map((item, index) => (
                        <>
                          {item.C_GROUP_CODE === 'CASH' && (
                            <label className="mt-1" key={index}>
                              <Field
                                className="mr-1"
                                name={item.C_CODE}
                                component="input"
                                type="checkbox"
                                checked={_.some(
                                  orderCheck,
                                  (o) => o === item.C_CODE
                                )}
                                onChange={_handleChange}
                              />
                              {item.C_NAME}
                            </label>
                          )}
                        </>
                      ))}
                  </div>
                  {(!glLimitFunc || !glLimitFunc.length) && (
                    <span className="text-danger fz-13">
                      {t('txt-no-data')}
                    </span>
                  )}
                </div>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>

                <Form.Label>
                  {t('txt-creator')}: {accLimitSingle?.C_CREATOR_CODE || ''}
                </Form.Label>
                <Form.Label>
                  {t('txt-create-time')}:{' '}
                  {accLimitSingle?.C_CREATE_TIME
                    ? accLimitSingle?.C_CREATE_TIME.split(' ')[0]
                    : ''}
                </Form.Label>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              {accRight?.C_APPROVE === 1 &&
                accLimitSingle?.C_STATUS === 'CHUA_DUYET' && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('approve')}
                    className="fz-13 mr-2 success"
                  >
                    {t('txt-appr')}
                  </BtnSubmit>
                )}
              {accRight?.C_UPDATE === 1 &&
                accLimitSingle?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="fz-13 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                  </>
                )}

              {accRight?.C_UPDATE === 1 && (
                <>
                  <BtnSubmit
                    variant="primary"
                    type="submit"
                    disabled={pristine || submitting}
                    className="fz-13 ml-2"
                  >
                    {t('txt-accept')}
                  </BtnSubmit>
                </>
              )}
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailAccountLimitedModal = reduxForm({
  form: 'detailAccLimitedModalform',
  enableReinitialize: true,
})(DetailAccountLimitedModal);

const selector = formValueSelector('detailAccLimitedModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getLimitFunction = makeGetLimitedService();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountLimitUpd = makeGetAccountLimitUpd();
  const getAccountLimitAppr = makeGetAccountLimitAppr();
  const getAccountLimitDel = makeGetAccountLimitDel();
  const getAccountLimitSingle = makeGetAccountLimitSingle();

  const { formAccountCode, formNote } = selector(
    state,
    'formAccountCode',
    'formNote'
  );

  return {
    token: getToken(state),
    glLimitFunc: getLimitFunction(state),
    accDetail: getAccountSingle(state),
    accLimitUpd: getAccountLimitUpd(state),
    accountApprove: getAccountLimitAppr(state),
    accountDelete: getAccountLimitDel(state),
    accLimitSingle: getAccountLimitSingle(state),

    formAccountCode,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailAccountLimitedModal)
);
