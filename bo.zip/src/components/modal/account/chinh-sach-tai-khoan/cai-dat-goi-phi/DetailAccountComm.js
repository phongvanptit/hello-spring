import React from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import {
  accChangeCommUpdRequest,
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';

import {
  makeGetAccountChangeCommUpd,
  makeGetAccountSingle,
  makeGetCommPackage,
  makeGetToken,
  makeGetSystemInfo,
} from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import {
  accChangeCommDelRequest,
  accChangeCommSingleRequest,
} from 'containers/account/actions';
import {
  makeGetAccountChangeCommDel,
  makeGetAccountChangeCommSingle,
} from 'lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import { stringToDate, formatDate, _diff2Date } from 'utils';


ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailAccountCommModal(props) {
  const dispatch = useDispatch();
  const [diff, setDiff] = React.useState(false);
  const {
    token,
    id,
    formAccountCode,
    accDetail,
    accCommUpd,
    accCommDel,
    accRight,
    accChangeCommSingle,
    sysSystemInfo,
  } = props;
  const preAccInternetUpd = usePrevious(accCommUpd);
  const preAccCommDel = usePrevious(accCommDel);
  const preAccChangeCommSingle = usePrevious(accChangeCommSingle);

  React.useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (accCommUpd && !_.isEqual(accCommUpd, preAccInternetUpd)) {
      _handleToast(`${t('txt-upd-fee-package-success')}`, 'success');
      onClose();
    }
  }, [accCommUpd]);

  React.useEffect(() => {
    if (accCommDel && !_.isEqual(accCommDel, preAccCommDel)) {
      onClose();
    }
  }, [accCommDel]);

  React.useEffect(() => {
    if (
      accChangeCommSingle &&
      accChangeCommSingle?.C_EFFECT_DATE &&
      !_.isEqual(accChangeCommSingle, preAccChangeCommSingle)
    ) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          accChangeCommSingle?.C_EFFECT_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [accChangeCommSingle]);

  React.useEffect(() => {
    if (accChangeCommSingle && !_.isEqual(accChangeCommSingle, preAccChangeCommSingle)) {
      initForm();
    }
  }, [accChangeCommSingle]);

  function initForm() {
    dispatch(
      change('detailAccCommModalform', 'formAccountCode', accChangeCommSingle?.C_ACCOUNT_CODE)
    );
    dispatch(
      change('detailAccCommModalform', 'formCommCode', accChangeCommSingle?.C_COMM_CODE)
    );
    dispatch(
      change('detailAccCommModalform', 'formCommBack', accChangeCommSingle?.C_COMM_BACK)
    );
    dispatch(
      change('detailAccCommModalform', 'formFromDate', accChangeCommSingle?.C_EFFECT_DATE)
    );
    dispatch(
      change('detailAccCommModalform', 'formToDate', accChangeCommSingle?.C_EXPIRE_DATE)
    );
    dispatch(
      change('detailAccCommModalform', 'formNote', accChangeCommSingle?.C_CONTENT)
    );
  }


  function handleGetSingle() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_COMM_CHANGE',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(accChangeCommSingleRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!accDetail) {
      _handleToast(`${t('txt-no-data-acc')}`, 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_CHANGE',
      group: 'LIST',
      data: {
        ID: id,
        ACCOUNT_CODE: accDetail?.C_ACCOUNT_CODE,
        COMM_CODE: values?.formCommCode,
        FROM_DATE: values?.formFromDate,
        TO_DATE: values?.formToDate || '31/12/9999',
        COMMM_BACK: values?.formCommBack,
        CONTENT: values?.formNote,
      },
    };

    dispatch(accChangeCommUpdRequest(params));
  }

  function _handleAddCallback() { }

  function handleDel() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-del-fee-package')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionDel();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_COMM_CHANGE',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(accChangeCommDelRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t, glCommPackage } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-fee-package')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formAccountCode"
                  className="form-control input-order"
                  component={renderNewInputAccount}
                  validate={[required, length7]}
                  fnAddCallback={_handleAddCallback}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-type')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-care-staff')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_ID || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-package')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formCommCode"
                  className="form-control input-order "
                  component={RenderNormalSelect}
                  opts={glCommPackage}
                  validate={[required]}
                  required
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-from-date')}</Form.Label>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  startDate={formatDate(new Date(), '/', 'dmy')}
                  validate={required}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-to-date')}</Form.Label>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-fee-after-renewal')}</Form.Label>
                <Field
                  name="formCommBack"
                  className="form-control input-order "
                  component={RenderNormalSelect}
                  opts={glCommPackage}
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-creator')}: </Form.Label>
                <Form.Label className="ml-2">
                  {accChangeCommSingle?.C_CREATOR_CODE}
                </Form.Label>
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-create-time')}: </Form.Label>
                <Form.Label className="ml-2">
                  {accChangeCommSingle?.C_CREATE_TIME
                    ? accChangeCommSingle?.C_CREATE_TIME.split(' ')[0]
                    : ''}
                </Form.Label>
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              {accRight?.C_UPDATE === 1 && (
                <>
                  {diff && (
                    <BtnSubmit
                      type="button"
                      className="danger mr-2"
                      disabled={submitting}
                      onClick={() => handleDel()}
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                  )}
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-accept')}
                  </BtnSubmit>
                </>
              )}
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailAccountCommModal = reduxForm({
  form: 'detailAccCommModalform',
  enableReinitialize: true,
})(DetailAccountCommModal);

const selector = formValueSelector('detailAccCommModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getCommPackage = makeGetCommPackage();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountCommUpd = makeGetAccountChangeCommUpd();
  const getAccountCommDel = makeGetAccountChangeCommDel();
  const getAccChangeCommSingle = makeGetAccountChangeCommSingle();
  const {
    formAccountCode,
    formCommCode,
    formFromDate,
    formToDate,
    formCommBack,
    formNote,
  } = selector(
    state,
    'formAccountCode',
    'formCommCode',
    'formFromDate',
    'formToDate',
    'formCommBack',
    'formNote'
  );

  const accChangeCommSingle = getAccChangeCommSingle(state);

  return {
    token: getToken(state),
    sysSystemInfo: getSystemInfo(state),
    glCommPack: getCommPackage(state),
    accDetail: getAccountSingle(state),
    accCommUpd: getAccountCommUpd(state),
    accCommDel: getAccountCommDel(state),
    glCommPackage: getCommPackage(state),
    accChangeCommSingle,

    formAccountCode,
    formCommCode,
    formFromDate,
    formToDate,
    formCommBack,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailAccountCommModal)
);

