import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import { Form } from 'react-bootstrap';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { translate } from 'react-i18next';

import { setToast } from 'containers/client/actions';
import { accountSingleSuccess } from 'containers/account/actions';
import { accountSingleRequest } from 'containers/account/actions';
import { accChangeCommUpdRequest } from 'containers/account/actions';
import { accChangeCommUpdSuccess } from 'containers/account/actions';

import { makeGetToken } from 'lib/selector';
import { makeGetAccountSingle } from 'lib/selector';
import { makeGetAccountChangeCommUpd } from 'lib/selector';
import { makeGetCommPackage } from 'lib/selector';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { required } from 'utils/validation';
import { lengthRequired } from 'utils/validation';
import { formatDate } from 'utils';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderArea from 'components/input/renderArea';
import { makeGetSystemInfo } from 'lib/selector';
import { stringToDate } from 'utils';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddAccountCommModal(props) {
  const dispatch = useDispatch();

  const { token, formAccountCode, glCommPack, accDetail, accLimitUpd } = props;

  const preAccInternetUpd = usePrevious(accLimitUpd);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (accLimitUpd && !_.isEqual(accLimitUpd, preAccInternetUpd)) {
      _handleToast(`${t('txt-add-fee-package-success')}`, 'success');
      dispatch(accChangeCommUpdSuccess(null));
      onClose();
    }
  }, [accLimitUpd]);

  function initForm() {
    dispatch(
      change('addAccCommModalform', 'formCommCode', '001')
    );
    dispatch(
      change('addAccCommModalform', 'formCommBack', '001')
    );
    dispatch(
      change('addAccCommModalform', 'formNote', '')
    );
    dispatch(
      change('addAccCommModalform', 'formFromDate', formatDate(stringToDate(sysSystemInfo?.C_T_DATE, 'dmy'), '/', 'dmy'))
    );
  }


  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!accDetail) {
      _handleToast(`${t('txt-no-data-acc')}`, 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_COMM_CHANGE',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: accDetail?.C_ACCOUNT_CODE,
        COMM_CODE: values?.formCommCode,
        FROM_DATE: values?.formFromDate,
        TO_DATE: values?.formToDate || '31/12/9999',
        COMMM_BACK: values?.formCommBack,
        CONTENT: values?.formNote,
      },
    };

    dispatch(accChangeCommUpdRequest(params));
  }

  function _handleAddCallback() { }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t, glCommPackage, sysSystemInfo } = props;

  console.log(glCommPack);

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-fee-package')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <Form.Group>
                <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                <span className="text-danger">*</span>
                <Field
                  name="formAccountCode"
                  className="form-control input-order"
                  component={RenderNewInputAccount}
                  validate={[required, length7]}
                  fnAddCallback={_handleAddCallback}
                  index={2}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-type')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-cust-care-staff')}</Form.Label>
                <Form.Control
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_ID || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>
                  {t('txt-fee-package')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formCommCode"
                  className="form-control input-order "
                  component={RenderNormalSelect}
                  opts={glCommPackage}
                  validate={[required]}
                  required
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-from-date')}</Form.Label>
                <Field
                  name="formFromDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                  startDate={formatDate(new Date(), '/', 'dmy')}
                  validate={required}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-to-date')}</Form.Label>
                <Field
                  name="formToDate"
                  className="form-control input-order "
                  classParentName="w-100"
                  component={RenderSelectDate}
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-fee-after-renewal')}</Form.Label>
                <Field
                  name="formCommBack"
                  className="form-control input-order "
                  component={RenderNormalSelect}
                  opts={glCommPackage}
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>{t('txt-note')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  rows="2"
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-confirm')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddAccountCommModal = reduxForm({
  form: 'addAccCommModalform',
  enableReinitialize: true,
})(AddAccountCommModal);

const selector = formValueSelector('addAccCommModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCommPackage = makeGetCommPackage();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountLimitUpd = makeGetAccountChangeCommUpd();
  const getSystemInfo = makeGetSystemInfo();

  const {
    formAccountCode,
    formCommCode,
    formFromDate,
    formToDate,
    formCommBack,
    formNote,
  } = selector(
    state,
    'formAccountCode',
    'formCommCode',
    'formFromDate',
    'formToDate',
    'formCommBack',
    'formNote'
  );

  const sysSystemInfo = getSystemInfo(state);

  return {
    token: getToken(state),
    glCommPack: getCommPackage(state),
    accDetail: getAccountSingle(state),
    accLimitUpd: getAccountLimitUpd(state),
    glCommPackage: getCommPackage(state),
    formAccountCode,
    formCommCode,
    formFromDate,
    formToDate,
    formCommBack,
    formNote,
    sysSystemInfo,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddAccountCommModal)
);
