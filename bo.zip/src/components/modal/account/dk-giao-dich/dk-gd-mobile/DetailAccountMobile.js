import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  accountPhoneApproveRequest,
  accountPhoneApproveSuccess,
  accountPhoneDelRequest,
  accountPhoneDelSuccess,
  accountPhoneSingleRequest,
  accountPhoneSingleSuccess,
  accountPhoneUpdRequest,
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  makeGetAccountPhoneApprove,
  makeGetAccountPhoneDel,
  makeGetAccountPhoneSingle,
  makeGetAccountPhoneUpdate,
  makeGetAccountSingle,
  makeGetPhoneFunc,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import styled from 'styled-components';
import { StringToInt } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import RenderSelectDate from 'components/input/renderDatePicker';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailAccountMobileModal(props) {
  const dispatch = useDispatch();
  const [orderCheck, setOrderCheck] = React.useState([]);

  const {
    token,
    id,
    accRight,
    formAccountCode,
    accDetail,
    accPhoneUpd,
    accPhoneDel,
    accPhoneAppr,
    glPhoneFunc,
    accPhoneSingle,
    formTelephoneNum,
  } = props;

  const preAccPhoneSingle = usePrevious(accPhoneSingle);
  const preAccPhoneUpd = usePrevious(accPhoneUpd);
  const preAccInternetDel = usePrevious(accPhoneDel);
  const preAccInternetAppr = usePrevious(accPhoneAppr);

  React.useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountPhoneDelSuccess(null));
      dispatch(accountPhoneApproveSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(accountPhoneSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (accPhoneUpd && !_.isEqual(accPhoneUpd, preAccPhoneUpd)) {
      _handleToast(`${t('txt-upd-service-success')}`, 'success');
      onClose();
    }
  }, [accPhoneUpd]);

  React.useEffect(() => {
    if (accPhoneDel && !_.isEqual(accPhoneDel, preAccInternetDel)) {
      onClose();
    }
  }, [accPhoneDel]);

  React.useEffect(() => {
    if (accPhoneAppr && !_.isEqual(accPhoneAppr, preAccInternetAppr)) {
      handleGetSingle();
    } else dispatch(accountSingleSuccess(null));
  }, [accPhoneAppr]);

  React.useEffect(() => {
    if (accPhoneSingle && !_.isEqual(accPhoneSingle, preAccPhoneSingle)) {
      dispatch(
        change(
          'detailAccMobileModalform',
          'formAccountCode',
          accPhoneSingle?.C_ACCOUNT_CODE
        )
      );
      dispatch(
        change(
          'detailAccMobileModalform',
          'formCustomerPass',
          accPhoneSingle?.C_CUST_PASSWORD
        )
      );
      dispatch(
        change(
          'detailAccMobileModalform',
          'formTelephoneNum',
          accPhoneSingle?.C_PHONE_NUMBER
        )
      );
      dispatch(
        change(
          'detailAccMobileModalform',
          'formNote',
          accPhoneSingle?.C_CONTENT
        )
      );
      dispatch(
        change(
          'detailAccMobileModalform',
          'formStartDate',
          accPhoneSingle?.C_EFFECT_DATE
            ? accPhoneSingle?.C_EFFECT_DATE.split(' ')[0]
            : null
        )
      );
      dispatch(
        change(
          'detailAccMobileModalform',
          'formToDate',
          accPhoneSingle?.C_EXPIRE_DATE
            ? accPhoneSingle?.C_EXPIRE_DATE.split(' ')[0]
            : null
        )
      );
      dispatch(change('detailAccMobileModalform', 'formStatus', true));

      setOrderCheck(
        accPhoneSingle?.FUNC ? accPhoneSingle?.FUNC.split(',') : []
      );

      _handleCheckAccount(accPhoneSingle?.C_ACCOUNT_CODE);
    }
  }, [accPhoneSingle]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
  }

  function handleGetSingle() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_PHONE',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(accountPhoneSingleRequest(params));
  }

  function _handleCheckAccount(_accCode) {
    if (!_accCode && !formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: _accCode || formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!formTelephoneNum) {
      _handleToast(`${t('txt-no-data-mobile')}`, 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_PHONE',
      group: 'LIST',
      data: {
        ID: accPhoneSingle?.PK_ACCOUNT_PHONE,
        ACCOUNT_CODE: values?.formAccountCode,
        CUST_PASSWORD: values?.formCustomerPass,
        PHONE_NUMBER: values?.formTelephoneNum,
        EFFECT_DATE: values?.formStartDate,
        EXPIRE_DATE: values?.formToDate,
        // OWNER_PASSWORD: values?.formCustomerPass,
        DAILY_ORDER: StringToInt(values?.formOrderPerDay),
        ORDER_VOLUME: StringToInt(values?.formVolumePerOrder),
        MIN_ORDER_VALUE: StringToInt(values?.formMinValue),
        MAX_ORDER_VALUE: StringToInt(values?.formMaxValue),
        STATUS: 'CHUA_DUYET',
        CONTENT: values?.formNote,
        FUNC: orderCheck,
      },
    };

    dispatch(accountPhoneUpdRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-service')
                : actionName === 'approve'
                  ? t('txt-appr-service')
                  : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_SINGLE_ACCOUNT_PHONE',
      group: 'LIST',
      data: {
        ID: accPhoneSingle?.PK_ACCOUNT_PHONE,
      },
    };

    dispatch(accountPhoneDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_SINGLE_ACCOUNT_PHONE',
      group: 'LIST',
      data: {
        ID: accPhoneSingle?.PK_ACCOUNT_PHONE,
      },
    };

    dispatch(accountPhoneApproveRequest(params));
  }

  function _handleAddCallback() { }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t, pristine,formStartDate } = props;

  //   console.log(custDetail, glNational)

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết dịch vụ đăng ký điện thoại</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                    fnAddCallback={_handleAddCallback}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-type')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={(accDetail?.C_SUB_BRANCH_CODE || '') + ' - ' + (accDetail?.C_SUB_BRANCH_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CARD_ID || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ISSUE_DATE || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_EXPIRE_DATE || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label> {t('txt-issue-place')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ISSUE_PLACE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  {t('txt-register-info')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-password-trading-phone')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustomerPass"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Field
                    name="formTelephoneNum"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formStartDate"
                    startDate={formStartDate}
                    component={RenderSelectDate}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-to-date')}</Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formToDate"
                    component={RenderSelectDate}
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                  {t('txt-regis-service-info')}
                </p>

                <Form.Label>{t('txt-func-right')}</Form.Label>
                <Form.Group
                  className="d-flex flex-column"
                  style={{ gridColumn: '2/5' }}
                >
                  {glPhoneFunc &&
                    glPhoneFunc.map((item, index) => (
                      <label className="mt-1" key={index}>
                        <Field
                          name={item.C_CODE}
                          component="input"
                          type="checkbox"
                          checked={_.some(orderCheck, (o) => o === item.C_CODE)}
                          onChange={_handleChange}
                        />{' '}
                        {item.C_NAME}
                      </label>
                    ))}
                  {(!glPhoneFunc || !glPhoneFunc.length) && (
                    <span className="text-danger fz-13">
                      {' '}
                      {t('txt-no-data')}
                    </span>
                  )}
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>

                {/* <Form.Group className="d-flex flex-column">
                  <Form.Label>{t('txt-status')}</Form.Label>
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group> */}
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              {accRight?.C_APPROVE === 1 && accPhoneSingle?.C_STATUS === 'CHUA_DUYET' && (
                <>
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('approve')}
                    className="fz-13 ml-2 success"
                  >
                    {t('txt-appr')}
                  </BtnSubmit>
                </>
              )}
              {accRight?.C_UPDATE === 1 && accPhoneSingle?.C_STATUS === 'CHUA_DUYET' && (
                <>
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('delete')}
                    className="fz-13 w_125 danger"
                  >
                    {t('txt-del')}
                  </BtnSubmit>
                </>
              )}
              {accRight?.C_UPDATE === 1 && accPhoneSingle?.C_STATUS === 'CHUA_DUYET' && (
                <>
                 <BtnSubmit
                variant="primary"
                type="submit"
                disabled={pristine || submitting}
                className="fz-13 ml-2"
              >
                {t('txt-confirm')}
              </BtnSubmit>
                </>
              )}
              
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailAccountMobileModal = reduxForm({
  form: 'detailAccMobileModalform',
  enableReinitialize: true,
})(DetailAccountMobileModal);

const selector = formValueSelector('detailAccMobileModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getPhoneFunc = makeGetPhoneFunc();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountPhoneSingle = makeGetAccountPhoneSingle();
  const getAccountPhoneUpdate = makeGetAccountPhoneUpdate();
  const getAccountPhoneDel = makeGetAccountPhoneDel();
  const getAccountPhoneApprove = makeGetAccountPhoneApprove();

  const {
    formAccountCode,
    formCustomerPass,
    formTelephoneNum,
    formNote,
    formStatus,
    formStartDate,
    formToDate,
  } = selector(
    state,
    'formAccountCode',
    'formCustomerPass',
    'formTelephoneNum',
    'formNote',
    'formStatus',
    'formStartDate',
    'formToDate',
  );

  return {
    token: getToken(state),
    glPhoneFunc: getPhoneFunc(state),
    accDetail: getAccountSingle(state),
    accPhoneSingle: getAccountPhoneSingle(state),
    accPhoneUpd: getAccountPhoneUpdate(state),
    accPhoneDel: getAccountPhoneDel(state),
    accPhoneAppr: getAccountPhoneApprove(state),

    formAccountCode,
    formCustomerPass,
    formTelephoneNum,
    formNote,
    formStatus,
    formStartDate,
    formToDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailAccountMobileModal)
);
