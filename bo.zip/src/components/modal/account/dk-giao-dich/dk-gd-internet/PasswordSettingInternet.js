import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';

import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import { setToast } from 'containers/client/actions';

import {
  makeGetAccountInternetSingle,
  makeGetAccResetPassInternet,
  makeGetToken,
} from 'lib/selector';

import {
  accountInternetSingleRequest,
  accountInternetSingleSuccess,
  accResetPassInternetRequest,
  accResetPassInternetSuccess,
} from 'containers/account/actions';
import { Form } from 'react-bootstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import * as _ from 'lodash';
import { confirmAlert } from 'react-confirm-alert';
import { StringToInt } from 'utils';

ReactModal.setAppElement('#root');

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function PasswordSettingInternetModal(props) {
  const dispatch = useDispatch();

  const { token, accInternetSingle, id, accResetPassInternet } = props;
  const preAccResetPassInternet = usePrevious(accResetPassInternet);

  React.useEffect(() => {
    initForm();
    getSingleAccInternetDetail();
    return () => {
      dispatch(accountInternetSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (
      accResetPassInternet &&
      !_.isEqual(accResetPassInternet, preAccResetPassInternet)
    ) {
      _handleToast(t('txt-setting-pass-success'), 'success');
      dispatch(accResetPassInternetSuccess(null));
      onClose();
    }
  }, [accResetPassInternet]);

  function initForm() {
    dispatch(
      change('passSettingInternetModalform', 'formResetPass', '1')
    );
  }

  function getSingleAccInternetDetail() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_INTERNET',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(accountInternetSingleRequest(params));
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-accept-setting-pass')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionResetPass();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionResetPass() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.RESET_ACCOUNT_INTERNET',
      group: 'LIST',
      data: {
        ID: id,
        RESET_PASSWORD_FLAG: StringToInt(props?.formResetPass),
      },
    };

    dispatch(accResetPassInternetRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-setting-pass-internet')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    component="input"
                    className="form-control input-order"
                    value={accInternetSingle?.C_ACCOUNT_DEFAULT || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    component="input"
                    className="form-control input-order"
                    value={accInternetSingle?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/3' }}>
                  <Field
                    name="formResetPass"
                    component="input"
                    type="radio"
                    value="1"
                    className="cursor-pointer mr-2"
                  />
                  <label>Reset password & pin</label>
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/3' }}>
                  <Field
                    name="formResetPass"
                    className="cursor-pointer mr-2"
                    component="input"
                    type="radio"
                    value="2"
                  />
                  <label>Reset password</label>
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/3' }}>
                  <Field
                    name="formResetPass"
                    className="cursor-pointer mr-2"
                    component="input"
                    type="radio"
                    value="3"
                  />
                  <label>Reset pin</label>
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

PasswordSettingInternetModal = reduxForm({
  form: 'passSettingInternetModalform',
  enableReinitialize: true,
})(PasswordSettingInternetModal);

const selector = formValueSelector('passSettingInternetModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountInternetSingle = makeGetAccountInternetSingle();
  const getAccResetPassInternet = makeGetAccResetPassInternet();

  const { formResetPass, formPass } = selector(
    state,
    'formResetPass',
    'formPass'
  );

  return {
    token: getToken(state),
    accInternetSingle: getAccountInternetSingle(state),
    accResetPassInternet: getAccResetPassInternet(state),
    formResetPass,
    formPass,

  };
};

export default connect(mapStateToProps)(
  translate('translations')(PasswordSettingInternetModal)
);


