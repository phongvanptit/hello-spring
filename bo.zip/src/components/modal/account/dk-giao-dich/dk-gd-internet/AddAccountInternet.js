import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { change, Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { translate } from 'react-i18next';

import { setToast } from 'containers/client/actions';
import { accountSingleSuccess } from 'containers/account/actions';

import { makeGetToken } from 'lib/selector';
import { makeGetAccountSingle } from 'lib/selector';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { makeGetAuthenType } from 'lib/selector';
import { makeGetInternetFunc } from 'lib/selector';
import { makeGetAccountInternetUpd } from 'lib/selector';
import { accountInternetDelSuccess } from 'containers/account/actions';
import { accountInternetUpdSuccess } from 'containers/account/actions';
import { accountSingleRequest } from 'containers/account/actions';
import { accountInternetUpdRequest } from 'containers/account/actions';
import { Form } from 'react-bootstrap';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import { required,maxLength } from 'utils/validation';
import { lengthRequired } from 'utils/validation';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { arrAuthenType } from 'utils/const';
import RenderInput from 'components/input/renderInput';
import { validatePhone } from 'utils/validation';
import RenderArea from 'components/input/renderArea';
import PerfectScrollbar from 'react-perfect-scrollbar';
ReactModal.setAppElement('#root');
const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const maxLength10 = maxLength(10);

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddAccountInternetModal(props) {
  const dispatch = useDispatch();
  const [checkAll, setCheckAll] = React.useState(false);
  const [orderCheck, setOrderCheck] = React.useState([]);

  const {
    token,
    formAccountCode,
    glAuthenType,
    glInternetFunc,
    accDetail,
    accInternetUpd,
  } = props;

  const preAccDetail = usePrevious(accDetail);
  const preAccInternetUpd = usePrevious(accInternetUpd);

  React.useEffect(() => {
    initForm();
    return () => {
      dispatch(accountInternetDelSuccess(null));
      dispatch(accountSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (accDetail && !_.isEqual(accDetail, preAccDetail)) {
      dispatch(
        change(
          'addAccInternetModalformGd',
          'formPhoneOTP',
          accDetail?.C_CUST_MOBILE
        )
      );
    }
  }, [accDetail]);
  React.useEffect(() => {
    if (accInternetUpd && !_.isEqual(accInternetUpd, preAccInternetUpd)) {
      _handleToast(`${t('txt-add-service-success')}`, 'success');
      dispatch(accountInternetUpdSuccess(null));
      onClose();
    }
  }, [accInternetUpd]);

  function initForm() {
    dispatch(
      change('addAccInternetModalformGd', 'formEntrustAuthenType', 'O')
    );
    dispatch(
      change('addAccInternetModalformGd', 'formPhoneOTP', '')
    );
    dispatch(
      change('addAccInternetModalformGd', 'formUseWebTrading', true)
    );
    dispatch(
      change('addAccInternetModalformGd', 'formUseOTPForLogin', false)
    );
    dispatch(
      change('addAccInternetModalformGd', 'formNote', '')
    );
  }

  function _handleChangeChkAll(e) {
    const { checked } = e.target;
    console.log(e);
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(glInternetFunc, 'C_CODE');
      setOrderCheck(allFunc);
    }
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.ADD_OR_UPDATE_ACCOUNT_INTERNET',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: values?.formAccountCode,
        AUTHEN_TYPE: values?.formEntrustAuthenType,
        PHONE_NUMBER: values?.formPhoneOTP,
        REQUIRE_OTP: values?.formUseOTPForLogin ? 1 : 0,
        CONTENT: values?.formNote,
        FUNC: orderCheck,
      },
    };

    dispatch(accountInternetUpdRequest(params));
  }

  function _handleAddCallback() { }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;

  //   console.log(custDetail, glNational)

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới dịch vụ đăng ký internet</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                    fnAddCallback={_handleAddCallback}
                    index={2}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-user-type')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                    disabled
                  />
                </Form.Group> */}
                <Form.Group>
                  <Form.Label>{t('txt-nick-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-cust-care-staff')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={(accDetail?.C_MARKETING_ID || '') + ' - ' + (accDetail?.C_MARKETING_NAME || '')}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>
                    {t('txt-electronic-service')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <div className="d-flex">
                    <label>
                      <Field
                        name="formUseWebTrading"
                        component="input"
                        type="checkbox"
                        checked
                        disabled
                      />{' '}
                      Webtrading
                    </label>
                    <label className="ml-3">
                      <Field
                        name="formUseOTPForLogin"
                        component="input"
                        type="checkbox"
                      />{' '}
                      {t('txt-authen-otp-login')}
                    </label>
                  </div>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-authen-type')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formEntrustAuthenType"
                    className="form-control input-order "
                    component={RenderNormalSelect}
                    opts={
                      glAuthenType && !!glAuthenType.length
                        ? glAuthenType
                        : arrAuthenType
                    }
                    validate={[required]}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-phone-receive-otp')}</Form.Label>
                  <Field
                    name="formPhoneOTP"
                    className="form-control input-order "
                    component={RenderInput}
                    validate={[validatePhone,maxLength10]}
                  />
                </Form.Group>

                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-func-right')}
                </p>

                <Form.Group
                  className="d-grid grid-3"
                  style={{ gridColumn: '1/5', gap: '5px 10px' }}
                >
                  <label>
                    <Field
                      name="custChkAll"
                      component="input"
                      type="checkbox"
                      onChange={_handleChangeChkAll}
                    />{' '}
                    Tất cả
                  </label>
                  {glInternetFunc &&
                    glInternetFunc.map((item, index) => (
                      <label key={index}>
                        <Field
                          name={item.C_CODE}
                          component="input"
                          type="checkbox"
                          checked={_.some(orderCheck, (o) => o === item.C_CODE)}
                          onChange={_handleChange}
                        />{' '}
                        {item.C_NAME}
                      </label>
                    ))}
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddAccountInternetModal = reduxForm({
  form: 'addAccInternetModalformGd',
  enableReinitialize: true,
})(AddAccountInternetModal);

const selector = formValueSelector('addAccInternetModalformGd');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAuthenType = makeGetAuthenType();
  const getInternetFunc = makeGetInternetFunc();
  const getAccountSingle = makeGetAccountSingle();
  const getAccountInternetUpd = makeGetAccountInternetUpd();

  const {
    formAccountCode,
    formPhoneOTP,
    formEntrustAuthenType,
    formUseWebTrading,
    formUseOTPForLogin,
    formNote,
  } = selector(
    state,
    'formAccountCode',
    'formPhoneOTP',
    'formEntrustAuthenType',
    'formUseWebTrading',
    'formUseOTPForLogin',
    'formNote'
  );

  return {
    token: getToken(state),
    glAuthenType: getAuthenType(state),
    glInternetFunc: getInternetFunc(state),
    accDetail: getAccountSingle(state),
    accInternetUpd: getAccountInternetUpd(state),

    formAccountCode,
    formPhoneOTP,
    formEntrustAuthenType,
    formUseWebTrading,
    formUseOTPForLogin,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddAccountInternetModal)
);
