import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import { accountSingleSuccess } from 'containers/account/actions';
import { setToast } from 'containers/client/actions';

import { makeGetAccountSingle, makeGetToken } from 'lib/selector';

import RenderArea from 'components/input/renderArea';
import renderNewInputAccount from 'components/input/renderNewInputAccount';
import {
  limitSmsEmailNotiSingleRequest,
  limitSmsEmailNotiApproveRequest,
  limitSmsEmailNotiDelRequest,
  limitSmsEmailNotiUpdRequest,
  accountSingleRequest,
} from 'containers/account/actions';
import {
  makeLimitSmsEmailNotiAppr,
  makeLimitSmsEmailNotiDel,
  makeLimitSmsEmailNotiSingle,
  makeLimitSmsEmailNotiUpdate,
  makeGetLimitedSmsService,
} from 'lib/selector';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import RenderSelectDate from 'components/input/renderDatePicker';
import { globalLimitedSmsFuncRequest } from 'containers/global/actions';
import { globalLimitedSmsFuncSuccess } from 'containers/global/actions';
ReactModal.setAppElement('#root');

const length7 = lengthRequired(7);

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 1rem 1rem 1rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailAccountLimitedModal(props) {
  const dispatch = useDispatch();
  const [, setCheckAll] = React.useState(false);
  const [orderCheck, setOrderCheck] = React.useState([]);
  console.log(orderCheck);

  const {
    token,
    id,
    formAccountCode,
    formTypeService,
    glLimitSmsFunc,
    accDetail,
    limitSmsEmailNotiUpd,
    limitSmsEmailNotiDel,
    limitSmsEmailNotiAppr,
    limitSmsEmailNotiSingle,
    accRight
  } = props;

  const preAccUpd = usePrevious(limitSmsEmailNotiUpd);
  const preAccountDelete = usePrevious(limitSmsEmailNotiDel);
  const preAccountApprove = usePrevious(limitSmsEmailNotiAppr);
  const preAccLimitSingle = usePrevious(limitSmsEmailNotiSingle);
  const preFormTypeService = usePrevious(formTypeService);

  React.useEffect(() => {
    handleGetSingleLimited();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(globalLimitedSmsFuncSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiSingle &&
      !_.isEqual(limitSmsEmailNotiSingle, preAccLimitSingle)
    ) {
      dispatch(
        change(
          'detailAccLimitedSmsModalform',
          'formAccountCode',
          limitSmsEmailNotiSingle?.C_ACCOUNT_CODE
        )
      );
      dispatch(
        change(
          'detailAccLimitedSmsModalform',
          'formStartDate',
          limitSmsEmailNotiSingle?.C_EFFECT_DATE
            ? limitSmsEmailNotiSingle?.C_EFFECT_DATE.split(' ')[0]
            : null
        )
      );
      dispatch(
        change(
          'detailAccLimitedSmsModalform',
          'formToDate',
          limitSmsEmailNotiSingle?.C_EXPIRE_DATE
            ? limitSmsEmailNotiSingle?.C_EXPIRE_DATE.split(' ')[0]
            : null
        )
      );
      dispatch(
        change(
          'detailAccLimitedSmsModalform',
          'formTypeService',
          limitSmsEmailNotiSingle?.C_BIZ_CODE
        )
      );
      dispatch(
        change(
          'detailAccLimitedSmsModalform',
          'formNote',
          limitSmsEmailNotiSingle?.C_CONTENT
        )
      );
      if (
        limitSmsEmailNotiSingle?.C_FUNC_LIST ||
        !!limitSmsEmailNotiSingle?.C_FUNC_LIST.length
      )
        setOrderCheck(limitSmsEmailNotiSingle?.C_FUNC_LIST.split(','));
    }
  }, [limitSmsEmailNotiSingle]);

  React.useEffect(() => {
    if (limitSmsEmailNotiUpd && !_.isEqual(limitSmsEmailNotiUpd, preAccUpd)) {
      _handleToast(`${t('txt-upd-limit-service-success')}`, 'success');
      onClose();
    }
  }, [limitSmsEmailNotiUpd]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiAppr &&
      !_.isEqual(limitSmsEmailNotiAppr, preAccountApprove)
    ) {
      handleGetSingleLimited();
    }
  }, [limitSmsEmailNotiAppr]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiDel &&
      !_.isEqual(limitSmsEmailNotiDel, preAccountDelete)
    ) {
      onClose();
    }
  }, [limitSmsEmailNotiDel]);

  React.useEffect(() => {
    if (
      limitSmsEmailNotiAppr &&
      !_.isEqual(limitSmsEmailNotiAppr, preAccountApprove)
    ) {
      onClose();
    }
  }, [limitSmsEmailNotiAppr]);

  React.useEffect(() => {
    if (formTypeService && !_.isEqual(formTypeService, preFormTypeService)) {
      getLimitedSmsService();
    }
  }, [formTypeService]);

  function getLimitedSmsService() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE: `${formTypeService}_SERVICES`,
      },
    };

    dispatch(globalLimitedSmsFuncRequest(params));
  }

  function _handleChange(e) {
    const { checked, name } = e.target;
    console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
      setCheckAll(false);
    }

    setOrderCheck(xxx);
  }

  function _handleChangeChkAll(e) {
    const { checked } = e.target;
    if (!checked) {
      // uncheck all
      setCheckAll(false);
      setOrderCheck([]);
    } else {
      // check all
      setCheckAll(true);
      const allFunc = _.map(glLimitSmsFunc, 'C_CODE');
      setOrderCheck(allFunc);
    }
  }

  function handleGetSingleLimited() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(limitSmsEmailNotiSingleRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    if (!orderCheck || !orderCheck.length) {
      _handleToast(`${t('txt-select-limited-service')}`, 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        ITEM_ID: limitSmsEmailNotiSingle.PK_ACCOUNT_SMS,
        BIZ_CODE: limitSmsEmailNotiSingle.C_BIZ_CODE,
        ACCOUNT_CODE: values?.formAccountCode,
        EFFECT_DATE: values?.formStartDate,
        EXPIRE_DATE: values?.formToDate,
        CONTENT: values?.formNote,
        FUNC: orderCheck,
      },
    };

    dispatch(limitSmsEmailNotiUpdRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-limit-service')
                : actionName === 'unApprove'
                ? 'Bạn muốn hủy duyệt dịch vụ hạn chế'
                : actionName === 'approve'
                ? t('txt-appr-limit-service')
                : ''}
            </p>

            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: limitSmsEmailNotiSingle?.PK_ACCOUNT_SMS,
      },
    };

    dispatch(limitSmsEmailNotiDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: limitSmsEmailNotiSingle?.PK_ACCOUNT_SMS,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(limitSmsEmailNotiApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ACCOUNT_SMS',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: limitSmsEmailNotiSingle?.PK_ACCOUNT_SMS,
        NEW_STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(limitSmsEmailNotiApproveRequest(params));
  }

  function _handleAddCallback() {}

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const {
    handleSubmit,
    submitting,
    onClose,
    t,
    formToDate,
    formStartDate,
    pristine,
  } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết dịch vụ sms/email</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order"
                    component={renderNewInputAccount}
                    validate={[required, length7]}
                    fnAddCallback={_handleAddCallback}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-type')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACC_CREDIT_TYPE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-cust-care-staff')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_MARKETING_ID} - ${accDetail?.C_MARKETING_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                Dịch vụ đăng ký
                </p>

                <Form.Group>
                  <Form.Label>Loại dịch vụ</Form.Label>

                  <Field
                    name="formTypeService"
                    className="form-control w-100"
                    component="select"
                  >
                    <option value="SMS">Sms</option>
                    <option value="EMAIL">EMAIL</option>
                    <option value="NOTI">Notification</option>
                  </Field>
                </Form.Group>

                <hr style={{ gridColumn: '1/5' }} className="my-1" />
                <p style={{ gridColumn: '1/5' }} className="color-thm mb-0">
                Dịch vụ đăng ký
                </p>

                <div
                  className="d-grid grid-2"
                  style={{ gridColumn: '1/5', gap: '5px' }}
                >
                  <Form.Label>
                    <Field
                      name="custChkAll"
                      component="input"
                      type="checkbox"
                      onChange={_handleChangeChkAll}
                    />{' '}
                    Tất cả
                  </Form.Label>
                  {glLimitSmsFunc &&
                    glLimitSmsFunc.map((item, index) => (
                      <label className="mt-1" key={index}>
                        <Field
                          name={item.C_CODE}
                          component="input"
                          type="checkbox"
                          checked={_.some(orderCheck, (o) => o === item.C_CODE)}
                          onChange={_handleChange}
                        />{' '}
                        {item.C_NAME}
                      </label>
                    ))}
                  {(!glLimitSmsFunc || !glLimitSmsFunc.length) && (
                    <span className="text-danger fz-13">{t('No data !')}</span>
                  )}
                </div>

                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formStartDate"
                    startDate={formStartDate}
                    component={RenderSelectDate}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-to-date')}</Form.Label>
                  <Field
                    className="form-control"
                    classParentName="w-100"
                    name="formToDate"
                    component={RenderSelectDate}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>

                <Form.Label>
                  {t('txt-creator')}:{' '}
                  {limitSmsEmailNotiSingle?.C_CREATOR_CODE || ''}
                </Form.Label>
                <Form.Label>
                  {t('txt-create-time')}:{' '}
                  {limitSmsEmailNotiSingle?.C_CREATE_TIME
                    ? limitSmsEmailNotiSingle?.C_CREATE_TIME.split(' ')[0]
                    : ''}
                </Form.Label>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              {
                accRight?.C_APPROVE === 1 &&
                limitSmsEmailNotiSingle?.C_STATUS === 'CHUA_DUYET' && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('approve')}
                    className="fz-13 mr-2 success"
                  >
                    {t('txt-appr')}
                  </BtnSubmit>
                )
              }
              {
                accRight?.C_APPROVE === 1 &&
                limitSmsEmailNotiSingle?.C_STATUS === 'DA_DUYET' && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleConfirm('unApprove')}
                    className="fz-13 mr-2 success"
                  >
                    Hủy duyệt
                  </BtnSubmit>
                )
              }
              {
                accRight?.C_UPDATE === 1 &&
                limitSmsEmailNotiSingle?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    <BtnSubmit
                      type="button"
                      onClick={() => handleConfirm('delete')}
                      className="fz-13 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                  </>
                )
              }

              {accRight?.C_UPDATE === 1 && (
                <> 
              <BtnSubmit
                variant="primary"
                type="submit"
                disabled={pristine || submitting}
                className="fz-13 ml-2"
              >
                {t('txt-accept')}
              </BtnSubmit>
              </>
              )} 
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailAccountLimitedModal = reduxForm({
  form: 'detailAccLimitedSmsModalform',
  enableReinitialize: true,
})(DetailAccountLimitedModal);

const selector = formValueSelector('detailAccLimitedSmsModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getLimitedSmsService = makeGetLimitedSmsService();
  const getAccountSingle = makeGetAccountSingle();
  const getLimitSmsEmailNotiUpdate = makeLimitSmsEmailNotiUpdate();
  const getLimitSmsEmailNotiAppr = makeLimitSmsEmailNotiAppr();
  const getLimitSmsEmailNotiDel = makeLimitSmsEmailNotiDel();
  const getLimitSmsEmailNotiSingle = makeLimitSmsEmailNotiSingle();

  const {
    formAccountCode,
    formStartDate,
    formTypeService,
    formNote,
    formToDate,
  } = selector(
    state,
    'formAccountCode',
    'formStartDate',
    'formTypeService',
    'formNote',
    'formToDate'
  );

  return {
    token: getToken(state),
    glLimitSmsFunc: getLimitedSmsService(state),
    accDetail: getAccountSingle(state),
    limitSmsEmailNotiUpd: getLimitSmsEmailNotiUpdate(state),
    limitSmsEmailNotiAppr: getLimitSmsEmailNotiAppr(state),
    limitSmsEmailNotiDel: getLimitSmsEmailNotiDel(state),
    limitSmsEmailNotiSingle: getLimitSmsEmailNotiSingle(state),

    formAccountCode,
    formStartDate,
    formTypeService,
    formNote,
    formToDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailAccountLimitedModal)
);
