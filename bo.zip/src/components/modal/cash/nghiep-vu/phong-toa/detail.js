import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt } from 'utils';
import { lengthRequired, required } from 'utils/validation';

import {
  cashApprBlockRequest,
  cashDelBlockRequest,
  cashRejectBlockRequest,
  cashRejectBlockSuccess,
  cashSingleBlockRequest,
  cashSingleBlockSuccess,
  cashUnApprBlockRequest,
  cashUnApprBlockSuccess,
  cashUpdBlockRequest,
  cashUpdBlockSuccess,
} from 'containers/cash/actions';

import {
  makeCashApprBlock,
  makeCashDelBlock,
  makeCashRejectBlock,
  makeCashSingleBlock,
  makeCashUnApprBlock,
  makeCashUpdBlock,
  makeGetAccountSingle,
  makeGetToken,
} from 'lib/selector';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validateNumberExact } from 'utils/validation';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const length7 = lengthRequired(7);

function DetailPhongToaModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    onClose,
    id,
    cashUpdBlock,
    cashDelBlock,
    accDetail,
    cashSingleBlock,
    accRight,
    cashApprBlock,
    cashRejectBlock,
    cashUnApprBlock,
    formAccountCode,
  } = props;
  const preCashUpdBlock = usePrevious(cashUpdBlock);
  const preCashDelBlock = usePrevious(cashDelBlock);
  const preCashApprBlock = usePrevious(cashApprBlock);
  const preCashRejectBlock = usePrevious(cashRejectBlock);
  const preCashUnApprBlock = usePrevious(cashUnApprBlock);
  const preCashSingleBlock = usePrevious(cashSingleBlock);

  useEffect(() => {
    getSingleBlockType();
    return () => {
      dispatch(cashSingleBlockSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (cashSingleBlock && !_.isEqual(cashSingleBlock, preCashSingleBlock)) {
      initForm();
    }
  }, [cashSingleBlock]);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      // _handleCheckBalance();
    } else {
      dispatch(accountSingleSuccess(null));
      // dispatch(cashBalanceSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (cashUpdBlock && !_.isEqual(cashUpdBlock, preCashUpdBlock)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashUpdBlockSuccess(null));
      getSingleBlockType();
    }
  }, [cashUpdBlock]);

  useEffect(() => {
    if (cashApprBlock && !_.isEqual(cashApprBlock, preCashApprBlock)) {
      getSingleBlockType();
    }
  }, [cashApprBlock]);

  useEffect(() => {
    if (cashUnApprBlock && !_.isEqual(cashUnApprBlock, preCashUnApprBlock)) {
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      dispatch(cashUnApprBlockSuccess(null));
      getSingleBlockType();
    }
  }, [cashUnApprBlock]);

  useEffect(() => {
    if (cashRejectBlock && !_.isEqual(cashRejectBlock, preCashRejectBlock)) {
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
      dispatch(cashRejectBlockSuccess(null));
      getSingleBlockType();
    }
  }, [cashRejectBlock]);

  useEffect(() => {
    if (cashDelBlock && !_.isEqual(cashDelBlock, preCashDelBlock)) {
      onClose();
    }
  }, [cashDelBlock]);

  function initForm() {
    dispatch(
      change(
        'detailNgiepVuPhongToaModalform',
        'formAccountCode',
        cashSingleBlock?.C_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailNgiepVuPhongToaModalform',
        'formBlockCashAmt',
        cashSingleBlock?.C_CASH_VALUE
      )
    );
    dispatch(
      change(
        'detailNgiepVuPhongToaModalform',
        'formStartDate',
        cashSingleBlock?.C_EFFECT_DATE
      )
    );
    dispatch(
      change(
        'detailNgiepVuPhongToaModalform',
        'formEndDate',
        cashSingleBlock?.C_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailNgiepVuPhongToaModalform',
        'formContent',
        cashSingleBlock?.C_CONTENT
      )
    );
    dispatch(
      change(
        'detailNgiepVuPhongToaModalform',
        'formBuyFlag',
        cashSingleBlock?.C_BUYING_FLAG === 1
      )
    );
  }

  function getSingleBlockType() {
    if (!id) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(cashSingleBlockRequest(params));
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_BLOCK',
      group: 'LIST',
      data: {
        ID: cashSingleBlock?.PK_CASH_BLOCK,
        ACCOUNT_CODE: values?.formAccountCode,
        CASH_VALUE: StringToInt(values?.formBlockCashAmt),
        BUYING_FLAG: props?.formBuyFlag ? 1 : 0,
        EFFECT_DATE: values?.formStartDate,
        EXPIRE_DATE: values?.formEndDate,
        CONTENT: values?.formContent,
      },
    };
    dispatch(cashUpdBlockRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                ? t('txt-appr-entry')
                : actionName === 'reject'
                ? t('txt-reject-entry')
                : actionName === 'unApprove'
                ? t('txt-unAppr-entry')
                : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    console.log(rejectText);
                    if (!rejectText) return;
                    handleActionRevert(rejectText);
                    break;

                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_BLOCK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleBlock?.PK_CASH_BLOCK,
      },
    };
    dispatch(cashDelBlockRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleBlock?.PK_CASH_BLOCK,
        NEW_STATUS: 'DA_DUYET',
      },
    };
    dispatch(cashApprBlockRequest(params));
  }

  function handleActionRevert() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CASH_BLOCK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleBlock?.PK_CASH_BLOCK,
      },
    };
    dispatch(cashRejectBlockRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleBlock?.PK_CASH_BLOCK,
        NEW_STATUS: 'CHUA_DUYET',
      },
    };
    dispatch(cashUnApprBlockRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t, pristine } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-block-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('txt-acc-info')}
              </p>
              <Form.Group style={{ gridColumn: '1/2' }}>
                <Form.Label>
                  {t('txt-acc')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formAccountCode"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderNewInputAccount}
                  validate={[required, length7]}
                  index="3"
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={
                    accDetail
                      ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                      : ''
                  }
                  disabled
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-mobile')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_CUST_MOBILE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-email')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_CUST_EMAIL || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '3/5' }}>
                <Form.Label>{t('txt-address')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_RESEDENCE_ADDRESS || ''}
                  disabled
                />
              </Form.Group>

              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('txt-lock-money-info')}
              </p>
              <Form.Group style={{ gridColumn: '1/2' }}>
                <Form.Label>
                  {t('txt-lock-cash')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formBlockCashAmt"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  validate={[required, validateNumberExact]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-balance')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
                <Field
                  className="form-control"
                  name="formStartDate"
                  type="start"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
                <Field
                  className="form-control"
                  name="formEndDate"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group className="d-flex flex-column">
                <label style={{ paddingTop: '10px' }}>
                  <Field name="formBuyFlag" component="input" type="checkbox" />{' '}
                  {t('txt-lock-buying-power')}
                </label>
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>
                  {t('txt-content')}
                  {/* <span className="text-danger">*</span> */}
                </Form.Label>
                <Field
                  name="formContent"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  //validate={[required]}
                  rows={2}
                />
              </Form.Group>
              <div
                className="d-flex mt-2"
                style={{ gridColumn: '1/5', gap: '5px 20px' }}
              >
                <div className="d-flex flex-column">
                  <Form.Label>
                    {t('txt-creator')}
                    {': '}
                    {cashSingleBlock?.C_CREATOR_CODE}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-create-time')}
                    {': '}
                    {cashSingleBlock?.C_CREATE_TIME || ''}
                  </Form.Label>
                </div>
                <div className="d-flex flex-column">
                  <Form.Label>
                    {t('txt-approver')}
                    {': '}
                    {cashSingleBlock?.C_APPROVER_CODE || ''}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-approve-time')}
                    {': '}
                    {cashSingleBlock?.C_APPROVE_TIME || ''}
                  </Form.Label>
                </div>
              </div>
            </FormAdd>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {cashSingleBlock?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                        {/* <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('reject')}
                          className="w_125 ml-2 info"
                        >
                          {t('bnt-reject-entry')}
                        </BtnSubmit> */}
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 danger ml-2"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="submit"
                          disabled={pristine || submitting}
                          className="w_125 ml-2"
                        >
                          {t('bnt-edit-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {cashSingleBlock?.C_STATUS === 'DA_DUYET' &&
                  accRight?.C_APPROVE === 1 && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailPhongToaModal = reduxForm({
  form: 'detailNgiepVuPhongToaModalform',
  enableReinitialize: true,
})(DetailPhongToaModal);

const selector = formValueSelector('detailNgiepVuPhongToaModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdBlock = makeCashUpdBlock();
  const getCashSingleBlock = makeCashSingleBlock();
  const getCashDelBlock = makeCashDelBlock();
  const getCashApprBlock = makeCashApprBlock();
  const getCashRejectBlock = makeCashRejectBlock();
  const getCashUnApprBlock = makeCashUnApprBlock();
  const {
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formContent,
    formBuyFlag,
    formEndDate,
  } = selector(
    state,
    'formAccountCode',
    'formBlockCashAmt',
    'formStartDate',
    'formContent',
    'formBuyFlag',
    'formEndDate'
  );
  const cashSingleBlock = getCashSingleBlock(state);
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdBlock: getCashUpdBlock(state),
    cashDelBlock: getCashDelBlock(state),
    cashApprBlock: getCashApprBlock(state),
    cashRejectBlock: getCashRejectBlock(state),
    cashUnApprBlock: getCashUnApprBlock(state),
    cashSingleBlock,
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formContent,
    formEndDate,
    formBuyFlag,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailPhongToaModal)
);
