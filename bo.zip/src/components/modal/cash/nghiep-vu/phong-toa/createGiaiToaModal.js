import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt } from 'utils';
import { lengthRequired, required } from 'utils/validation';
import PerfectScrollbar from 'react-perfect-scrollbar';

import {
  cashDelUnBlockRequest,
  cashSingleUnBlockRequest,
  cashSingleUnBlockSuccess,
  cashUpdUnBlockRequest,
  cashUpdUnBlockSuccess,
} from 'containers/cash/actions';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashApprUnBlockRequest,
  cashBalanceRequest,
  cashBlockRequest,
  cashBlockSuccess,
} from 'containers/cash/actions';
import {
  makeCashApprUnBlock,
  makeCashDelUnBlock,
  makeCashSingleUnBlock,
  makeCashUpdUnBlock,
  makeGetCashBalance,
  makeGetCashBlock,
  makeGetToken,
  makeGetAccountSingle,
} from 'lib/selector';
import { numberFormat } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validateNumberExact } from 'utils/validation';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const length7 = lengthRequired(7);

function DetailGiaiToaModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    onClose,
    id,
    cashUpdUnBlock,
    cashDelUnBlock,
    accDetail,
    cashSingleUnBlock,
    accRight,
    formAccountCode,
    cashApprUnBlock,
    cashBlock,
    cashBalance,
  } = props;
  const preCashUpdUnBlock = usePrevious(cashUpdUnBlock);
  const preCashDelUnBlock = usePrevious(cashDelUnBlock);
  const preCashApprUnBlock = usePrevious(cashApprUnBlock);
  const preCashSingleUnBlock = usePrevious(cashSingleUnBlock);

  useEffect(() => {
    if (
      cashSingleUnBlock &&
      !_.isEqual(cashSingleUnBlock, preCashSingleUnBlock)
    ) {
      initForm();
    }
  }, [cashSingleUnBlock]);

  useEffect(() => {
    getSingleBlockType();
    return () => {
      dispatch(cashSingleUnBlockSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(cashBlockSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      //_handleGetCashBlock();
      _handleCheckBalance();
    } else {
      dispatch(accountSingleSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (cashUpdUnBlock && !_.isEqual(cashUpdUnBlock, preCashUpdUnBlock)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashUpdUnBlockSuccess(null));
      //getSingleBlockType();
      onClose();
    }
  }, [cashUpdUnBlock]);

  useEffect(() => {
    if (cashDelUnBlock && !_.isEqual(cashDelUnBlock, preCashDelUnBlock)) {
      onClose();
    }
  }, [cashDelUnBlock]);

  useEffect(() => {
    if (cashApprUnBlock && !_.isEqual(cashApprUnBlock, preCashApprUnBlock)) {
      onClose();
    }
  }, [cashApprUnBlock]);
  useEffect(() => {
    if (cashApprUnBlock && !_.isEqual(cashApprUnBlock, preCashApprUnBlock)) {
      onClose();
    }
  }, [cashApprUnBlock]);

  function initForm() {
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formAccountCode',
        cashSingleUnBlock?.C_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formBlockCashAmt',
        cashSingleUnBlock?.C_CASH_VALUE
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formStartDate',
        cashSingleUnBlock?.C_TRADING_DATE
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formContent',
        cashSingleUnBlock?.C_CONTENT
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formStartDate',
        cashSingleUnBlock?.C_EFFECT_DATE
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formEndDate',
        cashSingleUnBlock?.C_EXPIRE_DATE
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formBuyFlag',
        cashSingleUnBlock?.C_BUYING_FLAG
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formBlockCashStill',
        cashSingleUnBlock?.C_CURRENT_VALUE
      )
    );
    dispatch(
      change(
        'detailGiaiToaNgiepVuModalform',
        'formBlockCashUN',
        cashSingleUnBlock?.C_CASH_VALUE
      )
    );
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function getSingleBlockType() {
    if (!id) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        ID: id,
      },
    };

    dispatch(cashSingleUnBlockRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_UNBLOCK',
      group: 'LIST',
      data: {
        BLOCK_ID: cashSingleUnBlock?.PK_CASH_BLOCK,
        CASH_VALUE: StringToInt(values?.formBlockCashUN),
        CONTENT: values?.formContentGT,
      },
    };
    dispatch(cashUpdUnBlockRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, t, pristine } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-unBlock-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
            <form onSubmit={handleSubmit(submit)}>
              <FormAdd>
                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-anounce-block-bt')}
                </p>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index="3"
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>

                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-lock-money-info')}
                </p>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-lock-cash')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBlockCashAmt"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-balance')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control fz-13"
                    value={
                      cashBalance?.C_CASH_BALANCE_BO === 0
                        ? '0'
                        : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-from-date')}
                  </Form.Label>
                  <Field
                    className="form-control"
                    name="formStartDate"
                    type="start"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
                  <Field
                    className="form-control"
                    name="formEndDate"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                    disabled
                  />
                </Form.Group>
                <Form.Group className="d-flex flex-column">
                  <label style={{ paddingTop: '10px' }}>
                    <Field
                      name="formBuyFlag"
                      component="input"
                      type="checkbox"
                      disabled
                    />{' '}
                    {t('txt-lock-buying-power')}
                  </label>
                </Form.Group>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-anounce-unBlock-bt')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cash-unBlock')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBlockCashUN"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-cash-block-still')}</Form.Label>
                  <Field
                    name="formBlockCashStill"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContentGT"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
                <div
                  className="d-flex mt-2"
                  style={{ gridColumn: '1/5', gap: '5px 20px' }}
                >
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-creator')}
                      {': '}
                      {cashSingleUnBlock?.C_CREATOR_CODE}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-create-time')}
                      {': '}
                      {cashSingleUnBlock?.C_CREATE_TIME || ''}
                    </Form.Label>
                  </div>
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-approver')}
                      {': '}
                      {cashSingleUnBlock?.C_APPROVER_CODE || ''}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-approve-time')}
                      {': '}
                      {cashSingleUnBlock?.C_APPROVE_TIME || ''}
                    </Form.Label>
                  </div>
                </div>
              </FormAdd>
              <hr style={{ gridColumn: '1/4' }} />
              <div
                className="d-flex"
                style={{
                  height: '30px',
                  whiteSpace: 'nowrap',
                  gridColumn: '1/4',
                }}
              >
                <BtnClose type="button" onClick={onClose} className="mr-auto">
                  {t('txt-close')}
                </BtnClose>
                <div className="d-flex">
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-accept')}
                  </BtnSubmit>
                </div>
              </div>
            </form>
          </PerfectScrollbar>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailGiaiToaModal = reduxForm({
  form: 'detailGiaiToaNgiepVuModalform',
  enableReinitialize: true,
})(DetailGiaiToaModal);

const selector = formValueSelector('detailGiaiToaNgiepVuModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdUnBlock = makeCashUpdUnBlock();
  const getCashSingleUnBlock = makeCashSingleUnBlock();
  const getCashDelUnBlock = makeCashDelUnBlock();
  const getCashApprUnBlock = makeCashApprUnBlock();
  const getCashBlock = makeGetCashBlock();
  const getCashBalance = makeGetCashBalance();
  const {
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formEndDate,
    formContent,
    formBlockCashUN,
    formContentGT,
  } = selector(
    state,
    'formAccountCode',
    'formBlockCashAmt',
    'formStartDate',
    'formEndDate',
    'formContent',
    'formBlockCashUN',
    'formContentGT'
  );
  const cashSingleUnBlock = getCashSingleUnBlock(state);
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdUnBlock: getCashUpdUnBlock(state),
    cashDelUnBlock: getCashDelUnBlock(state),
    cashApprUnBlock: getCashApprUnBlock(state),
    cashBlock: getCashBlock(state),
    cashBalance: getCashBalance(state),
    cashSingleUnBlock,
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formEndDate,
    formContent,
    formBlockCashUN,
    formContentGT,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailGiaiToaModal)
);
