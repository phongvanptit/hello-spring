import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, formatDate, numberFormat, stringToDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';

import {
  makeCashUpdBlock,
  makeGetAccountSingle,
  makeGetCashBalance,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';

import RenderSelectDate from 'components/input/renderDatePicker';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashUpdBlockRequest,
  cashUpdBlockSuccess,
} from 'containers/cash/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validateNumberExact } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddPhongToaModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    accDetail,
    formAccountCode,
    cashUpdBlock,
    cashBalance,
    formBlockCashAmt,
    _date,
  } = props;
  const preCashUpdBlock = usePrevious(cashUpdBlock);
  const preFormBlockCashAmt = usePrevious(formBlockCashAmt);
  const preCashBalance = usePrevious(cashBalance);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      _handleCheckBalance();
    } else {
      dispatch(accountSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (
      formBlockCashAmt &&
      cashBalance &&
      (!_.isEqual(formBlockCashAmt, preFormBlockCashAmt) ||
        !_.isEqual(cashBalance, preCashBalance))
    ) {
      if (
        StringToInt(formBlockCashAmt) >
        (cashBalance.C_CASH_BALANCE_BO ? cashBalance?.C_CASH_BALANCE_BO : 0)
      ) {
        _handleToast(t('txt-amount-exceed-current-balance'), 'error');
        dispatch(change('openPhongToaModalform', 'formBlockCashAmt', ''));
      }
    }
  }, [formBlockCashAmt, cashBalance]);

  useEffect(() => {
    if (cashUpdBlock && !_.isEqual(cashUpdBlock, preCashUpdBlock)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashUpdBlockSuccess(null));
      onClose();
    }
  }, [cashUpdBlock]);

  function initForm() {
    dispatch(
      change(
        'openNghiepVuPhongToaModalform',
        'formStartDate',
        formatDate(_date, '/', 'dmy')
      )
    );
    dispatch(change('openNghiepVuPhongToaModalform', 'formBlockCashAmt', 0));
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_BLOCK',
      group: 'LIST',
      data: {
        ID: '',
        ACCOUNT_CODE: props?.formAccountCode,
        CASH_VALUE: StringToInt(props?.formBlockCashAmt),
        BUYING_FLAG: props?.formBuyFlag ? 1 : 0,
        EFFECT_DATE: props?.formStartDate,
        EXPIRE_DATE: props?.formEndDate,
        CONTENT: props?.formContent,
      },
    };
    dispatch(cashUpdBlockRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-block-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('txt-acc-info')}
              </p>
              <Form.Group style={{ gridColumn: '1/2' }}>
                <Form.Label>
                  {t('txt-acc')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formAccountCode"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderNewInputAccount}
                  validate={[required, length7]}
                  index="3"
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '2/4' }}>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={
                    accDetail
                      ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                      : ''
                  }
                  disabled
                />
              </Form.Group>

              {/* <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_ID || ''}
                  disabled
                />
              </Form.Group> */}

              <Form.Group>
                <Form.Label>{t('txt-mobile')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_CUST_MOBILE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-email')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_CUST_EMAIL || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '3/5' }}>
                <Form.Label>{t('txt-address')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_RESEDENCE_ADDRESS || ''}
                  disabled
                />
              </Form.Group>

              <p style={{ gridColumn: '1/5' }} className="color-thm mb-0 fz-13">
                {t('txt-lock-money-info')}
              </p>
              <Form.Group>
                <Form.Label>
                  {t('txt-lock-cash')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formBlockCashAmt"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  validate={[required, validateNumberExact]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-balance')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control fz-13"
                  value={
                    cashBalance?.C_CASH_BALANCE_BO === 0
                      ? '0'
                      : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                  }
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
                <Field
                  className="form-control"
                  name="formStartDate"
                  type="start"
                  component={RenderSelectDate}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
                <span className="text-danger">*</span>
                <Field
                  className="form-control"
                  name="formEndDate"
                  component={RenderSelectDate}
                  validate={required}
                />
              </Form.Group>
              <Form.Group className="d-flex flex-column">
                <label style={{ paddingTop: '10px' }}>
                  <Field name="formBuyFlag" component="input" type="checkbox" />{' '}
                  {t('txt-lock-buying-power')}
                </label>
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label>
                  {t('txt-content')}
                  {/* <span className="text-danger">*</span> */}
                </Form.Label>
                <Field
                  name="formContent"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  //validate={[required]}
                  rows={2}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddPhongToaModal = reduxForm({
  form: 'openNghiepVuPhongToaModalform',
  enableReinitialize: true,
})(AddPhongToaModal);

const selector = formValueSelector('openNghiepVuPhongToaModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdBlock = makeCashUpdBlock();
  const getSystemInfo = makeGetSystemInfo();
  const getCashBalance = makeGetCashBalance();
  const {
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formContent,
    formBuyFlag,
    formEndDate,
  } = selector(
    state,
    'formAccountCode',
    'formBlockCashAmt',
    'formStartDate',
    'formContent',
    'formBuyFlag',
    'formEndDate'
  );
  const sysSystemInfo = getSystemInfo(state);
  const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdBlock: getCashUpdBlock(state),
    cashBalance: getCashBalance(state),
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formContent,
    formBuyFlag,
    formEndDate,
    _date,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddPhongToaModal)
);
