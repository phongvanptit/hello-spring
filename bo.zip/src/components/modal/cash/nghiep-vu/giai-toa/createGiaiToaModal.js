import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import { setToast } from 'containers/client/actions';
import {
  makeCashUpdUnBlock,
  makeGetAccountSingle,
  makeGetCashBalance,
  makeGetCashBlock,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import {Table } from 'react-bootstrap';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, formatDate, numberFormat, stringToDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';

import RenderSelectDate from 'components/input/renderDatePicker';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashBlockRequest,
  cashBlockSuccess,
  cashUpdUnBlockRequest,
  cashUpdUnBlockSuccess,
} from 'containers/cash/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validateNumberExact } from 'utils/validation';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddGiaiToaModal(props) {
  const abortController = new AbortController();
  const dispatch = useDispatch();
  const [cashBlockList, setCashBlock] = React.useState(null);
  const [cashSingleBlock, setCashUnBlock] = React.useState(null);

  const {
    token,
    accDetail,
    formAccountCode,
    cashUpdUnBlock,
    cashBlock,
    cashBalance,
    _date
  } = props;
  const preCashUpdUnBlock = usePrevious(cashUpdUnBlock);
  const preAccDetail = usePrevious(accDetail);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(cashBlockSuccess(null));
      dispatch(cashBalanceSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      //_handleGetCashBlock();
      _handleCheckBalance();
      setCashUnBlock(null);
    } else {
      dispatch(accountSingleSuccess(null));
      //dispatch(cashBlockSuccess(null));
      dispatch(cashBalanceSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (cashUpdUnBlock && !_.isEqual(cashUpdUnBlock, preCashUpdUnBlock)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashUpdUnBlockSuccess(null));
      onClose();
    }
  }, [cashUpdUnBlock]);

  useEffect(() => {
    if (accDetail && !_.isEqual(accDetail, preAccDetail)) {
      setCashBlock(null);
      getCashBlockList(accDetail?.C_ACCOUNT_CODE);
    }
  }, [accDetail]);

  function initForm() {
    dispatch(
      change('openGiaiToaNghiepVuModalform', 'formStartDate', formatDate(_date, '/', 'dmy'))
    );
    dispatch(
      change('openGiaiToaNghiepVuModalform', 'formEndDate', formatDate(_date, '/', 'dmy'))
    );
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function getCashBlockList(accountCode) {
    if (!accountCode) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        BUSSINESS_CODE: 'BLOCK_CASH',
        ACCOUNT_CODE: accountCode,
        APPROVE_STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        setCashBlock(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  

  // function _handleGetCashBlock() {
  //   const params = {
  //     user: token?.USER_NAME,
  //     session: token?.SESSION_ID,
  //     cmd: 'BACK.GET_CASH_BLOCK',
  //     group: 'LIST',
  //     data: {
  //       ACCOUNT_CODE: formAccountCode,
  //     },
  //   };

  //   dispatch(cashBlockRequest(params));
  // }

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_UNBLOCK',
      group: 'LIST',
      data: {
        BLOCK_ID: '',
        //ACCOUNT_CODE: props?.formAccountCode,
        CASH_VALUE: StringToInt(props?.formBlockCashAmt),
        //C_EFFECT_DATE: props?.formStartDate,
        //C_EXPIRE_DATE: '01/01/9999',
        CONTENT: props?.formContent,
      },
    };
    dispatch(cashUpdUnBlockRequest(params));
  }

  function handleDblClick(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BLOCK_UNBLOCK',
      group: 'LIST',
      data: {
        ID: record?.PK_CASH_BLOCK,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log('res', res);
        if (res?.code > 0 && !!res?.data?.length) {
          setCashUnBlock(res.data[0]);
          dispatch(
            change(
              'openGiaiToaNghiepVuModalform',
              'formBlockCashAmt',
              res.data[0]?.C_CASH_VALUE
            )
          );
          
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }


  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-unBlock-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('Account information')}
              </p>
              <Form.Group style={{ gridColumn: '1/2' }}>
                <Form.Label>
                  {t('txt-acc')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formAccountCode"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderNewInputAccount}
                  validate={[required, length7]}
                  index="3"
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-acc-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_ACCOUNT_NAME || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-marketing-id')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={accDetail?.C_MARKETING_ID || ''}
                  disabled
                />
              </Form.Group>
              {/* <Form.Group>
                <Form.Label>{t('txt-cash-block')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={
                    cashBlock
                      ? numberFormat(cashBlock?.C_CASH_BLOCK, 0, '0') || '0'
                      : ''
                  }
                  disabled
                />
              </Form.Group> */}
              <Form.Group>
                <Form.Label>{t('txt-acc-balance')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control fz-13"
                  value={
                    cashBalance
                      ? numberFormat(cashBalance?.C_CASH_BALANCE_BO, 0, '0') ||
                      '0'
                      : ''
                  }
                  disabled
                />
              </Form.Group>

              <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  Danh sách bút toán phong tỏa
                </p>
                <div style={{ gridColumn: '1/4' }}>
                  <Table bordered className="w-100">
                    <colgroup>
                      <col width="20%" />
                      <col width="20%" />
                      <col width="20%" />
                      <col width="20%" />
                      <col width="20%" />

                    </colgroup>
                    <thead>
                      <tr>
                      <th>Người tạo</th>
                        <th>{t('txt-time')}</th>
                        <th>{t('txt-acc')}</th>
                        <th>{t('txt-cash-vol')}</th>
                        <th>{t('txt-note')}</th>
                      
                      </tr>
                    </thead>
                    <tbody>
                    {cashBlockList &&
                      cashBlockList.map((item) => (
                        <tr key={item.ROW_NUM}
                            onClick={() => handleDblClick(item)}
                            style={{ cursor: 'pointer' }}>
                        
                          <td className="text-center">{item.C_CREATOR_CODE}</td>
                          <td className="text-center">                
                              {item.C_CREATE_TIME}
                          </td>
                          <td className="text-center">                        
                              {item.C_ACCOUNT_CODE}
                          </td>
                          <td className="text-right">
                            {numberFormat(item.C_CASH_VALUE, 0, '0')}
                          </td>
                        
                          <td>{item.C_CONTENT}</td>
                          
                        
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>

              <p style={{ gridColumn: '1/4' }} className="color-thm mb-0 fz-13">
                {t('txt-unblock-money-info')}
              </p>
              <Form.Group>
                <Form.Label>
                  {t('txt-cash-unBlock')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formBlockCashAmt"
                  className="form-control input-order fz-13"
                  component={RenderInputMask}
                  validate={[required, validateNumberExact]}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
                <Field
                  className="form-control"
                  name="formStartDate"
                  type="start"
                  component={RenderSelectDate}
                  disabled
                />
              </Form.Group>

              <Form.Group style={{ gridColumn: '1/4' }}>
                <Form.Label>
                  {t('txt-content')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formContent"
                  className="form-control input-order fz-13"
                  component={RenderArea}
                  validate={[required]}
                  rows={2}
                />
              </Form.Group>
            </FormAdd>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddGiaiToaModal = reduxForm({
  form: 'openGiaiToaNghiepVuModalform',
  enableReinitialize: true,
})(AddGiaiToaModal);

const selector = formValueSelector('openGiaiToaNghiepVuModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdUnBlock = makeCashUpdUnBlock();
  const getSystemInfo = makeGetSystemInfo();
  const getCashBlock = makeGetCashBlock();
  const getCashBalance = makeGetCashBalance();
  const {
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formEndDate,
    formContent,
  } = selector(
    state,
    'formAccountCode',
    'formBlockCashAmt',
    'formStartDate',
    'formEndDate',
    'formContent'
  );
  const sysSystemInfo = getSystemInfo(state);
  const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdUnBlock: getCashUpdUnBlock(state),
    cashBlock: getCashBlock(state),
    cashBalance: getCashBalance(state),
    formAccountCode,
    formBlockCashAmt,
    formStartDate,
    formEndDate,
    formContent,
    _date
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddGiaiToaModal)
);
