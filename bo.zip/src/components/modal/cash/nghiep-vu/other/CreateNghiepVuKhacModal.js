import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestCustomer from 'components/input/renderSuggestCustomer';
import RenderInput from 'components/input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, numberFormat, stringToDate, formatDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';

import {
  makeCashUpdOther,
  makeGetAccountSingle,
  makeGetCustomerDetail,
  makeGetGlobalCashBusinessOther,
  makeGetGlobalCashBusinessDetail,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';

import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';

import {
  cashUpdOtherRequest,
  cashUpdOtherSuccess,
} from 'containers/cash/actions';

import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalCashBusinessDetailRequest,
  globalCashBusinessDetailSuccess,
} from 'containers/global/actions';

import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
} from 'containers/cash/actions';
import { makeGetCashBalance } from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { BtnDetail } from 'utils/styledComponent';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';

ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function AddNghiepVuKhacModal(props) {
  const dispatch = useDispatch();
  const [detailTS, setDetailTS] = React.useState(null);

  const {
    token,
    accDetail,
    formAccountCode,
    cashUpdOther,
    glSingleList,
    formBranchBank,
    custDetail,
    formCardId,
    glCashBusinessOther,
    formBusiness,
    glCashBusinessDetail,
    cashBalance,
  } = props;
  const preCashUpdOther = usePrevious(cashUpdOther);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(globalSingleListSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(globalCashBusinessDetailSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formCardId) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formCardId]);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      _handleCheckBalance();
    } else {
      dispatch(accountSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (formBusiness) {
      _handleGetBusinessDetail();
    }
  }, [formBusiness]);

  useEffect(() => {
    if (cashUpdOther && !_.isEqual(cashUpdOther, preCashUpdOther)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashUpdOtherSuccess(null));
      onClose();
    }
  }, [cashUpdOther]);

  function initForm() {
    // dispatch(
    //   change('openNghiepVuKhacModalform', 'formBusiness', 'BOND_BUSINESS')
    // );
    dispatch(change('openNghiepVuKhacModalform', 'formBranchBank', '000'));
    dispatch(
      change(
        'openNghiepVuKhacModalform',
        'formTransDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
  }

  function _handleCheckCustomer() {
    if (!formCardId) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formCardId,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function _handleGetBusinessDetail() {
    if (!formBusiness) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BUSINESS_DETAIL',
      group: 'LIST',
      data: {
        BUSINESS_TRANSACTION_CODE: formBusiness,
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalCashBusinessDetailRequest(params));
  }

  function submit(values) {
    console.log(values);
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_OTHER_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ID: '',
        BUSINESS_CODE: props?.formBusiness,
        BUSINESS_DETAIL_CODE: props?.formBusinessDetail,
        ACCOUNT_CODE: props?.formAccountCode,
        ACCOUNT_TYPE: accDetail?.C_ACC_CREDIT_TYPE_NAME,
        ACCOUNT_NAME: accDetail?.C_ACCOUNT_NAME,
        AUTHOR_CARD_ID: props.formCardId,
        AUTHOR_NAME: custDetail?.C_CUSTOMER_NAME,
        CASH_VALUE: StringToInt(props?.formCashValue),
        BRANCH_BANK_CODE: props?.formBranchBank,
        CONTENT: props?.formContent,
        STATUS: 'CHUA_DUYET',
        TRANSACTION_DATE: props?.formTransDate,
        FILE_NO: props?.formFileNo,
        FILE_DATE: props?.formFileDate,
      },
    };
    dispatch(cashUpdOtherRequest(params));
  }

  function handleDetailTS() {
    if (!formAccountCode) return;
    setDetailTS(formAccountCode);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-bus-other')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>Số bút toán</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    name="formTransDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-file-no')}</Form.Label>
                  <Field
                    name="formFileNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-profile-date')}</Form.Label>
                  <Field
                    name="formFileDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSelectDate}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label className="fz-13">
                    {t('txt-bus')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusiness"
                    type="text"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glCashBusinessOther}
                    validate={[required]}
                    index={5}
                    //required
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label className="fz-13">
                    {t('txt-detail-business-t')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusinessDetail"
                    type="text"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glCashBusinessDetail}
                    validate={[required]}
                    index={4}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index={3}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashValue"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số tiền có thể rút</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      cashBalance?.C_CASH_BALANCE_BO === 0
                        ? '0'
                        : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label></Form.Label>
                  <BtnDetail type="button" onClick={handleDetailTS} />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('lab-acc-total')} <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index={1}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailTS && (
        <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
      )}
    </ReactModal>
  );
}

AddNghiepVuKhacModal = reduxForm({
  form: 'openNghiepVuKhacModalform',
  enableReinitialize: true,
})(AddNghiepVuKhacModal);

const selector = formValueSelector('openNghiepVuKhacModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdOther = makeCashUpdOther();
  const getSystemInfo = makeGetSystemInfo();
  const getSingleList = makeGetSingleList();
  const getCustomerDetail = makeGetCustomerDetail();
  const getGlobalCashBusinessOther = makeGetGlobalCashBusinessOther();
  const getGlobalCashBusinessDetail = makeGetGlobalCashBusinessDetail();
  const getCashBalance = makeGetCashBalance();
  const {
    formBusiness,
    formBusinessDetail,
    formAccountCode,
    formCardId,
    formCashValue,
    formBranchBank,
    formContent,
    formTransDate,
    formFileNo,
    formFileDate,
  } = selector(
    state,
    'formBusiness',
    'formBusinessDetail',
    'formAccountCode',
    'formCardId',
    'formCashValue',
    'formBranchBank',
    'formContent',
    'formTransDate',
    'formFileNo',
    'formFileDate'
  );
  const sysSystemInfo = getSystemInfo(state);
  const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdOther: getCashUpdOther(state),
    glSingleList: getSingleList(state),
    custDetail: getCustomerDetail(state),
    glCashBusinessOther: getGlobalCashBusinessOther(state),
    glCashBusinessDetail: getGlobalCashBusinessDetail(state),
    cashBalance: getCashBalance(state),
    formBusiness,
    formBusinessDetail,
    formAccountCode,
    formCardId,
    formCashValue,
    formBranchBank,
    formContent,
    formTransDate,
    formFileNo,
    formFileDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddNghiepVuKhacModal)
);
