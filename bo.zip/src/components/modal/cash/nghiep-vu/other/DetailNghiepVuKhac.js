import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestCustomer from 'components/input/renderSuggestCustomer';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';

import { setToast } from 'containers/client/actions';
import {
  makeCashDelOther,
  makeCashSingleOther,
  makeCashUpdOther,
  makeGetAccountSingle,
  makeGetCashManagementApprove,
  makeGetCashManagementReject,
  makeGetCashManagementUnApprove,
  makeGetCustomerDetail,
  makeGetGlobalCashBusinessOther,
  makeGetGlobalCashBusinessDetail,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetCashBalance,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import {
  StringToInt,
  _diff2Date,
  formatDate,
  stringToDate,
  numberFormat,
} from 'utils';
import { lengthRequired, required } from 'utils/validation';
import { BtnDetail } from 'utils/styledComponent';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';

import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';

import {
  cashDelOtherRequest,
  cashDelOtherSuccess,
  cashManagementApproveRequest,
  cashManagementApproveSuccess,
  cashManagementRejectRequest,
  cashManagementRejectSuccess,
  cashManagementUnApproveRequest,
  cashManagementUnApproveSuccess,
  cashSingleOtherRequest,
  cashSingleOtherSuccess,
  cashUpdOtherRequest,
  cashUpdOtherSuccess,
} from 'containers/cash/actions';

import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalCashBusinessDetailRequest,
  globalCashBusinessDetailSuccess,
} from 'containers/global/actions';

import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailNghiepVuKhacModal(props) {
  const dispatch = useDispatch();
  const [diff, setDiff] = React.useState(false);
  const [detailTS, setDetailTS] = React.useState(null);

  const {
    token,
    accDetail,
    formAccountCode,
    cashUpdOther,
    glSingleList,
    formBranchBank,
    custDetail,
    formCardId,
    glCashBusinessOther,
    formBusiness,
    glCashBusinessDetail,
    id,
    cashSingleOther,
    pristine,
    cashDelOther,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    accRight,
    sysSystemInfo,
    cashBalance,
  } = props;
  const preCashUpdOther = usePrevious(cashUpdOther);
  const preCashDelOther = usePrevious(cashDelOther);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashSingleOther = usePrevious(cashSingleOther);

  useEffect(() => {
    if (cashSingleOther && !_.isEqual(cashSingleOther, preCashSingleOther)) {
      initForm();
    }
  }, [cashSingleOther]);

  useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(globalSingleListSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(globalCashBusinessDetailSuccess(null));
      dispatch(cashSingleOtherSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formCardId) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formCardId]);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (formBusiness) {
      _handleGetBusinessDetail();
    }
  }, [formBusiness]);

  useEffect(() => {
    if (cashUpdOther && !_.isEqual(cashUpdOther, preCashUpdOther)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashUpdOtherSuccess(null));
      handleGetSingle();
    }
  }, [cashUpdOther]);

  useEffect(() => {
    if (cashDelOther && !_.isEqual(cashDelOther, preCashDelOther)) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashDelOtherSuccess(null));
      onClose();
    }
  }, [cashDelOther]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) {
      dispatch(cashManagementApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngApprove]);

  useEffect(() => {
    if (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) {
      dispatch(cashManagementUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngUnApprove]);

  useEffect(() => {
    if (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) {
      dispatch(cashManagementRejectSuccess(null));
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngReject]);

  useEffect(() => {
    if (cashSingleOther && cashSingleOther?.C_TRANSACTION_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          cashSingleOther?.C_TRANSACTION_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [cashSingleOther]);

  function initForm() {
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formBusiness',
        cashSingleOther?.C_BUSSINESS_CODE
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formBusinessDetail',
        cashSingleOther?.C_BUSSINESS_DETAIL_CODE
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formAccountCode',
        cashSingleOther?.C_ACCOUNT_IN
          ? cashSingleOther?.C_ACCOUNT_IN
          : cashSingleOther?.C_ACCOUNT_OUT
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formCardId',
        cashSingleOther?.C_AUTHOR_CERT_ID
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formCashValue',
        cashSingleOther?.C_CASH_VOLUME
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formBranchBank',
        cashSingleOther?.C_BRANCH_BANK_CODE
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formContent',
        cashSingleOther?.C_CONTENT
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formTransNo',
        cashSingleOther?.C_TRANSACTION_NO
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formTransDate',
        cashSingleOther?.C_TRANSACTION_DATE
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formFileNo',
        cashSingleOther?.C_FILE_NO
      )
    );
    dispatch(
      change(
        'detailNghiepVuKhacModalform',
        'formFileDate',
        cashSingleOther?.C_FILE_DATE
      )
    );
  }

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_OTHER_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(cashSingleOtherRequest(params));
  }

  function _handleCheckCustomer() {
    if (!formCardId) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formCardId,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function _handleGetBusinessDetail() {
    if (!formBusiness) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BUSINESS_DETAIL',
      group: 'LIST',
      data: {
        BUSINESS_TRANSACTION_CODE: formBusiness,
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalCashBusinessDetailRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_OTHER_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ID: cashSingleOther?.PK_CASH_MANAGEMENT,
        BUSINESS_CODE: values?.formBusiness,
        BUSINESS_DETAIL_CODE: values?.formBusinessDetail,
        ACCOUNT_CODE: values?.formAccountCode,
        ACCOUNT_TYPE: accDetail?.C_ACC_CREDIT_TYPE_NAME,
        ACCOUNT_NAME: accDetail?.C_ACCOUNT_NAME,
        AUTHOR_CARD_ID: values.formCardId,
        AUTHOR_NAME: custDetail?.C_CUSTOMER_NAME,
        CASH_VALUE: StringToInt(values?.formCashValue),
        BRANCH_BANK_CODE: values?.formBranchBank,
        CONTENT: values?.formContent,
      },
    };
    dispatch(cashUpdOtherRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                ? t('txt-appr-entry')
                : actionName === 'unApprove'
                ? t('txt-unAppr-entry')
                : actionName === 'reject'
                ? t('txt-reject-entry')
                : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    console.log(rejectText);
                    if (!rejectText) return;
                    handleActionRevert(rejectText);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
      // keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleOther?.PK_CASH_MANAGEMENT,
      },
    };
    dispatch(cashDelOtherRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleOther?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UN_APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleOther?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementUnApproveRequest(params));
  }

  function handleActionRevert(rejectText) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashSingleOther?.PK_CASH_MANAGEMENT,
        CANCEL_NOTE: rejectText,
      },
    };

    dispatch(cashManagementRejectRequest(params));
  }

  function handleDetailTS() {
    if (!formAccountCode) return;
    setDetailTS(formAccountCode);
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Chi tiết thông tin nghiệp vụ khác</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>Số bút toán</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    name="formTransDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-file-no')}</Form.Label>
                  <Field
                    name="formFileNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-profile-date')}</Form.Label>
                  <Field
                    name="formFileDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSelectDate}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label className="fz-13">
                    {t('txt-bus')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusiness"
                    type="text"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glCashBusinessOther}
                    validate={[required]}
                    index={5}
                    required
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label className="fz-13">
                    {t('txt-detail-business-t')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusinessDetail"
                    type="text"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={glCashBusinessDetail}
                    validate={[required]}
                    index={4}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index={3}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashValue"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số tiền có thể rút</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      cashBalance?.C_CASH_BALANCE_BO === 0
                        ? '0'
                        : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label></Form.Label>
                  <BtnDetail type="button" onClick={handleDetailTS} />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('lab-acc-total')} <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index={1}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
                <div
                  className="d-flex mt-2"
                  style={{ gridColumn: '1/5', gap: '5px 20px' }}
                >
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-creator')}
                      {': '}
                      {cashSingleOther?.C_CREATOR_CODE}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-create-time')}
                      {': '}
                      {cashSingleOther?.C_CREATE_TIME || ''}
                    </Form.Label>
                  </div>
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-approver')}
                      {': '}
                      {cashSingleOther?.C_APPROVER_CODE || ''}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-approve-time')}
                      {': '}
                      {cashSingleOther?.C_APPROVE_TIME || ''}
                    </Form.Label>
                  </div>
                </div>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {cashSingleOther?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                        {/* <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('reject')}
                          className="w_125 ml-2 info"
                        >
                          {t('bnt-reject-entry')}
                        </BtnSubmit> */}
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="submit"
                          disabled={pristine || submitting}
                          className="w_125 ml-2"
                        >
                          {t('bnt-edit-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {accRight?.C_APPROVE === 1 &&
                  cashSingleOther?.C_STATUS === 'DA_DUYET' &&
                  diff && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailTS && (
        <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
      )}
    </ReactModal>
  );
}

DetailNghiepVuKhacModal = reduxForm({
  form: 'detailNghiepVuKhacModalform',
  enableReinitialize: true,
})(DetailNghiepVuKhacModal);

const selector = formValueSelector('detailNghiepVuKhacModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCashUpdOther = makeCashUpdOther();
  const getSystemInfo = makeGetSystemInfo();
  const getSingleList = makeGetSingleList();
  const getCustomerDetail = makeGetCustomerDetail();
  const getGlobalCashBusinessOther = makeGetGlobalCashBusinessOther();
  const getGlobalCashBusinessDetail = makeGetGlobalCashBusinessDetail();
  const getCashSingleOther = makeCashSingleOther();
  const getCashDelOther = makeCashDelOther();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashBalance = makeGetCashBalance();
  const {
    formBusiness,
    formBusinessDetail,
    formAccountCode,
    formCardId,
    formCashValue,
    formBranchBank,
    formContent,
  } = selector(
    state,
    'formBusiness',
    'formBusinessDetail',
    'formAccountCode',
    'formCardId',
    'formCashValue',
    'formBranchBank',
    'formContent'
  );
  const sysSystemInfo = getSystemInfo(state);
  const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
  const cashSingleOther = getCashSingleOther(state);
  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    cashUpdOther: getCashUpdOther(state),
    glSingleList: getSingleList(state),
    custDetail: getCustomerDetail(state),
    glCashBusinessOther: getGlobalCashBusinessOther(state),
    glCashBusinessDetail: getGlobalCashBusinessDetail(state),
    cashMngApprove: getCashManagementApprove(state),
    cashMngUnApprove: getCashManagementUnApprove(state),
    cashMngReject: getCashManagementReject(state),
    cashBalance: getCashBalance(state),
    cashSingleOther,
    cashDelOther: getCashDelOther(state),
    sysSystemInfo,
    formBusiness,
    formBusinessDetail,
    formAccountCode,
    formCardId,
    formCashValue,
    formBranchBank,
    formContent,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailNghiepVuKhacModal)
);
