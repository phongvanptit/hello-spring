import RenderAdvanceSource from 'components/input/renderAdvanceSource';
import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestCustomer from 'components/input/renderSuggestCustomer';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { numberFormat, replaceAll, formatDate } from 'utils';
import { required } from 'utils/validation';

import {
  makeGetAccountSingle,
  makeGetCashCreditLimitCity,
  makeGetCashHSUUpdate,
  makeGetCashWithdrawAcc,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetGlobalCashDeposit,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetShareFee,
  makeGetToken,
} from 'lib/selector';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashCreditLimitCityRequest,
  cashCreditLimitCitySuccess,
  cashHSUUpdateRequest,
  cashHSUUpdateSuccess,
  cashWithdrawAccRequest,
  cashWithdrawAccSuccess,
} from 'containers/cash/actions';
import {
  shareFeeSuccess,
  shareFeeRequest,
} from 'containers/stock/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import { handleApiErrors } from 'lib/api-errors';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { StringToInt } from 'utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddUngTruocModal(props) {
  const abortController = new AbortController();
  const dispatch = useDispatch();
  const [withdrawInfo, setWithdrawInfo] = React.useState(null);
  const [cashSell, setCashSell] = React.useState(null);
  const {
    token,
    accDetail,
    formAccount,
    formCashVolume,
    formFeeRate,
    glChannelType,
    formAuthorCardId,
    custDetail,
    cashHSUUpdate,
    t,
    formBankSource,
    sysSystemInfo,
    cashCreditLimitCity,
    cashWithdrawAcc,
    formFeeValue,
    shareFee
  } = props;
  const preAccDetail = usePrevious(accDetail);
  const preFormAccount = usePrevious(formAccount);
  const preCashHSUUpdate = usePrevious(cashHSUUpdate);
  const preFormAuthorCardId = usePrevious(formAuthorCardId);
  const preFee = usePrevious(shareFee);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(cashWithdrawAccSuccess(null));
      dispatch(cashCreditLimitCitySuccess(null));
      dispatch(shareFeeSuccess(null));
    };
  }, []);

  useEffect(() => {
    if (
      formAccount &&
      formAccount.length === 7 &&
      !_.isEqual(formAccount, preFormAccount)
    ) {
      _handleCheckAccount();
      _handleGetCashWithdrawAcc();
      setWithdrawInfo(null);
      _handleGetCashCreditLimitCity();
    } else {
      dispatch(accountSingleSuccess(null));
      dispatch(cashWithdrawAccSuccess(null));
    }
  }, [formAccount]);

  useEffect(() => {
    if (formAuthorCardId) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formAuthorCardId]);

  // useEffect(() => {
  //   if (formCashVolume) {
  //     _handleChangeCashVol();
  //   }
  // }, [formCashVolume]);

  useEffect(() => {
    if (formCashVolume) {
      handleGetFee();
    } else dispatch(shareFeeSuccess(null));
  }, [formCashVolume]);

  useEffect(() => {
    if (shareFee && !_.isEqual(formFeeValue, preFee))
      dispatch(
        change('openUngTruocModalform', 'formFeeValue', shareFee?.C_FEE + '')
      );
      // dispatch(
      //   change('openUngTruocModalform', 'formTotalValue', (shareFee?.C_FEE + Number(formCashVolume)) + '')
      // );
      //Number(replaceAll(formCashVolume + '' || '0', ',', ''))
      dispatch(
        change('openUngTruocModalform', 'formTotalValue', (Number(replaceAll(shareFee?.C_FEE + '' || '0', ',', '')) + Number(replaceAll(formCashVolume + '' || '0', ',', ''))) + '')
      );
  }, [shareFee]);

  useEffect(() => {
    if (formBankSource) {
      _handleGetCashCreditLimitCity();
    } else dispatch(cashCreditLimitCitySuccess(null));
  }, [formBankSource]);

  useEffect(() => {
    if (accDetail && !_.isEqual(accDetail, preAccDetail)) {
      setCashSell(null);
      getAllCashSell(accDetail?.C_ACCOUNT_CODE);
    }
  }, [accDetail]);

  useEffect(() => {
    if (cashHSUUpdate && !_.isEqual(cashHSUUpdate, preCashHSUUpdate)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashHSUUpdateSuccess(null));
      onClose();
    }
  }, [cashHSUUpdate]);

  function initForm() {
    dispatch(change('openUngTruocModalform', 'formChannel', 'D'));
    dispatch(
      change(
        'openUngTruocModalform',
        'formTransDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
  }

  console.log('cash_value',cashCreditLimitCity?.C_CASH_VALUE);
  function _handleGetCashWithdrawAcc() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_WITHDRAWED_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccount,
      },
    };
    dispatch(cashWithdrawAccRequest(params));
  }

  function _handleGetCashCreditLimitCity() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.CREDIT_CASH_BY_BANK',
      group: 'LIST',
      data: {
        BANK_CODE: formBankSource,
        TRADING_DATE: sysSystemInfo?.C_T_DATE,
      },
    };

    dispatch(cashCreditLimitCityRequest(params));
  }

  function getAllCashSell(accountCode) {
    if (!accountCode) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_CASH_SELL',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: accountCode,
      },
    };

    const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }
    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log(res);
        setCashSell(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function _handleCheckCustomer() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorCardId,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleChangeCashVol() {
    if (!withdrawInfo || !formCashVolume) return;
    const _fee = Math.ceil(
      ((formFeeRate * withdrawInfo.C_FEE_DAYS) / 100) *
        Number(replaceAll(formCashVolume + '' || '0', ',', ''))
    );
    dispatch(
      change(
        'openUngTruocModalform',
        'formFeeValue',
        numberFormat(
          _fee < withdrawInfo?.C_FEE_MIN ? withdrawInfo?.C_FEE_MIN : _fee
        )
      )
    );
  }

  function handleGetFee() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ADVANCE_WITHDRAW_FEE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccount,
        WITHDRAW_CASH: StringToInt(formCashVolume) || 0,
        WITHDRAW_DATE: sysSystemInfo?.C_T_DATE,
        DUE_DATE: withdrawInfo?.C_DUE_DATE,
      },
    };
    dispatch(shareFeeRequest(params));
  }


  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccount,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  // function submit() {
  //   if ((formAccount, formAuthorCardId)) {
  //     const params = {
  //       user: token?.USER_NAME,
  //       session: token?.SESSION_ID,
  //       cmd: 'BACK.CHECK_AUTHOR',
  //       group: 'LIST',
  //       data: {
  //         ACCOUNT_CODE: formAccount,
  //         CUSTOMER_CODE: formAuthorCardId,
  //         BUSINESS_CODE: 'UNG_TAI_QUAY',
  //       },
  //     };

  //     const storedToken = localStorage.getItem('tokenBO');
  //     let bearerToken = '';
  //     if (storedToken) {
  //       const tokenObj = JSON.parse(storedToken);
  //       bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
  //     }
  //     fetch(appUrl, {
  //       method: 'POST',
  //       headers: {
  //         'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  //         'Authorization': `Bearer ${bearerToken}`,
  //       },
  //       body: JSON.stringify(params),
  //     })
  //       .then(handleApiErrors)
  //       .then((response) => response.json())
  //       .then((json) => {
  //         if (json.code === '1') {
  //           json.data[0].C_CHECK === 1
  //             ? handleConfirm()
  //             : _handleToast(t('txt-unauthorized-acc'), 'error');
  //         } else {
  //           _handleToast(json.re, 'error');
  //         }
  //       })
  //       .catch((error) => {
  //         console.log(error);
  //       });
  //   }
  // }

  function submit() {
    
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ADVANCE_WITHDRAW',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        ACCOUNT_CODE: props?.formAccount,
        AUTHOR_CARD_ID: props?.formAuthorCardId,
        AUTHOR_NAME: custDetail?.C_CUSTOMER_NAME,
        SELL_DATE: withdrawInfo?.C_SELL_DATE,
        DUE_DATE: withdrawInfo?.C_DUE_DATE,
        CASH_VOLUME: Number(
          replaceAll(props?.formCashVolume + '' || '0', ',', '')
        ),
        FEE_RATE: withdrawInfo?.C_FEE_RATE,
        FEE: Number(replaceAll(props?.formFeeValue + '' || '0', ',', '')),
        CONTENT: props?.formNote,
        CHANNEL: props?.formChannel,
        STATUS: 'CHUA_DUYET',
        BANK_CODE: props?.formBankSource,
      },
    };
    dispatch(cashHSUUpdateRequest(params));
  }

  function handleDblClick(record) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ADVANCE_WITHDRAW_INFO',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: record?.C_ACCOUNT_CODE,
        SELL_DATE: record?.C_SELL_DATE,
        DUE_DATE: record?.C_DUE_DATE,
      },
    };

    const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }
    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        console.log('res', res);
        if (res?.code > 0 && !!res?.data?.length) {
          setWithdrawInfo(res.data[0]);
          dispatch(
            change(
              'openUngTruocModalform',
              'formCashVolume',
              res.data[0]?.C_CASH_VOLUME
            )
          );
          // const _fee = Math.ceil(
          //   (res.data[0]?.C_FEE_RATE / 100) *
          //     Number(replaceAll(record.C_WITHDRAWABLE + '' || '0', ',', '')) *
          //     res.data[0]?.C_FEE_DAYS
          // );
          dispatch(
            change(
              'openUngTruocModalform',
              'formFeeRate',
              res.data[0]?.C_FEE_RATE
            )
          );
          // dispatch(
          //   change(
          //     'openUngTruocModalform',
          //     'formFeeValue',
          //     _fee < res.data[0].C_FEE_MIN ? res.data[0].C_FEE_MIN : _fee
          //   )
          // );
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, onClose } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-advance-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-channel')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formChannel"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số bút toán</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    name="formTransDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label className="fz-13">
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccount"
                    className="form-control "
                    classParent="w-100"
                    validate={[required]}
                    component={RenderNewInputAccount}
                    index={3}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label className="fz-13">{t('txt-acc-name')}</Form.Label>
                  <Form.Control
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-marketing-id')}
                  </Form.Label>
                  <Form.Control
                    value={accDetail?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group> */}
                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label className="fz-13">
                    {t('txt-card-id-2')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAuthorCardId"
                    className="form-control"
                    component={RenderSuggestCustomer}
                    validate={[required]}
                    index={2}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advancer-name')}
                  </Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-mobile')}</Form.Label>
                  <Form.Control
                    value={custDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group> */}

                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-list-sale-stock-not-back')}
                </p>
                <div style={{ gridColumn: '1/5' }}>
                  <Table bordered className="w-100">
                    <colgroup>
                      <col width="10%" />
                      <col width="10%" />
                      <col width="15%" />
                      <col width="10%" />
                      <col width="10%" />
                      <col width="15%" />
                      <col width="15%" />
                      <col width="15%" />
                    </colgroup>
                    <thead>
                      <tr>
                        <th>{t('txt-sell-date')}</th>
                        <th>{t('txt-due-date')}</th>
                        <th>{t('txt-sell-cash-total')}</th>
                        <th>{t('txt-sell-fee')}</th>
                        <th>{t('txt-tax')}</th>
                        <th>{t('txt-bonus-stock-tax')}</th>
                        <th>{t('txt-advanced-fee')}</th>
                        <th>{t('txt-cash-to-be-advance')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cashSell &&
                        cashSell.map((item) => (
                          <tr
                            key={item.ROW_NUM}
                            onClick={() => handleDblClick(item)}
                            style={{ cursor: 'pointer' }}
                          >
                            <td className="text-center">{item.C_SELL_DATE}</td>
                            <td className="text-center">{item.C_DUE_DATE}</td>
                            <td className="text-right">
                              {numberFormat(item.C_SELL_CASH_TOTAL)}
                            </td>
                            <td className="text-right">
                              {numberFormat(item.C_SELL_COMM)}
                            </td>
                            <td className="text-right">
                              {numberFormat(item.C_SELL_TAX)}
                            </td>
                            <td className="text-right">
                              {numberFormat(item.C_RIGHT_SELL_PAY_TAX)}
                            </td>
                            <td className="text-right">
                              {numberFormat(
                                item.C_WITHDRAWED + item.C_WITHDRAWED_FEE
                              )}
                            </td>
                            <td className="text-right">
                              {numberFormat(item.C_WITHDRAWABLE)}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </Table>
                </div>
                {/* <Form.Group>
                  <Form.Label>
                    {t('txt-advance-source')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankSource"
                    className="form-control"
                    component={RenderAdvanceSource}
                    validate={[required]}
                  />
                </Form.Group> */}
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advanced-city')}
                  </Form.Label>
                  <Form.Control
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_BANK_WITHDRAWED) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-credit-limit-city')}
                  </Form.Label>
                  <Form.Control
                    value={
                      cashCreditLimitCity
                        ? numberFormat(cashCreditLimitCity?.C_CASH_VALUE) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-cust-advanced-day')}
                  </Form.Label>
                  <Form.Control
                    value={
                      cashWithdrawAcc
                        ? numberFormat(cashWithdrawAcc?.C_CASH_VALUE) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label className="fz-13">
                    {t('txt-sell-date')}
                  </Form.Label>
                  <Form.Control
                    value={withdrawInfo?.C_SELL_DATE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-due-date')}</Form.Label>
                  <Form.Control
                    value={withdrawInfo?.C_DUE_DATE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advance-day-number')}
                  </Form.Label>
                  <Form.Control
                    value={withdrawInfo ? withdrawInfo?.C_FEE_DAYS || '0' : ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-sell-cash-total')}
                  </Form.Label>
                  <Form.Control
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_SELL_CASH_TOTAL) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-sell-fee')}</Form.Label>
                  <Form.Control
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_SELL_COMM) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-sell-tax')}</Form.Label>
                  <Form.Control
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_SELL_TAX) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advanced-fee')}
                  </Form.Label>
                  <Form.Control
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_WITHDRAWED) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-cash-to-be-advance')}
                  </Form.Label>
                  <Form.Control
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_WITHDRAWABLE) || '0'
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label className="fz-13">
                    {t('txt-advance-cash')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-interest-rate-2')}
                  </Form.Label>
                  <Field
                    name="formFeeRate"
                    className="form-control"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advance-fee')}
                  </Form.Label>
                  <Field
                    name="formFeeValue"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-advance-cash-fee')}
                  </Form.Label>
                  {/* <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      withdrawInfo
                        ? numberFormat(withdrawInfo?.C_CASH_TOTAL) || '0'
                        : ''
                    }
                    disabled
                  /> */}
                  <Field
                    name="formTotalValue"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label className="fz-13">{t('txt-content')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddUngTruocModal = reduxForm({
  form: 'openUngTruocModalform',
  enableReinitialize: true,
})(AddUngTruocModal);

const selector = formValueSelector('openUngTruocModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSingleList = makeGetSingleList();
  const getAccountSingle = makeGetAccountSingle();
  const getCashHSUUpdate = makeGetCashHSUUpdate();
  const getGlobalCashDeposit = makeGetGlobalCashDeposit();
  const getChannelType = makeGetChannelType();
  const getCustomerDetail = makeGetCustomerDetail();
  const getSystemInfo = makeGetSystemInfo();
  const getCashCreditLimitCity = makeGetCashCreditLimitCity();
  const getCashWithdrawAcc = makeGetCashWithdrawAcc();
  const getShareFee = makeGetShareFee();
  const {
    formAccount,
    formAuthorCardId,
    formChannel,
    formCashVolume,
    formFeeRate,
    formFeeValue,
    formNote,
    formBankSource,
    formCashFee,
  } = selector(
    state,
    'formAccount',
    'formAuthorCardId',
    'formChannel',
    'formCashVolume',
    'formFeeRate',
    'formFeeValue',
    'formNote',
    'formBankSource',
    'formCashFee'
  );

  return {
    token: getToken(state),
    glSingleList: getSingleList(state),
    accDetail: getAccountSingle(state),
    custDetail: getCustomerDetail(state),
    cashHSUUpdate: getCashHSUUpdate(state),
    glCashDeposit: getGlobalCashDeposit(state),
    glChannelType: getChannelType(state),
    sysSystemInfo: getSystemInfo(state),
    cashCreditLimitCity: getCashCreditLimitCity(state),
    cashWithdrawAcc: getCashWithdrawAcc(state),
    shareFee: getShareFee(state),
    formAccount,
    formAuthorCardId,
    formChannel,
    formCashVolume,
    formFeeRate,
    formFeeValue,
    formNote,
    formBankSource,
    formCashFee,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddUngTruocModal)
);
