import RenderArea from 'components/input/renderArea';
import RenderDatePicker from 'components/input/renderDatePicker';
import RenderSuggestCustomer from 'components/input/renderNewInput';
import RenderSuggestShare from 'components/input/renderSuggestShare';
import RenderInput from 'components/input/renderInput';
import RenderSelectDate from 'components/input/renderDatePicker';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  shareSingleRequest,
  shareSingleSuccess,
} from 'containers/stock/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form, FormGroup } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';

import {
  makeGetCashMHCUApprove,
  makeGetCashMHCUDel,
  makeGetCashMHCUSingle,
  makeGetCashMHCUUpdate,
  makeGetCustomerDetail,
  makeGetShareSingle,
  makeGetToken,
} from 'lib/selector';

import {
  cashMHCUApproveRequest,
  cashMHCUDelRequest,
  cashMHCUDetailRequest,
  cashMHCUDetailSuccess,
  cashMHCUUpdateRequest,
  cashMHCUUpdateSuccess,
} from 'containers/cash/actions';
import { _diff2Date, stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formFromDate, formToDate } = values;

  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

function AddHanCheUngModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    formCustomerCode,
    cashUpdateHMU,
    record,
    cashMHCUSingle,
    cashDelHMU,
    cashApproveHMU,
    formShareCode,
    shareSingle,
    accRight,
    formFromDate,
  } = props;
  const preCashDelHMU = usePrevious(cashDelHMU);
  const preCashUpdateHMU = usePrevious(cashUpdateHMU);
  const preCashApproveHMU = usePrevious(cashApproveHMU);
  const preCashMHCUSingle = usePrevious(cashMHCUSingle);

  useEffect(() => {
    if (cashMHCUSingle && !_.isEqual(cashMHCUSingle, preCashMHCUSingle)) {
      initForm();
    }
  }, [cashMHCUSingle]);

  useEffect(() => {
    if (record) handleGetDetail();
    return () => {
      dispatch(cashMHCUDetailSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(shareSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formShareCode) {
      _handleCheckShare();
    }
  }, [formShareCode]);

  useEffect(() => {
    if (formCustomerCode) {
      _handleCheckCustomer();
    }
  }, [formCustomerCode]);

  useEffect(() => {
    if (cashUpdateHMU && !_.isEqual(cashUpdateHMU, preCashUpdateHMU)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashMHCUUpdateSuccess(null));
      handleGetDetail();
    }
  }, [cashUpdateHMU]);

  useEffect(() => {
    if (cashDelHMU && !_.isEqual(cashDelHMU, preCashDelHMU)) {
      onClose();
    }
  }, [cashDelHMU]);

  useEffect(() => {
    if (cashApproveHMU && !_.isEqual(cashApproveHMU, preCashApproveHMU)) {
      handleGetDetail();
    }
  }, [cashApproveHMU]);

  function initForm() {
    dispatch(
      change(
        'openHanCheUngModalform',
        'formCustomerCode',
        cashMHCUSingle?.C_CUSTOMER_CODE
      )
    );
    dispatch(
      change(
        'openHanCheUngModalform',
        'formShareCode',
        cashMHCUSingle?.C_SHARE_CODE
      )
    );
    dispatch(
      change(
        'openHanCheUngModalform',
        'formFromDate',
        cashMHCUSingle?.C_FROM_DATE
      )
    );
    dispatch(
      change('openHanCheUngModalform', 'formToDate', cashMHCUSingle?.C_TO_DATE)
    );
    dispatch(
      change('openHanCheUngModalform', 'formNote', cashMHCUSingle?.C_CONTENT)
    );
    dispatch(
      change(
        'openHanCheUngModalform',
        'formTransNo',
        cashMHCUSingle?.C_TRANSACTION_NO
      )
    );
    dispatch(
      change(
        'openHanCheUngModalform',
        'formTransDate',
        cashMHCUSingle?.C_TRANSACTION_DATE
      )
    );
  }

  function _handleCheckShare() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_SHARE',
      group: 'LIST',
      data: {
        SHARE_ID: formShareCode,
      },
    };

    dispatch(shareSingleRequest(params));
  }

  function _handleCheckCustomer() {
    if (!formCustomerCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formCustomerCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function handleGetDetail() {
    if (!record) return;

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ADV_SHARE_LIMIT',
      group: 'LIST',
      data: {
        ITEM_ID: record?.PK_ADVANCE_SHARE_LIMIT,
      },
    };

    dispatch(cashMHCUDetailRequest(params));
  }

  function submit(values) {
    console.log(values);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_ADV_SHARE_LIMIT',
      group: 'LIST',
      data: {
        ITEM_ID: record?.PK_ADVANCE_SHARE_LIMIT,
        CUSTOMER_CODE: values?.formCustomerCode.trim(),
        SHARE_CODE: values?.formShareCode.toUpperCase().trim(),
        FROM_DATE: values?.formFromDate,
        TO_DATE: values?.formToDate,
        CONTENT: values?.formNote,
        STATUS: cashMHCUSingle?.C_STATUS || 'CHUA_DUYET',
      },
    };

    dispatch(cashMHCUUpdateRequest(params));
  }

  function _handleApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_ADV_SHARE_LIMIT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_ADVANCE_SHARE_LIMIT,
      },
    };

    dispatch(cashMHCUApproveRequest(params));
  }

  function _handleDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_ADV_SHARE_LIMIT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: record?.PK_ADVANCE_SHARE_LIMIT,
      },
    };

    dispatch(cashMHCUDelRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t, customerDetail } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
      ariaHideApp={false}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">
            {t('txt-detail-limit-advance-code-info')}
          </b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <FormAdd>
              {/* <Form.Group>
                <Form.Label>{t('txt-trans-no')}</Form.Label>
                <Field
                  name="formTransNo"
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderInput}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-date-trading')}</Form.Label>
                <Field
                  className="form-control"
                  name="formTransDate"
                  type="start"
                  component={RenderSelectDate}
                  validate={required}
                  disabled
                />
              </Form.Group> */}
              <FormGroup style={{ gridColumn: '1/2' }}>
                <Form.Label className="fz-13">
                  {t('txt-cust')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formCustomerCode"
                  className="form-control "
                  component={RenderSuggestCustomer}
                  validate={[required]}
                  index="2"
                />
              </FormGroup>
              <FormGroup style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">{t('txt-cust-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={customerDetail?.C_CUSTOMER_NAME || ''}
                  disabled
                />
              </FormGroup>
              <Form.Group>
                <Form.Label>{t('txt-subBranch')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={(customerDetail?.C_SUB_BRANCH_CODE || '') + ' - ' + (customerDetail?.C_SUB_BRANCH_NAME || '')}
                  disabled
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>{t('txt-phone')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={customerDetail?.C_CUST_MOBILE || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group>
                <Form.Label>{t('txt-email')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={customerDetail?.C_CUST_EMAIL || ''}
                  disabled
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '3/5' }}>
                <Form.Label>{t('txt-address')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={customerDetail?.C_RESEDENCE_ADDRESS || ''}
                  disabled
                />
              </Form.Group>
              <FormGroup>
                <Form.Label className="fz-13">
                  {t('txt-share-code')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formShareCode"
                  className="form-control"
                  component={RenderSuggestShare}
                  validate={[required]}
                />
              </FormGroup>
              <FormGroup style={{ gridColumn: '2/4' }}>
                <Form.Label className="fz-13">{t('txt-share-name')}</Form.Label>
                <input
                  type={'text'}
                  className="form-control input-order fz-13"
                  value={shareSingle?.C_SHARE_NAME || ''}
                  disabled
                />
              </FormGroup>
              <FormGroup style={{ gridColumn: '1/2' }}>
                <Form.Label className="fz-13">
                  {t('txt-from-date')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formFromDate"
                  className="form-control"
                  classParentName="w-100"
                  component={RenderDatePicker}
                  validate={[required]}
                />
              </FormGroup>
              <FormGroup>
                <Form.Label className="fz-13">
                  {t('txt-to-date')}
                  <span className="text-danger">*</span>
                </Form.Label>
                <Field
                  name="formToDate"
                  className="form-control"
                  classParentName="w-100"
                  component={RenderDatePicker}
                  minDate={
                    formFromDate && !formFromDate.includes('_')
                      ? formFromDate
                      : null
                  }
                  validate={[required]}
                />
              </FormGroup>
              <Form.Group style={{ gridColumn: '1/5' }}>
                <Form.Label className="fz-13">{t('txt-content')}</Form.Label>
                <Field
                  name="formNote"
                  className="form-control"
                  component={RenderArea}
                  rows="2"
                />
              </Form.Group>
              <div
                className="d-flex mt-2"
                style={{ gridColumn: '1/5', gap: '5px 20px' }}
              >
                <div className="d-flex flex-column">
                  <Form.Label>
                    {t('txt-creator')}
                    {': '}
                    {cashMHCUSingle?.C_CREATOR_CODE}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-create-time')}
                    {': '}
                    {cashMHCUSingle?.C_CREATE_TIME || ''}
                  </Form.Label>
                </div>
                <div className="d-flex flex-column">
                  <Form.Label>
                    {t('txt-approver')}
                    {': '}
                    {cashMHCUSingle?.C_APPROVER_CODE || ''}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-approve-time')}
                    {': '}
                    {cashMHCUSingle?.C_APPROVE_TIME || ''}
                  </Form.Label>
                </div>
              </div>
            </FormAdd>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_APPROVE === 1 &&
                  cashMHCUSingle?.C_STATUS === 'CHUA_DUYET' && (
                    <BtnSubmit
                      type="button"
                      disabled={submitting}
                      onClick={_handleApprove}
                      className="w_125 ml-2 info"
                    >
                      {t('bnt-appr-entry')}
                    </BtnSubmit>
                  )}
                {accRight?.C_UPDATE === 1 &&
                  cashMHCUSingle?.C_STATUS === 'CHUA_DUYET' && (
                    <>
                      <BtnSubmit
                        type="button"
                        disabled={submitting}
                        onClick={_handleDel}
                        className="w_125 ml-2 danger"
                      >
                        {t('bnt-del-entry')}
                      </BtnSubmit>
                      <BtnSubmit
                        type="submit"
                        disabled={submitting}
                        className="w_125 ml-2"
                      >
                        {t('bnt-edit-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddHanCheUngModal = reduxForm({
  form: 'openHanCheUngModalform',
  enableReinitialize: true,
  validate,
})(AddHanCheUngModal);

const selector = formValueSelector('openHanCheUngModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCustomerDetail = makeGetCustomerDetail();
  const getCashMHCUSingle = makeGetCashMHCUSingle();
  const getCashDelHMU = makeGetCashMHCUDel();
  const getCashApproveHMU = makeGetCashMHCUApprove();
  const getCashUpdateHMU = makeGetCashMHCUUpdate();
  const getShareSingle = makeGetShareSingle();
  const {
    formCustomerCode,
    formShareCode,
    formFromDate,
    formToDate,
    formNote,
  } = selector(
    state,
    'formCustomerCode',
    'formShareCode',
    'formFromDate',
    'formToDate',
    'formNote'
  );

  const d = new Date();
  d.setDate(d.getDate() - 30);
  const cashMHCUSingle = getCashMHCUSingle(state);
  return {
    token: getToken(state),
    customerDetail: getCustomerDetail(state),
    cashMHCUSingle,
    cashUpdateHMU: getCashUpdateHMU(state),
    cashDelHMU: getCashDelHMU(state),
    cashApproveHMU: getCashApproveHMU(state),
    shareSingle: getShareSingle(state),
    formCustomerCode,
    formShareCode,
    formFromDate,
    formToDate,
    formNote,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddHanCheUngModal)
);
