import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSelectSubBranch from 'components/input/renderSelectSubBranch';
import RenderSuggestBankIDN from 'components/input/renderSuggestBankIDN';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, formatDate } from 'utils';
import { arrGateWay, limitNapas } from 'utils/const';
import { lengthRequired, required } from 'utils/validation';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';
import { handleApiErrors } from 'lib/api-errors';
import DetailAuthorPerson from 'components/modal/detail-pop-up/detailAuthorPerson';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashTransferUpdateRequest,
  cashTransferUpdateSuccess,
} from 'containers/cash/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalAuthorPersonRequest,
  globalAuthorPersonSuccess,
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
import {
  makeGetAccountAuthorSingle,
  makeGetAccountSingle,
  makeGetAllSubBranch,
  makeGetCashBalance,
  makeGetCashTransferUpdate,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetGLAuthorPerson,
  makeGetProvinceList,
  makeGetSingleList,
  makeGetToken,
} from 'lib/selector';
import { numberFormat } from 'utils';
import { BtnClose, BtnDetail, BtnSubmit } from 'utils/styledComponent';
import { validateNumberExact } from 'utils/validation';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddCKOnlineModal(props) {
  const dispatch = useDispatch();
  const [accSource, setAccSource] = React.useState(null);
  const [checkInfor, setCheckInfor] = React.useState(null);
  const [detailTS, setDetailTS] = React.useState(null);
  const [detailNUQId, setDetailNUQId] = React.useState(null);
  const {
    token,
    formAccountSource,
    cashTransferUpd,
    glChannelType,
    accountSingle,
    glProvince,
    glSingleList,
    glAllSubBranch,
    formGateway,
    formBranchBank,
    formTargetBankCode,
    formTargetProvince,
    cashBalance,
    formCashVolume,
    formFeeType,
    formCheck,
    formAuthorPerson,
    glAuthorPerson,
    custDetail,
  } = props;
  const preCashTransferUpd = usePrevious(cashTransferUpd);
  const preFormCashVolume = usePrevious(formCashVolume);
  const preCashBalance = usePrevious(cashBalance);
  const preFormFeeType = usePrevious(formFeeType);
  const preFormAccountSource = usePrevious(formAccountSource);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(custDetailSuccess(null));
      dispatch(cashBalanceSuccess(null));
      dispatch(globalSingleListSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountSource && formAccountSource.length === 7) {
      _handleCheckAccount();
      _handleCheckBalance();
      _handleCheckAuthorPerson();
    } else {
      setAccSource(null);
      dispatch(cashBalanceSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(globalAuthorPersonSuccess(null));
      dispatch(custDetailSuccess(null));
    }
    if (!_.isEqual(formAccountSource, preFormAccountSource)) {
      dispatch(change('openCKOnlModalform', 'formCheck', '0'));
    }
  }, [formAccountSource]);

  useEffect(() => {
    if (formCheck) {
      setCheckInfor(
        formCheck === '0' ? true : formCheck === '1' ? false : null
      );
      dispatch(change('openCKOnlModalform', 'formAuthorPerson', ''));
      if (
        formAccountSource &&
        glAuthorPerson.length <= 0 &&
        formCheck === '1'
      ) {
        _handleToast(`${t('txt-alert-author-person-infor')}`, 'error');
      }
    }
  }, [formCheck]);

  useEffect(() => {
    if (formAuthorPerson) {
      _handleCheckCustomer();
    } else {
      dispatch(custDetailSuccess(null));
    }
  }, [formAuthorPerson]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (formFeeType && !_.isEqual(formFeeType, preFormFeeType)) {
      dispatch(change('openCKOnlModalform', 'formTransferFee', ''));
    }
  }, [formFeeType]);

  useEffect(() => {
    if (
      formCashVolume &&
      cashBalance &&
      (!_.isEqual(formCashVolume, preFormCashVolume) ||
        !_.isEqual(cashBalance, preCashBalance))
    ) {
      if (StringToInt(formCashVolume) > cashBalance?.C_CASH_BALANCE_FO) {
        _handleToast(t('txt-amount-exceed-current-balance'), 'error');
        dispatch(change('openCKOnlModalform', 'formCashVolume', ''));
      }
    }
  }, [formCashVolume, cashBalance]);

  useEffect(() => {
    if (cashTransferUpd && !_.isEqual(cashTransferUpd, preCashTransferUpd)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashTransferUpdateSuccess(null));
      onClose();
    }
  }, [cashTransferUpd]);

  function initForm() {
    dispatch(change('openCKOnlModalform', 'formBusinessType', 'D'));
    dispatch(change('openCKOnlModalform', 'formRadType', '0'));
    dispatch(change('openCKOnlModalform', 'formFeeType', '0'));
    dispatch(change('openCKOnlModalform', 'formCheck', '0'));
    dispatch(change('openCKOnlModalform', 'formCashVolume', 0));
    dispatch(change('openCKOnlModalform', 'formTransferFee', 0));
    dispatch(change('openCKOnlModalform', 'formBranchBank', '000'));
    dispatch(
      change(
        'openCKOnlModalform',
        'formTransDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function handleDetailNUQId() {
    if (!formAuthorPerson) return;
    const resultIncludes = glAuthorPerson.find((item) =>
      item.value.includes(formAuthorPerson)
    );
    setDetailNUQId(resultIncludes?.pk);
  }

  function _handleCheckCustomer() {
    if (!formAuthorPerson) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorPerson,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckAuthorPerson() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
        STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalAuthorPersonRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountSource,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  // function submit() {
  //   handleConfirm();
  // }

  function submit() {
    //if (formCheck === '1') {
      const params = {
        user: token?.USER_NAME,
        session: token?.SESSION_ID,
        cmd: 'BACK.CHECK_AUTHOR',
        group: 'LIST',
        data: {
          ACCOUNT_CODE: formAccountSource,
          CUSTOMER_CODE: checkInfor
            ? accountSingle?.C_CARD_ID
            : custDetail?.C_CARD_ID,
          BUSINESS_CODE: 'KY_CHUYEN_TIEN',
        },
      };

          const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


      fetch(appUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
        },
        body: JSON.stringify(params),
      })
        .then(handleApiErrors)
        .then((response) => response.json())
        .then((json) => {
          console.log(json);
          if (json.code === '1') {
            json.data[0].C_CHECK === 1
              ? handleConfirm()
              : _handleToast(t('txt-unauthorized-acc'), 'error');
          } else {
            _handleToast(json.re, 'error');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    //} else handleConfirm();
  }


  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_TRANSFER_OUT',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        ACCOUNT_OUT: props?.formAccountSource,
        AUTHOR_FLAG: StringToInt(props?.formCheck),
        AUTHOR_CARD_ID: checkInfor
          ? accountSingle?.C_CARD_ID
          : custDetail?.C_CARD_ID,
        AUTHOR_NAME: checkInfor
          ? accountSingle?.C_CUSTOMER_NAME
          : custDetail?.C_CUSTOMER_NAME,
        ACCOUNT_IN: props?.formAccountTarget,
        ACCOUNT_IN_NAME: props?.formAccountTargetName,
        BANK_CODE_ACCOUNT_IN: props?.formTargetBankCode,
        BANK_PROVINCE_ACCOUNT_IN: props?.formTargetProvince,
        BANK_BRANCH_ACCOUNT_IN: props?.formTargetBankBranch,
        CASH_VALUE: StringToInt(props?.formCashVolume),
        FEE_VALUE: StringToInt(props?.formTransferFee),
        RECEIVE_FEE_FLAG: StringToInt(props?.formFeeType),
        BRANCH_BANK_CODE: props?.formBranchBank,
        CHANNEL_CODE: props?.formBusinessType,
        PHONE_LINE: props?.formPhoneLine,
        ONLINE_FLAG: 1, // online
        ONLINE_CHANNEL:
          StringToInt(props?.formFeeType) < limitNapas ? 'NAPAS' : 'CITAD', // Kenh chuyen tien
        ONLINE_GATEWAY: props?.formGateway,
        CONTENT: props?.formContent,
        WITHDRAW_TYPE: StringToInt(props?.formRadType),
        TRANSACTION_DATE: props?.formTransDate,
      },
    };
    dispatch(cashTransferUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  function handleDetailTS() {
    if (!formAccountSource) return;
    setDetailTS(formAccountSource);
  }

  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-transfer-bank-ol-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-channel')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    validate={[required]}
                    required
                    index={5}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-ext-number')}</Form.Label>
                  <Field
                    name="formPhoneLine"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-trans-no')}</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    className="form-control"
                    name="formTransDate"
                    type="start"
                    component={RenderSelectDate}
                    validate={required}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-sender-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountSource"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index={4}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accountSingle?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accountSingle
                        ? `${accountSingle?.C_SUB_BRANCH_CODE} - ${accountSingle?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-phone')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_MOBILE
                        : custDetail?.C_CUST_MOBILE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_EMAIL
                        : custDetail?.C_CUST_EMAIL) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_RESEDENCE_ADDRESS
                        : custDetail?.C_RESEDENCE_ADDRESS) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Người thực hiện
                  </Form.Label>
                  <Field
                    name="formCheck"
                    className="form-control"
                    component="select"
                  >
                    <option value="0"> {t('txt-main-account')}</option>
                    <option value="1">{t('txt-author-person')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-author-person-id')}
                    {!checkInfor && <span className="text-danger">*</span>}
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <Field
                      name="formAuthorPerson"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderNormalSelect}
                      opts={glAuthorPerson}
                      index={4}
                      disabled={checkInfor}
                      validate={!checkInfor ? required : null}
                    />
                    <BtnDetail type="button" onClick={handleDetailNUQId} />
                  </div>
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CARD_ID
                        : custDetail?.C_CARD_ID) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-withdrawer-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUSTOMER_NAME
                        : custDetail?.C_CUSTOMER_NAME) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-transfer-fee')}</Form.Label>
                  <Field
                    name="formTransferFee"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    disabled={formFeeType === '1'}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Hình thức trả phí
                  </Form.Label>
                  <Field
                    name="formFeeType"
                    className="form-control"
                    component="select"
                  >
                    <option value="0">{t('txt-sender-acc-pay')}</option>
                    <option value="1"> {t('txt-target-acc-pay')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>Số có thể chuyển</Form.Label>
                  <div className="d-flex justify-content-between">
                    <input
                      type={'text'}
                      className="form-control fz-13"
                      value={
                        cashBalance?.C_CASH_BALANCE_BO === 0
                          ? '0'
                          : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                      }
                      disabled
                    />
                    <BtnDetail type="button" onClick={handleDetailTS} />
                  </div>
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('txt-acc-total')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Gateway<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formGateway"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={arrGateWay}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-bank')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formTargetBankCode"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBankIDN}
                    validate={[required]}
                    index="2"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t(t('txt-target-acc-1'))}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountTarget"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountTargetName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailNUQId && (
        <DetailAuthorPerson
          id={detailNUQId}
          onClose={() => setDetailNUQId(null)}
        />
      )}
      {detailTS && (
        <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
      )}
    </ReactModal>
  );
}

AddCKOnlineModal = reduxForm({
  form: 'openCKOnlModalform',
  enableReinitialize: true,
})(AddCKOnlineModal);

const selector = formValueSelector('openCKOnlModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCashTransferUpdate = makeGetCashTransferUpdate();
  const getCustomerDetail = makeGetCustomerDetail();
  const getChannelType = makeGetChannelType();
  const getProvinceList = makeGetProvinceList();
  const getSingleList = makeGetSingleList();
  const getAllSubBranch = makeGetAllSubBranch();
  const getCashBalance = makeGetCashBalance();
  const getAccountSingle = makeGetAccountSingle();
  const getGLAuthorPerson = makeGetGLAuthorPerson();
  const getAccountAuthorSingle = makeGetAccountAuthorSingle();

  const {
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formBranchBank,
    formAccountTarget,
    formAccountTargetName,
    formGateway,
    formTargetBankCode,
    formTargetProvince,
    formTargetBankBranch,
    formTransferFee,
    formFeeType,
    formContent,
    formCheck,
    formAuthorPerson,
    formTransDate,
  } = selector(
    state,
    'formBusinessType',
    'formPhoneLine',
    'formAccountSource',
    'formTransferCertId',
    'formRadType',
    'formCashVolume',
    'formBranchBank',
    'formAccountTarget',
    'formAccountTargetName',
    'formGateway',
    'formTargetBankCode',
    'formTargetProvince',
    'formTargetBankBranch',
    'formTransferFee',
    'formFeeType',
    'formContent',
    'formCheck',
    'formAuthorPerson',
    'formTransDate'
  );

  return {
    token: getToken(state),
    cashTransferUpd: getCashTransferUpdate(state),
    custDetail: getCustomerDetail(state),
    glChannelType: getChannelType(state),
    glProvince: getProvinceList(state),
    glSingleList: getSingleList(state),
    glAllSubBranch: getAllSubBranch(state),
    cashBalance: getCashBalance(state),
    accountSingle: getAccountSingle(state),
    glAuthorPerson: getGLAuthorPerson(state),
    accAuthorSingle: getAccountAuthorSingle(state),
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formBranchBank,
    formAccountTarget,
    formAccountTargetName,
    formGateway,
    formTargetBankCode,
    formTargetProvince,
    formTargetBankBranch,
    formTransferFee,
    formFeeType,
    formContent,
    formCheck,
    formAuthorPerson,
    formTransDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddCKOnlineModal)
);
