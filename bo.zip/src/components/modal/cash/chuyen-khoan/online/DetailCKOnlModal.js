import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSelectSubBranch from 'components/input/renderSelectSubBranch';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderSuggestBankIDN from 'components/input/renderSuggestBankIDN';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import DetailAuthorPerson from 'components/modal/detail-pop-up/detailAuthorPerson';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import { handleApiErrors } from 'lib/api-errors';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashManagementApproveRequest,
  cashManagementApproveSuccess,
  cashManagementDelRequest,
  cashManagementDelSuccess,
  cashManagementRejectRequest,
  cashManagementRejectSuccess,
  cashManagementSingleRequest,
  cashManagementSingleSuccess,
  cashManagementUnApproveRequest,
  cashManagementUnApproveSuccess,
  cashTransferUpdateRequest,
  cashTransferUpdateSuccess,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalAuthorPersonRequest,
  globalAuthorPersonSuccess,
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
import {
  makeGetAccountAuthorSingle,
  makeGetAccountSingle,
  makeGetAllSubBranch,
  makeGetCashBalance,
  makeGetCashManagementApprove,
  makeGetCashManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementSingle,
  makeGetCashManagementUnApprove,
  makeGetCashTransferUpdate,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetGLAuthorPerson,
  makeGetProvinceList,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import {
  StringToInt,
  _diff2Date,
  formatDate,
  stringToDate,
  numberFormat,
} from 'utils';
import { arrGateWay, limitNapas } from 'utils/const';
import { BtnClose, BtnDetail, BtnSubmit } from 'utils/styledComponent';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';
import {
  lengthRequired,
  required,
  validateNumberExact,
} from 'utils/validation';
import { globalExportFileWordRequest } from 'containers/report/actions';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function DetailCKUNCModal(props) {
  const dispatch = useDispatch();
  const [accSource, setAccSource] = React.useState(null);
  const [diff, setDiff] = React.useState(false);
  const [checkInfor, setCheckInfor] = React.useState(null);
  const [detailNUQId, setDetailNUQId] = React.useState(null);
  const [detailTS, setDetailTS] = React.useState(null);
  const {
    token,
    custDetail,
    formAccountSource,
    cashTransferUpd,
    glChannelType,
    formTransferCertId,
    cashMngSingle,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    id,
    pristine,
    glSingleList,
    glProvince,
    glAllSubBranch,
    formGateway,
    formTargetBankCode,
    formTargetProvince,
    formContent,
    accRight,
    cashBalance,
    formCashVolume,
    formFeeType,
    formBranchBank,
    sysSystemInfo,
    formCheck,
    formAuthorPerson,
    glAuthorPerson,
    accountSingle,
  } = props;
  const preCashTransferUpd = usePrevious(cashTransferUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preFormCashVolume = usePrevious(formCashVolume);
  const preCashBalance = usePrevious(cashBalance);
  const preFormFeeType = usePrevious(formFeeType);
  const preCashMngSingle = usePrevious(cashMngSingle);
  const preFormAccountSource = usePrevious(formAccountSource);
  const preFormCheck = usePrevious(formCheck);

  useEffect(() => {
    if (cashMngSingle && !_.isEqual(cashMngSingle, preCashMngSingle)) {
      initForm();
    }
  }, [cashMngSingle]);

  useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(custDetailSuccess(null));
      dispatch(cashManagementSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountSource && formAccountSource.length === 7) {
      _handleCheckAccount();
      _handleCheckAuthorPerson();
      _handleCheckBalance();
    } else {
      setAccSource(null);
      dispatch(cashBalanceSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(globalAuthorPersonSuccess(null));
      dispatch(custDetailSuccess(null));
    }
    if (!!preFormCheck && !_.isEqual(formAccountSource, preFormAccountSource)) {
      dispatch(change('detailCKOnlModalform', 'formCheck', '0'));
    }
  }, [formAccountSource]);

  useEffect(() => {
    if (formCheck) {
      setCheckInfor(
        formCheck === '0' ? true : formCheck === '1' ? false : null
      );
      if (formCheck === '0')
        dispatch(change('detailCKOnlModalform', 'formAuthorPerson', ''));
      if (
        formAccountSource &&
        !formAuthorPerson &&
        glAuthorPerson.length <= 0 &&
        formCheck === '1'
      ) {
        _handleToast(`${t('txt-alert-author-person-infor')}`, 'error');
      }
    }
  }, [formCheck]);

  useEffect(() => {
    if (formAuthorPerson) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formAuthorPerson]);

  useEffect(() => {
    if (
      formFeeType &&
      formFeeType === '1' &&
      !_.isEqual(formFeeType, preFormFeeType)
    ) {
      dispatch(change('detailCKOnlModalform', 'formTransferFee', ''));
    }
  }, [formFeeType]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (
      formCashVolume &&
      cashBalance &&
      cashBalance?.C_CASH_BALANCE_FO > StringToInt(formCashVolume) &&
      (!_.isEqual(formCashVolume, preFormCashVolume) ||
        !_.isEqual(cashBalance, preCashBalance))
    ) {
      dispatch(
        change(
          'detailCKOnlModalform',
          'formCashAfterTransfer',
          cashBalance?.C_CASH_BALANCE_FO - StringToInt(formCashVolume)
        )
      );
    } else
      dispatch(change('detailCKOnlModalform', 'formCashAfterTransfer', ''));
  }, [formCashVolume, cashBalance]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    ) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashManagementDelSuccess(null));
      onClose();
    }
  }, [cashManagementDel]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) {
      dispatch(cashManagementApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngApprove]);

  useEffect(() => {
    if (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) {
      dispatch(cashManagementUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngUnApprove]);

  useEffect(() => {
    if (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) {
      dispatch(cashManagementRejectSuccess(null));
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngReject]);

  useEffect(() => {
    if (cashTransferUpd && !_.isEqual(cashTransferUpd, preCashTransferUpd)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashTransferUpdateSuccess(null));
      handleGetSingle();
    }
  }, [cashTransferUpd]);

  function initForm() {
    dispatch(
      change(
        'detailCKOnlModalform',
        'formBusinessType',
        cashMngSingle?.C_CHANNEL_CODE
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formPhoneLine',
        cashMngSingle?.C_PHONE_LINE
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formAccountSource',
        cashMngSingle?.C_ACCOUNT_OUT
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTransferCertId',
        cashMngSingle?.C_AUTHOR_CERT_ID
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formCashVolume',
        cashMngSingle?.C_CASH_VOLUME
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formAccountTarget',
        cashMngSingle?.C_ACCOUNT_IN
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formAccountTargetName',
        cashMngSingle?.C_ACCOUNT_IN_NAME
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTargetProvince',
        cashMngSingle?.C_BANK_PROVINCE_ACCOUNT_IN
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTargetBankCode',
        cashMngSingle?.C_BANK_CODE_ACCOUNT_IN
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTargetBankBranch',
        cashMngSingle?.C_BANK_BRANCH_ACCOUNT_IN
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formBranchBank',
        cashMngSingle?.C_BRANCH_BANK_CODE
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formGateway',
        cashMngSingle?.C_BANK_GATEWAY
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTransferFee',
        cashMngSingle?.C_FEE_TRANSFER_OUT
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formFeeType',
        cashMngSingle?.C_RECEIVE_PAY_FEE_FLAG + ''
      )
    );
    dispatch(
      change('detailCKOnlModalform', 'formContent', cashMngSingle?.C_CONTENT)
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formRadType',
        cashMngSingle?.C_WITHDRAW_TYPE + ''
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formCheck',
        (cashMngSingle?.C_AUTHOR_FLAG).toString()
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formAuthorPerson',
        cashMngSingle?.C_CUST_AUTHOR
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTransNo',
        cashMngSingle?.C_TRANSACTION_NO
      )
    );
    dispatch(
      change(
        'detailCKOnlModalform',
        'formTransDate',
        cashMngSingle?.C_TRANSACTION_DATE
      )
    );
  }

  useEffect(() => {
    if (cashMngSingle && cashMngSingle?.C_TRANSACTION_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          cashMngSingle?.C_TRANSACTION_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [cashMngSingle]);

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(cashManagementSingleRequest(params));
  }

  function handleDetailNUQId() {
    if (!formAuthorPerson) return;
    const resultIncludes = glAuthorPerson.find((item) =>
      item.value.includes(formAuthorPerson)
    );
    setDetailNUQId(resultIncludes?.pk);
  }

  function _handleCheckCustomer() {
    if (!formAuthorPerson) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorPerson,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckAuthorPerson() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
        STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalAuthorPersonRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountSource,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function submit() {
    //if (formCheck === '1') {
      const params = {
        user: token?.USER_NAME,
        session: token?.SESSION_ID,
        cmd: 'BACK.CHECK_AUTHOR',
        group: 'LIST',
        data: {
          ACCOUNT_CODE: formAccountSource,
          CUSTOMER_CODE: checkInfor
            ? accountSingle?.C_CARD_ID
            : custDetail?.C_CARD_ID,
          BUSINESS_CODE: 'KY_CHUYEN_TIEN',
        },
      };

          const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


      fetch(appUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
        },
        body: JSON.stringify(params),
      })
        .then(handleApiErrors)
        .then((response) => response.json())
        .then((json) => {
          console.log(json);
          if (json.code === '1') {
            json.data[0].C_CHECK === 1
              ? handleUpdate()
              : _handleToast(t('txt-unauthorized-acc'), 'error');
          } else {
            _handleToast(json.re, 'error');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    //} else handleUpdate();
  }


  function handleUpdate() {
    if (formCashVolume > cashBalance?.C_CASH_BALANCE_FO) {
      _handleToast(t('txt-amount-exceed-current-balance'), 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_TRANSFER_OUT',
      group: 'LIST',
      data: {
        ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        ACCOUNT_OUT: props?.formAccountSource,
        AUTHOR_FLAG: StringToInt(props?.formCheck),
        AUTHOR_CARD_ID: checkInfor
          ? accountSingle?.C_CARD_ID
          : custDetail?.C_CARD_ID,
        AUTHOR_NAME: checkInfor
          ? accountSingle?.C_CUSTOMER_NAME
          : custDetail?.C_CUSTOMER_NAME,
        ACCOUNT_IN: props?.formAccountTarget,
        ACCOUNT_IN_NAME: props?.formAccountTargetName,
        BANK_CODE_ACCOUNT_IN: props?.formTargetBankCode,
        BANK_PROVINCE_ACCOUNT_IN: props?.formTargetProvince,
        BANK_BRANCH_ACCOUNT_IN: props?.formTargetBankBranch,
        CASH_VALUE: StringToInt(props?.formCashVolume),
        FEE_VALUE: StringToInt(props?.formTransferFee),
        RECEIVE_FEE_FLAG: StringToInt(props?.formFeeType),
        BRANCH_BANK_CODE: props?.formBranchBank,
        CHANNEL_CODE: props?.formBusinessType,
        PHONE_LINE: props?.formPhoneLine,
        ONLINE_FLAG: 1, // online
        ONLINE_CHANNEL:
          StringToInt(props?.formFeeType) < limitNapas ? 'NAPAS' : 'CITAD', // Kenh chuyen tien
        ONLINE_GATEWAY: props?.formGateway,
        CONTENT: props?.formContent,
        WITHDRAW_TYPE: StringToInt(props?.formRadType),
      },
    };
    dispatch(cashTransferUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                  ? t('txt-appr-entry')
                  : actionName === 'unApprove'
                    ? t('txt-unAppr-entry')
                    : actionName === 'reject'
                      ? t('txt-reject-entry')
                      : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    console.log(rejectText);
                    if (!rejectText) return;
                    handleActionRevert(rejectText);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UN_APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementUnApproveRequest(params));
  }

  function handleActionRevert(rejectText) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        CANCEL_NOTE: rejectText,
      },
    };

    dispatch(cashManagementRejectRequest(params));
  }

  function handleDetailTS() {
    if (!formAccountSource) return;
    setDetailTS(formAccountSource);
  }

  const { handleSubmit, submitting, reset, onClose, t } = props;

  function handlePrinter() {
    var content = formContent;
    if (content === null || content === undefined || content === '') {
      content = 'Chuyển khoản ra bank - UNC';
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountSource,
        CASH_VOLUME: formCashVolume,
        CONTENT: content,
      },
    };
    params.data.TEMPLATE_CODE = 'PHIEU_CHUYEN_KHOAN_UNC';
    dispatch(globalExportFileWordRequest(params));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-transfer-bank-ol-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-channel')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    validate={[required]}
                    required
                    index={5}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-ext-number')}</Form.Label>
                  <Field
                    name="formPhoneLine"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-trans-no')}</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    className="form-control"
                    name="formTransDate"
                    type="start"
                    component={RenderSelectDate}
                    validate={required}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-sender-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountSource"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index={4}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accountSingle?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accountSingle
                        ? `${accountSingle?.C_SUB_BRANCH_CODE} - ${accountSingle?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-phone')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_MOBILE
                        : custDetail?.C_CUST_MOBILE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_EMAIL
                        : custDetail?.C_CUST_EMAIL) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_RESEDENCE_ADDRESS
                        : custDetail?.C_RESEDENCE_ADDRESS) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Người thực hiện
                  </Form.Label>
                  <Field
                    name="formCheck"
                    className="form-control"
                    component="select"
                  >
                    <option value="0"> {t('txt-main-account')}</option>
                    <option value="1">{t('txt-author-person')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-author-person-id')}
                    {!checkInfor && <span className="text-danger">*</span>}
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <Field
                      name="formAuthorPerson"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderNormalSelect}
                      opts={glAuthorPerson}
                      index={4}
                      disabled={checkInfor}
                      validate={!checkInfor ? required : null}
                    />
                    <BtnDetail type="button" onClick={handleDetailNUQId} />
                  </div>
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CARD_ID
                        : custDetail?.C_CARD_ID) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-withdrawer-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUSTOMER_NAME
                        : custDetail?.C_CUSTOMER_NAME) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-transfer-fee')}</Form.Label>
                  <Field
                    name="formTransferFee"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    disabled={formFeeType === '1'}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Hình thức trả phí
                  </Form.Label>
                  <Field
                    name="formFeeType"
                    className="form-control"
                    component="select"
                  >
                    <option value="0">{t('txt-sender-acc-pay')}</option>
                    <option value="1"> {t('txt-target-acc-pay')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>Số có thể chuyển</Form.Label>
                  <div className="d-flex justify-content-between">
                    <input
                      type={'text'}
                      className="form-control fz-13"
                      value={
                        cashBalance?.C_CASH_BALANCE_BO === 0
                          ? '0'
                          : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                      }
                      disabled
                    />
                    <BtnDetail type="button" onClick={handleDetailTS} />
                  </div>
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('lab-acc-total')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index="1"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Gateway<span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formGateway"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={arrGateWay}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-bank')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formTargetBankCode"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBankIDN}
                    validate={[required]}
                    index="2"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-target-acc-1')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountTarget"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountTargetName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
                <div
                  className="d-flex mt-2"
                  style={{ gridColumn: '1/5', gap: '5px 20px' }}
                >
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-creator')}
                      {': '}
                      {cashMngSingle?.C_CREATOR_CODE}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-create-time')}
                      {': '}
                      {cashMngSingle?.C_CREATE_TIME || ''}
                    </Form.Label>
                  </div>
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-approver')}
                      {': '}
                      {cashMngSingle?.C_APPROVER_CODE || ''}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-approve-time')}
                      {': '}
                      {cashMngSingle?.C_APPROVE_TIME || ''}
                    </Form.Label>
                  </div>
                </div>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {/*<BtnSubmit*/}
                {/*  type="button"*/}
                {/*  onClick={handlePrinter}*/}
                {/*  className="w_125 ml-2 success"*/}
                {/*>*/}
                {/*  {t('lab-print-bill')}*/}
                {/*</BtnSubmit>*/}
                {(cashMngSingle?.C_STATUS === 'CHUA_DUYET' || cashMngSingle?.C_STATUS === 'DANG_XU_LY') && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('reject')}
                          className="w_125 ml-2 info"
                        >
                          {t('bnt-reject-entry')}
                        </BtnSubmit>
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="submit"
                          disabled={pristine || submitting}
                          className="w_125 ml-2"
                        >
                          {t('bnt-edit-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {cashMngSingle?.C_STATUS === 'DA_DUYET' &&
                  diff &&
                  accRight?.C_APPROVE === 1 && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
        {detailNUQId && (
          <DetailAuthorPerson
            id={detailNUQId}
            onClose={() => setDetailNUQId(null)}
          />
        )}
        {detailTS && (
          <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
        )}
      </div>
    </ReactModal>
  );
}

DetailCKUNCModal = reduxForm({
  form: 'detailCKOnlModalform',
  enableReinitialize: true,
})(DetailCKUNCModal);

const selector = formValueSelector('detailCKOnlModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCashTransferUpdate = makeGetCashTransferUpdate();
  const getCustomerDetail = makeGetCustomerDetail();
  const getChannelType = makeGetChannelType();
  const getCashManagementSingle = makeGetCashManagementSingle();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
  const getProvinceList = makeGetProvinceList();
  const getSingleList = makeGetSingleList();
  const getAllSubBranch = makeGetAllSubBranch();
  const getCashBalance = makeGetCashBalance();
  const getSystemInfo = makeGetSystemInfo();
  const getAccountSingle = makeGetAccountSingle();
  const getGLAuthorPerson = makeGetGLAuthorPerson();
  const getAccountAuthorSingle = makeGetAccountAuthorSingle();
  const {
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formBranchBank,
    formAccountTarget,
    formAccountTargetName,
    formGateway,
    formTargetBankCode,
    formTargetProvince,
    formTargetBankBranch,
    formTransferFee,
    formFeeType,
    formContent,
    formCashAfterTransfer,
    formCheck,
    formAuthorPerson,
  } = selector(
    state,
    'formBusinessType',
    'formPhoneLine',
    'formAccountSource',
    'formTransferCertId',
    'formRadType',
    'formCashVolume',
    'formBranchBank',
    'formAccountTarget',
    'formAccountTargetName',
    'formGateway',
    'formTargetBankCode',
    'formTargetProvince',
    'formTargetBankBranch',
    'formTransferFee',
    'formFeeType',
    'formContent',
    'formCashAfterTransfer',
    'formCheck',
    'formAuthorPerson'
  );
  const cashMngSingle = getCashManagementSingle(state);
  return {
    token: getToken(state),
    cashTransferUpd: getCashTransferUpdate(state),
    custDetail: getCustomerDetail(state),
    glChannelType: getChannelType(state),
    cashMngSingle,
    cashMngApprove: getCashManagementApprove(state),
    cashMngUnApprove: getCashManagementUnApprove(state),
    cashMngReject: getCashManagementReject(state),
    cashManagementDel: getCashManagementDel(state),
    custDetail: getCustomerDetail(state),
    glChannelType: getChannelType(state),
    glProvince: getProvinceList(state),
    glSingleList: getSingleList(state),
    glAllSubBranch: getAllSubBranch(state),
    cashBalance: getCashBalance(state),
    sysSystemInfo: getSystemInfo(state),
    accountSingle: getAccountSingle(state),
    glAuthorPerson: getGLAuthorPerson(state),
    accAuthorSingle: getAccountAuthorSingle(state),
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formBranchBank,
    formAccountTarget,
    formAccountTargetName,
    formGateway,
    formTargetBankCode,
    formTargetProvince,
    formTargetBankBranch,
    formTransferFee,
    formFeeType,
    formContent,
    formCashAfterTransfer,
    formCheck,
    formAuthorPerson,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailCKUNCModal)
);
