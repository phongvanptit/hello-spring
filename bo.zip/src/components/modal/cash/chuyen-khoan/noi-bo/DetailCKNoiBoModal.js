import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import DetailAuthorPerson from 'components/modal/detail-pop-up/detailAuthorPerson';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashManagementApproveRequest,
  cashManagementApproveSuccess,
  cashManagementDelRequest,
  cashManagementDelSuccess,
  cashManagementRejectRequest,
  cashManagementRejectSuccess,
  cashManagementSingleRequest,
  cashManagementSingleSuccess,
  cashManagementUnApproveRequest,
  cashManagementUnApproveSuccess,
  cashTransferUpdateRequest,
  cashTransferUpdateSuccess,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalAllAccRequest,
  globalAllAccSuccess,
  globalAuthorPersonRequest,
  globalAuthorPersonSuccess,
} from 'containers/global/actions';
import { handleApiErrors } from 'lib/api-errors';
import {
  makeGetAccountAuthorSingle,
  makeGetAccountSingle,
  makeGetCashManagementApprove,
  makeGetCashManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementSingle,
  makeGetCashManagementUnApprove,
  makeGetCashTransferUpdate,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetGLAuthorPerson,
  makeGetGlAllAcc,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import {
  StringToInt,
  _diff2Date,
  formatDate,
  numberFormat,
  stringToDate,
} from 'utils';
import { BtnClose, BtnDetail, BtnSubmit } from 'utils/styledComponent';
import {
  lengthRequired,
  required,
  validateNumberExact,
} from 'utils/validation';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddCTNoiBoModal(props) {
  const dispatch = useDispatch();
  const [accSource, setAccSource] = React.useState(null);
  const [accTarget, setAccTarget] = React.useState(null);
  const [diff, setDiff] = React.useState(false);
  const [checkInfor, setCheckInfor] = React.useState(null);
  const [detailNUQId, setDetailNUQId] = React.useState(null);
  const [detailTS, setDetailTS] = React.useState(null);

  const {
    token,
    custDetail,
    formAccountSource,
    formAccountTarget,
    cashTransferUpd,
    glChannelType,
    cashMngSingle,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    id,
    pristine,
    accRight,
    cashBalance,
    formCashVolume,
    sysSystemInfo,
    glAllAcc,
    formCheck,
    formAuthorPerson,
    glAuthorPerson,
    accountSingle,
    formRadType,
  } = props;
  const preCashTransferUpd = usePrevious(cashTransferUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preFormCashVolume = usePrevious(formCashVolume);
  const preCashBalance = usePrevious(cashBalance);
  const preCashMngSingle = usePrevious(cashMngSingle);
  const preFormAccountSource = usePrevious(formAccountSource);
  const preFormCheck = usePrevious(formCheck);

  useEffect(() => {
    handleGetSingle();
    return () => {
      dispatch(custDetailSuccess(null));
      dispatch(cashManagementSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
      dispatch(globalAllAccSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (cashMngSingle && !_.isEqual(cashMngSingle, preCashMngSingle)) {
      initForm();
    }
  }, [cashMngSingle]);

  useEffect(() => {
    if (formAccountSource && formAccountSource.length === 7) {
      _handleCheckAccount();
      _handleCheckBalance();
      _handleGetAllAcc();
      _handleCheckAuthorPerson();
    } else {
      setAccSource(null);
      dispatch(cashBalanceSuccess(null));
      dispatch(globalAllAccSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(globalAuthorPersonSuccess(null));
      dispatch(custDetailSuccess(null));
    }
    if (!!preFormCheck && !_.isEqual(formAccountSource, preFormAccountSource)) {
      dispatch(change('detailCTNoiBoModalform', 'formCheck', '0'));
    }
  }, [formAccountSource]);

  useEffect(() => {
    if (formAccountTarget && formAccountTarget.length === 7) {
      _handleCheckAccountTarget();
    } else setAccTarget(null);
  }, [formAccountTarget]);

  useEffect(() => {
    if (formCheck) {
      setCheckInfor(
        formCheck === '0' ? true : formCheck === '1' ? false : null
      );
      if (formCheck === '0')
        dispatch(change('detailCTNoiBoModalform', 'formAuthorPerson', ''));
      if (
        formAccountSource &&
        !formAuthorPerson &&
        glAuthorPerson.length <= 0 &&
        formCheck === '1'
      ) {
        _handleToast(`${t('txt-alert-author-person-infor')}`, 'error');
      }
    }
  }, [formCheck]);

  useEffect(() => {
    if (formAuthorPerson) {
      _handleCheckCustomer();
    } else {
      dispatch(custDetailSuccess(null));
    }
  }, [formAuthorPerson]);

  useEffect(() => {
    if (
      formCashVolume &&
      cashBalance &&
      cashBalance?.C_CASH_BALANCE_FO > StringToInt(formCashVolume) &&
      (!_.isEqual(formCashVolume, preFormCashVolume) ||
        !_.isEqual(cashBalance, preCashBalance))
    ) {
      dispatch(
        change(
          'detailCTNoiBoModalform',
          'formCashAfterTransfer',
          cashBalance?.C_CASH_BALANCE_FO - StringToInt(formCashVolume)
        )
      );
    } else
      dispatch(change('detailCTNoiBoModalform', 'formCashAfterTransfer', ''));
  }, [formCashVolume, cashBalance]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    ) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashManagementDelSuccess(null));
      onClose();
    }
  }, [cashManagementDel]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) {
      dispatch(cashManagementApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngApprove]);

  useEffect(() => {
    if (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) {
      dispatch(cashManagementUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngUnApprove]);

  useEffect(() => {
    if (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) {
      dispatch(cashManagementRejectSuccess(null));
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngReject]);

  useEffect(() => {
    if (cashTransferUpd && !_.isEqual(cashTransferUpd, preCashTransferUpd)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashTransferUpdateSuccess(null));
      handleGetSingle();
    }
  }, [cashTransferUpd]);

  function initForm() {
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formBusinessType',
        cashMngSingle?.C_CHANNEL_CODE
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formPhoneLine',
        cashMngSingle?.C_PHONE_LINE
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formAccountSource',
        cashMngSingle?.C_ACCOUNT_OUT
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formTransferCertId',
        cashMngSingle?.C_AUTHOR_CERT_ID
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formCashVolume',
        cashMngSingle?.C_CASH_VOLUME
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formAccountTarget',
        cashMngSingle?.C_ACCOUNT_IN
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formCheck',
        cashMngSingle?.C_AUTHOR_FLAG + ''
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formRadType',
        cashMngSingle?.C_WITHDRAW_TYPE + ''
      )
    );
    dispatch(
      change('detailCTNoiBoModalform', 'formContent', cashMngSingle?.C_CONTENT)
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formAuthorPerson',
        cashMngSingle?.C_CUST_AUTHOR
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formTransNo',
        cashMngSingle?.C_TRANSACTION_NO
      )
    );
    dispatch(
      change(
        'detailCTNoiBoModalform',
        'formTransDate',
        cashMngSingle?.C_TRANSACTION_DATE
      )
    );
  }

  useEffect(() => {
    if (cashMngSingle && cashMngSingle?.C_TRANSACTION_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          cashMngSingle?.C_TRANSACTION_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [cashMngSingle]);

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(cashManagementSingleRequest(params));
  }

  function handleDetailNUQId() {
    if (!formAuthorPerson) return;
    const resultIncludes = glAuthorPerson.find((item) =>
      item.value.includes(formAuthorPerson)
    );
    setDetailNUQId(resultIncludes?.pk);
  }

  function handleDetailTS() {
    if (!formAccountSource) return;
    setDetailTS(formAccountSource);
  }

  function _handleCheckCustomer() {
    if (!formAuthorPerson) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorPerson,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckAuthorPerson() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
        STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalAuthorPersonRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountSource,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckAccountTarget() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountTarget,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
    })
      .then(handleApiErrors)
      .then((response) => response.json())
      .then((json) => {
        console.log(json);
        if (json.code === '1') {
          setAccTarget(json.data[0]);
        } else {
          setAccTarget(null);
          _handleToast(json.re, 'error');
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function _handleGetAllAcc() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: formAccountSource.slice(0, -1),
        ALL_FLAG: 1,
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };
    dispatch(globalAllAccRequest(params));
  }

  function submit() {
    //if (formCheck === '1') {
      const params = {
        user: token?.USER_NAME,
        session: token?.SESSION_ID,
        cmd: 'BACK.CHECK_AUTHOR',
        group: 'LIST',
        data: {
          ACCOUNT_CODE: formAccountSource,
          CUSTOMER_CODE: checkInfor
            ? accountSingle?.C_CARD_ID
            : custDetail?.C_CARD_ID,
          BUSINESS_CODE: 'KY_CHUYEN_TIEN',
        },
      };

          const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
        },
        body: JSON.stringify(params),
      })
        .then(handleApiErrors)
        .then((response) => response.json())
        .then((json) => {
          console.log(json);
          if (json.code === '1') {
            json.data[0].C_CHECK === 1
              ? handleUpdate()
              : _handleToast(t('txt-unauthorized-acc'), 'error');
          } else {
            _handleToast(json.re, 'error');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    //} else handleUpdate();
  }

  function handleUpdate() {
    if (formCashVolume > cashBalance?.C_CASH_BALANCE_FO) {
      _handleToast(t('txt-amount-exceed-current-balance'), 'error');
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_TRANSFER',
      group: 'LIST',
      data: {
        ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        ACCOUNT_OUT: props?.formAccountSource,
        AUTHOR_FLAG: StringToInt(props?.formCheck),
        AUTHOR_CARD_ID: checkInfor
          ? accountSingle?.C_CARD_ID
          : custDetail?.C_CARD_ID || '',
        AUTHOR_NAME: checkInfor
          ? accountSingle?.C_CUSTOMER_NAME
          : custDetail?.C_CUSTOMER_NAME,
        ACCOUNT_IN: props?.formAccountTarget,
        CASH_VALUE: StringToInt(props?.formCashVolume),
        CHANNEL_CODE: props?.formBusinessType,
        PHONE_LINE: props?.formPhoneLine,
        CONTENT: props?.formContent,
        WITHDRAW_TYPE: StringToInt(props?.formRadType),
        TRANSACTION_DATE: props?.formTransDate,
      },
    };

    dispatch(cashTransferUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                ? t('txt-appr-entry')
                : actionName === 'unApprove'
                ? t('txt-unAppr-entry')
                : actionName === 'reject'
                ? t('txt-reject-entry')
                : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    console.log(rejectText);
                    if (!rejectText) return;
                    handleActionRevert(rejectText);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UN_APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementUnApproveRequest(params));
  }

  function handleActionRevert(rejectText) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        CANCEL_NOTE: rejectText,
      },
    };

    dispatch(cashManagementRejectRequest(params));
  }

  const { handleSubmit, submitting, reset, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-internal-transfer-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-channel')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    validate={[required]}
                    required
                    index={4}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-ext-number')}</Form.Label>
                  <Field
                    name="formPhoneLine"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-trans-no')}</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    className="form-control"
                    name="formTransDate"
                    type="start"
                    component={RenderSelectDate}
                    validate={required}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-sender-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountSource"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accountSingle?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accountSingle
                        ? `${accountSingle?.C_SUB_BRANCH_CODE} - ${accountSingle?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accountSingle?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group>
                  <Form.Label>{t('txt-phone')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_MOBILE
                        : custDetail?.C_CUST_MOBILE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_EMAIL
                        : custDetail?.C_CUST_EMAIL) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_RESEDENCE_ADDRESS
                        : custDetail?.C_RESEDENCE_ADDRESS) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Người thực hiện
                  </Form.Label>
                  <Field
                    name="formCheck"
                    className="form-control"
                    component="select"
                  >
                    <option value="0"> {t('txt-main-account')}</option>
                    <option value="1">{t('txt-author-person')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-author-person-id')}
                    {!checkInfor && <span className="text-danger">*</span>}
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <Field
                      name="formAuthorPerson"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderNormalSelect}
                      opts={glAuthorPerson}
                      index={4}
                      disabled={checkInfor}
                      validate={!checkInfor ? required : null}
                    />
                    <BtnDetail type="button" onClick={handleDetailNUQId} />
                  </div>
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CARD_ID
                        : custDetail?.C_CARD_ID) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-withdrawer-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUSTOMER_NAME
                        : custDetail?.C_CUSTOMER_NAME) || ''
                    }
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_ISSUE_DATE
                        : custDetail?.C_ISSUE_DATE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label> {t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_ISSUE_PLACE
                        : custDetail?.C_ISSUE_PLACE) || ''
                    }
                    disabled
                  />
                </Form.Group> */}

                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-withd-trans-method')}
                </p>
                <label>
                  <Field
                    name="formRadType"
                    component="input"
                    type="radio"
                    value="0"
                    className="cursor-pointer"
                  />{' '}
                  {t('txt-withd-trans-normal')}
                </label>
                <label>
                  <Field
                    name="formRadType"
                    component="input"
                    type="radio"
                    value="1"
                    className="cursor-pointer"
                    disabled={accountSingle?.C_ACCOUNT_CREDIT_TYPE === '0' ? true : false}
                  />{' '}
                  {t('txt-withd-trans-ee')}
                </label>
                <label>
                  <Field
                    name="formRadType"
                    component="input"
                    type="radio"
                    value="2"
                    className="cursor-pointer"
                    disabled={accountSingle?.C_ACCOUNT_CREDIT_TYPE === '0' ? true : false}
                  />{' '}
                  {t('txt-withd-trans-minus-ee')}
                </label>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-money-withdrawn')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control fz-13"
                    // value={
                    //   cashBalance?.C_CASH_BALANCE_FO === 0
                    //     ? '0'
                    //     : numberFormat(cashBalance?.C_CASH_BALANCE_FO) || ''
                    // }
                    value={
                      (formRadType === '0')
                        ? (numberFormat(cashBalance?.C_CASH_BALANCE_FO) || '')
                        : (numberFormat(cashBalance?.C_CASH_BALANCE_EE) || '')
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{/* {t('txt-after-transfer')} */}</Form.Label>
                  <div className="d-flex justify-content-between">
                    {/* <Field
                      name="formCashAfterTransfer"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderInput}
                      disabled
                    /> */}
                    <BtnDetail type="button" onClick={handleDetailTS} />
                  </div>
                </Form.Group>
                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-target-info-1')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-target-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountTarget"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={_.filter(
                      glAllAcc,
                      (o) => o.value !== formAccountSource
                    )}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/5' }}>
                  <Form.Label>{t('txt-target-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accTarget?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-acc-type')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accTarget?.C_ACCOUNT_FRONT_TYPE || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
                <div
                  className="d-flex mt-2"
                  style={{ gridColumn: '1/5', gap: '5px 20px' }}
                >
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-creator')}
                      {': '}
                      {cashMngSingle?.C_CREATOR_CODE}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-create-time')}
                      {': '}
                      {cashMngSingle?.C_CREATE_TIME || ''}
                    </Form.Label>
                  </div>
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-approver')}
                      {': '}
                      {cashMngSingle?.C_APPROVER_CODE || ''}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-approve-time')}
                      {': '}
                      {cashMngSingle?.C_APPROVE_TIME || ''}
                    </Form.Label>
                  </div>
                </div>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {(cashMngSingle?.C_STATUS === 'CHUA_DUYET' || cashMngSingle?.C_STATUS === 'DANG_XU_LY') && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                        {/* <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('reject')}
                          className="w_125 ml-2 info"
                        >
                          {t('bnt-reject-entry')}
                        </BtnSubmit> */}
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="submit"
                          disabled={pristine || submitting}
                          className="w_125 ml-2"
                        >
                          {t('bnt-edit-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {cashMngSingle?.C_STATUS === 'DA_DUYET' &&
                  diff &&
                  accRight?.C_APPROVE === 1 && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
        {detailNUQId && (
          <DetailAuthorPerson
            id={detailNUQId}
            onClose={() => setDetailNUQId(null)}
          />
        )}
        {detailTS && (
          <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
        )}
      </div>
    </ReactModal>
  );
}

AddCTNoiBoModal = reduxForm({
  form: 'detailCTNoiBoModalform',
  enableReinitialize: true,
})(AddCTNoiBoModal);

const selector = formValueSelector('detailCTNoiBoModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCashTransferUpdate = makeGetCashTransferUpdate();
  const getCustomerDetail = makeGetCustomerDetail();
  const getChannelType = makeGetChannelType();
  const getCashManagementSingle = makeGetCashManagementSingle();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
  const getSystemInfo = makeGetSystemInfo();
  const getGlAllAcc = makeGetGlAllAcc();
  const getAccountSingle = makeGetAccountSingle();
  const getGLAuthorPerson = makeGetGLAuthorPerson();
  const getAccountAuthorSingle = makeGetAccountAuthorSingle();
  const {
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formAccountTarget,
    formContent,
    formCashAfterTransfer,
    formCheck,
    formAuthorPerson,
    formTransDate,
  } = selector(
    state,
    'formBusinessType',
    'formPhoneLine',
    'formAccountSource',
    'formTransferCertId',
    'formRadType',
    'formCashVolume',
    'formAccountTarget',
    'formContent',
    'formCashAfterTransfer',
    'formCheck',
    'formAuthorPerson',
    'formTransDate'
  );

  return {
    token: getToken(state),
    cashTransferUpd: getCashTransferUpdate(state),
    custDetail: getCustomerDetail(state),
    glChannelType: getChannelType(state),
    cashMngApprove: getCashManagementApprove(state),
    cashMngUnApprove: getCashManagementUnApprove(state),
    cashMngReject: getCashManagementReject(state),
    cashManagementDel: getCashManagementDel(state),
    cashMngSingle: getCashManagementSingle(state),
    sysSystemInfo: getSystemInfo(state),
    glAllAcc: getGlAllAcc(state),
    accountSingle: getAccountSingle(state),
    glAuthorPerson: getGLAuthorPerson(state),
    accAuthorSingle: getAccountAuthorSingle(state),
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formAccountTarget,
    formContent,
    formCashAfterTransfer,
    formCheck,
    formAuthorPerson,
    formTransDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddCTNoiBoModal)
);
