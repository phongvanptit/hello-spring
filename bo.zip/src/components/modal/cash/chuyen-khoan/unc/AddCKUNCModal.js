import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderSuggestBank from 'components/input/renderSuggestBank';
import RenderSuggestBankIDN from 'components/input/renderSuggestBankIDN';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashTransferUpdateRequest,
  cashTransferUpdateSuccess,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
import {
  globalAllAccSuccess,
  globalAllAccRequest,
  globalAuthorPersonSuccess,
  globalAuthorPersonRequest,
} from 'containers/global/actions';
import { handleApiErrors } from 'lib/api-errors';
import {
  makeCashCheckAuthor,
  makeGetAccountSingle,
  makeGetCashBalance,
  makeGetCashTransferUpdate,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetProvinceList,
  makeGetSingleList,
  makeGetToken,
  makeGetGLAuthorPerson,
  makeGetAccountAuthorSingle,
} from 'lib/selector';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, numberFormat } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { BtnDetail } from 'utils/styledComponent';
import DetailAuthorPerson from 'components/modal/detail-pop-up/detailAuthorPerson';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';
import {
  lengthRequired,
  required,
  validateNumberExact,
} from 'utils/validation';
import { formatDate } from 'utils';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddCKUNCModal(props) {
  const dispatch = useDispatch();
  const [detailTS, setDetailTS] = React.useState(null);
  const {
    token,
    custDetail,
    formAccountSource,
    cashTransferUpd,
    glChannelType,
    formTransferCertId,
    glProvince,
    glSingleList,
    formBranchBank,
    formFeeType,
    cashCheckAuthor,
    accSource,
    cashBalance,
    formCashVolume,
    formCheck,
    formAuthorPerson,
    glAuthorPerson,
    accountSingle,
  } = props;

  const preCashTransferUpd = usePrevious(cashTransferUpd);
  const preFormFeeType = usePrevious(formFeeType);
  const preFormCashVolume = usePrevious(formCashVolume);
  const preCashBalance = usePrevious(cashBalance);
  const [checkInfor, setCheckInfor] = React.useState(null);
  const [detailNUQId, setDetailNUQId] = React.useState(null);
  const preFormAccountSource = usePrevious(formAccountSource);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(custDetailSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
      dispatch(globalSingleListSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountSource && formAccountSource.length === 7) {
      _handleCheckAccount();
      _handleCheckBalance();
      _handleCheckAuthorPerson();
    } else {
      dispatch(accountSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(globalAuthorPersonSuccess(null));
      dispatch(custDetailSuccess(null));
    }
    if (!_.isEqual(formAccountSource, preFormAccountSource)) {
      dispatch(change('openCKUNCModalform', 'formCheck', '0'));
    }
  }, [formAccountSource]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (cashTransferUpd && !_.isEqual(cashTransferUpd, preCashTransferUpd)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashTransferUpdateSuccess(null));
      onClose();
    }
  }, [cashTransferUpd]);

  useEffect(() => {
    if (formFeeType && !_.isEqual(formFeeType, preFormFeeType)) {
      dispatch(change('openCKUNCModalform', 'formTransferFee', ''));
    }
  }, [formFeeType]);

  useEffect(() => {
    if (formCheck) {
      setCheckInfor(
        formCheck === '0' ? true : formCheck === '1' ? false : null
      );
      dispatch(change('openCKUNCModalform', 'formAuthorPerson', ''));
      if (
        formAccountSource &&
        glAuthorPerson.length <= 0 &&
        formCheck === '1'
      ) {
        _handleToast(`${t('txt-alert-author-person-infor')}`, 'error');
      }
    }
  }, [formCheck]);

  useEffect(() => {
    if (formAuthorPerson) {
      _handleCheckCustomer();
    } else {
      dispatch(custDetailSuccess(null));
    }
  }, [formAuthorPerson]);

  useEffect(() => {
    if (
      formCashVolume &&
      cashBalance &&
      (!_.isEqual(formCashVolume, preFormCashVolume) ||
        !_.isEqual(cashBalance, preCashBalance))
    ) {
      if (StringToInt(formCashVolume) > cashBalance?.C_CASH_BALANCE_BO) {
        _handleToast(t('txt-amount-exceed-current-balance'), 'error');
        dispatch(change('openCKUNCModalform', 'formCashVolume', ''));
      }
    }
  }, [formCashVolume, cashBalance]);

  function initForm() {
    dispatch(change('openCKUNCModalform', 'formBusinessType', 'D'));
    dispatch(change('openCKUNCModalform', 'formRadType', '0'));
    dispatch(change('openCKUNCModalform', 'formFeeType', '0'));
    dispatch(change('openCKUNCModalform', 'formCheck', '0'));
    dispatch(change('openCKUNCModalform', 'formCashVolume', 0));
    dispatch(change('openCKUNCModalform', 'formTransferFee', 0));
    dispatch(change('openCKUNCModalform', 'formBranchBank', '000'));
    dispatch(
      change(
        'openCKUNCModalform',
        'formTransDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function handleDetailNUQId() {
    if (!formAuthorPerson) return;
    const resultIncludes = glAuthorPerson.find((item) =>
      item.value.includes(formAuthorPerson)
    );
    setDetailNUQId(resultIncludes?.pk);
  }

  function _handleCheckCustomer() {
    if (!formAuthorPerson) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorPerson,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function _handleCheckAccount() {
    if (!formAccountSource) {
      return;
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountSource,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function _handleCheckAuthorPerson() {
    if (!formAccountSource) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountSource,
        STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalAuthorPersonRequest(params));
  }

  function submit() {
    //if (formCheck === '1') {
      const params = {
        user: token?.USER_NAME,
        session: token?.SESSION_ID,
        cmd: 'BACK.CHECK_AUTHOR',
        group: 'LIST',
        data: {
          ACCOUNT_CODE: formAccountSource,
          CUSTOMER_CODE: checkInfor
            ? accountSingle?.C_CARD_ID
            : custDetail?.C_CARD_ID,
          BUSINESS_CODE: 'KY_CHUYEN_TIEN',
        },
      };

          const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


      fetch(appUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
        },
        body: JSON.stringify(params),
      })
        .then(handleApiErrors)
        .then((response) => response.json())
        .then((json) => {
          console.log(json);
          if (json.code === '1') {
            json.data[0].C_CHECK === 1
              ? handleConfirm()
              : _handleToast(t('txt-unauthorized-acc'), 'error');
          } else {
            _handleToast(json.re, 'error');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    //} else handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_TRANSFER_OUT',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        ACCOUNT_OUT: props?.formAccountSource,
        AUTHOR_FLAG: StringToInt(props?.formCheck),
        AUTHOR_CARD_ID: checkInfor
          ? accountSingle?.C_CARD_ID
          : custDetail?.C_CARD_ID,
        AUTHOR_NAME: checkInfor
          ? accountSingle?.C_CUSTOMER_NAME
          : custDetail?.C_CUSTOMER_NAME,
        ACCOUNT_IN: props?.formAccountTarget,
        ACCOUNT_IN_NAME: props?.formAccountTargetName,
        BANK_CODE_ACCOUNT_IN: props?.formTargetBankCode,
        BANK_PROVINCE_ACCOUNT_IN: props?.formTargetProvince,
        BANK_BRANCH_ACCOUNT_IN: props?.formTargetBankBranch,
        CASH_VALUE: StringToInt(props?.formCashVolume),
        FEE_VALUE: StringToInt(props?.formTransferFee),
        RECEIVE_FEE_FLAG: StringToInt(props?.formFeeType),
        BRANCH_BANK_CODE: props?.formBranchBank,
        CHANNEL_CODE: props?.formBusinessType,
        PHONE_LINE: props?.formPhoneLine,
        ONLINE_FLAG: 0, // UNC
        CONTENT: props?.formContent,
        WITHDRAW_TYPE: StringToInt(props?.formRadType),
        TRANSACTION_DATE: props?.formTransDate,
      },
    };
    dispatch(cashTransferUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;

  function handleDetailTS() {
    if (!formAccountSource) return;
    setDetailTS(formAccountSource);
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-transfer-bank-unc-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-channel')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    validate={[required]}
                    required
                    index={4}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-ext-number')}</Form.Label>
                  <Field
                    name="formPhoneLine"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-trans-no')}</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    className="form-control"
                    name="formTransDate"
                    type="start"
                    component={RenderSelectDate}
                    validate={required}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-sender-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountSource"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accountSingle?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accountSingle
                        ? `${accountSingle?.C_SUB_BRANCH_CODE} - ${accountSingle?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accountSingle?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group>
                  <Form.Label>{t('txt-phone')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_MOBILE
                        : custDetail?.C_CUST_MOBILE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUST_EMAIL
                        : custDetail?.C_CUST_EMAIL) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_RESEDENCE_ADDRESS
                        : custDetail?.C_RESEDENCE_ADDRESS) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Người thực hiện
                  </Form.Label>
                  <Field
                    name="formCheck"
                    className="form-control"
                    component="select"
                  >
                    <option value="0"> {t('txt-main-account')}</option>
                    <option value="1">{t('txt-author-person')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-author-person-id')}
                    {!checkInfor && <span className="text-danger">*</span>}
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <Field
                      name="formAuthorPerson"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderNormalSelect}
                      opts={glAuthorPerson}
                      index={4}
                      disabled={checkInfor}
                      validate={!checkInfor ? required : null}
                    />
                    <BtnDetail type="button" onClick={handleDetailNUQId} />
                  </div>
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CARD_ID
                        : custDetail?.C_CARD_ID) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-withdrawer-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accountSingle?.C_CUSTOMER_NAME
                        : custDetail?.C_CUSTOMER_NAME) || ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-transfer-fee')}</Form.Label>
                  <Field
                    name="formTransferFee"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    disabled={formFeeType === '1'}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label className="fz-13 w-fix">
                    Hình thức trả phí
                  </Form.Label>
                  <Field
                    name="formFeeType"
                    className="form-control"
                    component="select"
                  >
                    <option value="0">{t('txt-sender-acc-pay')}</option>
                    <option value="1"> {t('txt-target-acc-pay')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>Số có thể chuyển</Form.Label>
                  <div className="d-flex justify-content-between">
                    <input
                      type={'text'}
                      className="form-control fz-13"
                      value={
                        cashBalance?.C_CASH_BALANCE_BO === 0
                          ? '0'
                          : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                      }
                      disabled
                    />
                    <BtnDetail type="button" onClick={handleDetailTS} />
                  </div>
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('lab-acc-total')} <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index="3"
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-bank')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formTargetBankCode"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBankIDN}
                    validate={[required]}
                    index="2"
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-target-acc-1')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountTarget"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountTargetName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-branch')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formTargetBankBranch"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-province-city')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formTargetProvince"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glProvince}
                    validate={[required]}
                  />
                </Form.Group> */}

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>
                    {t('txt-content')}
                    {/* <span className="text-danger">*</span> */}
                  </Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    //validate={[required]}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailNUQId && (
        <DetailAuthorPerson
          id={detailNUQId}
          onClose={() => setDetailNUQId(null)}
        />
      )}
      {detailTS && (
        <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
      )}
    </ReactModal>
  );
}

AddCKUNCModal = reduxForm({
  form: 'openCKUNCModalform',
  enableReinitialize: true,
})(AddCKUNCModal);

const selector = formValueSelector('openCKUNCModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCashTransferUpdate = makeGetCashTransferUpdate();
  const getCustomerDetail = makeGetCustomerDetail();
  const getChannelType = makeGetChannelType();
  const getProvinceList = makeGetProvinceList();
  const getSingleList = makeGetSingleList();
  const getCashCheckAuthor = makeCashCheckAuthor();
  const getAccountSingle = makeGetAccountSingle();
  const getCashBalance = makeGetCashBalance();
  const getGLAuthorPerson = makeGetGLAuthorPerson();
  const getAccountAuthorSingle = makeGetAccountAuthorSingle();
  const {
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formBranchBank,
    formAccountTarget,
    formAccountTargetName,
    formTargetBankCode,
    formTargetBankBranch,
    formTargetProvince,
    formTransferFee,
    formFeeType,
    formContent,
    formCheck,
    formAuthorPerson,
    formTransDate,
  } = selector(
    state,
    'formBusinessType',
    'formPhoneLine',
    'formAccountSource',
    'formTransferCertId',
    'formRadType',
    'formCashVolume',
    'formBranchBank',
    'formAccountTarget',
    'formAccountTargetName',
    'formTargetBankCode',
    'formTargetBankBranch',
    'formTargetProvince',
    'formTransferFee',
    'formFeeType',
    'formContent',
    'formCheck',
    'formAuthorPerson',
    'formTransDate'
  );

  return {
    token: getToken(state),
    cashTransferUpd: getCashTransferUpdate(state),
    custDetail: getCustomerDetail(state),
    glChannelType: getChannelType(state),
    glProvince: getProvinceList(state),
    glSingleList: getSingleList(state),
    cashCheckAuthor: getCashCheckAuthor(state),
    cashBalance: getCashBalance(state),
    accountSingle: getAccountSingle(state),
    glAuthorPerson: getGLAuthorPerson(state),
    accAuthorSingle: getAccountAuthorSingle(state),
    formBusinessType,
    formPhoneLine,
    formAccountSource,
    formTransferCertId,
    formRadType,
    formCashVolume,
    formBranchBank,
    formAccountTarget,
    formAccountTargetName,
    formTargetBankCode,
    formTargetBankBranch,
    formTargetProvince,
    formTransferFee,
    formFeeType,
    formContent,
    formCheck,
    formAuthorPerson,
    formTransDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddCKUNCModal)
);
