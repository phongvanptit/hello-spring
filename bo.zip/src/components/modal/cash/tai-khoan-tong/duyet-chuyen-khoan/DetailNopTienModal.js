import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  bankInUpdateRequest,
  bankInUpdateSuccess,
  bankManagementApproveRequest,
  bankManagementApproveSuccess,
  bankManagementDelRequest,
  bankManagementDelSuccess,
  bankManagementSingleRequest,
  bankManagementSingleSuccess,
  bankManagementUnApproveRequest,
  bankManagementUnApproveSuccess,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, _diff2Date, formatDate, stringToDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';

import {
  makeGetAccountSingle,
  makeGetBankInUpdate,
  makeGetBankManagementApprove,
  makeGetBankManagementUnApprove,
  makeGetBankManagementDel,
  makeGetBankManagementSingle,
  makeGetGlobalCashDeposit,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailNopTienModal(props) {
  const dispatch = useDispatch();
  const [diff, setDiff] = useState(false);
  const {
    token,
    accDetail,
    glSingleList,
    formBranchBank,
    bankInUpd,
    bankMngSingle,
    bankMngApprove,
    bankMngUnApprove,
    bankManagementDel,
    id,
    pristine,
    handleSubmit,
    submitting,
    reset,
    onClose,
    t,
    glCashDeposit,
    accRight,
    sysSystemInfo,
  } = props;
  const preBankInUpd = usePrevious(bankInUpd);
  const preBankMngApprove = usePrevious(bankMngApprove);
  const preBankMngUnApprove = usePrevious(bankMngUnApprove);
  const preBankManagementDel = usePrevious(bankManagementDel);
  const preBankMngSingle = usePrevious(bankMngSingle);

  useEffect(() => {
    if (bankMngSingle && !_.isEqual(bankMngSingle, preBankMngSingle)) {
      initForm();
    }
  }, [bankMngSingle]);

  useEffect(() => {
    if (id) handleGetSingle();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(globalSingleListSuccess(null));
      dispatch(bankManagementSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (bankMngSingle && !_.isEqual(bankMngSingle, preBankMngSingle)) {
      initForm();
    }
  }, [bankMngSingle]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (
      bankManagementDel &&
      !_.isEqual(bankManagementDel, preBankManagementDel)
    ) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(bankManagementDelSuccess(null));
      onClose();
    }
  }, [bankManagementDel]);

  useEffect(() => {
    if (bankMngApprove && !_.isEqual(bankMngApprove, preBankMngApprove)) {
      dispatch(bankManagementApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      //handleGetSingle();
      onClose();
    }
  }, [bankMngApprove]);

  useEffect(() => {
    if (bankMngUnApprove && !_.isEqual(bankMngUnApprove, preBankMngUnApprove)) {
      dispatch(bankManagementUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      //handleGetSingle();
      onClose();
    }
  }, [bankMngUnApprove]);


  useEffect(() => {
    if (bankInUpd && !_.isEqual(bankInUpd, preBankInUpd)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(bankInUpdateSuccess(null));
      //handleGetSingle();
      onClose();
    }
  }, [bankInUpd]);

  function initForm() {
    
    dispatch(
      change(
        'detailNopTienModalform',
        'formCashVolume',
        bankMngSingle?.C_CASH_VALUE
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formBranchBank',
        bankMngSingle?.C_ACCOUNT_IN
      )
    );
    dispatch(
      change('detailNopTienModalform', 'formContent', bankMngSingle?.C_CONTENT)
    );
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BANK_MANAGEMENT',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(bankManagementSingleRequest(params));
  }


  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                ? t('txt-appr-entry')
                : actionName === 'unApprove'
                ? t('txt-unAppr-entry')
               
                : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_BANK_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: bankMngSingle?.PK_BANK_MANAGEMENT,
      },
    };

    dispatch(bankManagementDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_BANK_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: bankMngSingle?.PK_BANK_MANAGEMENT,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(bankManagementApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_BANK_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: bankMngSingle?.PK_BANK_MANAGEMENT,
        NEW_STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(bankManagementUnApproveRequest(params));
  }


  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-deposit-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form >
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                
                <p
                  style={{ gridColumn: '1/3' }}
                  className="color-thm mb-0 fz-13"
                >
                   Thông tin nghiệp vụ
                </p>
                
                <Form.Group>
                  <Form.Label>
                  Tài khoản nhận
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                  />
                </Form.Group>
                
                <Form.Group>
                  <Form.Label>Tên ngân hàng</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BRANCH_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                
                
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {bankMngSingle?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                       
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                         <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {bankMngSingle?.C_STATUS === 'DA_DUYET' &&
                  accRight?.C_APPROVE === 1 &&
                  (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailNopTienModal = reduxForm({
  form: 'detailNopTienModalform',
  enableReinitialize: true,
})(DetailNopTienModal);

const selector = formValueSelector('detailNopTienModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSingleList = makeGetSingleList();
  const getAccountSingle = makeGetAccountSingle();
  const getBankInUpdate = makeGetBankInUpdate();
  const getBankManagementSingle = makeGetBankManagementSingle();
  const getBankManagementApprove = makeGetBankManagementApprove();
  const getBankManagementUnApprove = makeGetBankManagementUnApprove();
  const getBankManagementDel = makeGetBankManagementDel();
  const getGlobalCashDeposit = makeGetGlobalCashDeposit();
  const getSystemInfo = makeGetSystemInfo();
  const {
    formCashVolume,
    formBranchBank,
    formContent,
  } = selector(
    state,
    'formCashVolume',
    'formBranchBank',
    'formContent'
  );
  const bankMngSingle = getBankManagementSingle(state);
  return {
    token: getToken(state),
    glSingleList: getSingleList(state),
    accDetail: getAccountSingle(state),
    bankInUpd: getBankInUpdate(state),
    sysSystemInfo: getSystemInfo(state),
    bankMngSingle,
    bankMngApprove: getBankManagementApprove(state),
    bankMngUnApprove: getBankManagementUnApprove(state),
    bankManagementDel: getBankManagementDel(state),
    glCashDeposit: getGlobalCashDeposit(state),
    formCashVolume,
    formBranchBank,
    formContent,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailNopTienModal)
);
