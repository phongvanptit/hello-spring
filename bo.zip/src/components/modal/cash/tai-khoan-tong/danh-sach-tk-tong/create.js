import React, { useEffect } from 'react';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';

import RenderArea from 'components/input/renderArea';
import RenderSelectBank from 'components/input/renderSuggestBank';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';

import {
  typeUpdBankRequest,
  typeUpdBankSuccess,
} from 'containers/category/actions';
import {
  makeGetAllBank,
  makeGetProvinceList,
  makeGetToken,
  makeGetTypeUpdBank,
} from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function CreateTKTongModal(props) {
  const dispatch = useDispatch();

  const { token, typeUpdBank, onClose, provinceList, t } = props;
  const preTypeUpdBank = usePrevious(typeUpdBank);

  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (typeUpdBank && !_.isEqual(typeUpdBank, preTypeUpdBank)) {
      _handleToast(t('txt-add-new-acc-total-success'), 'success');
      dispatch(typeUpdBankSuccess(null));
      onClose();
    }
  }, [typeUpdBank]);

  function initForm() {
    dispatch(change('createBranchBankform', 'formStatus', true));
  }

  function submit(values) {
    handleConfirm();
  }

  function initForm() {
    dispatch(change('createTKTongModalForm', 'formStatus', true));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-new-acc-total')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_BRANCH_BANK',
      group: 'LIST',
      data: {
        BRANCH_BANK_ID: '',
        BRANCH_BANK_CODE: props?.formCode || '',
        BRANCH_BANK_NAME: props?.formName || '',
        BANK_ACCOUNT_CODE: props?.formAccountCode || '',
        BANK_ACCOUNT_NAME: props?.formAccountName || '',
        BANK_CODE: props?.formBankCode || '',
        PROVINCE_CODE: props?.formProvinceCode || '',
        CONTENT: props?.formContent || '',
        STATUS: props?.formStatus ? 1 : 0,
      },
    };
    dispatch(typeUpdBankRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-create-new-acc-total')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-bank')}</Form.Label>
                  <Field
                    name="formBankCode"
                    className="form-control"
                    classParent="w-100"
                    component={RenderSelectBank}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-total-acc-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCode"
                    className="form-control"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-total-acc-name')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formName"
                    className="form-control"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-bank-number')}<span className="text-danger">*</span></Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Field
                    name="formAccountName"
                    className="form-control"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-province-city')}
                  </Form.Label>
                  <Field
                    name="formProvinceCode"
                    className="form-control"
                    classParent="w-100"
                    component={RenderNormalSelect}
                    opts={provinceList}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
                <Form.Group className="d-flex align-items-end">
                  <label>
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

CreateTKTongModal = reduxForm({
  form: 'createTKTongModalForm',
  enableReinitialize: true,
})(CreateTKTongModal);

const selector = formValueSelector('createTKTongModalForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getTypeUpdBank = makeGetTypeUpdBank();
  const getProvinceList = makeGetProvinceList();
  const {
    formBankCode,
    formCode,
    formName,
    formAccountCode,
    formAccountName,
    formProvinceCode,
    formContent,
    formStatus,
  } = selector(
    state,
    'formBankCode',
    'formCode',
    'formName',
    'formAccountCode',
    'formAccountName',
    'formProvinceCode',
    'formContent',
    'formStatus'
  );

  return {
    token: getToken(state),
    typeUpdBank: getTypeUpdBank(state),
    provinceList: getProvinceList(state),
    formBankCode,
    formCode,
    formName,
    formAccountCode,
    formAccountName,
    formProvinceCode,
    formContent,
    formStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(CreateTKTongModal)
);
