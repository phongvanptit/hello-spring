import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { required } from 'utils/validation';

import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSelectBank from 'components/input/renderSuggestBank';

import {
  typeDelBankRequest,
  typeSingleBankRequest,
  typeSingleBankSuccess,
  typeUpdBankRequest,
  typeUpdBankSuccess,
} from 'containers/category/actions';
import {
  makeGetProvinceList,
  makeGetToken,
  makeGetTypeDelBank,
  makeGetTypeSingleBank,
  makeGetTypeUpdBank,
} from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 275px )',
    height: 'auto',
    width: '550px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailTKTongModal(props) {
  const dispatch = useDispatch();

  const {
    token,
    typeSingleBank,
    typeUpdBank,
    typeDelBank,
    onClose,
    provinceList,
    t,
    id,
    accRight,
    pristine,
  } = props;

  const preTypeUpdBank = usePrevious(typeUpdBank);
  const preTypeDelBank = usePrevious(typeDelBank);
  const preTypeSingleBank = usePrevious(typeSingleBank);

  useEffect(() => {
    // get detail
    if (id) handleGetSingleBranchBank();
    return () => {
      dispatch(typeSingleBankSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (typeSingleBank && !_.isEqual(typeSingleBank, preTypeSingleBank)) {
      initForm();
    }
  }, [typeSingleBank]);

  useEffect(() => {
    if (typeUpdBank && !_.isEqual(typeUpdBank, preTypeUpdBank)) {
      _handleToast(t('txt-upd-acc-total-success'), 'success');
      dispatch(typeUpdBankSuccess(null));
      handleGetSingleBranchBank();
    }
  }, [typeUpdBank]);

  useEffect(() => {
    if (typeDelBank && !_.isEqual(typeDelBank, preTypeDelBank)) {
      onClose();
    }
  }, [typeDelBank]);

  function handleGetSingleBranchBank() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_BRANCH_BANK',
      group: 'LIST',
      data: {
        BRANCH_BANK_ID: id,
      },
    };
    dispatch(typeSingleBankRequest(params));
  }

  function initForm() {
    dispatch(
      change(
        'detailTKTongModalForm',
        'formBankCode',
        typeSingleBank?.C_BANK_CODE
      )
    );
    dispatch(
      change(
        'detailTKTongModalForm',
        'formCode',
        typeSingleBank?.C_BRANCH_BANK_CODE
      )
    );
    dispatch(
      change(
        'detailTKTongModalForm',
        'formName',
        typeSingleBank?.C_BRANCH_BANK_NAME
      )
    );
    dispatch(
      change(
        'detailTKTongModalForm',
        'formAccountCode',
        typeSingleBank?.C_BANK_ACCOUNT_CODE
      )
    );
    dispatch(
      change(
        'detailTKTongModalForm',
        'formAccountName',
        typeSingleBank?.C_BANK_ACCOUNT_NAME
      )
    );
    dispatch(
      change(
        'detailTKTongModalForm',
        'formProvinceCode',
        typeSingleBank?.C_PROVINCE_CODE
      )
    );
    dispatch(
      change('detailTKTongModalForm', 'formContent', typeSingleBank?.C_CONTENT)
    );
    dispatch(
      change(
        'detailTKTongModalForm',
        'formStatus',
        typeSingleBank?.C_STATUS === 1
      )
    );
  }

  function submit(values) {
    handleConfirm('update');
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'update'
                ? t('txt-add-new-acc-total')
                : actionName === 'delete'
                ? t('txt-del-acc-total')
                : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'update':
                    handleActionUpdate();
                    break;
                  case 'delete':
                    handleActionDel();
                    break;

                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_BRANCH_BANK',
      group: 'LIST',
      data: {
        BRANCH_BANK_ID: id,
        BRANCH_BANK_CODE: props?.formCode || '',
        BRANCH_BANK_NAME: props?.formName || '',
        BANK_ACCOUNT_CODE: props?.formAccountCode || '',
        BANK_ACCOUNT_NAME: props?.formAccountName || '',
        BANK_CODE: props?.formBankCode || '',
        PROVINCE_CODE: props?.formProvinceCode || '',
        CONTENT: props?.formContent || '',
        STATUS: props?.formStatus ? 1 : 0,
      },
    };
    dispatch(typeUpdBankRequest(params));
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_BRANCH_BANK',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: typeSingleBank?.PK_BRANCH_BANK,
      },
    };
    dispatch(typeDelBankRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-acc-total')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label className="fz-13">{t('txt-bank')}</Form.Label>
                  <Field
                    name="formBankCode"
                    className="form-control"
                    classParent="w-100"
                    component={RenderSelectBank}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-total-acc-code')}</Form.Label>
                  <Field
                    name="formCode"
                    className="form-control"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-total-acc-name')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formName"
                    className="form-control"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-bank-number')}<span className="text-danger">*</span></Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <Field
                    name="formAccountName"
                    className="form-control"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label className="fz-13">
                    {t('txt-province-city')}
                  </Form.Label>
                  <Field
                    name="formProvinceCode"
                    className="form-control"
                    classParent="w-100"
                    component={RenderNormalSelect}
                    opts={provinceList}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>
                <Form.Group className="d-flex align-items-end">
                  <label>
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {accRight?.C_UPDATE === 1 && (
                  <>
                    {typeSingleBank?.C_STATUS === 0 && (
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('delete')}
                        className="w_125 danger"
                      >
                        {t('txt-del')}
                      </BtnSubmit>
                    )}
                    <BtnSubmit
                      type="submit"
                      disabled={pristine || submitting}
                      className="w_125 ml-2"
                    >
                      {t('txt-confirm')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailTKTongModal = reduxForm({
  form: 'detailTKTongModalForm',
  enableReinitialize: true,
})(DetailTKTongModal);

const selector = formValueSelector('detailTKTongModalForm');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getTypeUpdBank = makeGetTypeUpdBank();
  const getTypeSingleBank = makeGetTypeSingleBank();
  const getTypeDelBank = makeGetTypeDelBank();
  const getProvinceList = makeGetProvinceList();
  const {
    formBankCode,
    formCode,
    formName,
    formAccountCode,
    formAccountName,
    formProvinceCode,
    formContent,
    formStatus,
  } = selector(
    state,
    'formBankCode',
    'formCode',
    'formName',
    'formAccountCode',
    'formAccountName',
    'formProvinceCode',
    'formContent',
    'formStatus'
  );

  return {
    token: getToken(state),
    typeUpdBank: getTypeUpdBank(state),
    typeSingleBank: getTypeSingleBank(state),
    typeDelBank: getTypeDelBank(state),
    provinceList: getProvinceList(state),
    formBankCode,
    formCode,
    formName,
    formAccountCode,
    formAccountName,
    formProvinceCode,
    formContent,
    formStatus,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailTKTongModal)
);
