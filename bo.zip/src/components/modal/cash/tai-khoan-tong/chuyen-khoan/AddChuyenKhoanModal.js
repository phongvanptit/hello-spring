import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';

import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import styled from 'styled-components';

import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { StringToInt, formatDate } from 'utils';
import { handleApiErrors } from 'lib/api-errors';
import {
  lengthRequired,
  required,
  validateNumberExact,
} from 'utils/validation';

import {
  makeGetAccountSingle,
  makeGetBankTransferUpdate,
  makeGetGlobalCashDeposit,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  bankTransferUpdateRequest,
  bankTransferUpdateSuccess,
} from 'containers/cash/actions';
import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddChuyenKhoanModal(props) {
  const dispatch = useDispatch();
  const [accTarget, setAccTarget] = React.useState(null);

  const {
    token,
    accDetail,
    glSingleList,
    formBranchBankOut,
    formBranchBankIn,
    formAccountCode,
    bankTransferUpd,
    glCashDeposit,

    handleSubmit,
    submitting,
    reset,
    onClose,
    t,
    sysSystemInfo,
  } = props;
  const preBankTransferUpd = usePrevious(bankTransferUpd);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(globalSingleListSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formBranchBankOut) {
      _handleCheckBankBranchOut();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBankOut]);

  useEffect(() => {
    if (formBranchBankIn) {
      _handleCheckBankBranchIn();
    } 
  }, [formBranchBankIn]);

  useEffect(() => {
    if (bankTransferUpd && !_.isEqual(bankTransferUpd, preBankTransferUpd)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(bankTransferUpdateSuccess(null));
      onClose();
    }
  }, [bankTransferUpd]);

  function initForm() {
    dispatch(
      change('openChuyenKhoanModalform', 'formBusinessType', 'CASH_DEPOSIT')
    );
  }


  function _handleCheckBankBranchOut() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBankOut,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function _handleCheckBankBranchIn() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBankIn,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
    })
      .then(handleApiErrors)
      .then((response) => response.json())
      .then((json) => {
        console.log(json);
        if (json.code === '1') {
          setAccTarget(json.data[0]);
        } else {
          setAccTarget(null);
          _handleToast(json.re, 'error');
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function submit(values) {
    handleConfirm();
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_BANK_TRANSFER',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        ACCOUNT_IN: props?.formBranchBankIn,
        ACCOUNT_OUT: props?.formBranchBankOut,
        CASH_VALUE: StringToInt(props?.formCashVolume),
        CONTENT: props?.formContent,
      },
    };

    dispatch(bankTransferUpdateRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">Thêm mới thông tin chuyển khoản</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                
                <p
                  style={{ gridColumn: '1/3' }}
                  className="color-thm mb-0 fz-13"
                >
                  Thông tin nghiệp vụ
                </p>
                
                <Form.Group>
                  <Form.Label>
                    Tài khoản chuyển
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBankOut"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tên ngân hàng</Form.Label>
                  <input
                    type={'text'}
                    name="formBranchBankOutName"
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BRANCH_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Tài khoản nhận
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBankIn"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tên ngân hàng</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accTarget?.C_BRANCH_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>
                
                
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/3' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/3',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddChuyenKhoanModal = reduxForm({
  form: 'openChuyenKhoanModalform',
  enableReinitialize: true,
})(AddChuyenKhoanModal);

const selector = formValueSelector('openChuyenKhoanModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSingleList = makeGetSingleList();
  const getAccountSingle = makeGetAccountSingle();
  const getBankTransferUpdate = makeGetBankTransferUpdate();
  const getGlobalCashDeposit = makeGetGlobalCashDeposit();
  const getSystemInfo = makeGetSystemInfo();

  const {
    formBusinessType,
    formFileNo,
    formAccountCode,
    formCashVolume,
    formBranchBankOut,
    formBranchBankIn,
    formContent,
  } = selector(
    state,
    'formBusinessType',
    'formFileNo',
    'formAccountCode',
    'formCashVolume',
    'formBranchBankOut',
    'formBranchBankIn',
    'formContent'
  );

  return {
    token: getToken(state),
    glSingleList: getSingleList(state),
    accDetail: getAccountSingle(state),
    bankTransferUpd: getBankTransferUpdate(state),
    glCashDeposit: getGlobalCashDeposit(state),
    sysSystemInfo: getSystemInfo(state),
    formBusinessType,
    formFileNo,
    formAccountCode,
    formCashVolume,
    formBranchBankOut,
    formBranchBankIn,
    formContent,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddChuyenKhoanModal)
);
