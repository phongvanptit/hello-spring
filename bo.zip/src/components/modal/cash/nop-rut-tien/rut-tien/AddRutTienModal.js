import RenderArea from 'components/input/renderArea';
import RenderInputMask from 'components/input/renderInputMask';
import RenderInput from 'components/input/renderInput';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, numberFormat, formatDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';
import {
  makeCashCheckAuthor,
  makeGetAccountSingle,
  makeGetCashBalance,
  makeGetCashOutUpdate,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetGlobalCashWithdraw,
  makeGetSingleList,
  makeGetToken,
  makeGetGLAuthorPerson,
} from 'lib/selector';

import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashBalanceRequest,
  cashBalanceSuccess,
  cashOutUpdateRequest,
  cashOutUpdateSuccess,
} from 'containers/cash/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalSingleListRequest,
  globalSingleListSuccess,
  globalAuthorPersonSuccess,
  globalAuthorPersonRequest,
} from 'containers/global/actions';
import { handleApiErrors } from 'lib/api-errors';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { validateNumberExact } from 'utils/validation';
import { BtnDetail } from 'utils/styledComponent';
import DetailAuthorPerson from 'components/modal/detail-pop-up/detailAuthorPerson';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';

ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddRutTienModal(props) {
  const dispatch = useDispatch();
  const [checkInfor, setCheckInfor] = React.useState(null);
  const [detailNUQId, setDetailNUQId] = React.useState(null);
  const [detailTS, setDetailTS] = React.useState(null);

  const {
    token,
    accDetail,
    glSingleList,
    formBranchBank,
    formAccountCode,
    cashOutUpd,
    custDetail,
    glChannelType,
    formWidthdrawCertId,
    glCashWithdraw,
    cashBalance,
    formCashVolume,
    glAuthorPerson,
    formCheck,
    formAuthorPerson,
  } = props;

  const preCashOutUpd = usePrevious(cashOutUpd);
  const preFormCashVolume = usePrevious(formCashVolume);
  const preCashBalance = usePrevious(cashBalance);
  const preFormAccountCode = usePrevious(formAccountCode);

  useEffect(() => {
    initForm();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(globalSingleListSuccess(null));
      dispatch(cashBalanceSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      _handleCheckBalance();
      _handleCheckAuthorPerson();
    } else {
      dispatch(accountSingleSuccess(null));
      dispatch(cashBalanceSuccess(null));
      dispatch(globalAuthorPersonSuccess(null));
      dispatch(custDetailSuccess(null));
    }
    if (!_.isEqual(formAccountCode, preFormAccountCode)) {
      dispatch(change('openRutTienModalform', 'formCheck', '0'));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (formWidthdrawCertId) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [formWidthdrawCertId]);

  useEffect(() => {
    if (
      formCashVolume &&
      cashBalance &&
      (!_.isEqual(formCashVolume, preFormCashVolume) ||
        !_.isEqual(cashBalance, preCashBalance))
    ) {
      if (StringToInt(formCashVolume) > cashBalance?.C_CASH_BALANCE_BO) {
        _handleToast(t('txt-amount-exceed-current-balance'), 'error');
        dispatch(change('openRutTienModalform', 'formCashVolume', ''));
        return;
      }
    }
  }, [formCashVolume, cashBalance]);

  useEffect(() => {
    if (cashOutUpd && !_.isEqual(cashOutUpd, preCashOutUpd)) {
      _handleToast(`${t('txt-add-entry-success')}`, 'success');
      dispatch(cashOutUpdateSuccess(null));
      onClose();
    }
  }, [cashOutUpd]);

  useEffect(() => {
    if (formCheck) {
      setCheckInfor(
        formCheck === '0' ? true : formCheck === '1' ? false : null
      );
      dispatch(change('openRutTienModalform', 'formAuthorPerson', ''));
      if (formAccountCode && glAuthorPerson.length <= 0 && formCheck === '1') {
        _handleToast(`${t('txt-alert-author-person-infor')}`, 'error');
      }
    }
  }, [formCheck]);

  useEffect(() => {
    if (formAuthorPerson) {
      _handleCheckCustomer();
    } else {
      dispatch(custDetailSuccess(null));
    }
  }, [formAuthorPerson]);

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function initForm() {
    dispatch(
      change('openRutTienModalform', 'formBusinessType', 'CASH_WITHDRAW')
    );
    dispatch(change('openRutTienModalform', 'formRadType', '0'));
    dispatch(change('openRutTienModalform', 'formChannel', 'D'));
    dispatch(change('openRutTienModalform', 'formCheck', '0'));
    dispatch(change('openRutTienModalform', 'formCashVolume', 0));
    dispatch(change('openRutTienModalform', 'formBranchBank', '000'));
    dispatch(
      change(
        'openRutTienModalform',
        'formTransDate',
        formatDate(new Date(), '/', 'dmy')
      )
    );
  }

  function _handleCheckAuthorPerson() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
        STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalAuthorPersonRequest(params));
  }

  function _handleCheckBalance() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function handleDetailNUQId() {
    if (!formAuthorPerson) return;
    const resultIncludes = glAuthorPerson.find((item) =>
      item.value.includes(formAuthorPerson)
    );
    setDetailNUQId(resultIncludes?.pk);
  }

  function handleDetailTS() {
    if (!formAccountCode) return;
    setDetailTS(formAccountCode);
  }

  function _handleCheckCustomer() {
    if (!formAuthorPerson) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorPerson,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t('txt-add-entry')}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionApprove();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_OUT',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        BUSINESS_TYPE: props?.formBusinessType,
        CHANNEL: props?.formChannel,
        ACCOUNT_CODE: props?.formAccountCode,
        AUTHOR_CARD_ID: checkInfor
          ? accDetail?.C_CARD_ID
          : custDetail?.C_CARD_ID,
        AUTHOR_NAME: checkInfor
          ? accDetail?.C_CUSTOMER_NAME
          : custDetail?.C_CUSTOMER_NAME,
        AUTHOR_FLAG: StringToInt(props?.formCheck),
        CASH_VALUE: StringToInt(props?.formCashVolume),
        BRANCH_BANK_CODE: props?.formBranchBank,
        WITHDRAW_TYPE: StringToInt(props?.formRadType),
        CONTENT: props?.formContent,
        TRANSACTION_DATE: props?.formTransDate,
      },
    };
    dispatch(cashOutUpdateRequest(params));
  }



  function submit() {
    //if (formCheck === '1') {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.CHECK_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
        CUSTOMER_CODE: checkInfor
          ? accDetail?.C_CARD_ID
          : custDetail?.C_CARD_ID,
        BUSINESS_CODE: 'KY_CHUYEN_TIEN',
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
    })
      .then(handleApiErrors)
      .then((response) => response.json())
      .then((json) => {
        console.log(json);
        if (json.code === '1') {
          json.data[0].C_CHECK === 1
            ? handleConfirm()
            : _handleToast(t('txt-unauthorized-acc'), 'error');
        } else {
          _handleToast(json.re, 'error');
        }
      })
      .catch((error) => {
        console.log(error);
      });
    //} else handleConfirm();
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, reset, onClose, t } = props;
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-withdrawal-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>{t('txt-bus-1')}</Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glCashWithdraw}
                    required
                    index="4"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số bút toán</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    name="formTransDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-channel')}</Form.Label>
                  <Field
                    name="formChannel"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    required
                  />
                </Form.Group> */}
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-150"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CUST_MOBILE
                        : custDetail?.C_CUST_MOBILE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CUST_EMAIL
                        : custDetail?.C_CUST_EMAIL) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_RESEDENCE_ADDRESS
                        : custDetail?.C_RESEDENCE_ADDRESS) || ''
                    }
                    disabled
                  />
                </Form.Group>

                {/* <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group>
                  <Form.Label>Người thực hiện</Form.Label>
                  <Field
                    name="formCheck"
                    className="form-control w_170"
                    component="select"
                  >
                    <option value="0"> {t('txt-main-account')}</option>
                    <option value="1"> {t('txt-author-person')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-author-person-id')}
                    {!checkInfor && <span className="text-danger">*</span>}
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <Field
                      name="formAuthorPerson"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderNormalSelect}
                      opts={glAuthorPerson}
                      index={4}
                      disabled={checkInfor}
                      validate={!checkInfor ? required : null}
                    />
                    <BtnDetail type="button" onClick={handleDetailNUQId} />
                  </div>
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CARD_ID
                        : custDetail?.C_CARD_ID) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-withdrawer-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CUSTOMER_NAME
                        : custDetail?.C_CUSTOMER_NAME) || ''
                    }
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_ISSUE_DATE
                        : custDetail?.C_ISSUE_DATE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label> {t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_ISSUE_PLACE
                        : custDetail?.C_ISSUE_PLACE) || ''
                    }
                    disabled
                  />
                </Form.Group> */}

                {/* <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-withd-trans-method')}
                </p>
                <label>
                  <Field
                    name="formRadType"
                    component="input"
                    type="radio"
                    value="0"
                    className="cursor-pointer"
                  />{' '}
                  {t('txt-withd-trans-normal')}
                </label> */}

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-money-withdrawn')}</Form.Label>
                  <div className="d-flex justify-content-between">
                    <input
                      type={'text'}
                      className="form-control fz-13"
                      value={
                        cashBalance?.C_CASH_BALANCE_BO === 0
                          ? '0'
                          : numberFormat(cashBalance?.C_CASH_BALANCE_BO) || ''
                      }
                      disabled
                    />
                  </div>
                </Form.Group>
                <Form.Group>
                  <Form.Label></Form.Label>
                  <BtnDetail type="button" onClick={handleDetailTS} />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('txt-acc-total')} <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                    index="1"
                  />
                </Form.Group>

                {/* <Form.Group>
                  <Form.Label>{t('txt-acc-number')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BANK_ACCOUNT_CODE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-bank-branch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BRANCH_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-bank-code')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BANK_CODE || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailNUQId && (
        <DetailAuthorPerson
          id={detailNUQId}
          onClose={() => setDetailNUQId(null)}
        />
      )}
      {detailTS && (
        <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
      )}
    </ReactModal>
  );
}

AddRutTienModal = reduxForm({
  form: 'openRutTienModalform',
  enableReinitialize: true,
})(AddRutTienModal);

const selector = formValueSelector('openRutTienModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getAccountSingle = makeGetAccountSingle();
  const getCustomerDetail = makeGetCustomerDetail();
  const getSingleList = makeGetSingleList();
  const getCashOutUpdate = makeGetCashOutUpdate();
  const getChannelType = makeGetChannelType();
  const getGlobalCashWithdraw = makeGetGlobalCashWithdraw();
  const getCashCheckAuthor = makeCashCheckAuthor();
  const getCashBalance = makeGetCashBalance();
  const getGLAuthorPerson = makeGetGLAuthorPerson();

  const {
    formBusinessType,
    formChannel,
    formAccountCode,
    formWidthdrawCertId,
    formRadType,
    formCashVolume,
    formOpenCashBalanceOut,
    formBranchBank,
    formContent,
    formCheck,
    formAuthorPerson,
    formTransDate,
  } = selector(
    state,
    'formBusinessType',
    'formChannel',
    'formAccountCode',
    'formWidthdrawCertId',
    'formRadType',
    'formCashVolume',
    'formOpenCashBalanceOut',
    'formBranchBank',
    'formContent',
    'formCheck',
    'formAuthorPerson',
    'formTransDate'
  );

  return {
    token: getToken(state),
    accDetail: getAccountSingle(state),
    custDetail: getCustomerDetail(state),
    glSingleList: getSingleList(state),
    cashOutUpd: getCashOutUpdate(state),
    glChannelType: getChannelType(state),
    glCashWithdraw: getGlobalCashWithdraw(state),
    cashCheckAuthor: getCashCheckAuthor(state),
    cashBalance: getCashBalance(state),
    glAuthorPerson: getGLAuthorPerson(state),

    formBusinessType,
    formChannel,
    formAccountCode,
    formWidthdrawCertId,
    formRadType,
    formCashVolume,
    formOpenCashBalanceOut,
    formBranchBank,
    formContent,
    formCheck,
    formAuthorPerson,
    formTransDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddRutTienModal)
);
