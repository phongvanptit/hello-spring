import RenderArea from 'components/input/renderArea';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import { setToast } from 'containers/client/actions';
import {
  custDetailRequest,
  custDetailSuccess,
} from 'containers/customer/actions';
import {
  globalSingleListRequest,
  globalSingleListSuccess,
  globalAuthorPersonSuccess,
} from 'containers/global/actions';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, _diff2Date, formatDate, stringToDate } from 'utils';
import { arrCashOutType } from 'utils/const';
import {
  lengthRequired,
  required,
  validateNumberExact,
} from 'utils/validation';

import {
  cashManagementApproveRequest,
  cashManagementApproveSuccess,
  cashManagementDelRequest,
  cashManagementDelSuccess,
  cashManagementRejectRequest,
  cashManagementRejectSuccess,
  cashManagementSingleRequest,
  cashManagementSingleSuccess,
  cashManagementUnApproveRequest,
  cashManagementUnApproveSuccess,
  cashOutUpdateRequest,
  cashOutUpdateSuccess,
} from 'containers/cash/actions';

import { handleApiErrors } from 'lib/api-errors';
import {
  makeCashCheckAuthor,
  makeGetAccountSingle,
  makeGetCashManagementApprove,
  makeGetCashManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementSingle,
  makeGetCashManagementUnApprove,
  makeGetCashOutUpdate,
  makeGetChannelType,
  makeGetCustomerDetail,
  makeGetGlobalCashWithdraw,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetToken,
  makeGetGLAuthorPerson,
} from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { BtnDetail } from 'utils/styledComponent';
import DetailAuthorPerson from 'components/modal/detail-pop-up/detailAuthorPerson';
import DetailTaiSan from 'components/modal/detail-pop-up/detailTaiSan';
import { globalAuthorPersonRequest } from 'containers/global/actions';
import { globalExportFileWordRequest } from 'containers/report/actions';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function DetailNopTienModal(props) {
  const dispatch = useDispatch();
  const [diff, setDiff] = useState(false);
  const [checkInfor, setCheckInfor] = React.useState(null);
  const [detailNUQId, setDetailNUQId] = React.useState(null);
  const [detailTS, setDetailTS] = React.useState(null);

  const {
    token,
    accDetail,
    glSingleList,
    formBranchBank,
    formAccountCode,
    cashOutUpd,
    custDetail,
    glChannelType,
    formWidthdrawCertId,
    cashMngSingle,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    id,
    formCashVolume,
    formContent,

    pristine,
    handleSubmit,
    submitting,
    onClose,
    t,
    accRight,
    sysSystemInfo,
    formAuthorPerson,
    glAuthorPerson,
    accountSingle,
    formCheck,
  } = props;
  const preCashOutUpd = usePrevious(cashOutUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preCashMngSingle = usePrevious(cashMngSingle);
  const preFormAccountCode = usePrevious(formAccountCode);
  const preFormCheck = usePrevious(formCheck);

  useEffect(() => {
    if (cashMngSingle && !_.isEqual(cashMngSingle, preCashMngSingle)) {
      initForm();
    }
  }, [cashMngSingle]);

  useEffect(() => {
    if (id) handleGetSingle();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(custDetailSuccess(null));
      dispatch(globalSingleListSuccess(null));
      dispatch(cashManagementSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
      _handleCheckAuthorPerson();
    } else {
      dispatch(accountSingleSuccess(null));
      dispatch(globalAuthorPersonSuccess(null));
      dispatch(custDetailSuccess(null));
    }
    if (!!preFormCheck && !_.isEqual(formAccountCode, preFormAccountCode)) {
      dispatch(change('detailRutTienModalform', 'formCheck', '0'));
    }
  }, [formAccountCode]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (formAuthorPerson) {
      _handleCheckCustomer();
    } else {
      dispatch(custDetailSuccess(null));
    }
  }, [formAuthorPerson]);

  useEffect(() => {
    if (cashMngSingle && cashMngSingle?.C_TRANSACTION_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          cashMngSingle?.C_TRANSACTION_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [cashMngSingle]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    ) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashManagementDelSuccess(null));
      onClose();
    }
  }, [cashManagementDel]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) {
      dispatch(cashManagementApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngApprove]);

  useEffect(() => {
    if (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) {
      dispatch(cashManagementUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngUnApprove]);

  useEffect(() => {
    if (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) {
      dispatch(cashManagementRejectSuccess(null));
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngReject]);

  useEffect(() => {
    if (cashOutUpd && !_.isEqual(cashOutUpd, preCashOutUpd)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashOutUpdateSuccess(null));
      handleGetSingle();
    }
  }, [cashOutUpd]);

  useEffect(() => {
    if (formCheck) {
      setCheckInfor(
        formCheck === '0' ? true : formCheck === '1' ? false : null
      );
      if (formCheck === '0')
        dispatch(change('detailRutTienModalform', 'formAuthorPerson', ''));

      if (
        formAccountCode &&
        !formAuthorPerson &&
        glAuthorPerson.length <= 0 &&
        formCheck === '1'
      ) {
        _handleToast(`${t('txt-alert-author-person-infor')}`, 'error');
      }
    }
  }, [formCheck]);

  function initForm() {
    dispatch(
      change(
        'detailRutTienModalform',
        'formBusinessType',
        cashMngSingle?.C_BUSSINESS_DETAIL_CODE
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formChannel',
        cashMngSingle?.C_CHANNEL_CODE
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formAccountCode',
        cashMngSingle?.C_ACCOUNT_OUT
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formWidthdrawCertId',
        cashMngSingle?.C_AUTHOR_CERT_ID
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formCashVolume',
        cashMngSingle?.C_CASH_VOLUME
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formBranchBank',
        cashMngSingle?.C_BRANCH_BANK_CODE
      )
    );
    dispatch(
      change('detailRutTienModalform', 'formContent', cashMngSingle?.C_CONTENT)
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formCheck',
        (cashMngSingle?.C_AUTHOR_FLAG).toString()
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formRadType',
        cashMngSingle?.C_WITHDRAW_TYPE + ''
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formAuthorPerson',
        cashMngSingle?.C_CUST_AUTHOR
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formTransNo',
        cashMngSingle?.C_TRANSACTION_NO
      )
    );
    dispatch(
      change(
        'detailRutTienModalform',
        'formTransDate',
        cashMngSingle?.C_TRANSACTION_DATE
      )
    );
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function _handleCheckAuthorPerson() {
    if (!formAccountCode) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_ACCOUNT_AUTHOR',
      group: 'LIST',
      data: {
        ACCOUNT_CODE: formAccountCode,
        STATUS: 'DA_DUYET',

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalAuthorPersonRequest(params));
  }

  function handleDetailNUQId() {
    if (!formAuthorPerson) return;
    const resultIncludes = glAuthorPerson.find((item) =>
      item.value.includes(formAuthorPerson)
    );
    setDetailNUQId(resultIncludes?.pk);
  }

  function handleDetailTS() {
    if (!formAccountCode) return;
    setDetailTS(formAccountCode);
  }

  function _handleCheckCustomer() {
    if (!formAuthorPerson) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: formAuthorPerson,
      },
    };

    dispatch(custDetailRequest(params));
  }

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(cashManagementSingleRequest(params));
  }

  function submit() {
    handleUpdate()
  }

  function handleUpdate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_OUT',
      group: 'LIST',
      data: {
        ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        BUSINESS_TYPE: props?.formBusinessType,
        CHANNEL: props?.formChannel,
        ACCOUNT_CODE: props?.formAccountCode,
        AUTHOR_CARD_ID: checkInfor
          ? accDetail?.C_CARD_ID
          : custDetail?.C_CARD_ID,
        AUTHOR_NAME: checkInfor
          ? accDetail?.C_CUSTOMER_NAME
          : custDetail?.C_CUSTOMER_NAME,
        AUTHOR_FLAG: StringToInt(props?.formCheck),
        CASH_VALUE: StringToInt(props?.formCashVolume),
        BRANCH_BANK_CODE: props?.formBranchBank,
        WITHDRAW_TYPE: StringToInt(props?.formRadType),
        CONTENT: props?.formContent,
      },
    };

    dispatch(cashOutUpdateRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                  ? t('txt-appr-entry')
                  : actionName === 'unApprove'
                    ? t('txt-unAppr-entry')
                    : actionName === 'reject'
                      ? t('txt-reject-entry')
                      : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    console.log(rejectText);
                    if (!rejectText) return;
                    handleActionRevert(rejectText);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UN_APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementUnApproveRequest(params));
  }

  function handleActionRevert(rejectText) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        CANCEL_NOTE: rejectText,
      },
    };

    dispatch(cashManagementRejectRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  function handlePrinter() {
    var content = formContent;
    if (content === null || content === undefined || content === '') {
      content = 'Rút tiền';
    }
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
        CASH_VOLUME: formCashVolume,
        CONTENT: content,
      },
    };
    params.data.TEMPLATE_CODE = 'PHIEU_RUT_TIEN_01';
    dispatch(globalExportFileWordRequest(params));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-withdrawal-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label style={{ gridColumn: '1/3' }}>
                    {t('txt-bus-1')}
                  </Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={arrCashOutType}
                    disabled
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số bút toán</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    name="formTransDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-channel')}</Form.Label>
                  <Field
                    name="formChannel"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glChannelType}
                    disabled
                  />
                </Form.Group> */}
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CUST_MOBILE
                        : custDetail?.C_CUST_MOBILE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CUST_EMAIL
                        : custDetail?.C_CUST_EMAIL) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_RESEDENCE_ADDRESS
                        : custDetail?.C_RESEDENCE_ADDRESS) || ''
                    }
                    disabled
                  />
                </Form.Group>

                {/* <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group>
                  <Form.Label>Người thực hiện</Form.Label>
                  <Field
                    name="formCheck"
                    className="form-control w_170"
                    component="select"
                  >
                    <option value="0"> {t('txt-main-account')}</option>
                    <option value="1"> {t('txt-author-person')}</option>
                  </Field>
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    {t('txt-author-person-id')}
                    {!checkInfor && <span className="text-danger">*</span>}
                  </Form.Label>
                  <div className="d-flex justify-content-between">
                    <Field
                      name="formAuthorPerson"
                      classParent="w-100"
                      className="form-control input-order fz-13"
                      component={RenderNormalSelect}
                      opts={glAuthorPerson}
                      index={4}
                      disabled={checkInfor}
                      validate={!checkInfor ? required : null}
                    />
                    <BtnDetail type="button" onClick={handleDetailNUQId} />
                  </div>
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-card-id')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CARD_ID
                        : custDetail?.C_CARD_ID) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-withdrawer-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_CUSTOMER_NAME
                        : custDetail?.C_CUSTOMER_NAME) || ''
                    }
                    disabled
                  />
                </Form.Group>

                {/* <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_ISSUE_DATE
                        : custDetail?.C_ISSUE_DATE) || ''
                    }
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label> {t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      (checkInfor
                        ? accDetail?.C_ISSUE_PLACE
                        : custDetail?.C_ISSUE_PLACE) || ''
                    }
                    disabled
                  />
                </Form.Group> */}

                {/* <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-withd-trans-method')}
                </p>
                <label>
                  <Field
                    name="formRadType"
                    component="input"
                    type="radio"
                    value="0"
                    className="cursor-pointer"
                  />{' '}
                  {t('txt-withd-trans-normal')}
                </label> */}
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required, validateNumberExact]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-withdrawable')}</Form.Label>
                  <Field
                    name="formOpenCashBalanceOut"
                    className="form-control input-order fz-13"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{/* {t('txt-after-withd')} */}</Form.Label>
                  <div className="d-flex justify-content-between">
                    {/* <Field
                      name="formCloseCashBalanceOut"
                      className="form-control input-order fz-13"
                      component={RenderInput}
                      disabled
                    /> */}
                    <BtnDetail type="button" onClick={handleDetailTS} />
                  </div>
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('txt-acc-total')} <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                  />
                </Form.Group>

                {/* <Form.Group>
                  <Form.Label>{t('txt-acc-number')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BANK_ACCOUNT_CODE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-bank-branch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BRANCH_BANK_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-bank-code')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={glSingleList?.C_BANK_CODE || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                <div
                  className="d-flex mt-2"
                  style={{ gridColumn: '1/5', gap: '5px 20px' }}
                >
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-creator')}
                      {': '}
                      {cashMngSingle?.C_CREATOR_CODE}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-create-time')}
                      {': '}
                      {cashMngSingle?.C_CREATE_TIME || ''}
                    </Form.Label>
                  </div>
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-approver')}
                      {': '}
                      {cashMngSingle?.C_APPROVER_CODE || ''}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-approve-time')}
                      {': '}
                      {cashMngSingle?.C_APPROVE_TIME || ''}
                    </Form.Label>
                  </div>
                </div>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {/*<BtnSubmit*/}
                {/*  type="button"*/}
                {/*  onClick={handlePrinter}*/}
                {/*  className="w_125 ml-2 success"*/}
                {/*>*/}
                {/*  {t('lab-print-bill')}*/}
                {/*</BtnSubmit>*/}
                {(cashMngSingle?.C_STATUS === 'CHUA_DUYET' || cashMngSingle?.C_STATUS === 'DANG_XU_LY') && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                        {/* <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('reject')}
                          className="w_125 ml-2 info"
                        >
                          {t('bnt-reject-entry')}
                        </BtnSubmit> */}
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="submit"
                          disabled={pristine || submitting}
                          className="w_125 ml-2"
                        >
                          {t('bnt-edit-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {cashMngSingle?.C_STATUS === 'DA_DUYET' &&
                  accRight?.C_APPROVE === 1 &&
                  diff && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
      {detailNUQId && (
        <DetailAuthorPerson
          id={detailNUQId}
          onClose={() => setDetailNUQId(null)}
        />
      )}
      {detailTS && (
        <DetailTaiSan acc={detailTS} onClose={() => setDetailTS(null)} />
      )}
    </ReactModal>
  );
}

DetailNopTienModal = reduxForm({
  form: 'detailRutTienModalform',
  enableReinitialize: true,
})(DetailNopTienModal);

const selector = formValueSelector('detailRutTienModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getSingleList = makeGetSingleList();
  const getAccountSingle = makeGetAccountSingle();
  const getCustomerDetail = makeGetCustomerDetail();
  const getCashOutUpdate = makeGetCashOutUpdate();
  const getChannelType = makeGetChannelType();
  const getCashManagementSingle = makeGetCashManagementSingle();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
  const getGlobalCashWithdraw = makeGetGlobalCashWithdraw();
  const getCashCheckAuthor = makeCashCheckAuthor();
  const getGLAuthorPerson = makeGetGLAuthorPerson();

  const {
    formBusinessType,
    formChannel,
    formAccountCode,
    formWidthdrawCertId,
    formRadType,
    formCashVolume,
    formOpenCashBalanceOut,
    formCloseCashBalanceOut,
    formBranchBank,
    formContent,
    formCheck,
    formAuthorPerson,
  } = selector(
    state,
    'formBusinessType',
    'formChannel',
    'formAccountCode',
    'formWidthdrawCertId',
    'formRadType',
    'formCashVolume',
    'formOpenCashBalanceOut',
    'formCloseCashBalanceOut',
    'formBranchBank',
    'formContent',
    'formCheck',
    'formAuthorPerson'
  );
  const cashMngSingle = getCashManagementSingle(state);
  return {
    token: getToken(state),
    sysSystemInfo: getSystemInfo(state),
    accDetail: getAccountSingle(state),
    custDetail: getCustomerDetail(state),
    glSingleList: getSingleList(state),
    cashOutUpd: getCashOutUpdate(state),
    glChannelType: getChannelType(state),
    cashMngSingle,
    cashMngApprove: getCashManagementApprove(state),
    cashMngUnApprove: getCashManagementUnApprove(state),
    cashMngReject: getCashManagementReject(state),
    cashManagementDel: getCashManagementDel(state),
    glCashWithdraw: getGlobalCashWithdraw(state),
    cashCheckAuthor: getCashCheckAuthor(state),
    glAuthorPerson: getGLAuthorPerson(state),

    formBusinessType,
    formChannel,
    formAccountCode,
    formWidthdrawCertId,
    formRadType,
    formCashVolume,
    formOpenCashBalanceOut,
    formCloseCashBalanceOut,
    formBranchBank,
    formContent,
    formCheck,
    formAuthorPerson,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailNopTienModal)
);
