import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import RenderInputMask from 'components/input/renderInputMask';
import RenderNewInputAccount from 'components/input/renderNewInputAccount';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import RenderSuggestBranchBank from 'components/input/renderSuggestBranchBank';
import {
  accountSingleRequest,
  accountSingleSuccess,
} from 'containers/account/actions';
import {
  cashInUpdateRequest,
  cashInUpdateSuccess,
  cashManagementApproveRequest,
  cashManagementApproveSuccess,
  cashManagementDelRequest,
  cashManagementDelSuccess,
  cashManagementRejectRequest,
  cashManagementRejectSuccess,
  cashManagementSingleRequest,
  cashManagementSingleSuccess,
  cashManagementUnApproveRequest,
  cashManagementUnApproveSuccess,
} from 'containers/cash/actions';
import { setToast } from 'containers/client/actions';
import {
  globalSingleListRequest,
  globalSingleListSuccess,
} from 'containers/global/actions';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToInt, _diff2Date, formatDate, stringToDate } from 'utils';
import { lengthRequired, required } from 'utils/validation';


import {
  makeGetAccountSingle,
  makeGetCashInUpdate,
  makeGetCashManagementApprove,
  makeGetCashManagementDel,
  makeGetCashManagementReject,
  makeGetCashManagementSingle,
  makeGetCashManagementUnApprove,
  makeGetGlobalCashDeposit,
  makeGetSingleList,
  makeGetSystemInfo,
  makeGetToken,
} from 'lib/selector';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '850px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(7);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailNopTienModal(props) {
  const dispatch = useDispatch();
  const [diff, setDiff] = useState(false);
  const {
    token,
    accDetail,
    glSingleList,
    formBranchBank,
    formAccountCode,
    cashInUpd,
    cashMngSingle,
    cashMngApprove,
    cashMngUnApprove,
    cashMngReject,
    cashManagementDel,
    id,
    pristine,
    handleSubmit,
    submitting,
    onClose,
    t,
    glCashDeposit,
    accRight,
    sysSystemInfo,
  } = props;
  const preCashInUpd = usePrevious(cashInUpd);
  const preCashMngApprove = usePrevious(cashMngApprove);
  const preCashMngUnApprove = usePrevious(cashMngUnApprove);
  const preCashMngReject = usePrevious(cashMngReject);
  const preCashManagementDel = usePrevious(cashManagementDel);
  const preCashMngSingle = usePrevious(cashMngSingle);

  useEffect(() => {
    if (id) handleGetSingle();
    return () => {
      dispatch(accountSingleSuccess(null));
      dispatch(globalSingleListSuccess(null));
      dispatch(cashManagementSingleSuccess(null));
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (cashMngSingle && !_.isEqual(cashMngSingle, preCashMngSingle)) {
      initForm();
    }
  }, [cashMngSingle]);

  useEffect(() => {
    if (formAccountCode && formAccountCode.length === 7) {
      _handleCheckAccount();
    } else dispatch(accountSingleSuccess(null));
  }, [formAccountCode]);

  useEffect(() => {
    if (formBranchBank) {
      _handleCheckBankBranch();
    } else dispatch(globalSingleListSuccess(null));
  }, [formBranchBank]);

  useEffect(() => {
    if (cashMngSingle && cashMngSingle?.C_TRANSACTION_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          cashMngSingle?.C_TRANSACTION_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [cashMngSingle]);

  useEffect(() => {
    if (
      cashManagementDel &&
      !_.isEqual(cashManagementDel, preCashManagementDel)
    ) {
      _handleToast(`${t('txt-del-entry-success')}`, 'success');
      dispatch(cashManagementDelSuccess(null));
      onClose();
    }
  }, [cashManagementDel]);

  useEffect(() => {
    if (cashMngApprove && !_.isEqual(cashMngApprove, preCashMngApprove)) {
      dispatch(cashManagementApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngApprove]);

  useEffect(() => {
    if (cashMngUnApprove && !_.isEqual(cashMngUnApprove, preCashMngUnApprove)) {
      dispatch(cashManagementUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngUnApprove]);

  useEffect(() => {
    if (cashMngReject && !_.isEqual(cashMngReject, preCashMngReject)) {
      dispatch(cashManagementRejectSuccess(null));
      _handleToast(`${t('txt-reject-entry-success')}`, 'success');
      handleGetSingle();
    }
  }, [cashMngReject]);

  useEffect(() => {
    if (cashInUpd && !_.isEqual(cashInUpd, preCashInUpd)) {
      _handleToast(`${t('txt-upd-entry-success')}`, 'success');
      dispatch(cashInUpdateSuccess(null));
      handleGetSingle();
    }
  }, [cashInUpd]);

  function initForm() {
    dispatch(
      change(
        'detailNopTienModalform',
        'formBusinessType',
        cashMngSingle?.C_BUSSINESS_DETAIL_CODE
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formFileDate',
        cashMngSingle?.C_FILE_DATE
          ? cashMngSingle?.C_FILE_DATE.split(' ')[0]
          : null
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formTransNo',
        cashMngSingle?.C_TRANSACTION_NO
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formTransDate',
        cashMngSingle?.C_TRANSACTION_DATE
      )
    );
    dispatch(
      change('detailNopTienModalform', 'formFileNo', cashMngSingle?.C_FILE_NO)
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formFileDate',
        cashMngSingle?.C_FILE_DATE
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formAccountCode',
        cashMngSingle?.C_ACCOUNT_IN
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formCashVolume',
        cashMngSingle?.C_CASH_VOLUME
      )
    );
    dispatch(
      change(
        'detailNopTienModalform',
        'formBranchBank',
        cashMngSingle?.C_BRANCH_BANK_CODE
      )
    );
    dispatch(
      change('detailNopTienModalform', 'formContent', cashMngSingle?.C_CONTENT)
    );
  }

  function _handleCheckAccount() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_ACCOUNT',
      group: 'LIST',
      data: {
        ACCOUNT_ID: formAccountCode,
      },
    };

    dispatch(accountSingleRequest(params));
  }

  function _handleCheckBankBranch() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST',
      group: 'LIST',
      data: {
        LIST_TYPE_CODE: 'BRANCH_BANK_CODE',
        ITEM_ID: formBranchBank,
      },
    };

    dispatch(globalSingleListRequest(params));
  }

  function handleGetSingle() {
    if (!id) {
      return;
    }

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(cashManagementSingleRequest(params));
  }

  function submit(values) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_CASH_IN',
      group: 'LIST',
      data: {
        ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        BUSINESS_TYPE: values?.formBusinessType,
        ACCOUNT_CODE: values?.formAccountCode,
        FILE_DATE: values?.formFileDate,
        FILE_NO: values?.formFileNo,
        CASH_VALUE: StringToInt(values?.formCashVolume),
        BRANCH_BANK_CODE: values?.formBranchBank,
        CONTENT: values?.formContent,
      },
    };

    dispatch(cashInUpdateRequest(params));
  }

  function handleConfirm(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'delete'
                ? t('txt-del-entry')
                : actionName === 'approve'
                  ? t('txt-appr-entry')
                  : actionName === 'unApprove'
                    ? t('txt-unAppr-entry')
                    : actionName === 'reject'
                      ? t('txt-reject-entry')
                      : ''}
            </p>
            {actionName === 'reject' && (
              <div className="text-left">
                <label className="fz-13">
                  {t('txt-reason-reject')}{' '}
                  <span className="text-danger">*</span>
                </label>
                <input
                  type={'text'}
                  className="form-control my-2"
                  id="txtRejectText"
                  onChange={(e) => console.log(e)}
                />
              </div>
            )}
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {
                  case 'delete':
                    handleActionDel();
                    break;
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;
                  case 'reject':
                    const rejectText =
                      document.getElementById('txtRejectText')?.value;
                    if (!rejectText) return;
                    handleActionRevert(rejectText);
                    break;
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionDel() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.DELETE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementDelRequest(params));
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UN_APPROVE_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
      },
    };

    dispatch(cashManagementUnApproveRequest(params));
  }

  function handleActionRevert(rejectText) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REJECT_CASH_MANAGEMENT',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: cashMngSingle?.PK_CASH_MANAGEMENT,
        CANCEL_NOTE: rejectText,
      },
    };

    dispatch(cashManagementRejectRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-deposit-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>Số bút toán</Form.Label>
                  <Field
                    name="formTransNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-date-trading')}</Form.Label>
                  <Field
                    name="formTransDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-file-no')}</Form.Label>
                  <Field
                    name="formFileNo"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-profile-date')}</Form.Label>
                  <Field
                    name="formFileDate"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSelectDate}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-bus-1')}</Form.Label>
                  <Field
                    name="formBusinessType"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={glCashDeposit}
                    disabled
                    required
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-acc')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNewInputAccount}
                    validate={[required, length7]}
                    index={2}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-acc-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_ACCOUNT_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={
                      accDetail
                        ? `${accDetail?.C_SUB_BRANCH_CODE} - ${accDetail?.C_SUB_BRANCH_NAME}`
                        : ''
                    }
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-mobile')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_MOBILE || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-email')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_CUST_EMAIL || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={accDetail?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>
                <p
                  style={{ gridColumn: '1/4' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-bank-info')}
                </p>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cash-vol')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCashVolume"
                    className="form-control input-order fz-13"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('txt-acc-total')} <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBranchBank"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestBranchBank}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                <div
                  className="d-flex mt-2"
                  style={{ gridColumn: '1/5', gap: '5px 20px' }}
                >
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-creator')}
                      {': '}
                      {cashMngSingle?.C_CREATOR_CODE}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-create-time')}
                      {': '}
                      {cashMngSingle?.C_CREATE_TIME || ''}
                    </Form.Label>
                  </div>
                  <div className="d-flex flex-column">
                    <Form.Label>
                      {t('txt-approver')}
                      {': '}
                      {cashMngSingle?.C_APPROVER_CODE || ''}
                    </Form.Label>
                    <Form.Label>
                      {t('txt-approve-time')}
                      {': '}
                      {cashMngSingle?.C_APPROVE_TIME || ''}
                    </Form.Label>
                  </div>
                </div>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {(cashMngSingle?.C_STATUS === 'CHUA_DUYET' || cashMngSingle?.C_STATUS === 'DANG_XU_LY') && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                        {/* <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('reject')}
                          className="w_125 ml-2 info"
                        >
                          {t('bnt-reject-entry')}
                        </BtnSubmit> */}
                      </>
                    )}
                    {accRight?.C_UPDATE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirm('delete')}
                          className="w_125 ml-2 danger"
                        >
                          {t('bnt-del-entry')}
                        </BtnSubmit>
                        <BtnSubmit
                          type="submit"
                          disabled={pristine || submitting}
                          className="w_125 ml-2"
                        >
                          {t('bnt-edit-entry')}
                        </BtnSubmit>
                      </>
                    )}
                  </>
                )}
                {cashMngSingle?.C_STATUS === 'DA_DUYET' &&
                  accRight?.C_APPROVE === 1 &&
                  diff && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirm('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailNopTienModal = reduxForm({
  form: 'detailNopTienModalform',
  enableReinitialize: true,
})(DetailNopTienModal);

const selector = formValueSelector('detailNopTienModalform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getSingleList = makeGetSingleList();
  const getAccountSingle = makeGetAccountSingle();
  const getCashInUpdate = makeGetCashInUpdate();
  const getCashManagementSingle = makeGetCashManagementSingle();
  const getCashManagementApprove = makeGetCashManagementApprove();
  const getCashManagementUnApprove = makeGetCashManagementUnApprove();
  const getCashManagementReject = makeGetCashManagementReject();
  const getCashManagementDel = makeGetCashManagementDel();
  const getGlobalCashDeposit = makeGetGlobalCashDeposit();
  const getSystemInfo = makeGetSystemInfo();
  const {
    formBusinessType,
    formFileDate,
    formFileNo,
    formAccountCode,
    formCashVolume,
    formBranchBank,
    formContent,
    formTransNo,
    formTransDate,
  } = selector(
    state,
    'formBusinessType',
    'formFileDate',
    'formFileNo',
    'formAccountCode',
    'formCashVolume',
    'formBranchBank',
    'formContent',
    'formTransNo',
    'formTransDate'
  );
  const cashMngSingle = getCashManagementSingle(state);
  return {
    token: getToken(state),
    glSingleList: getSingleList(state),
    accDetail: getAccountSingle(state),
    cashInUpd: getCashInUpdate(state),
    sysSystemInfo: getSystemInfo(state),
    cashMngSingle,
    cashMngApprove: getCashManagementApprove(state),
    cashMngUnApprove: getCashManagementUnApprove(state),
    cashMngReject: getCashManagementReject(state),
    cashManagementDel: getCashManagementDel(state),
    glCashDeposit: getGlobalCashDeposit(state),
    formBusinessType,
    formFileDate,
    formFileNo,
    formAccountCode,
    formCashVolume,
    formBranchBank,
    formContent,
    formTransNo,
    formTransDate,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailNopTienModal)
);
