/* eslint-disable react/jsx-no-target-blank */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import { connect, useDispatch } from 'react-redux';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';

import { setToast } from 'containers/client/actions';

import { makeGetToken,makeGetSystemInfo,makeGetIpmApprove,makeGetIpmUnApprove } from 'lib/selector';
import  { useState } from 'react';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { StringToInt, _diff2Date, formatDate, stringToDate } from 'utils';
import { ipmApproveRequest,ipmApproveSuccess,ipmUnApproveRequest,ipmUnApproveSuccess } from 'containers/import/actions';

import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { impGetSingleRequest } from 'containers/import/actions';
import { impGetSingleSuccess } from 'containers/import/actions';
import { makeGetDetailInfo } from 'lib/reselect/import';
import { makeGetAllRecordInfo } from 'lib/reselect/import';
import { impInfoAllRecordRequest } from 'containers/import/actions';
import { numberFormat } from 'utils';

ReactModal.setAppElement('#root');
// const customStyles = {
//   content: {
//     inset: '40px',
//     padding: '0',
//     borderWidth: '0',
//     borderColor: '#f3f3f3',
//     overflow: 'inherit',
//   },
// };

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 2rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 3px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function DetailImportDataModal(props) {
  const dispatch = useDispatch();
  const [diff, setDiff] = useState(false);

  const { token, id, impInfoDetail, impInfoAllRc,ipmUnAppr,ipmAppr,accRight,sysSystemInfo } = props;

  const preApprove = usePrevious(ipmAppr);
  const preUnApprove = usePrevious(ipmUnAppr);

  React.useEffect(() => {
    makeGetRecordInfo();
    makeGetAllRecord();

    return () => {
      dispatch(impGetSingleSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (id) makeGetRecordInfo();
    return () => {
      dispatch(impGetSingleSuccess(null));
      //props.reset();
    };
  }, []);

  React.useEffect(() => {
    if (impInfoDetail && impInfoDetail?.C_DUE_DATE) {
      const date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
      setDiff(
        _diff2Date(
          impInfoDetail?.C_DUE_DATE,
          formatDate(date, '/', 'dmy')
        ) >= 0
      );
    }
  }, [impInfoDetail]);

  React.useEffect(() => {
    if (ipmAppr && !_.isEqual(ipmAppr, preApprove)) {
      dispatch(ipmApproveSuccess(null));
      _handleToast(`${t('txt-appr-entry-success')}`, 'success');
      makeGetRecordInfo();
    }
  }, [ipmAppr]);

  React.useEffect(() => {
    if (ipmUnAppr && !_.isEqual(ipmUnAppr, preUnApprove)) {
      dispatch(ipmUnApproveSuccess(null));
      _handleToast(`${t('txt-unAppr-entry-success')}`, 'success');
      makeGetRecordInfo();
    }
  }, [ipmUnAppr]);

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1> {t('txt-confirm')}</h1>
            <p> Import dữ liệu</p>
            <button onClick={onClose}> {t('txt-cancel')}</button>
            <button
              onClick={() => {
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleConfirmAppr(actionName) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>
              {actionName === 'approve'
                  ? t('txt-appr-entry')
                  : actionName === 'unApprove'
                    ? t('txt-unAppr-entry')
                      : ''}
            </p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                switch (actionName) {           
                  case 'approve':
                    handleActionApprove();
                    break;
                  case 'unApprove':
                    handleActionUnApprove();
                    break;               
                  default:
                    break;
                }
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: false,
      closeOnClickOutside: true,
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_IMPORT_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: impInfoDetail?.PK_IMPORT_INFO,
        NEW_STATUS: 'DA_DUYET',
      },
    };

    dispatch(ipmApproveRequest(params));
  }

  function handleActionUnApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.APPROVE_IMPORT_INFO',
      group: 'LIST',
      data: {
        LIST_ITEM_ID: impInfoDetail?.PK_IMPORT_INFO,
        NEW_STATUS: 'CHUA_DUYET',
      },
    };

    dispatch(ipmUnApproveRequest(params));
  }

  function makeGetRecordInfo() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_IMPORT_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(impGetSingleRequest(params));
  }

  
  function makeGetAllRecord() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_IMPORT_RECORD',
      group: 'LIST',
      data: {
        ITEM_ID: id,
      },
    };

    dispatch(impInfoAllRecordRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { onClose, t } = props;

  // console.log(glImportType, typeBizList, glCashBizDetail);

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={false}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{`Chi tiết import tiền`}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
        <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
          <FormAdd>
          <Form.Group style={{ gridColumn: '1/5' }}>
            <a
              className="fz-14 my-2"
              href={process.env.PUBLIC_URL + '/docs/ImportTemp.xlsx'}
              target="_blank"
            >
              Tải file mẫu
            </a>
           </Form.Group>
            <Form.Group style={{ gridColumn: '1/3' }}>
              <Form.Label className="fz-13">
              Nghiệp vụ<span className="text-danger">*</span>
              </Form.Label>
              <input
              type={'text'}
              value={impInfoDetail?.C_BUSINESS_NAME || ''}
              className="form-control input-order "
              disabled
             />
           </Form.Group>
           <Form.Group style={{ gridColumn: '3/5' }}>
              <Form.Label className="fz-13">
              Nghiệp vụ chi tiết<span className="text-danger">*</span>
              </Form.Label>
              <input
              type={'text'}
              value={impInfoDetail?.C_BUSINESS_DETAIL_NAME || ''}
              className="form-control input-order "
              disabled
             />
           </Form.Group>
           <Form.Group style={{ gridColumn: '1/3' }}>
              <Form.Label className="fz-13">
              Ngày giao dịch<span className="text-danger">*</span>
              </Form.Label>
              <input
              type={'text'}
              value={impInfoDetail?.C_TRADING_DATE || ''}
              className="form-control input-order "
              disabled
            />
           </Form.Group>
           <Form.Group style={{ gridColumn: '3/5' }}>
              <Form.Label className="fz-13">
              Tài khoản tổng<span className="text-danger">*</span>
              </Form.Label>
              <input
              type={'text'}
              value={impInfoDetail?.C_BRANCH_BANK_CODE + '-' + impInfoDetail?.C_BRANCH_BANK_NAME || ''}
              className="form-control input-order "
              disabled
            />
           </Form.Group>
           <Form.Group style={{ gridColumn: '1/3' }}>
              <Form.Label className="fz-13">
              Mã chứng khoán<span className="text-danger">*</span>
              </Form.Label>
              <input
              type={'text'}
              value={impInfoDetail?.C_SHARE_CODE || ''}
              className="form-control input-order "
              disabled
            />
           </Form.Group>
           
           <Form.Group>
              <Form.Label className="fz-13">
              File import<span className="text-danger">*</span>
              </Form.Label>
              <a href={impInfoDetail?.C_FILE_NAME || ''} target="_blank">
              {impInfoDetail?.C_FILE_NAME
                ? impInfoDetail?.C_FILE_NAME.replace(/^.*[\\/]/, '')
                : ''}
            </a>
           </Form.Group>
           <Form.Group style={{ gridColumn: '1/5' }}>
              <Form.Label className="fz-13">
              {t('txt-note')}<span className="text-danger">*</span>
              </Form.Label>
              <input
              type={'text'}
              value={impInfoDetail?.C_CONTENT || ''}
              className="form-control input-order "
              disabled
            />
           </Form.Group>
          </FormAdd>
          </PerfectScrollbar>
          <hr />
          <p style={{ gridColumn: '1/5' }} className="color-thm mb-0 fz-13">
            Dữ liệu import
          </p>
          <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 380px)' }}>
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Tài khoản</th>
                  <th>Tên tài khoản</th>
                  <th>Số tiền</th>
                  <th>Nội dung</th>
                  <th>trạng thái</th>
                </tr>
              </thead>
              <tbody>
                {impInfoAllRc &&
                  impInfoAllRc.map((item, index) => (
                    <tr key={index}>
                      <td className="text-center">{index + 1}</td>
                      <td className="text-center">{item.C_ACCOUNT_CODE}</td>
                      <td className="">{item.C_ACCOUNT_NAME}</td>
                      <td className="text-right">
                        {numberFormat(item.C_CASH_VALUE, 0, '0')}
                      </td>
                      <td className="">{item.C_CONTENT}</td>
                      <td className="text-center">{item.C_STATUS}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </PerfectScrollbar>

          <div
            className="d-flex mt-2"
            style={{
              height: '30px',
              whiteSpace: 'nowrap',
              gridColumn: '1/5',
            }}
          >
            <BtnClose type="button" onClick={onClose} className="w_60 mr-auto">
              {t('txt-close')}
            </BtnClose>
            {/* <BtnSubmit type="button">
              {t('txt-accept')}
            </BtnSubmit> */}
            <div className="d-flex">
                {impInfoDetail?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    {accRight?.C_APPROVE === 1 && (
                      <>
                        <BtnSubmit
                          type="button"
                          onClick={() => handleConfirmAppr('approve')}
                          className="w_125 ml-2 success"
                        >
                          {t('bnt-appr-entry')}
                        </BtnSubmit>
                       
                      </>
                    )}
                    
                  </>
                )}
                {impInfoDetail?.C_STATUS === 'DA_DUYET' &&
                  accRight?.C_APPROVE === 1 &&
                  diff && (
                    <>
                      <BtnSubmit
                        type="button"
                        onClick={() => handleConfirmAppr('unApprove')}
                        className="w_125 ml-2 success"
                      >
                        {t('bnt-unAppr-entry')}
                      </BtnSubmit>
                    </>
                  )}
              </div>
          </div>
          
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getDetailInfo = makeGetDetailInfo();
  const getAllRecordInfo = makeGetAllRecordInfo();
  const getSystemInfo = makeGetSystemInfo();
  const getIpmApprove = makeGetIpmApprove();
  const getIpmUnApprove = makeGetIpmUnApprove();

  const token = getToken(state);

  return {
    token,
    impInfoDetail: getDetailInfo(state),
    impInfoAllRc: getAllRecordInfo(state),
    sysSystemInfo: getSystemInfo(state),
    ipmAppr: getIpmApprove(state),
    ipmUnAppr: getIpmUnApprove(state),
  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailImportDataModal)
);
