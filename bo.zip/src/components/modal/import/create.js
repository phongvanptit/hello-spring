/* eslint-disable react/jsx-no-target-blank */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { change, Field, formValueSelector, reduxForm } from 'redux-form';

import * as _ from 'lodash';
import ReactModal from 'react-modal';
import styled from 'styled-components';
import { FaTimes } from 'react-icons/fa';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { formatDate } from 'utils';
import { required } from 'utils/validation';

import { setToast } from 'containers/client/actions';

import {
  makeGetToken,
  makeGetGLImportType,
  makeGetTypeBizList,
  makeGetGlobalCashBusinessDetail,
  makeGetShareSingle
} from 'lib/selector';

import RenderNormalSelect from 'components/input/renderSelect';
import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderFileInput from 'components/input/renderFileInput';
import RenderInput from 'components/input/renderInput';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import Spinner from 'assets/img/spinner.gif';
import RenderSuggestShare from 'components/input/renderSuggestShare';
import {
  typeBankSearchRequest,
} from 'containers/category/actions';

import {
  globalCashBusinessDetailRequest,
  globalCashBusinessDetailSuccess,
} from 'containers/global/actions';
import { confirmAlert } from 'react-confirm-alert';
import Excel from 'exceljs';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { replaceAll } from 'utils';
import { typeDelBankSuccess } from 'containers/category/actions';
import { ipmUpdateRequest } from 'containers/import/actions';
import {
  shareSingleRequest,
  shareSingleSuccess,
} from 'containers/stock/actions';
ReactModal.setAppElement('#root');
// const customStyles = {
//   content: {
//     inset: '40px',
//     padding: '0',
//     borderWidth: '0',
//     borderColor: '#f3f3f3',
//     overflow: 'inherit',
//   },
// };

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.3rem 0.3rem 1rem 0.3rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4 minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const fileUrl = `${process.env.REACT_APP_FILE_URL}/upload`;
const appUrl = `${process.env.REACT_APP_API_URL}/backServices`;

function AddImportDataModal(props) {
  const dispatch = useDispatch();
  const abortController = new AbortController();
  const [isLoading, setIsLoading] = React.useState(false);
  const [dataShow, setDataShow] = React.useState([]);
  const [dataHeader, setDataHeader] = React.useState([]);

  const importId = React.useRef();

  const {
    token,
    typeBizList,
    glImportType,
    glCashBizDetail,
    formShareCode,

    formBizCode,
    formFile,
    formImportType,
    shareSingle,
  } = props;

  const preFormFile = usePrevious(formFile);
  const preBizCode = usePrevious(formBizCode);

  React.useEffect(() => {
    return () => {
      dispatch(globalCashBusinessDetailSuccess(null));
    };
  }, []);

  React.useEffect(() => {
    if (formBizCode && !_.isEqual(formBizCode, preBizCode)) {
      dispatch(change('importDataform', 'formBizDetail', ''));
      getAllBizDetail();
    }
  }, [formBizCode]);
  React.useEffect(() => {
    if (formShareCode) {
      _handleCheckShare();
    } else dispatch(shareSingleSuccess(null));
  }, [formShareCode]);

  React.useEffect(() => {
    if (formFile && !_.isEqual(formFile, preFormFile)) {
      // console.log(formFile);
      handleProcessFile(formFile);
    }
  }, [formFile]);

  function _handleCheckShare() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_LIST_SHARE',
      group: 'LIST',
      data: {
        SHARE_ID: formShareCode,
      },
    };

    dispatch(shareSingleRequest(params));
  }
  

  function asyncIterator(_array) {
    return {
      next: function () {
        if (_array.length) {
          return {
            value: _array.shift(),
            done: false,
          };
        } else {
          return {
            done: true,
          };
        }
      },
    };
  }

  function handleImport() {
    var _ite = asyncIterator(dataShow);
    setIsLoading(true);
    importItems(_ite);
  }

  async function importItems(_ite) {
    const _iterator = _ite.next();
    if (_iterator.done) {
      _handleToast('Import thành công', 'success');
      setIsLoading(false);
      setDataShow([]);
      // clear file input
      dispatch(change('importDataform', 'formImportType', ''));
      dispatch(change('importDataform', 'formBizCode', ''));
      dispatch(change('importDataform', 'formBizDetail', ''));
      dispatch(change('importDataform', 'formShareCode', ''));
      dispatch(change('importDataform', 'formContent', ''));
      dispatch(change('importDataform', 'formFile', null));

      // toggle search
      dispatch(typeDelBankSuccess(Math.random()));
      getList();
    } else {
      acceptImport(_iterator.value).then((response) => {
        if (response.code < 1) {
          _handleToast('Import thất bại: ' + response.re, 'error');
          //   setIsLoading(false);
        }
        importItems(_ite);
      });
    }
  }

  function acceptImport(data) {
    console.log(formImportType, formBizCode, data);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.IMPORT_DATA_RECORD',
      group: 'LIST',
      data: {
        IMPORT_ID: importId.current || '',
        IMPORT_TYPE: formImportType || 'CASH_TRANS',
        BUSINESS_CODE: formBizCode,
        ACCOUNT_CODE: data[0],
        CASH_VALUE: Number(replaceAll(data[1], ',', '')),
        CONTENT: data[2],
      },
    };
    
    const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }
    const request = fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    });

    return request
      .then((response) => response.json())
      .then((json) => json)
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
      
  }

  function handleProcessFile(file) {
    setIsLoading(true);
    const wb = new Excel.Workbook();
    const reader = new FileReader();

    reader.readAsArrayBuffer(file);
    reader.onload = () => {
      const buffer = reader.result;

      let _arr = [],
        rowlength = 0;

      let isCurSheet = false;

      wb.xlsx
        .load(buffer)
        .then((workbook) => {
          // console.log('workbook', workbook);
          workbook.eachSheet((sheet, id) => {
            // console.log('sheet id', id, sheet);
            isCurSheet = false;
            if (sheet.state === 'hidden') return;

            sheet.eachRow((row) => {
              if (!row.hasValues) return;

              const _rowValue = row.values;

              // console.log(row.values, rowIndex);
              // if(row.hasValues && row.values.length) {
              //   console.log((row.values as CellValue[])[1])
              // }
              if (
                _rowValue.length &&
                _rowValue[1]?.toString().includes('ACCOUNT_CODE')
              ) {
                isCurSheet = true;
                let _string = [];
                row.values.forEach((item) => {
                  if (item) _string.push(item.toString());
                });
                // _string.push("TT");
                rowlength = _string.length;
                setDataHeader(_string);
              }
              if (
                isCurSheet &&
                _rowValue.length &&
                _rowValue[1] &&
                !_rowValue[1]?.toString().includes('ACCOUNT_CODE')
              ) {
                // khởi tạo mảng rỗng
                let _string = _.fill(Array(rowlength), '');

                _rowValue.forEach((item, i) => {
                  _string[i - 1] = item?.toString().trim() || '';
                });
                if (_string.length) _arr.push(_string);
              }
            });
          });

          // console.log(_arr);
          setDataShow(_arr);
          setIsLoading(false);
        })
        .catch(() => {
          setIsLoading(false);
        });
    };
  }

  function handleConfirm() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1> {t('txt-confirm')}</h1>
            <p> Import dữ liệu</p>
            <button onClick={onClose}> {t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleImport();
                onClose();
              }}
            >
              {t('txt-accept')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function getAllBizDetail() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_BUSINESS_DETAIL',
      group: 'LIST',
      data: {
        BUSINESS_TRANSACTION_CODE: formBizCode,
        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

    dispatch(globalCashBusinessDetailRequest(params));
  }

  function submit(values) {
    setIsLoading(true);
    handleUploadAnh(values, values.formFile);
  }

  function handleUploadAnh(values, file) {
    fileUpload(file).then((response) => {
      if (response.code > 0) {
        const _filePaths = response.FILE_DIR;
        handleNextProcess(values, _filePaths);
      } else {
        _handleToast(response.re);
      }
    });
  }

  function getList() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.GET_ALL_IMPORT_INFO',
      group: 'LIST',
      data: {
        IMPORT_TYPE: 'CASH_TRANS',
        BUSINESS_CODE: '',
        BIZ_DETAIL_CODE: '',
        SHARE_CODE: '',
        STATUS: '',
        FROM_DATE: '',
        TO_DATE: '',

        PAGE: 1,
        RECORD_PER_PAGE: 10,
      },
    };
    dispatch(typeBankSearchRequest(params));
  }

  function handleNextProcess(values, _filePaths) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.UPDATE_IMPORT_INFO',
      group: 'LIST',
      data: {
        ITEM_ID: '',
        IMPORT_TYPE: 'CASH_TRANS',
        BUSINESS_CODE: values.formBizCode,
        BUSINESS_DETAIL_CODE: values.formBizDetail,
        SHARE_CODE: values.formShareCode,
        BRANCH_BANK_CODE: values.formBankAccount,
        FILE_NAME: _filePaths,
        CONTENT: values.formContent,
      },
    };

    const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }
    const request = fetch(appUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    });

    return request
      .then((response) => response.json())
      .then((json) => {
        if (json.code > 0) {
          importId.current = json.data[0].IMPORT_ID;
          handleImport();
        } else {
          _handleToast(json.re);
          setIsLoading(false);
        }
      })
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
  }

  function fileUpload(file) {
    const formData = new FormData();
    formData.append('file', file);
    const request = fetch(fileUrl, {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    return request
      .then((response) => response.json())
      .then((json) => json)
      .catch((error) => {
        setIsLoading(false);
        throw error;
      });
  }

  const _handleToast = (msg, type = 'info') => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  const { handleSubmit, submitting, onClose, t } = props;

  // console.log(glImportType, typeBizList, glCashBizDetail);

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      //onRequestClose={onClose}
      shouldCloseOnOverlayClick={false}
      overlayClassName="overlay"
      style={customStyles}
    >
      {isLoading && (
        <div className="loading">
          <img src={Spinner} alt="" />
        </div>
      )}
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{`Thông tin chi tiết`}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
          <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
            <FormAdd>
              <Form.Group style={{ gridColumn: '1/5' }}>
              <a
                className="fz-13 my-2"
                href={process.env.PUBLIC_URL + '/docs/ImportTemp.xlsx'}
                target="_blank"
              >
                Tải file mẫu
              </a>
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>Nghiệp vụ <span className="text-danger">*</span></Form.Label>
                  <Field
                    name="formBizCode"
                    className="form-control input-order"
                    opts={typeBizList}
                    component={RenderNormalSelect}
                    validate={[required]}
                    index="3"
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>Nghiệp vụ chi tiết <span className="text-danger">*</span></Form.Label>
                  <Field
                    name="formBizDetail"
                    className="form-control input-order"
                    opts={glCashBizDetail}
                    component={RenderNormalSelect}
                    validate={[required]}
                    index="3"
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>Ngày giao dịch</Form.Label>
                  <Field
                    name="formTradingDate"
                    className="form-control"
                    startDate={formatDate(new Date(), '/', 'dmy')}
                    component={RenderSelectDate}
                    validate={[required]}
                    //index="3"
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>Tài khoản tổng</Form.Label>
                  <Field
                    name="formBankAccount"
                    className="form-control input-order"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                   
                />
              </Form.Group>
              <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>
                    {t('txt-share-code')}
                    
                  </Form.Label>
                  <Field
                    name="formShareCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderSuggestShare}
                    
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-share-name')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={shareSingle?.C_SHARE_NAME || ''}
                    disabled
                  />
                </Form.Group>
             
                <hr style={{ gridColumn: '1/5' }} className="my-2" />

              <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>File import</Form.Label>
                  <Field
                    name="formFile"
                    className="fz-13"
                    type="file"
                    accept=".xls, .xlsm, .xlsx"
                    component={RenderFileInput}
                    validate={required}
                   
                />
              </Form.Group>
              <hr style={{ gridColumn: '1/5' }} className="my-1" />

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows="2"
                  />
                </Form.Group>

            </FormAdd>
            </PerfectScrollbar>
            <hr />
            <p style={{ gridColumn: '1/5' }} className="color-thm mb-0 fz-13">
              Dữ liệu import
            </p>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 380px)' }}>
              <table className="table table-bordered">
                <thead>
                  <tr>
                    {dataHeader && !!dataHeader.length && <th>STT</th>}
                    {dataHeader &&
                      dataHeader.map((item, index) => (
                        <th key={index}>{item}</th>
                      ))}
                  </tr>
                </thead>
                <tbody>
                  {dataShow &&
                    dataShow.map((item, index) => (
                      <tr key={index}>
                        <td className="text-center">{index + 1}</td>
                        {item.map((p, i) => (
                          <td
                            key={'child_' + i}
                            className="text-xs text-center"
                          >
                            {p}
                          </td>
                        ))}
                      </tr>
                    ))}
                </tbody>
              </table>
            </PerfectScrollbar>

            <div
              className="d-flex mt-2"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose
                type="button"
                onClick={onClose}
                className="w_60 mr-auto"
              >
                {t('txt-close')}
              </BtnClose>
              <BtnSubmit type="submit" disabled={submitting}>
                {t('txt-accept')}
              </BtnSubmit>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddImportDataModal = reduxForm({
  form: 'importDataform',
  enableReinitialize: true,
})(AddImportDataModal);

const selector = formValueSelector('importDataform');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getGLImportType = makeGetGLImportType();
  const getTypeBizList = makeGetTypeBizList();
  const getShareSingle = makeGetShareSingle();
  const getGlobalCashBusinessDetail = makeGetGlobalCashBusinessDetail();

  const {
    formImportType,
    formBizCode,
    formBizDetail,
    formTradingDate,
    formShareCode,
    formBankAccount,
    formFile,
    formContent,
  } = selector(
    state,
    'formImportType',
    'formBizCode',
    'formBizDetail',
    'formTradingDate',
    'formShareCode',
    'formBankAccount',
    'formFile',
    'formContent'
  );

  const token = getToken(state);

  return {
    token,
    glImportType: getGLImportType(state),
    typeBizList: getTypeBizList(state),
    glCashBizDetail: getGlobalCashBusinessDetail(state),
    shareSingle: getShareSingle(state),

    formImportType,
    formBizCode,
    formBizDetail,
    formTradingDate,
    formShareCode,
    formBankAccount,
    formFile,
    formContent,

    initialValues: {
      formBizCode: '',
      formBizDetail: '',
      formTradingDate: formatDate(new Date(), '/', 'dmy'),
      formShareCode: '',
      formBankAccount: '000',
      formFile: null,
      formContent: '',
    },
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddImportDataModal)
);
