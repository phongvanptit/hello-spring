import RenderArea from '../../../input/renderArea';
import RenderSelectDate from '../../../input/renderDatePicker';
import RenderInput from '../../../input/renderInput';
import RenderInputMask from '../../../input/renderInputMask';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import { setToast } from '../../../../containers/client/actions';
import {
  capTermContractSuccess,
  mmSingleFeeRateRequest, mmSingleFeeRateSuccess,
  mmUpdFeeRateRequest
} from '../../../../containers/product/actions';
import {
  makeGetAccountRight,
  makeGetActionFinra,
  makeGetCapTermContract,
  makeGetExtendTypeFinra,
  makeGetFeePayTypeFinra,
  makeGetListProductTypeFinra, makeGetListWebProductTypeFinra,
  makeGetMMSingleFeeRate,
  makeGetMMUpdFeeRate,
  makeGetSystemInfo,
  makeGetToken
} from '../../../../lib/selector';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import {
  StringToDouble,
  _diff2Date,
  replaceAll,
  stringToDate,
  StringToInt,
  StringToNumber,
  numberFormatDecimal
} from '../../../../utils';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import { required, validateNumberExact } from '../../../../utils/validation';
import {
  actionFinraRequesting,
  actionFinraSuccess,
  getFeePayTypeSuccess,
  getListExtendTypeSuccess, getListProductTypeSuccess, getListWebProductTypeRequesting
} from '../../../../containers/finra/actions';
import RenderListProductCode from '../../../input/floating/element/RenderListLiquidPolicyCode';
import { confirmAlert } from 'react-confirm-alert';
import RenderInputMaskMax from '../../../input/renderInputMaskMax';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_fee_rate_req',
    messageSuccess: 'txt_mm_create_fee_rate_success',
    cmd: 'MM.UPDATE_FEE_RATE'
  },
  update: {
    messageRequest: 'txt_mm_update_fee_rate_req',
    messageSuccess: 'txt_mm_update_fee_rate_success',
    cmd: 'MM.UPDATE_FEE_RATE'
  },
  approve: {
    messageRequest: 'txt_mm_approve_fee_rate_req',
    messageSuccess: 'txt_mm_approve_fee_rate_success',
    cmd: 'MM.APPROVE_FEE_RATE'
  },
  delete: {
    messageRequest: 'txt_mm_delete_fee_rate_req',
    messageSuccess: 'txt_mm_delete_fee_rate_success',
    cmd: 'MM.DELETE_FEE_RATE'
  }
}

const validate = (values) => {
  const errors = {};
  const { formCapMin, formCapMax, formFromDate, formToDate } = values;
  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

const validateLiquidMin = (value, value1) => {
  let errors = {};
  const { formCapMax, formLiquidMin } = value1;
  if (formCapMax && formLiquidMin && formCapMax != "-1" && StringToDouble(formCapMax) < StringToDouble(formLiquidMin)) {
    errors = `Không được lớn hơn giá trị tối đa`;
    return errors;
  }
};

function UpdateProduct(props) {
  const dispatch = useDispatch();
  const {
    token,
    t,
    handleSubmit, submitting, onClose
  } = props;
  const preActionFinra = usePrevious(props.actionFinra);

  const [initLoad, setInitLoad] = useState(true);

  useEffect(() => {
    getListProductWebType()
    if (!props.itemId) {
      setInitLoad(false)
      initForm();
    } else {
      getDetailFeeRate();
    }

    return () => {
      props.reset();

      dispatch(actionFinraSuccess(undefined))
      dispatch(mmSingleFeeRateSuccess(undefined))

      // actionFinra: makeGetActionFinra()(state),
      //   capTermContract: getCapTermContract(state),
      //   feePayType: makeGetFeePayTypeFinra()(state),
      //   listExtendType: makeGetExtendTypeFinra()(state),
      //   listProductType: makeGetListProductTypeFinra()(state),
      //   sysSystemInfo: makeGetSystemInfo()(state),
      //   singleFeeRate: makeGetMMSingleFeeRate()(state),
    };
  }, []);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      onClose()
    }
  }, [props.actionFinra]);

  useEffect(() => {
    if (!['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType)) {
      dispatch(change('addLoanProdModal', 'formDayNo', null))
    }
  }, [props.formPayType]);

  function initForm() {
    dispatch(change('addLoanProdModal', 'formStatus', true));
    dispatch(change('addLoanProdModal', 'formNote', 'Sản phẩm mặc định'));
    dispatch(change('addLoanProdModal', 'formTermCode', '30'));
    dispatch(change('addLoanProdModal', 'formPayType', 'DAY_OF_MONTH'));
    dispatch(change('addLoanProdModal', 'formLiquidType', '1'));
    dispatch(change('addLoanProdModal', 'formViewFlag', true));
    dispatch(change('addLoanProdModal', 'formListingDate', props.sysSystemInfo?.C_T_DATE));
    dispatch(change('addLoanProdModal', 'formExtendType', 'KHONG_GIA_HAN'));
  }

  function submit(_values) {
    if (props.itemId) {
      handleButtonAction('update');
    } else{
      handleButtonAction('create');
    }
  }

  const handleButtonAction = (action) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (['create', 'update'].includes(action)) {
                  handleAction(action)
                } else {
                  handleActionApprove(action)
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove(action) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: configNotification[action].cmd,
      group: 'LIST',
      data: {
        LIST_ITEM_ID: props.itemId,
        NEW_STATUS: 'DA_DUYET'
      },
    };

    props.onSetMessageContent(configNotification[action].messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  function handleAction(action) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: configNotification.create.cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
        TERM_CODE: props.formTermCode,
        PRODUCT_CODE: props?.formProdCode,
        PRODUCT_NAME: props?.formProdName,
        CAP_MIN: StringToNumber(props?.formCapMin),
        CAP_MAX: StringToNumber(props?.formCapMax),
        FEE_RATE: StringToNumber(props?.formFeeRate),
        LIQUID_RATE: StringToNumber(props?.formLiquidRate),
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,
        LIQUID_CODE: props.formFeeLiquidCode,
        LIQUID_MIN: StringToNumber(props.formLiquidMin),
        LIQUID_TYPE: props.formLiquidType,
        EXPIRE_DATE: props?.formExpireDate,
        CAP_TOTAL: StringToNumber(props?.formCapTotal),
        CAP_ADD_MIN: StringToNumber(props?.formCapAddMin),
        PAY_TYPE: props?.formPayType,
        DAY_NO: StringToNumber(props?.formDayNo),
        VIEW_FLAG: props.formViewFlag ? 1 : 0,
        LISTING_DATE: props?.formListingDate,
        ACTIVE: props?.formStatus ? 1 : 0,
        CONTENT: props?.formNote,
        EXTEND_TYPE: props?.formExtendType,
        URL_BANNER: props?.formUrlBanner,
        PRODUCT_TYPE: props?.formProductType,
        WEB_PRODUCT_TYPE: props?.formWebProductType,
      },
    };

    props.onSetMessageContent(configNotification[action].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  function getListProductWebType() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'MM_PRODUCT_WEB_TYPE.GET_ALL_SELECT',
      group: 'LIST',
      data: {
        TYPE_GET: props.itemId ? 'VIEW' : 'INSERT'
      },
    };

    dispatch(getListWebProductTypeRequesting(params));
  }

  function getDetailFeeRate() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'MM.GET_SINGLE_FEE_RATE',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
      },
    };
    dispatch(mmSingleFeeRateRequest(params));
  }

  useEffect(() => {
    if (props.singleFeeRate) {
      loadDataDetail()
    }
  }, [props.singleFeeRate]);
  
  useEffect(() => {
    if (props.formProductType == 'KKH_01') {
      dispatch(change('addLoanProdModal', 'formExtendType', 'KHONG_GIA_HAN'));
    }
  }, [props.formProductType]);
  
  function loadDataDetail() {
    dispatch(change('addLoanProdModal', 'formProdCode', props.singleFeeRate?.C_PRODUCT_CODE));
    dispatch(change('addLoanProdModal', 'formProdName', props.singleFeeRate?.C_PRODUCT_NAME));
    dispatch(change('addLoanProdModal', 'formLiquidRate', numberFormatDecimal(props.singleFeeRate?.C_LIQUID_RATE + '')));
    dispatch(change('addLoanProdModal', 'formNote', props.singleFeeRate?.C_CONTENT));
    dispatch(change('addLoanProdModal', 'formCapMin', numberFormatDecimal(props.singleFeeRate?.C_CAP_MIN + '')));
    dispatch(change('addLoanProdModal', 'formCapMax', numberFormatDecimal(props.singleFeeRate?.C_CAP_MAX + '')));
    dispatch(change('addLoanProdModal', 'formFeeRate', numberFormatDecimal(props.singleFeeRate?.C_FEE_RATE + '')));
    dispatch(change('addLoanProdModal', 'formFromDate', props.singleFeeRate?.C_FROM_DATE));
    dispatch(change('addLoanProdModal', 'formToDate', props.singleFeeRate?.C_TO_DATE));
    dispatch(change('addLoanProdModal', 'formStatus', props.singleFeeRate?.C_ACTIVE === 1));
    dispatch(change('addLoanProdModal', 'formFeeLiquidCode', props.singleFeeRate?.C_LIQUID_CODE));
    dispatch(change('addLoanProdModal', 'formCapTotal', numberFormatDecimal(props.singleFeeRate?.C_CAP_TOTAL)));
    dispatch(change('addLoanProdModal', 'formCapAddMin', numberFormatDecimal(props.singleFeeRate?.C_CAP_ADD_MIN)));
    dispatch(change('addLoanProdModal', 'formLiquidMin', numberFormatDecimal(props.singleFeeRate?.C_LIQUID_MIN)));
    dispatch(change('addLoanProdModal', 'formDayNo', props.singleFeeRate?.C_DAY_NO));
    dispatch(change('addLoanProdModal', 'formPayType', props.singleFeeRate?.C_PAY_TYPE));
    dispatch(change('addLoanProdModal', 'formExpireDate', props.singleFeeRate?.C_EXPIRE_DATE));
    dispatch(change('addLoanProdModal', 'formListingDate', props.singleFeeRate?.C_LISTING_DATE));
    dispatch(change('addLoanProdModal', 'formLiquidType', props.singleFeeRate?.C_LIQUID_TYPE));
    dispatch(change('addLoanProdModal', 'formViewFlag', props.singleFeeRate?.C_VIEW_FLAG === 1));
    dispatch(change('addLoanProdModal', 'formExtendType', props.singleFeeRate?.C_EXTEND_TYPE));
    dispatch(change('addLoanProdModal', 'formUrlBanner', props.singleFeeRate?.C_URL_BANNER));
    dispatch(change('addLoanProdModal', 'formProductType', props.singleFeeRate?.C_PRODUCT_TYPE));
    dispatch(change('addLoanProdModal', 'formWebProductType', props.singleFeeRate?.C_WEB_PRODUCT_TYPE));
    dispatch(change('addLoanProdModal', 'formTermCode', props.singleFeeRate?.C_TERM_CODE));

    setTimeout(() => {
      setInitLoad(false)
    }, 300)
  }

  useEffect(() => {
    if (initLoad) {
      return
    }

    if (!props.formStatus) {
      dispatch(change('addLoanProdModal', 'formViewFlag', false));
    }
  }, [props.formStatus]);

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t(props.itemId ? 'txt-detail-loan-product-info' : 'txt-add-new-loan-product-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>Loại sản phẩm</Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formProductType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={(() => {
                      if (!props.listProductType) {
                        return [];
                      }

                      return props.listProductType.map((e) => {
                        return {
                          label: `${e.value} - ${e.label}`,
                          value: e.value
                        };
                      });
                    })()}
                    validate={[required]}
                    disabled={props.itemId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Loại SP app/web</Form.Label>
                  {/*<span className="text-danger">*</span>*/}
                  <Field
                    name="formWebProductType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={(() => {
                      if (!props.listWebProductType) {
                        return [];
                      }

                      return props.listWebProductType.map((e) => {
                        return {
                          label: `${e.label}`,
                          value: e.value
                        };
                      });
                    })()}
                    // validate={[required]}
                    // disabled={props.itemId}
                  />
                </Form.Group>
                <Form.Group>
                <Form.Label>
                    {t('txt-prod-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProdCode"
                    className="form-control"
                    component={RenderInput}
                    validate={required}
                    disabled={props.itemId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-prod-name')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProdName"
                    className="form-control"
                    component={RenderInput}
                    validate={required}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-period')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formTermCode"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={(() => {
                      const a = props.capTermContract.map(e => {
                        return {
                          valueNumber: Number(e.value),
                          value: e.value,
                          label: e.label
                        }
                      }).sort((a, b) => {
                        return a.valueNumber - b.valueNumber
                      })
                      return a
                    })()}
                    validate={required}
                    required
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-min-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapMin"
                    className="form-control"
                    component={RenderInputMask}
                    validate={required}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-max-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapMax"
                    className="form-control"
                    component={RenderInputMaskMax}
                    validate={[required]}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Tổng sản phẩm
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapTotal"
                    className="form-control"
                    component={RenderInputMaskMax}
                    validate={required}
                    // disabled={props.itemId}
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>*/}
                {/*    Bổ sung tối thiểu*/}
                {/*    <span className="text-danger">*</span>*/}
                {/*  </Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formCapAddMin"*/}
                {/*    className="form-control"*/}
                {/*    component={RenderInputMask}*/}
                {/*    validate={required}*/}
                {/*    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group>
                  <Form.Label>
                    Lãi suất (%/năm)
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFeeRate"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal
                    validate={[required]}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Giá trị thanh lý tối thiểu</Form.Label>
                  <Field
                    name="formLiquidMin"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal={true}
                    decimalLimit={6}
                    validate={validateLiquidMin}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-liquid-type')}</Form.Label>
                  <Field
                    name="formLiquidType"
                    className="form-control w-100"
                    component="select"
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  >
                    <option value="1">Cho thanh lý trước hạn</option>
                    <option value="0">Không thanh lý trước hạn</option>
                  </Field>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Biểu lãi thanh lý</Form.Label>
                  <Field
                    name="formFeeLiquidCode"
                    className="form-control"
                    component={RenderListProductCode}
                    opts={props.listProductCode}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tỷ lệ phí thanh lý (%/năm)</Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formLiquidRate"
                    className="form-control"
                    component={RenderInputMask}
                    validate={required}
                    allowDecimal={true}
                    decimalLimit={6}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Hình thức trả lãi
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPayType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={props.feePayType}
                    validate={required}
                    required
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Ngày trả lãi
                    {['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType) && <span className="text-danger">*</span>}
                  </Form.Label>
                  <Field
                    name="formDayNo"
                    className="form-control"
                    component={RenderInputMask}
                    validate={['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType) ? required : undefined}
                    disabled={!['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType) || (props.itemId && props.singleFeeRate?.C_APPROVER_CODE)}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Gia hạn</Form.Label>
                  <Field
                    name="formExtendType"
                    className="form-control"
                    component="select"
                    // opts={props.listExtendType}
                    disabled={props?.formProductType == 'KKH_01' || (props.itemId && props.singleFeeRate?.C_APPROVER_CODE)}
                  >
                    <option value="CO_GIA_HAN">Có gia hạn</option>
                    <option value="KHONG_GIA_HAN">Không gia hạn</option>
                  </Field>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Ngày khai báo</Form.Label>
                  <Field
                    name="formListingDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    // disabled={props.itemId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFromDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    validate={required}
                    // disabled={props.itemId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-to-date')}</Form.Label>
                  <Field
                    name="formToDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    minDate={
                      props.formFromDate && !props.formFromDate.includes('_')
                        ? props.formFromDate
                        : null
                    }
                    // disabled={props.itemId}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Ngày hết hạn</Form.Label>
                  <Field
                    name="formExpireDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                <Form.Group className="d-flex align-items-end">
                  <label className="form-label">
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group>
                <Form.Group className="d-flex align-items-end">
                  <label className="form-label">
                    <Field
                      name="formViewFlag"
                      component="input"
                      type="checkbox"
                    />{' '}
                    View trên web/app
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label></Form.Label>
                  {props.formProductCode && (
                    <BtnClose type="button" className="mr-auto">
                      Xem
                    </BtnClose>
                  )}
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label>URL Banner</Form.Label>
                  <Field
                    name="formUrlBanner"
                    className="form-control"
                    component={RenderInput}
                    placeholder={'https://img.example.com/123.png'}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order"
                    component={RenderArea}
                    rows={2}
                    disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                  />
                </Form.Group>
                {/* Khai báo người các kiểu */}
                <Form.Label>
                  {t('txt-creator')} : {props.singleFeeRate?.C_CREATOR_CODE}
                </Form.Label>
                <Form.Label style={{ gridColumn: '2/4' }}>
                  {t('txt-create-time')} : {props.singleFeeRate?.C_CREATE_TIME}
                </Form.Label>
                <Form.Label>
                  {t('txt-approver')} : {props.singleFeeRate?.C_APPROVER_CODE}
                </Form.Label>
                <Form.Label style={{ gridColumn: '2/4' }}>
                  {t('txt-approve-time')} : {props.singleFeeRate?.C_APPROVE_TIME}
                </Form.Label>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {props.singleFeeRate?.C_STATUS === 'CHUA_DUYET' && (
                  <>
                    {props.accRight?.C_APPROVE === 1 && (
                      <BtnSubmit
                        type="button"
                        disabled={submitting}
                        className="success mr-2"
                        onClick={() => handleButtonAction('approve')}
                      >
                        {t('txt-appr')}
                      </BtnSubmit>
                    )}
                  </>
                )}
                {props.singleFeeRate?.TOTAL_APPENDIX === 0 && props.accRight?.C_UPDATE === 1 && (
                  <>
                    <BtnSubmit
                      type="button"
                      disabled={submitting}
                      className="danger mr-2"
                      onClick={() => handleButtonAction('delete')}
                    >
                      {t('txt-del')}
                    </BtnSubmit>
                  </>
                )}
                {props.accRight?.C_UPDATE === 1 && !(props.singleFeeRate?.C_STATUS === 'DA_DUYET' && props.singleFeeRate?.C_ACTIVE === 0) && (
                  <>
                    <BtnSubmit type="submit" disabled={submitting}>
                      {t('txt-accept')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

UpdateProduct = reduxForm({
  form: 'addLoanProdModal',
  enableReinitialize: true,
  validate,
})(UpdateProduct);

const selector = formValueSelector('addLoanProdModal');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCapTermContract = makeGetCapTermContract();

  const {
    formProdCode,
    formProdName,
    formStatus,
    formTermCode,
    formFeeRate,
    formLiquidRate,
    formCapMin,
    formCapMax,
    formFromDate,
    formToDate,
    formNote,
    formFeeLiquidCode,
    formCapTotal,
    formCapAddMin,
    formDayNo,
    formPayType,
    formListingDate,
    formLiquidMin,
    formLiquidType,
    formExpireDate,
    formViewFlag,
    formUrlBanner,
    formExtendType,
    formProductType,
    formWebProductType,
  } = selector(
    state,
    'formProdCode',
    'formProdName',
    'formStatus',
    'formTermCode',
    'formFeeRate',
    'formLiquidRate',
    'formCapMin',
    'formCapMax',
    'formFromDate',
    'formToDate',
    'formNote',
    'formFeeLiquidCode',
    'formCapTotal',
    'formCapAddMin',
    'formDayNo',
    'formPayType',
    'formListingDate',
    'formLiquidMin',
    'formLiquidType',
    'formExpireDate',
    'formViewFlag',
    'formUrlBanner',
    'formExtendType',
    'formProductType',
    'formWebProductType',
  );

  return {
    token: getToken(state),
    actionFinra: makeGetActionFinra()(state),
    accRight: makeGetAccountRight()(state),
    capTermContract: getCapTermContract(state),
    feePayType: makeGetFeePayTypeFinra()(state),
    listExtendType: makeGetExtendTypeFinra()(state),
    listProductType: makeGetListProductTypeFinra()(state),
    listWebProductType: makeGetListWebProductTypeFinra()(state),
    sysSystemInfo: makeGetSystemInfo()(state),
    singleFeeRate: makeGetMMSingleFeeRate()(state),

    formProdCode,
    formProdName,
    formStatus,
    formTermCode,
    formFeeRate,
    formLiquidRate,
    formCapMin,
    formCapMax,
    formFromDate,
    formToDate,
    formNote,
    formFeeLiquidCode,
    formCapTotal,
    formCapAddMin,
    formDayNo,
    formPayType,
    formListingDate,
    formLiquidMin,
    formLiquidType,
    formExpireDate,
    formViewFlag,
    formUrlBanner,
    formExtendType,
    formProductType,
    formWebProductType,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(UpdateProduct)
);
