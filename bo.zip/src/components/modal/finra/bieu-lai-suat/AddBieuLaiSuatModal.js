import RenderArea from '../../../input/renderArea';
import RenderSelectDate from '../../../input/renderDatePicker';
import RenderInput from '../../../input/renderInput';
import RenderInputMask from '../../../input/renderInputMask';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import { setToast } from '../../../../containers/client/actions';
import { mmUpdFeeRateRequest } from '../../../../containers/product/actions';
import {
  makeGetActionFinra,
  makeGetCapTermContract, makeGetExtendTypeFinra, makeGetFeePayTypeFinra, makeGetListProductTypeFinra,
  makeGetMMUpdFeeRate,
  makeGetSystemInfo,
  makeGetToken
} from '../../../../lib/selector';
import * as _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { StringToDouble, _diff2Date, replaceAll, stringToDate, StringToInt, StringToNumber } from '../../../../utils';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import { required, validateNumberExact } from '../../../../utils/validation';
import { actionFinraRequesting } from '../../../../containers/finra/actions';
import RenderListProductCode from '../../../input/floating/element/RenderListLiquidPolicyCode';
import { confirmAlert } from 'react-confirm-alert';
import RenderInputMaskMax from '../../../input/renderInputMaskMax';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 375px )',
    height: 'auto',
    width: '750px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_fee_rate_req',
    messageSuccess: 'txt_mm_create_fee_rate_success',
    cmd: 'MM.UPDATE_FEE_RATE'
  }
}

const validate = (values) => {
  const errors = {};
  const { formCapMin, formCapMax, formFromDate, formToDate } = values;
  if (formFromDate && formToDate && _diff2Date(formFromDate, formToDate) > 0) {
    errors.formToDate = `Ngày không hợp lệ`;
  }

  return errors;
};

const validateLiquidMin = (value, value1) => {
  let errors = {};
  const { formCapMax, formLiquidMin } = value1;
  if (formCapMax && formLiquidMin && formCapMax != "-1" && StringToDouble(formCapMax) < StringToDouble(formLiquidMin)) {
    errors = `Không được lớn hơn giá trị tối đa`;
    return errors;
  }
};

function AddBieuLaiSuatModal(props) {
  const dispatch = useDispatch();
  const {
    token,
    t,
    capTermContract,
    formTermCode,
    formFromDate,
  } = props;
  const [term, setTerm] = useState(false);
  const preActionFinra = usePrevious(props.actionFinra);
  const preFormTermCode = usePrevious(props.formTermCode);

  useEffect(() => {
    initForm();

    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      onClose()
    }
  }, [props.actionFinra]);

  useEffect(() => {
    if (formTermCode && !_.isEqual(formTermCode, preFormTermCode)) {
      if (formTermCode === '0') {
        setTerm(true);
      } else {
        setTerm(false);
        dispatch(change('addLoanProdModal', 'formOtherTerm', ''));
      }
    }
  }, [formTermCode]);

  useEffect(() => {
    if (!['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType)) {
      dispatch(change('addLoanProdModal', 'formDayNo', null))
    }
  }, [props.formPayType]);

  function initForm() {
    dispatch(change('addLoanProdModal', 'formStatus', true));
    dispatch(change('addLoanProdModal', 'formNote', 'Sản phẩm mặc định'));
    dispatch(change('addLoanProdModal', 'formTermCode', '30'));
    dispatch(change('addLoanProdModal', 'formPayType', 'DAY_OF_MONTH'));
    dispatch(change('addLoanProdModal', 'formLiquidType', '1'));
    dispatch(change('addLoanProdModal', 'formViewFlag', true));
    dispatch(change('addLoanProdModal', 'formListingDate', props.sysSystemInfo?.C_T_DATE));
  }

  function submit(_values) {
    handleButtonAction('create');
  }

  const handleButtonAction = (action) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (['create', 'update'].includes(action)) {
                  handleActionApprove()
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionApprove() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: configNotification.create.cmd,
      group: 'LIST',
      data: {
        ITEM_ID: '',
        TERM_CODE: props?.formOtherTerm
          ? props?.formOtherTerm + ''
          : props.formTermCode,
        PRODUCT_CODE: props?.formProdCode,
        PRODUCT_NAME: props?.formProdName,
        CAP_MIN: StringToNumber(props?.formCapMin),
        CAP_MAX: StringToNumber(props?.formCapMax),
        FEE_RATE: StringToNumber(props?.formFeeRate),
        LIQUID_RATE: StringToNumber(props?.formLiquidRate),
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,
        LIQUID_CODE: props.formFeeLiquidCode,
        LIQUID_MIN: StringToNumber(props.formLiquidMin),
        LIQUID_TYPE: props.formLiquidType,
        EXPIRE_DATE: props?.formExpireDate,
        CAP_TOTAL: StringToNumber(props?.formCapTotal),
        CAP_ADD_MIN: StringToNumber(props?.formCapAddMin),
        PAY_TYPE: props?.formPayType,
        DAY_NO: StringToNumber(props?.formDayNo),
        VIEW_FLAG: props.formViewFlag ? 1 : 0,
        LISTING_DATE: props?.formListingDate,
        STATUS: props?.formStatus ? 1 : 0,
        CONTENT: props?.formNote,
        EXTEND_TYPE: props?.formExtendType,
        URL_BANNER: props?.formUrlBanner,
        PRODUCT_TYPE: props?.formProductType,
      },
    };

    props.onSetMessageContent(configNotification.create.messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  const { handleSubmit, submitting, onClose } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-new-loan-product-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group style={{ gridColumn: '1/3' }}>
                  <Form.Label>Loại sản phẩm</Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formProductType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={(() => {
                      if (!props.listProductType) {
                        return [];
                      }

                      return props.listProductType.map((e) => {
                        return {
                          label: `${e.value} - ${e.label}`,
                          value: e.value
                        };
                      });
                    })()}
                    validate={[required]}
                  />
                </Form.Group>
                <div></div>
                <Form.Group>
                <Form.Label>
                    {t('txt-prod-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProdCode"
                    className="form-control"
                    component={RenderInput}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-prod-name')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProdName"
                    className="form-control"
                    component={RenderInput}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-period')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formTermCode"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={(() => {
                      const a = capTermContract.map(e => {
                        return {
                          valueNumber: Number(e.value),
                          value: e.value,
                          label: e.label
                        }
                      }).sort((a, b) => {
                        return a.valueNumber - b.valueNumber
                      })
                      return a
                    })()}
                    validate={required}
                    required
                  />
                </Form.Group>
                {term && (
                  <Form.Group>
                    <Form.Label>
                      {t('txt-other-term')}{' '}
                      <span className="text-danger">*</span>
                    </Form.Label>
                    <Field
                      name="formOtherTerm"
                      className="form-control"
                      component={RenderInputMask}
                      validate={required}
                    />
                  </Form.Group>
                )}
                <Form.Group>
                  <Form.Label>
                    {t('txt-min-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapMin"
                    className="form-control"
                    component={RenderInputMask}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-max-value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapMax"
                    className="form-control"
                    component={RenderInputMaskMax}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Tổng sản phẩm
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapTotal"
                    className="form-control"
                    component={RenderInputMaskMax}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Bổ sung tối thiểu
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapAddMin"
                    className="form-control"
                    component={RenderInputMask}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Lãi suất (%/năm)
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFeeRate"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-liquid-type')}</Form.Label>
                  <Field
                    name="formLiquidType"
                    className="form-control w-100"
                    component="select"
                  >
                    <option value="1">Cho thanh lý trước hạn</option>
                    <option value="0">Không thanh lý trước hạn</option>
                  </Field>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Biểu lãi thanh lý</Form.Label>
                  <Field
                    name="formFeeLiquidCode"
                    className="form-control"
                    component={RenderListProductCode}
                    opts={props.listProductCode}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tỷ lệ phí thanh lý (%/năm)</Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formLiquidRate"
                    className="form-control"
                    component={RenderInputMask}
                    validate={required}
                    allowDecimal={true}
                    decimalLimit={6}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Giá trị thanh lý tối thiểu</Form.Label>
                  <Field
                    name="formLiquidMin"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal={true}
                    decimalLimit={6}
                    validate={validateLiquidMin}  
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Hình thức trả lãi
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPayType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={props.feePayType}
                    validate={required}
                    required
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Ngày trả lãi
                    {['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType) && <span className="text-danger">*</span>}
                  </Form.Label>
                  <Field
                    name="formDayNo"
                    className="form-control"
                    component={RenderInputMask}
                    validate={['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType) ? required : undefined}
                    disabled={!['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType)}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Phương thức gia hạn</Form.Label>
                  <Field
                    name="formExtendType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={props.listExtendType}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Ngày khai báo</Form.Label>
                  <Field
                    name="formListingDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-from-date')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formFromDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-to-date')}</Form.Label>
                  <Field
                    name="formToDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    minDate={
                      formFromDate && !formFromDate.includes('_')
                        ? formFromDate
                        : null
                    }
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Ngày hết hạn</Form.Label>
                  <Field
                    name="formExpireDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                  />
                </Form.Group>
                <div></div>
                <div></div>
                <Form.Group className="d-flex align-items-end">
                  <label className="form-label">
                    <Field
                      name="formStatus"
                      component="input"
                      type="checkbox"
                    />{' '}
                    {t('txt-active')}
                  </label>
                </Form.Group>
                <Form.Group className="d-flex align-items-end">
                  <label className="form-label">
                    <Field
                      name="formViewFlag"
                      component="input"
                      type="checkbox"
                    />{' '}
                    View trên web/app
                  </label>
                </Form.Group>
                <Form.Group>
                  <Form.Label></Form.Label>
                  {props.formProductCode && (
                    <BtnClose type="button" className="mr-auto">
                      Xem
                    </BtnClose>
                  )}
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label>URL Banner</Form.Label>
                  <Field
                    name="formUrlBanner"
                    className="form-control"
                    component={RenderInput}
                    placeholder={'https://img.example.com/123.png'}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/4' }}>
                  <Form.Label>{t('txt-note')}</Form.Label>
                  <Field
                    name="formNote"
                    className="form-control input-order"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/4' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddBieuLaiSuatModal = reduxForm({
  form: 'addLoanProdModal',
  enableReinitialize: true,
  validate,
})(AddBieuLaiSuatModal);

const selector = formValueSelector('addLoanProdModal');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCapTermContract = makeGetCapTermContract();

  const {
    formProdCode,
    formProdName,
    formStatus,
    formTermCode,
    formFeeRate,
    formLiquidRate,
    formCapMin,
    formCapMax,
    formFromDate,
    formToDate,
    formNote,
    formOtherTerm,
    formFeeLiquidCode,
    formCapTotal,
    formCapAddMin,
    formDayNo,
    formPayType,
    formListingDate,
    formLiquidMin,
    formLiquidType,
    formExpireDate,
    formViewFlag,
    formUrlBanner,
    formExtendType,
    formProductType,
  } = selector(
    state,
    'formProdCode',
    'formProdName',
    'formStatus',
    'formTermCode',
    'formFeeRate',
    'formLiquidRate',
    'formCapMin',
    'formCapMax',
    'formFromDate',
    'formToDate',
    'formNote',
    'formOtherTerm',
    'formFeeLiquidCode',
    'formCapTotal',
    'formCapAddMin',
    'formDayNo',
    'formPayType',
    'formListingDate',
    'formLiquidMin',
    'formLiquidType',
    'formExpireDate',
    'formViewFlag',
    'formUrlBanner',
    'formExtendType',
    'formProductType',
  );

  return {
    token: getToken(state),
    actionFinra: makeGetActionFinra()(state),
    capTermContract: getCapTermContract(state),
    feePayType: makeGetFeePayTypeFinra()(state),
    listExtendType: makeGetExtendTypeFinra()(state),
    listProductType: makeGetListProductTypeFinra()(state),
    sysSystemInfo: makeGetSystemInfo()(state),

    formProdCode,
    formProdName,
    formStatus,
    formTermCode,
    formFeeRate,
    formLiquidRate,
    formCapMin,
    formCapMax,
    formFromDate,
    formToDate,
    formNote,
    formOtherTerm,
    formFeeLiquidCode,
    formCapTotal,
    formCapAddMin,
    formDayNo,
    formPayType,
    formListingDate,
    formLiquidMin,
    formLiquidType,
    formExpireDate,
    formViewFlag,
    formUrlBanner,
    formExtendType,
    formProductType,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddBieuLaiSuatModal)
);
