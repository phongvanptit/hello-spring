import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import renderNewInput from 'components/input/renderNewInput';
import renderNewInputMkt from 'components/input/renderNewInputMkt';
import renderNewInputPartner from 'components/input/renderNewInputPartner';
import * as _ from 'lodash';
import {
  makeGetAccountRight,
  makeGetActionFinra,
  makeGetCapLenderType,
  makeGetCapTermContract,
  makeGetContractCodeFinra,
  makeGetCustomerDetail,
  makeGetDetailAppendixFinra,
  makeGetDetailAppendixLiquidFinra,
  makeGetDetailFeeRateFinra,
  makeGetFeeTaxLiquidFinra,
  makeGetMainDetailFinra,
  makeGetMainListFinra,
  makeGetMmContactBaseCode,
  makeGetMmGetExpireDate,
  makeGetMMSinglePartner,
  makeGetRightFeeBase,
  makeGetSingleUserFront,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { _diff2Date, formatDate, numberFormatDecimal, stringToDate, StringToDouble, StringToNumber } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required, validateNumberExact } from 'utils/validation';
import {
  actionFinraRequesting,
  actionFinraSuccess,
  getContractCodeRequesting,
  getContractCodeSuccess,
  getDetailAppendixLiquidRequesting,
  getDetailAppendixLiquidSuccess,
  getDetailAppendixRequesting,
  getDetailAppendixSuccess,
  getDetailFeeRateRequesting,
  getFeeTaxLiquidRequesting,
  getFeeTaxLiquidSuccess,
  mainItemFinraRequesting,
  mainItemFinraSuccess,
  mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { cashBalanceRequest, cashBalanceSuccess } from '../../../../containers/cash/actions';
import { custDetailRequest, custDetailSuccess } from '../../../../containers/customer/actions';
import { singleUserFrontRequest, singleUserFrontSuccess } from '../../../../containers/account/actions';
import { confirmAlert } from 'react-confirm-alert';
import {
  mmContactBaseCodeRequest, mmContactBaseCodeSuccess, mmGetExpireDateRequest, mmGetExpireDateSuccess,
  mmSinglePartnerRequest,
  mmSinglePartnerSuccess
} from '../../../../containers/product/actions';
import RenderNewInput from '../../../input/renderNewInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import RenderInputMask from '../../../input/renderInputMask';
import RenderListProductCode from '../../../input/floating/element/RenderListLiquidPolicyCode';
import Decimal from 'decimal.js';
import UpdateLiquidPolicy from '../liquiq-policy/UpdateLiquidPolicy';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 550px )',
    height: 'auto',
    width: '1100px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
        font-size: 13px;
    }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formOpenDate, formExpireDate } = values;

  if (
    formOpenDate &&
    formExpireDate &&
    _diff2Date(formOpenDate, formExpireDate) > 0
  ) {
    errors.formExpireDate = `Ngày không hợp lệ`;
  }

  return errors;
};

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_appendix_liquid_req',
    messageSuccess: 'txt_mm_create_appendix_liquid_success',
    cmd: 'MM_APPENDIX_LIQUID.UPDATE_ITEM'
  },
  update: {
    messageRequest: 'txt_mm_update_appendix_liquid_req',
    messageSuccess: 'txt_mm_update_appendix_liquid_success',
    cmd: 'MM_APPENDIX_LIQUID.UPDATE_ITEM'
  },
  delete: {
    messageRequest: 'txt_mm_delete_appendix_liquid_req',
    messageSuccess: 'txt_mm_delete_appendix_liquid_success',
    cmd: 'MM_APPENDIX_LIQUID.DELETE_ITEM'
  },
  approve: {
    messageRequest: 'txt_mm_approve_appendix_liquid_req',
    messageSuccess: 'txt_mm_approve_appendix_liquid_success',
    cmd: 'MM_APPENDIX_LIQUID.APPROVE_ITEM'
  },
  un_approve: {
    messageRequest: 'txt_mm_unapprove_appendix_liquid_req',
    messageSuccess: 'txt_mm_unapprove_appendix_liquid_success',
    cmd: 'MM_APPENDIX_LIQUID.UN_APPROVE_ITEM'
  }
}

function UpdateAppendixLiquid(props) {
  const { handleSubmit, submitting, onClose, t } = props;

  const [isInitLoad, setIsInitLoad] = useState(!!props.itemId);
  const [isShowProductDetail, setIsShowProductDetail] = useState(undefined);

  const dispatch = useDispatch();

  const preActionFinra = usePrevious(props.actionFinra)

  useEffect(() => {
    initForm();
    if (props.itemId) {
      getDetailAppendixLiquid()
    } else {
      getDetailAppendix()
    }


    return () => {
      dispatch(getDetailAppendixSuccess(undefined))
      dispatch(getDetailAppendixLiquidSuccess(undefined))
      dispatch(mmContactBaseCodeSuccess(undefined))
      dispatch(mmGetExpireDateSuccess(undefined))
      dispatch(actionFinraSuccess(undefined))
      dispatch(getFeeTaxLiquidSuccess(undefined))

      props.reset();
    };
  }, []);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      props.onClose()
    }
  }, [props.actionFinra])

  useEffect(() => {
    if (props.formCustCode) {
      getAppendixCode()
    } else {
      dispatch(mmContactBaseCodeSuccess(undefined))

    }
  }, [props.formCustCode]);

  useEffect(() => {
    if (props.formTerm && props.formOpenDate) {
      getExpireDate()
    }
  }, [props.formTerm, props.formOpenDate]);

  useEffect(() => {
    if (props.detailAppendix) {
      dispatch(change('UpdateAppendixLiquid', 'formCustCode', props.detailAppendix.C_CUSTOMER_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formAppendixNumber', props.detailAppendix.C_APPENDIX_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formProductCode', props.detailAppendix.C_PRODUCT_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formOpenDate', props.detailAppendix.C_OPEN_DATE));
      dispatch(change('UpdateAppendixLiquid', 'formTerm', props.detailAppendix.C_TERM));
      dispatch(change('UpdateAppendixLiquid', 'formLenderType', ''));
      dispatch(change('UpdateAppendixLiquid', 'formCapital', props.detailAppendix.C_CAPITAL));
      dispatch(change('UpdateAppendixLiquid', 'formCapitalLeft', props.detailAppendix.C_CAPITAL_LEFT));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidTaxRate', props.detailAppendix.C_TAX));
      dispatch(change('UpdateAppendixLiquid', 'formFeeBase', props.detailAppendix.C_FEE_BASE));
      dispatch(change('UpdateAppendixLiquid', 'formExpireDate', props.detailAppendix.C_EXPIRE_DATE));
      dispatch(change('UpdateAppendixLiquid', 'formNumberDay', numberFormatDecimal(props.detailAppendix.C_NUMBER_DAY)));
      dispatch(change('UpdateAppendixLiquid', 'formDayDiff', numberFormatDecimal(props.detailAppendix.C_DAY_DIFF)));

      // if (!props.itemId) {
      //   dispatch(change('UpdateAppendixLiquid', 'formDayDiff', props.detailAppendix.C_DAY_DIFF));
      //   dispatch(change('UpdateAppendixLiquid', 'formLiquidFeeRate', props.detailAppendix.C_RATE));
      // }
    }
  }, [props.detailAppendix]);

  const getAppendixCode = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX.SINGLE_CONTRACT_BASE',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: props.formCustCode,
      },
    };
    dispatch(mmContactBaseCodeRequest(params));
  }

  const getExpireDate = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX.GET_EXPIRE_DATE',
      group: 'LIST',
      data: {
        OPEN_DATE: props.formOpenDate,
        TERM: props.formTerm,
      },
    };

    dispatch(mmGetExpireDateRequest(params));
  }

  const initForm = () => {
    // dispatch(change('UpdateAppendixLiquid', 'formLiquidCapital', '0'));
    dispatch(change('UpdateAppendixLiquid', 'formLiquidTax', '0'));
    dispatch(change('UpdateAppendixLiquid', 'formLiquidFee', '0'));
    dispatch(change('UpdateAppendixLiquid', 'formLiquidRate', null));
    dispatch(change('UpdateAppendixLiquid', 'formLiquidDate', formatDate(stringToDate(props.sysSystemInfo?.C_T_DATE, 'dmy'), '/', 'dmy')));
  }

  useEffect(() => {
    if (isInitLoad) {
      return
    }

    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX_LIQUID.CALC_FEE_LIQUID',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemAppendixId,
        LIQUID_VALUE: StringToNumber(props.formLiquidCapital),
        "LIQUID_RATE": StringToDouble(props.formLiquidRate),
        "FEE_FLEX_FLAG": props.formFeeFlexFlag ? 1 : 0
      },
    };

    dispatch(getFeeTaxLiquidRequesting(params));
  }, [props.formLiquidCapital, props.formLiquidRate]);

  useEffect(() => {
    if (isInitLoad) {
      return
    }
    if (props.feeTaxLiquid) {

      console.log(props.feeTaxLiquid, isInitLoad);

      dispatch(change('UpdateAppendixLiquid', 'formLiquidFee', numberFormatDecimal(props.feeTaxLiquid.INTEREST)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidTaxRate', numberFormatDecimal(props.feeTaxLiquid.TAX_RATE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidTax', numberFormatDecimal(props.feeTaxLiquid.TAX)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidPenalty', numberFormatDecimal(props.feeTaxLiquid.PENALTY)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidRawValue', numberFormatDecimal(props.feeTaxLiquid.RAW_VALUE)));
    }
  }, [props.feeTaxLiquid, isInitLoad]);

  useEffect(() => {
    if (props.detailAppendixLiquid) {
      dispatch(change('UpdateAppendixLiquid', 'formLiquidFee', numberFormatDecimal(props.detailAppendixLiquid.C_FEE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidTax', numberFormatDecimal(props.detailAppendixLiquid.C_TAX_VALUE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidCapital', numberFormatDecimal(props.detailAppendixLiquid.C_CAPITAL)));
      dispatch(change('UpdateAppendixLiquid', 'formNumberDay', numberFormatDecimal(props.detailAppendixLiquid.C_NUMBER_DAY)));
      dispatch(change('UpdateAppendixLiquid', 'formDayDiff', numberFormatDecimal(props.detailAppendixLiquid.C_DAY_DIFF)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidFeeRate', numberFormatDecimal(props.detailAppendixLiquid.C_RATE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidDate', props.detailAppendixLiquid.C_LIQUID_DATE));

      dispatch(change('UpdateAppendixLiquid', 'formLiquidTaxRate', numberFormatDecimal(props.detailAppendixLiquid.C_TAX_RATE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidPenalty', numberFormatDecimal(props.detailAppendixLiquid.C_PENALTY_VALUE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidRawValue', numberFormatDecimal(props.detailAppendixLiquid.RAW_VALUE)));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidRate', numberFormatDecimal(props.detailAppendixLiquid.C_LIQUID_RATE)));

      dispatch(change('UpdateAppendixLiquid', 'formCustCode', props.detailAppendixLiquid.C_CUSTOMER_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formAppendixNumber', props.detailAppendixLiquid.C_APPENDIX_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formProductCode', props.detailAppendixLiquid.C_PRODUCT_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formOpenDate', props.detailAppendixLiquid.C_OPEN_DATE));
      dispatch(change('UpdateAppendixLiquid', 'formTerm', props.detailAppendixLiquid.C_TERM));
      dispatch(change('UpdateAppendixLiquid', 'formLenderType', ''));
      dispatch(change('UpdateAppendixLiquid', 'formCapital', props.detailAppendixLiquid.C_CAPITAL_APPENDIX));
      dispatch(change('UpdateAppendixLiquid', 'formCapitalLeft', props.detailAppendixLiquid.C_CAPITAL_LEFT));
      dispatch(change('UpdateAppendixLiquid', 'formFeeBase', props.detailAppendixLiquid.C_FEE_BASE));
      dispatch(change('UpdateAppendixLiquid', 'formLiquidFeeRate', props.detailAppendixLiquid.C_RATE));
      dispatch(change('UpdateAppendixLiquid', 'formExpireDate', props.detailAppendixLiquid.C_EXPIRE_DATE));
      dispatch(change('UpdateAppendixLiquid', 'formFeeFlexFlag', props.detailAppendixLiquid.C_FEE_FLEX_FLAG)); 

      setTimeout(() => {
        setIsInitLoad(false)
      }, 250)

    }
  }, [props.detailAppendixLiquid]);

  const getDetailAppendix = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX.GET_ITEM',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemAppendixId
      },
    };
    dispatch(getDetailAppendixRequesting(params));
  }

  const getDetailAppendixLiquid = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX_LIQUID.GET_ITEM',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId
      },
    };
    dispatch(getDetailAppendixLiquidRequesting(params));
  }

  const handleButtonAction = (action) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (['create', 'update'].includes(action)) {
                  UpdateAppendixLiquid(action)
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  const submit = () => {
    handleButtonAction(props.itemId ? 'update' : 'create')
  }

  const UpdateAppendixLiquid = (type) => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification[type].cmd,
      group: 'LIST',
      data: {
        "ITEM_ID": props.itemId,
        "APPENDIX_ID": props.itemAppendixId,
        "LIQUID_TYPE": "MANUAL",
        "LIQUID_RATE": StringToDouble(props.formLiquidRate),
        "CAPITAL": StringToDouble(props.formLiquidCapital),
        "CONTENT": props.formContent,
        "FEE_FLEX_FLAG": props.formFeeFlexFlag ? 1 : 0,
      },
    };
    props.onSetMessageContent(configNotification[type].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  useEffect(() => {
    if (props.detailFeeRate) {
      dispatch(change('UpdateAppendixLiquid', 'formTerm', props.detailFeeRate.C_TERM_CODE));
      dispatch(change('UpdateAppendixLiquid', 'formProductName', props.detailFeeRate.C_PRODUCT_NAME));
      dispatch(change('UpdateAppendixLiquid', 'formProductRate', props.detailFeeRate.C_FEE_RATE));
      // default lấy ls của sp, chỉ có ở bước tạo
      if(!props.itemId)
        dispatch(change('UpdateAppendixLiquid', 'formLiquidRate', props.detailFeeRate?.C_LIQUID_RATE));
    } else {
      dispatch(change('UpdateAppendixLiquid', 'formTerm', '30'));
      dispatch(change('UpdateAppendixLiquid', 'formProductName', ''));
      dispatch(change('UpdateAppendixLiquid', 'formProductRate', ''));
    }
  }, [props.detailFeeRate]);

  useEffect(() => {
    if (props.formProductCode) {
      getDetailFeeRate();
    }
  }, [props.formProductCode]);

  const getDetailFeeRate = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_SINGLE_FEE_RATE',
      group: 'LIST',
      data: {
        ITEM_ID: props.formProductCode,
      },
    };
    dispatch(getDetailFeeRateRequesting(params));
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)', overflow: 'hidden' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t(props.itemId ? 'txt_finra_modal_update_liquid' : 'txt_finra_modal_create_liquid')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 260px)' }}>
              <FormAdd>
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-framework-contarct-info')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-code')}
                  </Form.Label>
                  <Field
                    name="formCustCode"
                    className="form-control"
                    component={RenderInput}
                    disabled
                    index={2}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <input
                    value={props.appendixCodeInfo?.C_CUSTOMER_NAME || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <input
                    value={props.appendixCodeInfo?.C_MARKETING_ID || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-marketing-name')}</Form.Label>
                  <input
                    value={props.appendixCodeInfo?.C_MARKETING_NAME || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-framework-contarct-number')}</Form.Label>*/}
                {/*  <input*/}
                {/*    value={props.appendixCodeInfo?.C_CONTRACT_CODE || ''}*/}
                {/*    type={'text'}*/}
                {/*    className="form-control"*/}
                {/*    disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-open-date-contract')}</Form.Label>*/}
                {/*  <input*/}
                {/*    value={props.appendixCodeInfo?.C_OPEN_DATE || ''}*/}
                {/*    type={'text'}*/}
                {/*    className="form-control"*/}
                {/*    disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  Thông tin sản phẩm
                </p>
                <Form.Group>
                  <Form.Label>Mã sản phẩm</Form.Label>
                  <Field
                    name="formProductCode"
                    className="form-control"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Tên sản phẩm</Form.Label>
                  <Field
                    name="formProductName"
                    className="form-control"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Lãi suất (%/năm)</Form.Label>
                  <Field
                    name="formProductRate"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal={true}
                    decimalLimit={6}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Biểu lãi thanh lý</Form.Label>
                  <Field
                    name="formLiquidPolicy"
                    className="form-control"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label></Form.Label>*/}
                {/*  {props.detailFeeRate?.C_LIQUID_CODE && (*/}
                {/*    <BtnClose type="button" className="mr-auto" onClick={() => setIsShowProductDetail(props.detailFeeRate?.C_LIQUID_CODE)}>*/}
                {/*      Xem*/}
                {/*    </BtnClose>*/}
                {/*  )}*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-appendix-business-info')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-loan-appendix-number')}{' '}
                  </Form.Label>
                  <Field
                    name="formAppendixNumber"
                    className="form-control"
                    component={RenderInput}
                    disabled
                    placeholder={props.appendixCodeInfo?.C_CONTRACT_CODE ? `__/${props.appendixCodeInfo?.C_CONTRACT_CODE}` : ''}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-period')}
                  </Form.Label>
                  <Field
                    name="formTerm"
                    className="form-control"
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={props.capTermContract}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-sign-day')}
                  </Form.Label>
                  <Field
                    name="formOpenDate"
                    className="form-control input-order fz-13"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <Field
                    name="formExpireDate"
                    className="form-control input-order fz-13"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-number-day')}</Form.Label>
                  <Field
                    name="formNumberDay"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Số ngày thực tế</Form.Label>
                  <Field
                    name="formDayDiff"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-loan-value')}
                  </Form.Label>
                  <Field
                    name="formCapital"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                {(props.detailAppendixLiquid?.C_STATUS === 'CHUA_DUYET' || props.itemId === null || props.itemId === undefined) && <Form.Group>
                  <Form.Label>
                    Số tiền còn lại
                  </Form.Label>
                  <Field
                    name="formCapitalLeft"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>}
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  Thông tin thanh lý
                </p>
                <Form.Group>
                  <Form.Label>
                    Giá trị thanh lý
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formLiquidCapital"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[validateNumberExact]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    LS thanh lý
                    {/*<span className="text-danger">*</span>*/}
                  </Form.Label>
                  <Field
                    name="formLiquidRate"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal={true}
                    decimalLimit={6}
                    disabled={!props.formFeeFlexFlag}
                  // validate={[validateNumberExact]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Ngày thanh lý
                  </Form.Label>
                  <Field
                    name="formLiquidDate"
                    className="form-control input-order fz-13"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                <Form.Group className="pt-4">
                  <label className="form-label">
                    <Field
                      name="formFeeFlexFlag"
                      component="input"
                      type="checkbox"
                    />{' '}
                    LS linh hoạt
                  </label>
                </Form.Group>
                <div></div>
                <Form.Group>
                  <Form.Label>
                    Lãi nhận
                  </Form.Label>
                  <Field
                    name="formLiquidFee"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Tỷ lệ thuế (%)
                  </Form.Label>
                  <Field
                    name="formLiquidTaxRate"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal={true}
                    decimalLimit={6}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Thuế
                  </Form.Label>
                  <Field
                    name="formLiquidTax"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Tiền phạt
                  </Form.Label>
                  <Field
                    name="formLiquidPenalty"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>
                    Thực nhận
                  </Form.Label>
                  <Field
                    name="formLiquidRawValue"
                    className="form-control"
                    component={RenderInputMask}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/6' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                {/* Khai báo người các kiểu */}
                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label className='mr-5'>
                    {t('txt-creator')} : {props.itemId ? props.detailAppendixLiquid?.C_CREATOR_CODE : ''}
                  </Form.Label>
                  <Form.Label className='mr-5'>
                    {t('txt-create-time')} : {props.itemId ? props.detailAppendixLiquid?.C_CREATE_TIME : ''}
                  </Form.Label>
                  <Form.Label className='mr-5'>
                    {t('txt-approver')} : {props.itemId ? props.detailAppendixLiquid?.C_APPROVER_CODE : ''}
                  </Form.Label>
                  <Form.Label>
                    {t('txt-approve-time')} : {props.itemId ? props.detailAppendixLiquid?.C_APPROVE_TIME : ''}
                  </Form.Label>
                </Form.Group>

              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/6' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              {props.accRight?.C_UPDATE === 1 && <div className="d-flex">
                {(!props.detailAppendixLiquid || (props.detailAppendixLiquid && props.detailAppendixLiquid.C_STATUS === 'CHUA_DUYET')) && (
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-accept')}
                  </BtnSubmit>)
                }
              </div>}
            </div>
          </form>
        </StyleContainer>
        {isShowProductDetail && (
          <UpdateLiquidPolicy
            itemId={props.formProductCode}
            onClose={() => { setIsShowProductDetail(false) }}
          />
        )}
      </div>
    </ReactModal>
  );
}

UpdateAppendixLiquid = reduxForm({
  form: 'UpdateAppendixLiquid',
  enableReinitialize: true,
  validate
})(UpdateAppendixLiquid);

const selector = formValueSelector('UpdateAppendixLiquid');

const mapStateToProps = (state) => {
  const {
    formCustCode,
    formAppendixNumber,
    formProductCode,
    formOpenDate,
    formTerm,
    formLenderType,
    formCapital,
    formFeeBase,
    formContent,
    formLiquidCapital,
    formLiquidFeeRate,
    formLiquidTaxRate,
    formLiquidFee,
    formLiquidTax,
    formLiquidPolicy,
    formLiquidDate,
    formLiquidPenalty,
    formLiquidRawValue,
    formExpireDate,
    formDayDiff,
    formLiquidRate,
    formFeeFlexFlag,
  } = selector(
    state,
    'formCustCode',
    'formAppendixNumber',
    'formProductCode',
    'formOpenDate',
    'formTerm',
    'formLenderType',
    'formCapital',
    'formFeeBase',
    'formContent',
    'formLiquidCapital',
    'formLiquidFeeRate',
    'formLiquidTaxRate',
    'formLiquidFee',
    'formLiquidTax',
    'formLiquidPolicy',
    'formLiquidDate',
    'formLiquidPenalty',
    'formLiquidRawValue',
    'formExpireDate',
    'formDayDiff',
    'formLiquidRate',
    'formFeeFlexFlag',
  );

  return {
    token: makeGetToken()(state),
    accRight: makeGetAccountRight()(state),
    sysSystemInfo: makeGetSystemInfo()(state),
    appendixCodeInfo: makeGetMmContactBaseCode()(state),
    capLenderType: makeGetCapLenderType()(state),
    capTermContract: makeGetCapTermContract()(state),
    mmGetExpireDate: makeGetMmGetExpireDate()(state),
    capFeeBase: makeGetRightFeeBase()(state),
    actionFinra: makeGetActionFinra()(state),
    detailAppendix: makeGetDetailAppendixFinra()(state),
    feeTaxLiquid: makeGetFeeTaxLiquidFinra()(state),
    detailAppendixLiquid: makeGetDetailAppendixLiquidFinra()(state),
    detailFeeRate: makeGetDetailFeeRateFinra()(state),

    formCustCode,
    formAppendixNumber,
    formProductCode,
    formOpenDate,
    formTerm,
    formLenderType,
    formCapital,
    formFeeBase,
    formContent,
    formLiquidCapital,
    formLiquidFeeRate,
    formLiquidTaxRate,
    formLiquidFee,
    formLiquidTax,
    formLiquidPolicy,
    formLiquidDate,
    formLiquidPenalty,
    formLiquidRawValue,
    formExpireDate,
    formDayDiff,
    formLiquidRate,
    formFeeFlexFlag,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(UpdateAppendixLiquid)
);
