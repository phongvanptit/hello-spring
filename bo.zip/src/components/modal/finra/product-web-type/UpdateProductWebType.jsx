import RenderArea from '../../../input/renderArea';
import RenderInput from '../../../input/renderInput';
import RenderNormalSelect from '../../../input/renderNormalSelect'; import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm, FieldArray } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';
import {
    makeGetAccountRight,
    makeGetActionFinra,
    makeGetCapTermContract,
    makeGetDetailFeeChangeFinra,
    makeGetDetailFeeRateFinra, makeGetDetailProductWebTypeFinra,
    makeGetFeePayTypeFinra,
    makeGetMainDetailFinra, makeGetSecondListFinra, makeGetTermLiquidPolicyFinra,
    makeGetToken
} from '../../../../lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import {
    actionFinraRequesting,
    actionFinraSuccess,
    getDetaiFeeChangeRequesting,
    getDetailFeeChangeSuccess,
    getDetailFeeRateRequesting,
    getDetailFeeRateSuccess, getDetailProductWebTypeRequesting, getDetailProductWebTypeSuccess,
    mainItemFinraRequesting,
    mainItemFinraSuccess, secondListFinraRequesting, secondListFinraSuccess
} from '../../../../containers/finra/actions';
import { numberFormatDecimal, StringToDouble, StringToInt } from '../../../../utils';
import RenderListProductCode from '../../../input/floating/element/RenderListProductCode';
import RenderInputMask from '../../../input/renderInputMask';
import RenderSelectDate from '../../../input/renderDatePicker';

ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
    content: {
        top: '40px',
        bottom: 'auto',
        left: 'calc( 50% - 400px )',
        height: 'auto',
        width: '800px',
        padding: '0',
        borderWidth: '0',
        borderColor: '#f3f3f3',
        overflow: 'inherit',
    },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
  `;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
      font-size: 13px;
    }
  `;

//#endregion
function usePrevious(value) {
    const ref = React.useRef();

    React.useEffect(() => {
        ref.current = value;
    }, [value]);

    return ref.current;
}

const configNotification = {
    create: {
        messageRequest: 'txt_mm_create_product_web_type_req',
        messageSuccess: 'txt_mm_create_product_web_type_success',
        cmd: 'MM_PRODUCT_WEB_TYPE.UPDATE_ITEM'
    },
    update: {
        messageRequest: 'txt_mm_update_product_web_type_req',
        messageSuccess: 'txt_mm_update_product_web_type_success',
        cmd: 'MM_PRODUCT_WEB_TYPE.UPDATE_ITEM'
    },
    delete: {
        messageRequest: 'txt_mm_delete_product_web_type_req',
        messageSuccess: 'txt_mm_delete_product_web_type_success',
        cmd: 'MM_PRODUCT_WEB_TYPE.DELETE_ITEM'
    },
    approve: {
        messageRequest: 'txt_mm_approve_product_web_type_req',
        messageSuccess: 'txt_mm_approve_product_web_type_success',
        cmd: 'MM_PRODUCT_WEB_TYPE.APPROVE_ITEM'
    },
}

function UpdateProductWebType(props) {
    const [isApproved, setIsApproved] = useState(true);

    const dispatch = useDispatch();
    const preActionFinra = usePrevious(props.actionFinra)

    useEffect(() => {
        if (props.itemId) {
            getDetailProductWebType()
        }
        return () => {
            dispatch(actionFinraSuccess(undefined))
            dispatch(getDetailProductWebTypeSuccess(undefined))

            props.reset();
        };
    }, []);

    useEffect(() => {
        if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionFinra])

    useEffect(() => {
        console.log(props.detailProductWebType);

        if (props.detailProductWebType) {
            dispatch(change('UpdateProductWebType', 'formCode', props.detailProductWebType?.C_CODE));
            dispatch(change('UpdateProductWebType', 'formName', props.detailProductWebType?.C_NAME));
            dispatch(change('UpdateProductWebType', 'formActive', Boolean(props.detailProductWebType?.C_ACTIVE)));
            dispatch(change('UpdateProductWebType', 'formBannerUrl', props.detailProductWebType?.C_BANNER_URL));
            dispatch(change('UpdateProductWebType', 'formDescription', props.detailProductWebType?.C_DESCRIPTION));

            setIsApproved(props.detailProductWebType.C_STATUS === 'DA_DUYET')
        }
    }, [props.detailProductWebType])

    useEffect(() => {
        if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionFinra])

    const getDetailProductWebType = () => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM_PRODUCT_WEB_TYPE.GET_ITEM',
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId,
            },
        };
        dispatch(getDetailProductWebTypeRequesting(params));
    }

    function submit(value) {
        const data = {
            ITEM_ID: props.itemId,
            CODE: value.formCode,
            NAME: value.formName,
            BANNER_URL: value.formBannerUrl,
            DESCRIPTION: value.formDescription,
            ACTIVE: value.formActive ? 1 : 0,
        }

        if (props.itemId) {
            handleButtonAction('update', data)
        } else {
            handleButtonAction('create', data)
        }
    }

    function handleButtonAction(action, data) {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configNotification[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                if (['create', 'update'].includes(action)) {
                                    handleUpdateCall(action, data)
                                } else if (action === 'approve') {
                                    handleActionApprove();
                                } else {
                                    handleActionDel();
                                }

                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    const handleUpdateCall = (action, data) => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification[action].cmd,
            group: 'LIST',
            data: data,
        };

        props.onSetMessageContent(configNotification[action].messageSuccess)
        dispatch(actionFinraRequesting(params));
    }

    function handleActionDel() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification.delete.cmd,
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId,
            },
        };

        props.onSetMessageContent(configNotification.delete.messageSuccess)
        dispatch(actionFinraRequesting(params));
    }

    function handleActionApprove() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification.approve.cmd,
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId
            },
        };

        props.onSetMessageContent(configNotification.approve.messageSuccess)
        dispatch(actionFinraRequesting(params));
    }

    const { handleSubmit, submitting, onClose, t } = props;

    return (
        <ReactModal
            isOpen={true}
            contentLabel="onRequestClose Example"
            onRequestClose={onClose}
            shouldCloseOnOverlayClick={true}
            overlayClassName="overlay"
            style={customStyles}
        >
            <div
                className="w-100 p-0 rounded"
                style={{ maxHeight: 'calc(100vh - 120px)' }}
            >
                <div className="py-2 d-flex justify-content-between">
                    <b className="fz-16 pl-3">{t((!props.itemId) ? 'txt_finra_modal_create_product_web_type' : 'txt_finra_modal_update_product_web_type')}</b>
                    <a onClick={onClose} className="pr-3">
                        <FaTimes />
                    </a>
                </div>
                <StyleContainer>
                    <form onSubmit={handleSubmit(submit)}>
                        <FormAdd>
                            <Form.Group>
                                <Form.Label>Mã loại SP<span className="text-danger">*</span></Form.Label>
                                <Field
                                    name="formCode"
                                    className="form-control"
                                    component={RenderInput}
                                    validate={[required]}
                                    disabled={props.itemId}
                                />
                            </Form.Group>
                            <Form.Group style={{ gridColumn: '2/4' }}>
                                <Form.Label>Tên Loại SP<span className="text-danger">*</span></Form.Label>
                                <Field
                                  name="formName"
                                  className="form-control"
                                  component={RenderInput}
                                  validate={[required]}
                                />
                            </Form.Group>
                            <Form.Group style={{ gridColumn: '1/4' }}>
                                <Form.Label>Thông tin</Form.Label>
                                <Field
                                  name="formDescription"
                                  className="form-control"
                                  component={RenderArea}
                                />
                            </Form.Group>
                            <Form.Group style={{ gridColumn: '1/4' }}>
                                <Form.Label>Banner URL</Form.Label>
                                <Field
                                  name="formBannerUrl"
                                  className="form-control"
                                  component={RenderInput}
                                  placeholder={'https://img.example.com/123.png'}
                                />
                            </Form.Group>
                            <Form.Group style={{
                                display: 'flex',
                                flexDirection: 'row',
                                gap: 10,
                                alignItems: 'center',
                                gridColumn: '1/4'
                            }}
                            >
                                <Field
                                  name="formActive"
                                  component="input"
                                  type="checkbox"
                                />
                                <label className="form-label">
                                    Active
                                </label>
                            </Form.Group>
                            <div style={{marginTop: 20}}></div>
                            <Form.Label style={{ gridColumn: '1/2' }}>
                                {t('txt-creator')}: {props.itemId ? props.detailProductWebType?.C_CREATOR_CODE : ''}
                            </Form.Label>
                            <Form.Label style={{ gridColumn: '2/3' }}>
                                {t('txt-create-time')} : {props.itemId ? props.detailProductWebType?.C_CREATE_TIME : ''}
                            </Form.Label>
                            <Form.Label style={{ gridColumn: '1/2' }}>
                                {t('txt-approver')} : {props.itemId ? props.detailProductWebType?.C_APPROVER_CODE : ''}
                            </Form.Label>
                            <Form.Label style={{ gridColumn: '2/3' }}>
                                {t('txt-approve-time')} : {props.itemId ? props.detailProductWebType?.C_APPROVE_TIME : ''}
                            </Form.Label>

                        </FormAdd>
                        <hr style={{ gridColumn: '1/5' }} />
                        <div
                            className="d-flex"
                            style={{
                                height: '30px',
                                whiteSpace: 'nowrap',
                                gridColumn: '1/5'
                            }}
                        >
                            <BtnClose type="button" onClick={onClose} className="mr-auto">
                                {t('txt-close')}
                            </BtnClose>
                            <div className="d-flex">
                                {props.accRight?.C_APPROVE === 1 && Boolean(props.itemId) && !isApproved && (
                                    <BtnSubmit
                                        type="button"
                                        onClick={() => handleButtonAction('approve')}
                                        className="success mr-2"
                                    >
                                        {t('txt-appr')}
                                    </BtnSubmit>
                                )}
                            </div>
                            <div className="d-flex">
                                {props.accRight?.C_UPDATE === 1 && Boolean(props.itemId) && !Boolean(props.detailProductWebType?.C_APPROVER_CODE) && (
                                    <BtnSubmit
                                        type="button"
                                        onClick={() => handleButtonAction('delete')}
                                        className="mr-2 danger"
                                    >
                                        {t('txt-del')}
                                    </BtnSubmit>
                                )}
                            </div>
                            <div className="d-flex">
                                {(props.accRight?.C_UPDATE === 1 && Boolean(props.itemId)) && (
                                    <BtnSubmit type="submit" disabled={submitting}>
                                        {t('txt-edit')}
                                    </BtnSubmit>
                                )}
                            </div>
                            <div className="d-flex">
                                {props.accRight?.C_UPDATE === 1 && !props.itemId && (
                                    <BtnSubmit type="submit" disabled={submitting}>
                                        {t('txt-add')}
                                    </BtnSubmit>
                                )}
                            </div>
                        </div>
                    </form>
                </StyleContainer>
            </div>
        </ReactModal >
    );
}

UpdateProductWebType = reduxForm({
    form: 'UpdateProductWebType',
    enableReinitialize: true
})(UpdateProductWebType);

const selector = formValueSelector('UpdateProductWebType');

const mapStateToProps = (state) => {
    const getToken = makeGetToken();

    const {
        formCode,
        formName,
        formStatus,
        formActive,
        formBannerUrl,
        formDescription,
    } = selector(
        state,
        'formCode',
        'formName',
        'formStatus',
        'formActive',
        'formBannerUrl',
        'formDescription',
    );

    return {
        token: getToken(state),
        accRight: makeGetAccountRight()(state),
        actionFinra: makeGetActionFinra()(state),
        detailProductWebType: makeGetDetailProductWebTypeFinra()(state),

        formCode,
        formName,
        formStatus,
        formActive,
        formBannerUrl,
        formDescription,
    };
};

export default connect(mapStateToProps)(
    translate('translations')(UpdateProductWebType)
);