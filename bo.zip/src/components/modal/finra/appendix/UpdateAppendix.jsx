import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import renderNewInput from 'components/input/renderNewInput';
import renderNewInputMkt from 'components/input/renderNewInputMkt';
import renderNewInputPartner from 'components/input/renderNewInputPartner';
import * as _ from 'lodash';
import {
  makeGetAccountRight,
  makeGetActionFinra,
  makeGetCapLenderType,
  makeGetCapTermContract, makeGetCashBalance,
  makeGetContractCodeFinra,
  makeGetCustomerDetail, makeGetDetailAppendixFinra, makeGetDetailFeeRateFinra, makeGetExtendTypeFinra,
  makeGetMainDetailFinra,
  makeGetMainListFinra,
  makeGetMmContactBaseCode,
  makeGetMmGetExpireDate,
  makeGetMMSinglePartner, makeGetRightFeeBase,
  makeGetSingleUserFront,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import React, { Fragment, useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { _diff2Date, formatDate, numberFormatDecimal, stringToDate, StringToDouble, StringToNumber } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import {
  actionFinraRequesting,
  actionFinraSuccess,
  getContractCodeRequesting,
  getContractCodeSuccess,
  getDetailAppendixRequesting, getDetailAppendixSuccess, getDetailFeeRateRequesting, getDetailFeeRateSuccess,
  mainItemFinraRequesting,
  mainItemFinraSuccess,
  mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { cashBalanceRequest, cashBalanceSuccess } from '../../../../containers/cash/actions';
import { custDetailRequest, custDetailSuccess } from '../../../../containers/customer/actions';
import { singleUserFrontRequest, singleUserFrontSuccess } from '../../../../containers/account/actions';
import { confirmAlert } from 'react-confirm-alert';
import {
  mmContactBaseCodeRequest, mmContactBaseCodeSuccess, mmGetExpireDateRequest, mmGetExpireDateSuccess,
  mmSinglePartnerRequest,
  mmSinglePartnerSuccess
} from '../../../../containers/product/actions';
import RenderNewInput from '../../../input/renderNewInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import RenderInputMask from '../../../input/renderInputMask';
import RenderListProductCode from '../../../input/floating/element/RenderListProductCode';
import Decimal from 'decimal.js';
import UpdateLiquidPolicy from '../liquiq-policy/UpdateLiquidPolicy';
import { globalExportDocxVer2Request } from '../../../../containers/report/actions';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
        font-size: 13px;
    }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formOpenDate, formExpireDate } = values;

  if (
    formOpenDate &&
    formExpireDate &&
    _diff2Date(formOpenDate, formExpireDate) > 0
  ) {
    errors.formExpireDate = `Ngày không hợp lệ`;
  }

  return errors;
};

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_appendix_req',
    messageSuccess: 'txt_mm_create_appendix_success',
    cmd: 'MM_APPENDIX.UPDATE_ITEM'
  },
  update: {
    messageRequest: 'txt_mm_update_appendix_req',
    messageSuccess: 'txt_mm_update_appendix_success',
    cmd: 'MM_APPENDIX.UPDATE_ITEM'
  },
  delete: {
    messageRequest: 'txt_mm_delete_appendix_req',
    messageSuccess: 'txt_mm_delete_appendix_success',
    cmd: 'MM_APPENDIX.DELETE_ITEM'
  },
  approve: {
    messageRequest: 'txt_mm_approve_appendix_req',
    messageSuccess: 'txt_mm_approve_appendix_success',
    cmd: 'MM_APPENDIX.APPROVE_ITEM'
  },
  un_approve: {
    messageRequest: 'txt_mm_unapprove_appendix_req',
    messageSuccess: 'txt_mm_unapprove_appendix_success',
    cmd: 'MM_APPENDIX.UN_APPROVE_ITEM'
  },
  update_extend_type: {
    messageRequest: 'txt_mm_update_extend_type_appendix_req',
    messageSuccess: 'txt_mm_update_extend_type_appendix_success',
    cmd: 'MM_APPENDIX_EXTEND.UPDATE_EXTEND_TYPE'
  }
}

function UpdateAppendix(props) {
  const { handleSubmit, submitting, onClose, t} = props;

  const [isInitLoad, setIsInitLoad] = useState(true);
  const [listExtendTypeCustom, setListExtendTypeCustom] = useState([]);
  const [cashValid, setCashValid] = useState(0);
  const [isShowProductDetail, setIsShowProductDetail] = useState(undefined);

  const dispatch = useDispatch();

  const preActionFinra = usePrevious(props.actionFinra)

  useEffect(() => {
    if (props.itemId) {
      getDetailAppendix()
    } else {
      setIsInitLoad(false)
      initForm();
    }

    return () => {
      dispatch(mmContactBaseCodeSuccess(undefined))
      dispatch(mmGetExpireDateSuccess(undefined))
      dispatch(actionFinraSuccess(undefined))
      dispatch(cashBalanceSuccess(undefined))
      dispatch(getDetailAppendixSuccess(undefined))

      props.reset();
    };
  }, []);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      props.onClose()
    }
  }, [props.actionFinra])

  useEffect(() => {
    if (props.formCustCode) {
      getAppendixCode()
      getCashBalanceDate()
    } else {
      dispatch(mmContactBaseCodeSuccess(undefined))
      dispatch(cashBalanceSuccess(undefined))
      dispatch(getDetailFeeRateSuccess(undefined))
    }
  }, [props.formCustCode]);

  useEffect(() => {
    if (props.appendixCodeInfo) {
      console.log(isInitLoad);

      if (isInitLoad) {
        setIsInitLoad(false)
        return
      }
      dispatch(change('UpdateAppendix', 'formAppendixNumber', props.appendixCodeInfo.C_APPENDIX_CODE));
    } else {

      if (isInitLoad) {
        return
      }
      dispatch(change('UpdateAppendix', 'formAppendixNumber', ''));
    }
  }, [props.appendixCodeInfo]);

  useEffect(() => {
    if (props.formTerm && props.formOpenDate) {
      getExpireDate()
    }
  }, [props.formTerm, props.formOpenDate]);

  useEffect(() => {
    if (props.listExtendType && listExtendTypeCustom.length == 0) {
      setListExtendTypeCustom(props.listExtendType.filter((item) => item.value != 'LAI_NHAP_GOC'));
    }
  }, [props.listExtendType]);

  useEffect(() => {
    if (props.detailAppendix) {
      dispatch(change('UpdateAppendix', 'formCustCode', props.detailAppendix.C_CUSTOMER_CODE));
      dispatch(change('UpdateAppendix', 'formAppendixNumber', props.detailAppendix.C_APPENDIX_CODE));
      dispatch(change('UpdateAppendix', 'formProductCode', props.detailAppendix.C_PRODUCT_CODE));
      dispatch(change('UpdateAppendix', 'formOpenDate', props.detailAppendix.C_OPEN_DATE));
      dispatch(change('UpdateAppendix', 'formLenderType', ''));
      dispatch(change('UpdateAppendix', 'formCapital', props.detailAppendix.C_CAPITAL));
      dispatch(change('UpdateAppendix', 'formFeeBase', props.detailAppendix.C_FEE_BASE));
      dispatch(change('UpdateAppendix', 'formContent', props.detailAppendix.C_CONTENT));
      dispatch(change('UpdateAppendix', 'formFeeOther', props.detailAppendix.C_OTHER_FEE_RATE));
      dispatch(change('UpdateAppendix', 'formExtendType', props.detailAppendix.C_EXTENT_TYPE));
    }
  }, [props.detailAppendix]);

  useEffect(() => {
    if (props.cashBalance && props.detailAppendix) {
      setCashValid(new Decimal(props.detailAppendix.C_CAPITAL).add(new Decimal(props.cashBalance.C_CASH_BALANCE_BO)).toNumber())
    }
    if (props.cashBalance && !props.detailAppendix && !props.itemId) {
      setCashValid(props.cashBalance.C_CASH_BALANCE_BO)
    }
  }, [props.cashBalance, props.detailAppendix]);

  useEffect(() => {
    if (props.formProductCode) {
      getDetailFeeRate();
    } else {

      dispatch(change('UpdateAppendix', 'formTerm', '30'));
      dispatch(change('UpdateAppendix', 'formProductName', ''));
      dispatch(change('UpdateAppendix', 'formProductRate', ''));
    }
    if(!props.itemId && !props.detailAppendix?.C_APPROVER_CODE)
      dispatch(change('UpdateAppendix', 'formExtendType', 'KHONG_GIA_HAN'));
  }, [props.formProductCode]);

  useEffect(() => {
    if (props.detailFeeRate) {
      dispatch(change('UpdateAppendix', 'formTerm', props.detailFeeRate.C_TERM_CODE));
      dispatch(change('UpdateAppendix', 'formProductName', props.detailFeeRate.C_PRODUCT_NAME));
      dispatch(change('UpdateAppendix', 'formProductRate', props.detailFeeRate.C_FEE_RATE));

    } else {
      dispatch(change('UpdateAppendix', 'formTerm', '30'));
      dispatch(change('UpdateAppendix', 'formProductName', ''));
      dispatch(change('UpdateAppendix', 'formProductRate', ''));
    }
  }, [props.detailFeeRate]);

  const getDetailFeeRate = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_SINGLE_FEE_RATE',
      group: 'LIST',
      data: {
        ITEM_ID: props.formProductCode,
      },
    };
    dispatch(getDetailFeeRateRequesting(params));
  }

  const getAppendixCode = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX.SINGLE_CONTRACT_BASE',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: props.formCustCode,
      },
    };
    dispatch(mmContactBaseCodeRequest(params));
  }

  const getExpireDate = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX.GET_EXPIRE_DATE',
      group: 'LIST',
      data: {
        OPEN_DATE: props.formOpenDate,
        TERM: props.formTerm,
      },
    };

    dispatch(mmGetExpireDateRequest(params));
  }

  const getCashBalanceDate = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: props.formCustCode,
      },
    };

    dispatch(cashBalanceRequest(params));
  }

  const initForm = () => {
    dispatch(change('UpdateAppendix', 'formOpenDate', formatDate(stringToDate(props.sysSystemInfo?.C_T_DATE, 'dmy'), '/', 'dmy')));
    dispatch(change('UpdateAppendix', 'formTerm', '30'));
    dispatch(change('UpdateAppendix', 'formFeeBase', '365'));
    dispatch(change('UpdateAppendix', 'formExtendType', 'KHONG_GIA_HAN'));
    dispatch(change('UpdateAppendix', 'formFeeOther', '0'));
  }

  const getDetailAppendix = () => {

    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_APPENDIX.GET_ITEM',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId
      },
    };

    dispatch(getDetailAppendixRequesting(params));
  }

  const processNumber = (value) => {
    if (value === null || value === undefined) {
      return '0';
    } else if (typeof value === 'string' && value.trim() === '') {
      return '0';
    } else {
      return StringToNumber(value);
    }
  }

  useEffect(() => {
    const dayNo = new Decimal(processNumber(props.mmGetExpireDate?.C_DAY_DIFF));
    const capital = new Decimal(processNumber(props.formCapital));
    const rate = new Decimal(processNumber(props.formProductRate));

    const coupon = capital.mul(rate).mul(dayNo).div(365).div(100).round().toString();
    console.log(dayNo.toString(), capital.toString(), rate.toString(), coupon);
    dispatch(change('UpdateAppendix', 'formCoupon', coupon));

  }, [props.formCapital, props.formProductRate, props.mmGetExpireDate?.C_DAY_DIFF]);

  const handleButtonAction = (action) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (['create', 'update'].includes(action)) {
                  UpdateAppendix(action)
                }

                if (action == 'update_extend_type') {
                  updateExtendType(action);
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  const submit = () => {
    handleButtonAction(props.itemId ? 'update' : 'create')
  }

  const UpdateAppendix = (type) => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification[type].cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
        CUSTOMER_CODE: props?.formCustCode.toUpperCase(),
        PRODUCT_CODE: props.formProductCode,
        LENDER_TYPE: props.formLenderType,
        TERM: props.formTerm,
        FEE_BASE: props.formFeeBase,
        CONTRACT_CODE: props?.formAppendixNumber,
        EXTEND_TYPE: props?.formExtendType,
        OTHER_FEE_RATE: StringToNumber(props?.formFeeOther),
        OPEN_DATE: props?.formOpenDate,
        CONTENT: props?.formContent,
        CAPITAL: StringToDouble(props.formCapital),
      },
    };
    props.onSetMessageContent(configNotification[type].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  const handleDownloadAppendix = () => {
    const param = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM_REPORT.REPORT_06',
      group: 'LIST',
      data: {
        APPENDIX_ID: props.itemId,

        TEMPLATE_CODE: 'BM_APPENDIX',
        EXPORT_FILE_TYPE: 'DOCX'
      },
    }

    dispatch(globalExportDocxVer2Request(param))
  }

  const handleUpdateExtend = () => {
    handleButtonAction('update_extend_type')
  }
  
  const updateExtendType = (type) => {
    const param = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification[type].cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
        EXTEND_TYPE: props?.formExtendType,
      },
    }
    props.onSetMessageContent(configNotification[type].messageSuccess)
    dispatch(actionFinraRequesting(param))
  }

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)', overflow: 'hidden' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t(props.itemId ? 'txt_finra_modal_update_appendix' : 'txt_finra_modal_create_appendix')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 260px)' }}>
              <FormAdd>
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-framework-contarct-info')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-cust-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustCode"
                    className="form-control"
                    component={RenderNewInput}
                    validate={[required]}
                    index={2}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <input
                    value={props.appendixCodeInfo?.C_CUSTOMER_NAME || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <input
                    value={props.appendixCodeInfo?.C_MARKETING_ID || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-marketing-name')}</Form.Label>
                  <input
                    value={props.appendixCodeInfo?.C_MARKETING_NAME || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-framework-contarct-number')}</Form.Label>*/}
                {/*  <input*/}
                {/*    value={props.appendixCodeInfo?.C_CONTRACT_CODE || ''}*/}
                {/*    type={'text'}*/}
                {/*    className="form-control"*/}
                {/*    disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-open-date-contract')}</Form.Label>*/}
                {/*  <input*/}
                {/*    value={props.appendixCodeInfo?.C_OPEN_DATE || ''}*/}
                {/*    type={'text'}*/}
                {/*    className="form-control"*/}
                {/*    disabled*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  Thông tin sản phẩm
                </p>
                <Form.Group>
                  <Form.Label>Mã sản phẩm</Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formProductCode"
                    className="form-control"
                    component={RenderListProductCode}
                    opts={props.listProductCode}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>Tên sản phẩm</Form.Label>
                  <Field
                    name="formProductName"
                    className="form-control"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Lãi suất (%/năm)</Form.Label>
                  <Field
                    name="formProductRate"
                    className="form-control"
                    component={RenderInputMask}
                    allowDecimal={true}
                    decimalLimit={6}
                    disabled
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>Lãi khác (%/năm)</Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formFeeOther"*/}
                {/*    className="form-control"*/}
                {/*    component={RenderInputMask}*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group>*/}
                {/*  <Form.Label></Form.Label>*/}
                {/*  {props.detailFeeRate?.C_LIQUID_CODE && (*/}
                {/*    <BtnClose type="button" className="mr-auto" onClick={() => setIsShowProductDetail(props.detailFeeRate?.C_LIQUID_CODE)}>*/}
                {/*      Xem*/}
                {/*    </BtnClose>*/}
                {/*  )}*/}
                {/*</Form.Group>*/}
                <p
                  style={{ gridColumn: '1/6' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-appendix-business-info')}
                </p>
                <Form.Group>
                  <Form.Label>
                    {t('txt-loan-appendix-number')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formAppendixNumber"
                    className="form-control"
                    component={RenderInput}
                    validate={[required]}
                    placeholder={props.appendixCodeInfo?.C_CONTRACT_CODE ? `__/${props.appendixCodeInfo?.C_CONTRACT_CODE}` : ''}
                  />
                </Form.Group>

                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-cust-type')}</Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formLenderType"*/}
                {/*    className="form-control"*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={props.capLenderType}*/}
                {/*    required*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group>
                  <Form.Label>
                    {t('txt-period')}
                  </Form.Label>
                  <Field
                    name="formTerm"
                    className="form-control"
                    component={RenderNormalSelect}
                    validate={[required]}
                    opts={props.capTermContract}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-sign-day')}
                  </Form.Label>
                  <Field
                    name="formOpenDate"
                    className="form-control input-order fz-13"
                    classParentName="w-100"
                    component={RenderSelectDate}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <input
                    value={props.mmGetExpireDate?.C_EXPIRE_DATE || ''}
                    type={'text'}
                    className="form-control"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-number-day')}</Form.Label>
                  <input
                    value={numberFormatDecimal(props.mmGetExpireDate?.C_DAY_DIFF) || ''}
                    type={'text'}
                    className="form-control text-right"
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt_finra_appendix_value')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCapital"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                  />
                </Form.Group>
                {(props.detailAppendix?.C_STATUS === 'CHUA_DUYET' || props.itemId === null || props.itemId === undefined) && <Form.Group>
                  <Form.Label>Số dư khả dụng</Form.Label>
                  <input
                    value={numberFormatDecimal(cashValid) || ''}
                    type={'text'}
                    className="form-control text-right"
                    disabled
                  />
                </Form.Group>}
                <Form.Group>
                  <Form.Label>Lãi (tạm tính)</Form.Label>
                  <Field
                    name="formCoupon"
                    className="form-control"
                    component={RenderInputMask}
                    validate={[required]}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Phương thức gia hạn</Form.Label>
                  <Field
                    name="formExtendType"
                    className="form-control"
                    component={RenderNormalSelect}
                    opts={props.detailFeeRate?.C_PRODUCT_TYPE == 'TL_02'? listExtendTypeCustom : props.listExtendType}
                    required
                    disabled={props.detailFeeRate?.C_EXTEND_TYPE == 'KHONG_GIA_HAN'}
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-interest-calculation-basis')}</Form.Label>*/}
                {/*  <Field*/}
                {/*    name="formFeeBase"*/}
                {/*    className="form-control"*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={props.capFeeBase}*/}
                {/*    required*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                <Form.Group style={{ gridColumn: '1/6' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                {/* Khai báo người các kiểu */}
                <Form.Label>
                  {t('txt-creator')} : {props.itemId ? props.detailAppendix?.C_CREATOR_CODE : ''}
                </Form.Label>
                <Form.Label>
                  {t('txt-create-time')} : {props.itemId ? props.detailAppendix?.C_CREATE_TIME : ''}
                </Form.Label>
                <Form.Label className='ml-5'>
                  {t('txt-approver')} : {props.itemId ? props.detailAppendix?.C_APPROVER_CODE : ''}
                </Form.Label>
                <Form.Label className='ml-2'>
                  {t('txt-approve-time')} : {props.itemId ? props.detailAppendix?.C_APPROVE_TIME : ''}
                </Form.Label>

              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/6' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/4',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              {props.accRight?.C_UPDATE === 1 && <div className="d-flex">
                {(props.detailAppendix && props.detailAppendix.C_STATUS === 'DA_DUYET') &&
                  <BtnSubmit type="button" onClick={handleUpdateExtend} className="mr-2">
                    Cập nhật gia hạn
                  </BtnSubmit>}

                {props.itemId && (
                  <BtnSubmit type="button" onClick={handleDownloadAppendix} className="success mr-2">
                    In hợp đồng
                  </BtnSubmit>
                )}
                {(!props.detailAppendix || (props.detailAppendix && props.detailAppendix.C_STATUS === 'CHUA_DUYET')) &&
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-accept')}
                  </BtnSubmit>}
              </div>}
            </div>
          </form>
        </StyleContainer>
        {isShowProductDetail && (
          <UpdateLiquidPolicy
            itemId={isShowProductDetail}
            onClose={() => { setIsShowProductDetail(undefined) }}
          />
        )}
      </div>
    </ReactModal>
  );
}

UpdateAppendix = reduxForm({
  form: 'UpdateAppendix',
  enableReinitialize: true,
  validate
})(UpdateAppendix);

const selector = formValueSelector('UpdateAppendix');

const mapStateToProps = (state) => {
  const {
    formCustCode,
    formAppendixNumber,
    formProductCode,
    formOpenDate,
    formTerm,
    formLenderType,
    formCapital,
    formFeeBase,
    formContent,
    formProductRate,
    formFeeOther,
    formExtendType,
  } = selector(
    state,
    'formCustCode',
    'formAppendixNumber',
    'formProductCode',
    'formOpenDate',
    'formTerm',
    'formLenderType',
    'formCapital',
    'formFeeBase',
    'formContent',
    'formProductRate',
    'formFeeOther',
    'formExtendType',
  );

  return {
    token: makeGetToken()(state),
    accRight: makeGetAccountRight()(state),
    sysSystemInfo: makeGetSystemInfo()(state),
    appendixCodeInfo: makeGetMmContactBaseCode()(state),
    capLenderType: makeGetCapLenderType()(state),
    capTermContract: makeGetCapTermContract()(state),
    mmGetExpireDate: makeGetMmGetExpireDate()(state),
    capFeeBase: makeGetRightFeeBase()(state),
    actionFinra: makeGetActionFinra()(state),
    detailAppendix: makeGetDetailAppendixFinra()(state),
    cashBalance: makeGetCashBalance()(state),
    detailFeeRate: makeGetDetailFeeRateFinra()(state),
    listExtendType: makeGetExtendTypeFinra()(state),

    formCustCode,
    formAppendixNumber,
    formProductCode,
    formOpenDate,
    formTerm,
    formLenderType,
    formCapital,
    formFeeBase,
    formContent,
    formProductRate,
    formFeeOther,
    formExtendType,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(UpdateAppendix)
);
