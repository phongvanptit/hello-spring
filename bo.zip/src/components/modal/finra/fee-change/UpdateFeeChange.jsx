import RenderArea from '../../../input/renderArea';
import RenderInput from '../../../input/renderInput';
import RenderNormalSelect from '../../../input/renderNormalSelect'; import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm, FieldArray } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';
import {
    makeGetAccountRight,
    makeGetActionFinra,
    makeGetCapTermContract,
    makeGetDetailFeeChangeFinra,
    makeGetDetailFeeRateFinra,
    makeGetFeePayTypeFinra,
    makeGetMainDetailFinra, makeGetSecondListFinra, makeGetTermLiquidPolicyFinra,
    makeGetToken
} from '../../../../lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import {
    actionFinraRequesting,
    actionFinraSuccess,
    getDetaiFeeChangeRequesting,
    getDetailFeeChangeSuccess,
    getDetailFeeRateRequesting,
    getDetailFeeRateSuccess,
    mainItemFinraRequesting,
    mainItemFinraSuccess, secondListFinraRequesting, secondListFinraSuccess
} from '../../../../containers/finra/actions';
import { numberFormatDecimal, StringToDouble, StringToInt } from '../../../../utils';
import RenderListProductCode from '../../../input/floating/element/RenderListProductCode';
import RenderInputMask from '../../../input/renderInputMask';
import RenderSelectDate from '../../../input/renderDatePicker';

ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
    content: {
        top: '40px',
        bottom: 'auto',
        left: 'calc( 50% - 400px )',
        height: 'auto',
        width: '800px',
        padding: '0',
        borderWidth: '0',
        borderColor: '#f3f3f3',
        overflow: 'inherit',
    },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
  `;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
      font-size: 13px;
    }
  `;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
    const ref = React.useRef();

    React.useEffect(() => {
        ref.current = value;
    }, [value]);

    return ref.current;
}

const configNotification = {
    create: {
        messageRequest: 'txt_mm_create_fee_change_req',
        messageSuccess: 'txt_mm_create_fee_change_success',
        cmd: 'MM.REQUEST_UPDATE'
    },
    update: {
        messageRequest: 'txt_mm_update_fee_change_req',
        messageSuccess: 'txt_mm_update_fee_change_success',
        cmd: 'MM.REQUEST_UPDATE'
    },
    delete: {
        messageRequest: 'txt_mm_delete_fee_change_req',
        messageSuccess: 'txt_mm_delete_fee_change_success',
        cmd: 'MM.DELETE_REQUEST_UPDATE'
    },
    approve: {
        messageRequest: 'txt_mm_approve_fee_change_req',
        messageSuccess: 'txt_mm_approve_fee_change_success',
        cmd: 'MM.APPROVE_REQUEST_UPDATE'
    },
}

function UpdateFeeChange(props) {
    const [isApproved, setIsApproved] = useState(true);

    const dispatch = useDispatch();
    const preActionFinra = usePrevious(props.actionFinra)

    useEffect(() => {
        if (props.itemId) {
            getDetailFeeChange()
        }
        return () => {
            dispatch(actionFinraSuccess(undefined))
            dispatch(getDetailFeeChangeSuccess(undefined))
            dispatch(getDetailFeeRateSuccess(undefined))

            props.reset();
        };
    }, []);

    useEffect(() => {
        if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionFinra])

    useEffect(() => {
        if (props.detailFeeChange) {
            dispatch(change('UpdateFeeChange', 'formProductCode', props.detailFeeChange?.C_PRODUCT_CODE));
            dispatch(change('UpdateFeeChange', 'formProductRate', props.detailFeeChange?.C_FEE_RATE));
            dispatch(change('UpdateFeeChange', 'formApplyDate', props.detailFeeChange?.C_APPLY_DATE));

            setIsApproved(props.detailFeeChange.C_STATUS === 'CHUA_DUYET')
        }
    }, [props.detailFeeChange])

    useEffect(() => {
        if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
            props.onComplete()
            props.onClose()
        }
    }, [props.actionFinra])

    useEffect(() => {
        if (props.formProductCode) {
            getDetailFeeRate();
        } else {
            dispatch(change('UpdateFeeChange', 'formTermCode', '30'));
            dispatch(change('UpdateFeeChange', 'formProductName', ''));
            dispatch(change('UpdateFeeChange', 'formProductRate', ''));
            dispatch(change('UpdateFeeChange', 'formPayType', ''));
        }
    }, [props.formProductCode]);

    useEffect(() => {
        if (props.detailFeeRate) {
            dispatch(change('UpdateFeeChange', 'formTermCode', props.detailFeeRate?.C_TERM_CODE));
            dispatch(change('UpdateFeeChange', 'formProductName', props.detailFeeRate?.C_PRODUCT_NAME));
            dispatch(change('UpdateFeeChange', 'formProductRate', props.detailFeeChange?.C_FEE_RATE || props.detailFeeRate?.C_FEE_RATE));
            dispatch(change('UpdateFeeChange', 'formDayNo', props.detailFeeRate?.C_DAY_NO));
            dispatch(change('UpdateFeeChange', 'formPayType', props.detailFeeRate?.C_PAY_TYPE));
        } else {
            dispatch(change('UpdateFeeChange', 'formTermCode', '30'));
            dispatch(change('UpdateFeeChange', 'formProductName', ''));
            dispatch(change('UpdateFeeChange', 'formPayType', ''));
            dispatch(change('UpdateFeeChange', 'formProductRate', ''));
        }
    }, [props.detailFeeRate]);

    useEffect(() => {
        if (!['DAY_OF_MONTH', 'DAY_T'].includes(props.formPayType)) {
            dispatch(change('UpdateFeeChange', 'formDayNo', null))
        }
    }, [props.formPayType]);

    const getDetailFeeRate = () => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_SINGLE_FEE_RATE',
            group: 'LIST',
            data: {
                ITEM_ID: props.formProductCode,
            },
        };
        dispatch(getDetailFeeRateRequesting(params));
    }

    const getDetailFeeChange = () => {

        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ITEM_REQUEST',
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId
            },
        };

        dispatch(getDetaiFeeChangeRequesting(params));
    }

    function submit(value) {
        const data = {
            ITEM_ID: props.itemId,
            PRODUCT_CODE: value.formProductCode,
            FEE_RATE: value.formProductRate,
            APPLY_DATE: value.formApplyDate
        }

        if (props.itemId) {
            handleButtonAction('update', data)
        } else {
            handleButtonAction('create', data)
        }
    }

    function handleButtonAction(action, data) {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configNotification[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                if (['create', 'update'].includes(action)) {
                                    handleUpdateCall(action, data)
                                } else if (action == 'approve') {
                                    handleActionApprove();
                                } else {
                                    handleActionDel();
                                }

                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    const handleUpdateCall = (action, data) => {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification[action].cmd,
            group: 'LIST',
            data: data,
        };

        props.onSetMessageContent(configNotification[action].messageSuccess)
        dispatch(actionFinraRequesting(params));
    }

    function handleActionDel() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification.delete.cmd,
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId,
            },
        };

        props.onSetMessageContent(configNotification.delete.messageSuccess)
        dispatch(actionFinraRequesting(params));
    }

    function handleActionApprove() {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configNotification.approve.cmd,
            group: 'LIST',
            data: {
                ITEM_ID: props.itemId
            },
        };

        props.onSetMessageContent(configNotification.approve.messageSuccess)
        dispatch(actionFinraRequesting(params));
    }

    const { handleSubmit, submitting, onClose, t } = props;

    return (
        <ReactModal
            isOpen={true}
            contentLabel="onRequestClose Example"
            onRequestClose={onClose}
            shouldCloseOnOverlayClick={true}
            overlayClassName="overlay"
            style={customStyles}
        >
            <div
                className="w-100 p-0 rounded"
                style={{ maxHeight: 'calc(100vh - 120px)' }}
            >
                <div className="py-2 d-flex justify-content-between">
                    <b className="fz-16 pl-3">{t((props.itemId && !isApproved) ? 'txt_finra_modal_update_fee_change' : 'txt_finra_modal_create_fee_change')}</b>
                    <a onClick={onClose} className="pr-3">
                        <FaTimes />
                    </a>
                </div>
                <StyleContainer>
                    <form onSubmit={handleSubmit(submit)}>
                        <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 260px)' }}>
                            <FormAdd>
                                <p
                                    style={{ gridColumn: '1/6' }}
                                    className="color-thm mb-0 fz-13"
                                >
                                    Thông tin sản phẩm
                                </p>
                                <Form.Group>
                                    <Form.Label>
                                        Mã sản phẩm
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formProductCode"
                                        className="form-control"
                                        component={RenderListProductCode}
                                        opts={props.listProductCode}
                                        validate={[required]}
                                        disabled={props.itemId}
                                    />
                                </Form.Group>
                                <Form.Group style={{ gridColumn: '2/4' }}>
                                    <Form.Label>Tên sản phẩm</Form.Label>
                                    <Field
                                        name="formProductName"
                                        className="form-control"
                                        component={RenderInput}
                                        disabled
                                    />
                                </Form.Group>

                                <Form.Group>
                                    <Form.Label>
                                        {t('txt-period')}
                                    </Form.Label>
                                    <Field
                                        name="formTermCode"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        opts={props.capTermContract}
                                        disabled
                                    />
                                </Form.Group>

                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        Hình thức trả lãi
                                    </Form.Label>
                                    <Field
                                        name="formPayType"
                                        className="form-control"
                                        component={RenderNormalSelect}
                                        opts={props.feePayType}
                                        disabled
                                    />
                                </Form.Group>

                                <Form.Group>
                                    <Form.Label>
                                        Ngày trả lãi
                                    </Form.Label>
                                    <Field
                                        name="formDayNo"
                                        className="form-control"
                                        component={RenderInputMask}
                                        disabled
                                    />
                                </Form.Group>

                                <Form.Group style={{ gridColumn: '1/2' }}>
                                    <Form.Label>
                                        Lãi suất (%/năm)
                                    </Form.Label>
                                    <Field
                                        name="formProductRate"
                                        className="form-control"
                                        component={RenderInputMask}
                                        allowDecimal={true}
                                        decimalLimit={6}
                                    />
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label>
                                        Ngày áp dụng
                                        <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Field
                                        name="formApplyDate"
                                        className="form-control input-order "
                                        classParentName="w-100"
                                        component={RenderSelectDate}
                                        validate={[required]}
                                    // disabled={props.itemId && props.singleFeeRate?.C_APPROVER_CODE}
                                    />
                                </Form.Group>
                                
                                <Form.Label style={{ gridColumn: '1/2' }}>
                                    {t('txt-creator')}: {props.itemId ? props.detailFeeChange?.C_CREATOR_CODE : ''}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '2/6' }}>
                                    {t('txt-create-time')} : {props.itemId ? props.detailFeeChange?.C_CREATE_TIME : ''}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '1/2' }}>
                                    {t('txt-approver')} : {props.itemId ? props.detailFeeChange?.C_APPROVER_CODE : ''}
                                </Form.Label>
                                <Form.Label style={{ gridColumn: '2/6' }}>
                                    {t('txt-approve-time')} : {props.itemId ? props.detailFeeChange?.C_APPROVE_TIME : ''}
                                </Form.Label>

                            </FormAdd>
                        </PerfectScrollbar>
                        <hr style={{ gridColumn: '1/5' }} />
                        <div
                            className="d-flex"
                            style={{
                                height: '30px',
                                whiteSpace: 'nowrap',
                                gridColumn: '1/5'
                            }}
                        >
                            <BtnClose type="button" onClick={onClose} className="mr-auto">
                                {t('txt-close')}
                            </BtnClose>
                            <div className="d-flex">
                                {props.accRight?.C_APPROVE === 1 && Boolean(props.itemId) && isApproved && (
                                    <BtnSubmit
                                        type="button"
                                        onClick={() => handleButtonAction('approve')}
                                        className="success mr-2"
                                    >
                                        {t('txt-appr')}
                                    </BtnSubmit>
                                )}
                            </div>
                            <div className="d-flex">
                                {props.accRight?.C_UPDATE === 1 && Boolean(props.itemId) && isApproved && (
                                    <BtnSubmit
                                        type="button"
                                        onClick={() => handleButtonAction('delete')}
                                        className="mr-2 danger"
                                    >
                                        {t('txt-del')}
                                    </BtnSubmit>
                                )}
                            </div>
                            <div className="d-flex">
                                {((props.accRight?.C_UPDATE === 1 && Boolean(props.itemId) && isApproved) || props.detailFeeChange?.IS_CAN_UPDATE == 1) && (
                                    <BtnSubmit type="submit" disabled={submitting}>
                                        {t('txt-edit')}
                                    </BtnSubmit>
                                )}
                            </div>
                            <div className="d-flex">
                                {props.accRight?.C_UPDATE === 1 && !props.itemId && (
                                    <BtnSubmit type="submit" disabled={submitting}>
                                        {t('txt-add')}
                                    </BtnSubmit>
                                )}
                            </div>
                        </div>
                    </form>
                </StyleContainer>
            </div>
        </ReactModal >
    );
}

UpdateFeeChange = reduxForm({
    form: 'UpdateFeeChange',
    enableReinitialize: true
})(UpdateFeeChange);

const selector = formValueSelector('UpdateFeeChange');

const mapStateToProps = (state) => {
    const getToken = makeGetToken();

    const {
        formLiquidPolicyCode,
        formLiquidPolicyName,
        formProductCode,
        formTermCode,
        formDayNo,
        formApplyDate,
        formPayType,
        formContent,
        formItems,
        formType,
    } = selector(
        state,
        'formLiquidPolicyCode',
        'formLiquidPolicyName',
        'formProductCode',
        'formTermCode',
        'formDayNo',
        'formApplyDate',
        'formPayType',
        'formContent',
        'formItems',
        'formType',
    );

    return {
        token: getToken(state),
        accRight: makeGetAccountRight()(state),
        actionFinra: makeGetActionFinra()(state),
        detailFeeChange: makeGetDetailFeeChangeFinra()(state),
        listRate: makeGetSecondListFinra()(state),
        detailFeeRate: makeGetDetailFeeRateFinra()(state),
        capTermContract: makeGetCapTermContract()(state),
        feePayType: makeGetFeePayTypeFinra()(state),

        formProductCode,
        formDayNo,
        formApplyDate,
        formTermCode,
        formPayType,
        formLiquidPolicyCode,
        formLiquidPolicyName,
        formContent,
        formItems,
        formType,
    };
};

export default connect(mapStateToProps)(
    translate('translations')(UpdateFeeChange)
);