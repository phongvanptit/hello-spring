import RenderArea from '../../../input/renderArea';
import RenderInput from '../../../input/renderInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import RenderSelectSubBranch from '../../../input/renderSelectSubBranch';
import RenderSuggestBank from '../../../input/renderSuggestBank';
import { setToast } from '../../../../containers/client/actions';
import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Form, Table } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm, FieldArray } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';

import renderNewInput from '../../../input/renderNewInput';
import {
  makeGetAccountRight,
  makeGetActionFinra,
  makeGetMainDetailFinra, makeGetSecondListFinra, makeGetTermLiquidPolicyFinra,
  makeGetToken
} from '../../../../lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import {
  actionFinraRequesting,
  actionFinraSuccess,
  mainItemFinraRequesting,
  mainItemFinraSuccess, secondListFinraRequesting, secondListFinraSuccess
} from '../../../../containers/finra/actions';
import ItemLiquidPolicyRate from './ItemLiquidPolicyRate';
import NodataSearch from '../../../noDataSearch';
import { numberFormatDecimal, StringToDouble, StringToInt } from '../../../../utils';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 400px )',
    height: 'auto',
    width: '800px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_liq_policy_req',
    messageSuccess: 'txt_mm_create_liq_policy_success',
    cmd: 'MM.UPDATE_LIQUID_POLICY'
  },
  update: {
    messageRequest: 'txt_mm_update_liq_policy_req',
    messageSuccess: 'txt_mm_update_liq_policy_success',
    cmd: 'MM.UPDATE_LIQUID_POLICY'
  },
  delete: {
    messageRequest: 'txt_mm_delete_liq_policy_req',
    messageSuccess: 'txt_mm_delete_liq_policy_success',
    cmd: 'MM.DELETE_LIQUID_POLICY'
  },
  approve: {
    messageRequest: 'txt_mm_approve_liq_policy_req',
    messageSuccess: 'txt_mm_approve_liq_policy_success',
    cmd: 'MM.APPROVE_LIQUID_POLICY'
  },
}

function UpdateLiquidPolicy(props) {
  const [isApproved, setIsApproved] = useState(true);

  const dispatch = useDispatch();
  const preActionFinra = usePrevious(props.actionFinra)

  useEffect(() => {
    dispatch(actionFinraSuccess(undefined))
    dispatch(mainItemFinraSuccess(undefined))
    dispatch(secondListFinraSuccess(undefined))
    dispatch(change('UpdateLiquidPolicy', 'formType', 'DAY'));

    getDetailItem()
    getListRate()

    return () => {
      dispatch(actionFinraSuccess(undefined))
      dispatch(mainItemFinraSuccess(undefined))
      dispatch(secondListFinraSuccess(undefined))

      props.reset();
    };
  }, []);

  useEffect(() => {
    if (props.detailPolicy) {
      dispatch(change('UpdateLiquidPolicy', 'formLiquidPolicyCode', props.detailPolicy.C_LIQUID_CODE));
      dispatch(change('UpdateLiquidPolicy', 'formLiquidPolicyName', props.detailPolicy.C_LIQUID_NAME));
      dispatch(change('UpdateLiquidPolicy', 'formContent', props.detailPolicy.C_CONTENT));
      dispatch(change('UpdateLiquidPolicy', 'formType', props.detailPolicy.C_LIQUID_POLICY_TYPE));

      setIsApproved(props.detailPolicy.C_STATUS === 'DA_DUYET')
    }
  }, [props.detailPolicy])

  useEffect(() => {
    if (props.listRate) {
      dispatch(change('UpdateLiquidPolicy', 'formItems', props.listRate.map((item) => {
        return {
          fromValue: numberFormatDecimal(item.C_FROM_VALUE),
          toValue: numberFormatDecimal(item.C_TO_VALUE),
          month: item.C_MONTH_VALUE,
          rateValue: numberFormatDecimal(item.C_LIQUID_RATE),
        }
      })));
    }
  }, [props.listRate])

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      props.onClose()
    }
  }, [props.actionFinra])

  const getDetailItem = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_ITEM_LIQUID_POLICY',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId
      },
    };

    dispatch(mainItemFinraRequesting(params));
  }

  const getListRate = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_ALL_RATE_POLICY',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
        PAGE: 1,
        RECORD_PER_PAGE: 999
      },
    };

    dispatch(secondListFinraRequesting(params));
  }

  function submit(value) {
    const data = {
      ITEM_ID: props.itemId,
      LIQUID_CODE: value.formLiquidPolicyCode,
      LIQUID_NAME: value.formLiquidPolicyName,
      LIQUID_POLICY_TYPE: value.formType,
      CONTENT: value.formContent,
      RATE: value.formItems.map((item) => {
        return {
          FROM_VALUE: StringToInt(item.fromValue),
          TO_VALUE: StringToInt(item.toValue),
          MONTH_VALUE: item.month,
          LIQUID_RATE: StringToDouble(item.rateValue),
        }
      })
    }

    if (props.itemId) {
      handleButtonAction('update', data)
    } else {
      handleButtonAction('create', data)
    }
  }

  function handleButtonAction(action, data) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (['create', 'update'].includes(action)) {
                  handleUpdateCall(action, data)
                } else if(action = 'approve'){
                  handleActionApprove();
                } else {
                  handleActionDel();
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  const handleUpdateCall = (action, data) => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification[action].cmd,
      group: 'LIST',
      data: data,
    };

    props.onSetMessageContent(configNotification[action].messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  function handleActionDel() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification.delete.cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
      },
    };

    props.onSetMessageContent(configNotification.delete.messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  function handleActionApprove() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification.approve.cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
        NEW_STATUS: 'DA_DUYET'
      },
    };

    props.onSetMessageContent(configNotification.approve.messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  const { handleSubmit, submitting, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t((props.itemId && isApproved) ? 'txt_finra_modal_update_liquid_policy' : 'txt_finra_modal_create_liquid_policy')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt_finra_form_upd_lp_code')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formLiquidPolicyCode"
                    className="form-control input-order fz-13 text-uppercase"
                    component={RenderInput}
                    validate={[required]}
                    disabled={props.itemId && isApproved}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>
                    {t('txt_finra_form_upd_lp_name')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formLiquidPolicyName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                    disabled={props.itemId && isApproved}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    Loại
                  </Form.Label>
                  <Field
                    name="formType"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderNormalSelect}
                    opts={[
                      {value: 'DAY', label: 'Từng ngày'},
                      {value: 'MONTH', label: 'Tháng'},
                    ]}
                    required
                    disabled={props.itemId && isApproved}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <div className={'custom-tabs-content my-3 py-1 px-3'}>
                    <Table bordered>
                      <thead>
                      <tr>
                        <th>#</th>
                        {props.formType === 'DAY' && <Fragment>
                          <th>{t('txt_finra_form_upd_lp_from_value')}</th>
                          <th>{t('txt_finra_form_upd_lp_to_value')}</th>
                        </Fragment>}
                        {props.formType === 'MONTH' &&
                          <th>{t('txt_finra_form_upd_lp_month')}</th>
                        }
                        <th>{t('txt_finra_form_upd_lp_rate_value')}</th>
                        <th>{t('txt-action')}</th>
                      </tr>
                      </thead>
                      <tbody>
                      <FieldArray
                        formType={props.formType}
                        termLiquidPolicy={props.termLiquidPolicy}
                        itemId={props.itemId}
                        isApproved={isApproved}
                        name="formItems"
                        component={ItemLiquidPolicyRate} />
                      </tbody>
                    </Table>

                    {/*<NodataSearch />*/}
                  </div>
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt_finra_form_upd_lp_content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                    disabled={props.itemId && isApproved}
                  />
                </Form.Group>

                <Form.Label>
                  {t('txt-creator')}: {props.itemId ? props.detailPolicy?.C_CREATOR_CODE : ''}
                </Form.Label>
                <Form.Label style={{ gridColumn: '3/5' }}>
                  {t('txt-create-time')} : {props.itemId ? props.detailPolicy?.C_CREATE_TIME : ''}
                </Form.Label>
                <Form.Label>
                  {t('txt-approver')} : {props.itemId ? props.detailPolicy?.C_APPROVER_CODE : ''}
                </Form.Label>
                <Form.Label style={{ gridColumn: '3/5' }}>
                  {t('txt-approve-time')} : {props.itemId ? props.detailPolicy?.C_APPROVE_TIME : ''}
                </Form.Label>
                
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5'
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {props.accRight?.C_APPROVE === 1 && Boolean(props.itemId) && !isApproved && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleButtonAction('approve')}
                    className="success mr-2"
                  >
                    {t('txt-appr')}
                  </BtnSubmit>
                )}
              </div>
              <div className="d-flex">
                {props.accRight?.C_UPDATE === 1 && Boolean(props.itemId) && !isApproved && (
                  <BtnSubmit
                    type="button"
                    onClick={() => handleButtonAction('delete')}
                    className="mr-2 danger"
                  >
                    {t('txt-del')}
                  </BtnSubmit>
                )}
              </div>
              <div className="d-flex">
                {props.accRight?.C_UPDATE === 1 && Boolean(props.itemId) && !isApproved && (
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-edit')}
                  </BtnSubmit>
                )}
              </div>
              <div className="d-flex">
                {props.accRight?.C_UPDATE === 1 && !props.itemId && (
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-add')}
                  </BtnSubmit>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal >
  );
}

UpdateLiquidPolicy = reduxForm({
  form: 'UpdateLiquidPolicy',
  enableReinitialize: true
})(UpdateLiquidPolicy);

const selector = formValueSelector('UpdateLiquidPolicy');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  const {
    formLiquidPolicyCode,
    formLiquidPolicyName,
    formContent,
    formItems,
    formType,
  } = selector(
    state,
    'formLiquidPolicyCode',
    'formLiquidPolicyName',
    'formContent',
    'formItems',
    'formType',
  );

  return {
    token: getToken(state),
    accRight: makeGetAccountRight()(state),
    actionFinra: makeGetActionFinra()(state),
    detailPolicy: makeGetMainDetailFinra()(state),
    listRate: makeGetSecondListFinra()(state),
    termLiquidPolicy: makeGetTermLiquidPolicyFinra()(state),

    formLiquidPolicyCode,
    formLiquidPolicyName,
    formContent,
    formItems,
    formType,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(UpdateLiquidPolicy)
);
