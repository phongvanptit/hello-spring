import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { translate } from 'react-i18next';
import { BtnSubmit } from '../../../../utils/styledComponent';
import React, { Fragment } from 'react';
import RenderInput from '../../../input/renderInput';
import { Field } from 'redux-form';
import { GroupButton } from 'utils/styledComponent';
import { required } from '../../../../utils/validation';
import RenderInputMask from '../../../input/renderInputMask';
import RenderNormalSelect from '../../../input/renderNormalSelect';

let ItemLiquidPolicyRate = (props) => {
  const t = props.t

  console.log(props);

  const handleAddItem = () => {
    props.fields.push({})
  }

  const handleRemoveItem = (index) => {
    props.fields.remove(index)
  }

  return (
    <Fragment>
      {props.fields.map((item, index) => {
        return (
          <tr key={index}>
            <td className={'text-center'}>{index + 1}</td>
            {props.formType === 'DAY' && <Fragment>
              <td>
                <Field
                  name={`${item}.fromValue`}
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderInputMask}
                  validate={[required]}
                  disabled={props.itemId && props.isApproved}
                />
              </td>
              <td>
                <Field
                  name={`${item}.toValue`}
                  className="form-control input-order fz-13"
                  classParent="w-100"
                  component={RenderInputMask}
                  validate={[required]}
                  disabled={props.itemId && props.isApproved}
                />
              </td>
            </Fragment>}
            {props.formType === 'MONTH' && <td>
              <Field
                name={`${item}.month`}
                className="form-control input-order fz-13"
                classParent="w-100"
                component={RenderNormalSelect}
                validate={[required]}
                disabled={props.itemId && props.isApproved}
                opts={props.termLiquidPolicy}
              />
            </td>}
            <td>
              <Field
                name={`${item}.rateValue`}
                className="form-control input-order fz-13"
                classParent="w-100"
                component={RenderInputMask}
                validate={[required]}
                disabled={props.itemId && props.isApproved}
                allowDecimal
                decimalLimit={6}
              />
            </td>
            <td>
              <GroupButton>
                <a
                  title={t('txt-del')}
                  rel="noreferrer noopener"
                  className={(props.itemId && props.isApproved) ? 'disabled' : ''}
                  onClick={() => (props.itemId && props.isApproved) ? undefined : handleRemoveItem(index)}
                >
                  <IconTrash />
                </a>
              </GroupButton>
            </td>
          </tr>
        )
      })}

      {!(props.itemId && props.isApproved) && <tr>
        <td colSpan={6}>
          <div style={{ display: 'flex', justifyContent: 'right' }}>
            <BtnSubmit
              type="button"
              onClick={() => handleAddItem()}
              className="primary py-1 px-3"
            >
              {t('btn_finra_add_policy')}
            </BtnSubmit>
          </div>
        </td>
      </tr>}
    </Fragment>
  )
}

export default translate('translations')(ItemLiquidPolicyRate);