import RenderArea from 'components/input/renderArea';
import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';
import renderNewInput from 'components/input/renderNewInput';
import renderNewInputMkt from 'components/input/renderNewInputMkt';
import renderNewInputPartner from 'components/input/renderNewInputPartner';
import * as _ from 'lodash';
import {
  makeGetAccountRight,
  makeGetActionFinra,
  makeGetContractCodeFinra,
  makeGetCustomerDetail, makeGetMainDetailFinra, makeGetMainListFinra, makeGetMMSinglePartner,
  makeGetSingleUserFront,
  makeGetSystemInfo,
  makeGetToken
} from 'lib/selector';
import React, { useEffect, useState } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { _diff2Date, formatDate, stringToDate } from 'utils';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import { lengthRequired, required } from 'utils/validation';
import {
  actionFinraRequesting,
  actionFinraSuccess,
  getContractCodeRequesting, getContractCodeSuccess, mainItemFinraRequesting, mainItemFinraSuccess, mainListFinraSuccess
} from '../../../../containers/finra/actions';
import { cashBalanceRequest, cashBalanceSuccess } from '../../../../containers/cash/actions';
import { custDetailRequest, custDetailSuccess } from '../../../../containers/customer/actions';
import { singleUserFrontRequest, singleUserFrontSuccess } from '../../../../containers/account/actions';
import { confirmAlert } from 'react-confirm-alert';
import { mmSinglePartnerRequest, mmSinglePartnerSuccess } from '../../../../containers/product/actions';
ReactModal.setAppElement('#root');

//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 5px 10px;
    padding: 0 10px 10px 10px;
    input.form-control,
    label {
        font-size: 13px;
    }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const validate = (values) => {
  const errors = {};
  const { formOpenDate, formExpireDate } = values;

  if (
    formOpenDate &&
    formExpireDate &&
    _diff2Date(formOpenDate, formExpireDate) > 0
  ) {
    errors.formExpireDate = `Ngày không hợp lệ`;
  }

  return errors;
};

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_contract_req',
    messageSuccess: 'txt_mm_create_contract_success',
    cmd: 'MM.UPDATE_CONTRACT_BASE'
  },
  update: {
    messageRequest: 'txt_mm_update_contract_req',
    messageSuccess: 'txt_mm_update_contract_success',
    cmd: 'MM.UPDATE_CONTRACT_BASE'
  },
  delete: {
    messageRequest: 'txt_mm_delete_contract_req',
    messageSuccess: 'txt_mm_delete_contract_success',
    cmd: 'MM.DELETE_CONTRACT_BASE'
  },
  approve: {
    messageRequest: 'txt_mm_approve_contract_req',
    messageSuccess: 'txt_mm_approve_contract_success',
    cmd: 'MM.APPROVE_CONTRACT_BASE'
  },
  un_approve: {
    messageRequest: 'txt_mm_unapprove_contract_req',
    messageSuccess: 'txt_mm_unapprove_contract_success',
    cmd: 'MM.UNAPPROVE_CONTRACT_BASE'
  }
}

function UpdateContract(props) {
  const { handleSubmit, submitting, onClose, t } = props;

  const [isInitLoad, setIsInitLoad] = useState(true);

  const dispatch = useDispatch();

  const preActionFinra = usePrevious(props.actionFinra)

  useEffect(() => {
    if (props.itemId) {
      getDetailContract()
    } else {
      initForm();
    }

    return () => {
      dispatch(custDetailSuccess(undefined))
      dispatch(cashBalanceSuccess(undefined))
      dispatch(singleUserFrontSuccess(undefined))
      dispatch(getContractCodeSuccess(undefined))
      dispatch(actionFinraSuccess(undefined))
      dispatch(mainItemFinraSuccess(undefined))

      props.reset();
    };
  }, []);

  useEffect(() => {
    if (props.formCustomerCode) {
      getInformationCustomer()
      getCashBalance()
      getContractCode()
    } else {
      dispatch(custDetailSuccess(undefined))
      dispatch(cashBalanceSuccess(undefined))
      dispatch(getContractCodeSuccess(undefined))

      dispatch(change('UpdateContract', 'formMktId', ''));
      dispatch(change('UpdateContract', 'formContractCode', ''));
    }
  }, [props.formCustomerCode]);

  useEffect(() => {
    if (props.infoCustomer) {
      dispatch(change('UpdateContract', 'formMktId', props.infoCustomer.C_MARKETING_ID));
    }
  }, [props.infoCustomer]);

  useEffect(() => {
    if (props.formMktId) {
      getMarketingId()
    } else {
      dispatch(singleUserFrontSuccess(undefined))
    }
  }, [props.formMktId]);

  useEffect(() => {
    if (props.formPartnerCode) {
      getInformationPartner()
    } else {
      dispatch(mmSinglePartnerSuccess(undefined))
    }
  }, [props.formPartnerCode]);

  useEffect(() => {
    if (props.contractCode) {
      dispatch(change('UpdateContract', 'formContractCode', props.contractCode.C_CONTRACT_CODE));
    }
  }, [props.contractCode]);

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      props.onClose()
    }
  }, [props.actionFinra])

  useEffect(() => {
    if (props.mainItemFinra) {
      dispatch(change('UpdateContract', 'formCustomerCode', props.mainItemFinra.C_CUSTOMER_CODE));
      dispatch(change('UpdateContract', 'formOpenDate', props.mainItemFinra.C_OPEN_DATE));
      dispatch(change('UpdateContract', 'formExpireDate', props.mainItemFinra.C_EXPIRE_DATE));
      dispatch(change('UpdateContract', 'formPartnerCode', props.mainItemFinra.C_PARTNER_CODE));
      dispatch(change('UpdateContract', 'formContent', props.mainItemFinra.C_CONTENT));
    }

    setIsInitLoad(false)
  }, [props.mainItemFinra]);

  const getDetailContract = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_SINGLE_CONTRACT_BASE',
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
      },
    };
    dispatch(mainItemFinraRequesting(params));
  }

  const getInformationCustomer = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: props.formCustomerCode,
      },
    };
    dispatch(custDetailRequest(params));
  }

  const getCashBalance = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'BACK.GET_CASH_BALANCE',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: props.formAccountCode,
      },
    };
    dispatch(cashBalanceRequest(params));
  }

  const getContractCode = () => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_CONTRACT_BASE_CODE',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: props.formCustomerCode,
      },
    };
    dispatch(getContractCodeRequesting(params))
  }

  function getMarketingId() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_USER_FRONT',
      group: 'LIST',
      data: {
        USER_ID: props.formMktId,
      },
    };
    dispatch(singleUserFrontRequest(params));
  }

  function getInformationPartner() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_SINGLE_PARTNER',
      group: 'LIST',
      data: {
        ITEM_ID: props.formPartnerCode,
      },
    };
    dispatch(mmSinglePartnerRequest(params));
  }

  const initForm = () => {
    dispatch(change('UpdateContract', 'formOpenDate', formatDate(stringToDate(props.sysSystemInfo?.C_T_DATE, 'dmy'), '/', 'dmy')));
  }

  const handleButtonAction = (action) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (['create', 'update'].includes(action)) {
                  updateContract(action)
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  const submit = () => {
    handleButtonAction(props.itemId ? 'update' : 'create')
  }

  const updateContract = (type) => {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification[type].cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.itemId,
        CUSTOMER_CODE: props?.formCustomerCode.toUpperCase(),
        CONTRACT_CODE: props?.formContractCode,
        OPEN_DATE: props?.formOpenDate,
        EXPIRE_DATE: props?.formExpireDate,
        PARTNER_CODE: props?.formPartnerCode,
        CONTENT: props?.formContent,
      },
    };
    props.onSetMessageContent(configNotification[type].messageSuccess)
    dispatch(actionFinraRequesting(params))
  }

  console.log(props.mainItemFinra?.C_STATUS === 'CHUA_DUYET')
  console.log(props.accRight?.C_UPDATE === 1, Boolean(props.itemId), props.mainItemFinra?.C_STATUS === 'CHUA_DUYET');

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t(props.itemId ? 'txt_finra_modal_update_contract' : 'txt_finra_modal_create_contract')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-cust-code')} </Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formCustomerCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={renderNewInput}
                    validate={[required, length7]}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={props.infoCustomer?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-contract-no')}</Form.Label>
                  <Field
                    name="formContractCode"
                    className="form-control input-order"
                    component={RenderInput}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    value={props.infoCustomer?.C_CARD_ID || ''}
                    className="input-order "
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    value={props.infoCustomer?.C_ISSUE_DATE || ''}
                    className="input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-place')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={props.infoCustomer?.C_ISSUE_PLACE_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>Địa chỉ</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={props.infoCustomer?.C_CUST_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>
                {/* <Form.Group>
                  <Form.Label>{t('txt-subBranch')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={props.infoCustomer?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-acc-depository')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={props.infoCustomer?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group> */}

                <Form.Group>
                  <Form.Label>
                    {t('txt-marketing-id')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formMktId"
                    className="form-control input-order"
                    classParent="w-100"
                    component={renderNewInputMkt}
                    validate={required}
                    disabled={true}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-marketing-name')}</Form.Label>
                  <Form.Control
                    value={props.singleUserFront?.C_FRONT_USER_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-borrower-code')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPartnerCode"
                    className="form-control input-order"
                    classParent="w-100"
                    component={renderNewInputPartner}
                    validate={required}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-borrower-name')}</Form.Label>
                  <Form.Control
                    value={props.detailPartner?.C_PARTNER_NAME || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-open-date')}</Form.Label>
                  <span className="text-danger">*</span>
                  <Field
                    name="formOpenDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    validate={required}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-expire-date')}</Form.Label>
                  <Field
                    name="formExpireDate"
                    className="form-control input-order "
                    classParentName="w-100"
                    component={RenderSelectDate}
                    minDate={
                      props.formOpenDate && !props.formOpenDate.includes('_')
                        ? props.formOpenDate
                        : null
                    }
                  />
                </Form.Group>
                {/*<Form.Group>*/}
                {/*  <Form.Label>{t('txt-channel')}</Form.Label>*/}
                {/*  <Field*/}
                {/*    name={`formChannel`}*/}
                {/*    className="form-control"*/}
                {/*    component={RenderNormalSelect}*/}
                {/*    opts={props.glChannelType}*/}
                {/*  />*/}
                {/*</Form.Group>*/}
                {/*<Form.Group className="d-flex align-items-end">*/}
                {/*  <label>*/}
                {/*    <Field*/}
                {/*      name="formDocument"*/}
                {/*      component="input"*/}
                {/*      type="checkbox"*/}
                {/*    />{' '}*/}
                {/*    {t('txt-original-contract')}*/}
                {/*  </label>*/}
                {/*</Form.Group>*/}

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                {/* Khai báo người các kiểu */}
                <Form.Label>
                  {t('txt-creator')} : {props.itemId ? props.mainItemFinra?.C_CREATOR_CODE : ''}
                </Form.Label>
                <Form.Label>
                  {t('txt-create-time')} : {props.itemId ? props.mainItemFinra?.C_CREATE_TIME : ''}
                </Form.Label>
                <Form.Label className='mx-5'>
                  {t('txt-approver')} : {props.itemId ? props.mainItemFinra?.C_APPROVER_CODE : ''}
                </Form.Label>
                <Form.Label>
                  {t('txt-approve-time')} : {props.itemId ? props.mainItemFinra?.C_APPROVE_TIME : ''}
                </Form.Label>

              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5'
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>

              <div className="d-flex">
                {props.accRight?.C_UPDATE === 1 && Boolean(props.itemId) && props.mainItemFinra?.C_STATUS === 'CHUA_DUYET' && (
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-edit')}
                  </BtnSubmit>
                )}
              </div>

              <div className="d-flex">
                {props.accRight?.C_UPDATE === 1 && !props.itemId && (
                  <BtnSubmit type="submit" disabled={submitting}>
                    {t('txt-add')}
                  </BtnSubmit>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

UpdateContract = reduxForm({
  form: 'UpdateContract',
  enableReinitialize: true,
  validate
})(UpdateContract);

const selector = formValueSelector('UpdateContract');

const mapStateToProps = (state) => {
  const {
    formCustomerCode,
    formContractCode,
    formMktId,
    formOpenDate,
    formExpireDate,
    formPartnerCode,
    formDocument,
    formChannel,
    formContent
  } = selector(
    state,
    'formCustomerCode',
    'formContractCode',
    'formMktId',
    'formOpenDate',
    'formExpireDate',
    'formPartnerCode',
    'formDocument',
    'formChannel',
    'formContent'
  );

  return {
    token: makeGetToken()(state),
    accRight: makeGetAccountRight()(state),
    sysSystemInfo: makeGetSystemInfo()(state),
    infoCustomer: makeGetCustomerDetail()(state),
    contractCode: makeGetContractCodeFinra()(state),
    singleUserFront: makeGetSingleUserFront()(state),
    actionFinra: makeGetActionFinra()(state),
    mainItemFinra: makeGetMainDetailFinra()(state),
    detailPartner: makeGetMMSinglePartner()(state),
    formCustomerCode,
    formContractCode,
    formMktId,
    formOpenDate,
    formExpireDate,
    formPartnerCode,
    formDocument,
    formChannel,
    formContent,
  };
};

export default connect(mapStateToProps)(
  translate('translations')(UpdateContract)
);
