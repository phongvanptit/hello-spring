import RenderArea from '../../../input/renderArea';
import RenderInput from '../../../input/renderInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import RenderSelectSubBranch from '../../../input/renderSelectSubBranch';
import RenderSuggestBank from '../../../input/renderSuggestBank';
import { setToast } from '../../../../containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';

import renderNewInput from '../../../input/renderNewInput';
import {
  custDetailRequest,
  custDetailSuccess,
} from '../../../../containers/customer/actions';
import { mmUpdPartnerRequest } from '../../../../containers/product/actions';
import {
  makeActionFinra, makeGetActionFinra,
  makeGetAllSubBranch,
  makeGetCustomerDetail,
  makeGetMMUpdPartner,
  makeGetProvinceList,
  makeGetToken
} from '../../../../lib/selector';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import { actionFinraRequesting, actionFinraSuccess } from '../../../../containers/finra/actions';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const configNotification = {
  create: {
    messageRequest: 'txt_mm_create_partner_req',
    messageSuccess: 'txt_mm_create_partner_success',
    cmd: 'MM.UPDATE_PARTNER'
  }
}

function AddDoiTuongVayModal(props) {
  const preActionFinra = usePrevious(props.actionFinra);
  const preCustomerCode = usePrevious(props.formCustomerCode);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(custDetailSuccess(undefined));
    dispatch(actionFinraSuccess(undefined))

    return () => {
      dispatch(custDetailSuccess(undefined));
      dispatch(actionFinraSuccess(undefined))

      props.reset();
    };
  }, []);

  useEffect(() => {
    if (
      props.formCustomerCode &&
      props.formCustomerCode.length === 6 &&
      !_.isEqual(props.formCustomerCode, preCustomerCode)
    ) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [props.formCustomerCode]);

  function _handleCheckCustomer() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: props.formCustomerCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  useEffect(() => {
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      props.onClose()
    }
  }, [props.actionFinra]);

  function submit(_values) {
    if (!props.custDetail) {
      _handleToast(`${t(configNotification.create.messageRequest)}`, 'error');
      return;
    }

    handleActionApprove();
  }

  function handleActionApprove() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification.create.cmd,
      group: 'LIST',
      data: {
        ITEM_ID: '',
        PARTNER_CODE: props?.formPartnerCode.toUpperCase(),
        PARTNER_NAME: props?.formPartnerName,
        CUSTOMER_CODE: props?.formCustomerCode,
        BANK_ACCOUNT: props?.formBankAccountCode,
        BANK_CODE: props?.formBankCode,
        BANK_BRANCH_CODE: props?.formBankBranch,
        PROVINCE_CODE: props?.formProvince,
        NOTE: props?.formContent,
      },
    };

    props.onSetMessageContent(configNotification.create.messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  function _handleAddCallback() { }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-add-borrower-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-borrower-code')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPartnerCode"
                    className="form-control input-order fz-13 text-uppercase"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>
                    {t('txt-borrower-name')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPartnerName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}

                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-cust-code')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formCustomerCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={renderNewInput}
                    validate={[required, length7]}
                    fnAddCallback={_handleAddCallback}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={props.custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order fz-13"
                    value={props.custDetail?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    value={props.custDetail?.C_CARD_ID || ''}
                    className="input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    value={props.custDetail?.C_ISSUE_DATE || ''}
                    className="input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={props.custDetail?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>

                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-target-info-1')}
                </p>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-target-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-bank')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formBankCode"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBank}
                    validate={[required]}
                    fnAddCallback={_handleAddCallback}
                    index="2"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-province-city')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProvince"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={props.glProvince}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-branch')}{''}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankBranch"
                    className="form-control input-order fz-13"
                    component={RenderSelectSubBranch}
                    bankCode={props.formBankCode}
                    provinceCode={props.formProvince}
                    opts={props.glAllSubBranch}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                <BtnSubmit type="submit" disabled={submitting}>
                  {t('txt-accept')}
                </BtnSubmit>
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

AddDoiTuongVayModal = reduxForm({
  form: 'addPartnerModal',
  enableReinitialize: true,
})(AddDoiTuongVayModal);

const selector = formValueSelector('addPartnerModal');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getActionFinra = makeGetActionFinra();
  const getCustomerDetail = makeGetCustomerDetail();
  const getProvinceList = makeGetProvinceList();
  const getAllSubBranch = makeGetAllSubBranch();

  const {
    formPartnerCode,
    formPartnerName,
    formCustomerCode,
    formBankAccountCode,
    formBankCode,
    formProvince,
    formBankBranch,
    formContent,
  } = selector(
    state,
    'formPartnerCode',
    'formPartnerName',
    'formCustomerCode',
    'formBankAccountCode',
    'formBankCode',
    'formProvince',
    'formBankBranch',
    'formContent'
  );

  return {
    token: getToken(state),
    actionFinra: getActionFinra(state),
    custDetail: getCustomerDetail(state),
    glProvince: getProvinceList(state),
    glAllSubBranch: getAllSubBranch(state),
    formPartnerCode,
    formPartnerName,
    formCustomerCode,
    formBankAccountCode,
    formBankCode,
    formProvince,
    formBankBranch,
    formContent,

  };
};

export default connect(mapStateToProps)(
  translate('translations')(AddDoiTuongVayModal)
);
