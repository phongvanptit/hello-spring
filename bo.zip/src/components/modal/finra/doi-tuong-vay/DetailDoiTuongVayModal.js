import RenderArea from '../../../input/renderArea';
import RenderInput from '../../../input/renderInput';
import RenderNormalSelect from '../../../input/renderNormalSelect';
import RenderSelectSubBranch from '../../../input/renderSelectSubBranch';
import RenderSuggestBank from '../../../input/renderSuggestBank';
import { setToast } from '../../../../containers/client/actions';
import * as _ from 'lodash';
import React, { useEffect } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { FaTimes } from 'react-icons/fa';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';
import { Field, change, formValueSelector, reduxForm } from 'redux-form';
import styled from 'styled-components';
import { lengthRequired, required } from '../../../../utils/validation';

import renderNewInput from '../../../input/renderNewInput';
import {
  custDetailRequest,
  custDetailSuccess,
} from '../../../../containers/customer/actions';
import {
  mmDelPartnerRequest,
  mmSinglePartnerRequest,
  mmSinglePartnerSuccess,
  mmUpdPartnerRequest
} from '../../../../containers/product/actions';
import {
  makeGetAccountRight,
  makeGetActionFinra,
  makeGetAllSubBranch,
  makeGetCustomerDetail, makeGetMainDetailFinra,
  makeGetMMDelPartner,
  makeGetMMSinglePartner,
  makeGetMMUpdPartner,
  makeGetProvinceList,
  makeGetToken
} from '../../../../lib/selector';
import { confirmAlert } from 'react-confirm-alert';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { BtnClose, BtnSubmit } from '../../../../utils/styledComponent';
import {
  actionFinraRequesting,
  actionFinraSuccess,
  mainItemFinraRequesting,
  mainItemFinraSuccess
} from '../../../../containers/finra/actions';
ReactModal.setAppElement('#root');
//#region styled

const customStyles = {
  content: {
    top: '40px',
    bottom: 'auto',
    left: 'calc( 50% - 500px )',
    height: 'auto',
    width: '1000px',
    padding: '0',
    borderWidth: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

const StyleContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #fff;
  padding: 0.5rem 0.5rem 1rem 0.5rem;
`;

const FormAdd = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px 10px;
  padding: 0 10px 10px 10px;
  input.form-control,
  label {
    font-size: 13px;
  }
`;

const length7 = lengthRequired(6);

//#endregion
function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

const configNotification = {
  update: {
    messageRequest: 'txt_mm_update_partner_req',
    messageSuccess: 'txt_mm_update_partner_success',
    cmd: 'MM.UPDATE_PARTNER'
  },
  delete: {
    messageRequest: 'txt_mm_delete_partner_req',
    messageSuccess: 'txt_mm_delete_partner_success',
    cmd: 'MM.DELETE_PARTNER'
  }
}

function DetailDoiTuongVayModal(props) {
  const dispatch = useDispatch();
  const {

  } = props;

  const preActionFinra = usePrevious(props.actionFinra);
  const preCustomerCode = usePrevious(props.formCustomerCode);

  useEffect(() => {
    dispatch(custDetailSuccess(undefined));
    dispatch(mainItemFinraSuccess(undefined));
    dispatch(actionFinraSuccess(undefined));

    getSinglePartner();

    return () => {
      dispatch(custDetailSuccess(undefined));
      dispatch(mainItemFinraSuccess(undefined));
      dispatch(actionFinraSuccess(undefined));

      props.reset();
    };
  }, []);

  React.useEffect(() => {
    console.log(props.detailPartner);

    if (props.detailPartner) {
      dispatch(change('detailPartnerModal','formPartnerCode',props.detailPartner.C_PARTNER_CODE));
      dispatch(change('detailPartnerModal','formPartnerName',props.detailPartner.C_PARTNER_NAME));
      dispatch(change('detailPartnerModal','formCustomerCode',props.detailPartner.C_CUSTOMER_CODE));
      dispatch(change('detailPartnerModal','formBankAccountCode',props.detailPartner.C_BANK_ACCOUNT));
      dispatch(change('detailPartnerModal','formBankCode',props.detailPartner.C_BANK_CODE));
      dispatch(change('detailPartnerModal','formProvince',props.detailPartner.C_PROVINCE_CODE));
      dispatch(change('detailPartnerModal','formBankBranch',props.detailPartner.C_BANK_BRANCH_CODE));
      dispatch(change('detailPartnerModal','formContent',props.detailPartner.C_NOTE));
    }
  }, [props.detailPartner]);

  React.useEffect(() => {
    if (
      props.formCustomerCode &&
      props.formCustomerCode.length === 6 &&
      !_.isEqual(props.formCustomerCode, preCustomerCode)
    ) {
      _handleCheckCustomer();
    } else dispatch(custDetailSuccess(null));
  }, [props.formCustomerCode]);

  function getSinglePartner() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'MM.GET_SINGLE_PARTNER',
      group: 'LIST',
      data: {
        ITEM_ID: props.pk,
      },
    };

    dispatch(mainItemFinraRequesting(params));
  }

  function _handleCheckCustomer() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: 'BACK.GET_SINGLE_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_ID: props.formCustomerCode,
      },
    };

    dispatch(custDetailRequest(params));
  }

  useEffect(() => {
    console.log(props.actionFinra, preActionFinra);
    if (props.actionFinra && !_.isEqual(props.actionFinra, preActionFinra)) {
      props.onComplete()
      props.onClose();
    }
  }, [props.actionFinra]);

  function submit(_values) {
    if (!props.custDetail) {
      _handleToast(`${t('txt-no-data-cust')}`, 'error');
      return;
    }

    handleButtonAction('update');
  }

  function handleActionApprove() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification.update.cmd,
      group: 'LIST',
      data: {
        ITEM_ID: props.pk,
        PARTNER_CODE: props?.formPartnerCode.toUpperCase(),
        PARTNER_NAME: props?.formPartnerName,
        CUSTOMER_CODE: props?.formCustomerCode,
        BANK_ACCOUNT: props?.formBankAccountCode,
        BANK_CODE: props?.formBankCode,
        BANK_BRANCH_CODE: props?.formBankBranch,
        PROVINCE_CODE: props?.formProvince,
        NOTE: props?.formContent,
      },
    };

    props.onSetMessageContent(configNotification.update.messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  function handleButtonAction(action) {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>{t(configNotification[action].messageRequest)}</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                if (action === 'update') {
                  handleActionApprove()
                } else {
                  handleActionDel();
                }

                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionDel() {
    const params = {
      user: props.token?.USER_NAME,
      session: props.token?.SESSION_ID,
      cmd: configNotification.delete.cmd,
      group: 'LIST',
      data: {
        LIST_ITEM_ID: props.pk,
      },
    };

    props.onSetMessageContent(configNotification.delete.messageSuccess)
    dispatch(actionFinraRequesting(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };
  const { handleSubmit, submitting, onClose, t } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0 rounded"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        <div className="py-2 d-flex justify-content-between">
          <b className="fz-16 pl-3">{t('txt-detail-borrower-info')}</b>
          <a onClick={onClose} className="pr-3">
            <FaTimes />
          </a>
        </div>
        <StyleContainer>
          <form onSubmit={handleSubmit(submit)}>
            <PerfectScrollbar style={{ maxHeight: 'calc(100vh - 215px)' }}>
              <FormAdd>
                <Form.Group>
                  <Form.Label>
                    {t('txt-borrower-code')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPartnerCode"
                    className="form-control input-order fz-13 text-uppercase"
                    component={RenderInput}
                    validate={[required]}
                    disabled
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>
                    {t('txt-borrower-name')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formPartnerName"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>{t('txt-cust-code')}</Form.Label>
                  <Field
                    name="formCustomerCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={renderNewInput}
                    validate={[required, length7]}
                    fnAddCallback={() => { }}
                    index="3"
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '2/4' }}>
                  <Form.Label>{t('txt-cust-name')}</Form.Label>
                  <Form.Control
                    value={props.custDetail?.C_CUSTOMER_NAME || ''}
                    disabled
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-marketing-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    className="input-order fz-13"
                    value={props.custDetail?.C_MARKETING_ID || ''}
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-card-id')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    value={props.custDetail?.C_CARD_ID || ''}
                    className="input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>{t('txt-issue-date')}</Form.Label>
                  <Form.Control
                    type={'text'}
                    value={props.custDetail?.C_ISSUE_DATE || ''}
                    className="input-order "
                    disabled
                  />
                </Form.Group>
                <Form.Group style={{ gridColumn: '3/5' }}>
                  <Form.Label>{t('txt-address')}</Form.Label>
                  <input
                    type={'text'}
                    className="form-control input-order fz-13"
                    value={props.custDetail?.C_RESEDENCE_ADDRESS || ''}
                    disabled
                  />
                </Form.Group>

                <p
                  style={{ gridColumn: '1/5' }}
                  className="color-thm mb-0 fz-13"
                >
                  {t('txt-target-info-1')}
                </p>

                <Form.Group style={{ gridColumn: '1/2' }}>
                  <Form.Label>
                    {t('txt-target-acc')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankAccountCode"
                    className="form-control input-order fz-13"
                    classParent="w-100"
                    component={RenderInput}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Label>{t('txt-bank')}</Form.Label>{' '}
                  <span className="text-danger">*</span>
                  <Field
                    name="formBankCode"
                    className="form-control input-order fz-13"
                    component={RenderSuggestBank}
                    validate={[required]}
                    fnAddCallback={() => { }}
                    index="2"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-province-city')}{' '}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formProvince"
                    className="form-control input-order fz-13"
                    component={RenderNormalSelect}
                    opts={props.glProvince}
                    validate={[required]}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    {t('txt-branch')}
                    <span className="text-danger">*</span>
                  </Form.Label>
                  <Field
                    name="formBankBranch"
                    className="form-control input-order fz-13"
                    component={RenderSelectSubBranch}
                    bankCode={props.formBankCode}
                    provinceCode={props.formProvince}
                    opts={props.glAllSubBranch}
                    validate={[required]}
                  />
                </Form.Group>

                <Form.Group style={{ gridColumn: '1/5' }}>
                  <Form.Label>{t('txt-content')}</Form.Label>
                  <Field
                    name="formContent"
                    className="form-control input-order fz-13"
                    component={RenderArea}
                    rows={2}
                  />
                </Form.Group>
                <Form.Label>
                  {t('txt-creator')}: {props.detailPartner?.C_CREATOR_CODE}
                </Form.Label>
                <Form.Label>
                  {t('txt-create-time')} : {props.detailPartner?.C_CREATE_TIME}
                </Form.Label>
              </FormAdd>
            </PerfectScrollbar>
            <hr style={{ gridColumn: '1/5' }} />
            <div
              className="d-flex"
              style={{
                height: '30px',
                whiteSpace: 'nowrap',
                gridColumn: '1/5',
              }}
            >
              <BtnClose type="button" onClick={onClose} className="mr-auto">
                {t('txt-close')}
              </BtnClose>
              <div className="d-flex">
                {props.accRight?.C_UPDATE === 1 && (
                  <>
                    <BtnSubmit
                      type="button"
                      onClick={() => handleButtonAction('delete')}
                      className="mr-2 danger"
                    >
                      {t('txt-del')}
                    </BtnSubmit>

                    <BtnSubmit type="submit" disabled={submitting}>
                      {t('txt-edit')}
                    </BtnSubmit>
                  </>
                )}
              </div>
            </div>
          </form>
        </StyleContainer>
      </div>
    </ReactModal>
  );
}

DetailDoiTuongVayModal = reduxForm({
  form: 'detailPartnerModal',
  enableReinitialize: true,
})(DetailDoiTuongVayModal);

const selector = formValueSelector('detailPartnerModal');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getCustomerDetail = makeGetCustomerDetail();
  const getProvinceList = makeGetProvinceList();
  const getAllSubBranch = makeGetAllSubBranch();

  const {
    formPartnerCode,
    formPartnerName,
    formCustomerCode,
    formBankAccountCode,
    formBankCode,
    formProvince,
    formBankBranch,
    formContent,
  } = selector(
    state,
    'formPartnerCode',
    'formPartnerName',
    'formCustomerCode',
    'formBankAccountCode',
    'formBankCode',
    'formProvince',
    'formBankBranch',
    'formContent'
  );

  return {
    token: getToken(state),
    accRight: makeGetAccountRight()(state),
    actionFinra: makeGetActionFinra()(state),
    detailPartner: makeGetMainDetailFinra()(state),
    custDetail: getCustomerDetail(state),
    glProvince: getProvinceList(state),
    glAllSubBranch: getAllSubBranch(state),

    formPartnerCode,
    formPartnerName,
    formCustomerCode,
    formBankAccountCode,
    formBankCode,
    formProvince,
    formBankBranch,
    formContent,

  };
};

export default connect(mapStateToProps)(
  translate('translations')(DetailDoiTuongVayModal)
);
