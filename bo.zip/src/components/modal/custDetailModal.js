import React, { memo } from 'react';
import ReactModal from 'react-modal';

import { Card, Col } from 'react-bootstrap';
import { FaTimes, FaUserAlt } from 'react-icons/fa';

import PerfectScrollbar from 'react-perfect-scrollbar';

import * as _ from 'lodash';
import { numberFormat } from '../../utils';

ReactModal.setAppElement('#root');

const customStyles = {
  content: {
    top: '80px',
    left: '40px',
    right: '40px',
    height: 'auto',
    padding: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

function CustDetailModal({ onClose, custDetail }) {
  const __detail = custDetail && !!custDetail.length ? custDetail[0] : null;
  const __count =
    custDetail && !!custDetail.length ? custDetail[0].SOLUONGBANGHI : 0;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <Card className="w-100 p-3" style={{ overflow: 'hidden' }}>
        <Card.Header>Chi tiết lệnh</Card.Header>
        <hr className="w-50 light my-2" />
        <Card.Body className="pt-0 h-100 position-relative">
          <div className="w-100 d-flex flex-row">
            <Col md="3" className="p-0">
              <FaUserAlt style={{ fontSize: '75px' }} />
              <div className="d-grid">
                <span className="head font-weight-bold">{__detail?.TENKH}</span>
                <span className="sub-head fz-12">{__detail?.SOGIAYTO}</span>
                <span className="mt-1 fz-13">{__detail?.SDT} </span>
                <span className="mt-1 fz-13">{__detail?.NGAYSINH} </span>
                <span className="mt-1 fz-13">{__detail?.DIACHI} </span>
              </div>
            </Col>
            <Col md="9" className="p-0">
              <Card className="w-100">
                <Card.Body>
                  <Card.Title className="font-weight-bold text-uppercase fz-16 ">
                    Danh mục trái phiếu
                  </Card.Title>
                  <p>
                    <span className="pr-2">Tổng giá trị đầu tư:</span>
                    <span className="pr-5">
                      {numberFormat(__detail?.TONGGIATRI)} (triệu VNĐ)
                    </span>
                    <span className="pr-2">Tổng lợi tức dự kiến:</span>
                    <span>{numberFormat(__detail?.TONGLAI)} (VNĐ)</span>
                  </p>
                  <PerfectScrollbar style={{ height: 'calc(100vh - 285px)' }}>
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>STT</th>
                          <th>Mã TP</th>
                          <th>Số HĐ</th>
                          <th>Sản phẩm</th>
                          <th>Số lượng TP</th>
                          <th>Giá trị đầu tư</th>
                          <th>Kỳ hạn</th>
                          <th>Ngày đầu tư</th>
                          <th>Ngày đáo hạn</th>
                          <th>Trạng thái HĐ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {__count > 0 &&
                          custDetail &&
                          custDetail.map((item, index) => (
                            <tr key={index}>
                              <td className="text-center">{item.STT}</td>
                              <td className="text-center">{item.MATP}</td>
                              <td className="">{item.SOHD}</td>
                              <td className="text-center">{item.LOAISP}</td>
                              <td className="text-right">
                                {numberFormat(item.SOLUONG)}
                              </td>
                              <td className="text-right">
                                {numberFormat(item.GIATRIDAUTU)}
                              </td>
                              <td className="text-center">{item.KYHAN}</td>
                              <td className="text-center">{item.NGAYDAUTU}</td>
                              <td className="text-center">{item.NGAYDAOHAN}</td>
                              <td className="text-center">
                                {item.TRANGTHAIHD}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </Table>
                  </PerfectScrollbar>
                </Card.Body>
              </Card>
            </Col>
          </div>
        </Card.Body>
      </Card>

      <div
        onClick={onClose}
        style={{
          position: 'absolute',
          top: '-15px',
          right: '-15px',
          padding: '8px 12px',
          borderRadius: '50%',
          background: '#F14E63',
        }}
      >
        <FaTimes className="text-white" />
      </div>
    </ReactModal>
  );
}

export default memo(CustDetailModal);
