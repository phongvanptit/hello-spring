import { useEffect } from 'react';
import ReactModal from 'react-modal';
import { connect, useDispatch } from 'react-redux';

import { makeGetDelOrder, makeGetToken } from 'lib/selector';
import { Button, Card, Form } from 'react-bootstrap';

import { usePrevious } from 'lib/useHook';

import RenderInput from 'components/input/renderInput';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { required } from 'utils/validation';
ReactModal.setAppElement('#root');

const customStyles = {
  content: {
    top: '80px',
    bottom: 'auto',
    left: 'calc( 50% - 300px )',
    height: 'auto',
    width: '600px',
    padding: '0',
    borderColor: '#f3f3f3',
    overflow: 'inherit',
  },
};

function ConfirmModal(props) {
  const dispatch = useDispatch();

  const { onClose, token, orderDetail, delOrder } = props;

  const preDelOrder = usePrevious(delOrder);

  console.log(orderDetail);

  useEffect(() => {
    if (delOrder && !_.isEqual(delOrder, preDelOrder)) {
      _handleToast('Huỷ hơp đồng thành công!');
      props.reset();
      dispatch({ type: 'CLEAR_DEL_ORDER' });
    }
  }, [delOrder]);

  const _handleToast = (msg) => {
    // console.log(msg)
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type: 'success',
    };
    dispatch(setToast(toastMsg));
  };

  const submit = (values) => {
    console.log(values);
  };

  const { handleSubmit, pristine, submitting } = props;

  return (
    <ReactModal
      isOpen={true}
      contentLabel="onRequestClose Example"
      onRequestClose={onClose}
      shouldCloseOnOverlayClick={true}
      overlayClassName="overlay"
      style={customStyles}
    >
      <div
        className="w-100 p-0"
        style={{ maxHeight: 'calc(100vh - 120px)', overflow: 'hidden' }}
      >
        <p className="p-header fz-13 font-weight-bold py-2 text-center">
          Xác nhận huỷ
        </p>
        <Card.Body className="pt-0">
          <form onSubmit={handleSubmit(submit)}>
            <div
              className="info d-grid"
              style={{
                gridTemplateColumns: 'auto auto',
                gap: '10px',
              }}
            >
              <Form.Label className="fz-13">Số hợp đồng </Form.Label>
              <b className="fz-13">
                {orderDetail?.C_ORDER_NO || orderDetail?.SOHD}
              </b>

              <label className="fz-13 form-label">Lý do huỷ</label>
              <Field
                name="content"
                className="form-control"
                placeholder="Nhập lý do huỷ"
                component={RenderInput}
                validate={[required]}
              />
            </div>

            <div className="text-center mt-4">
              <Button variant="outline-info" className="mr-2" onClick={onClose}>
                Huỷ
              </Button>
              <Button type="submit" disabled={pristine || submitting}>
                Xác nhận
              </Button>
            </div>
          </form>
        </Card.Body>
      </div>
    </ReactModal>
  );
}

ConfirmModal = reduxForm({
  form: 'formConfirmDelOrder',
  enableReinitialize: true,
})(ConfirmModal);

const selector = formValueSelector('formConfirmDelOrder');

const mapStateToProps = (state) => {
  const getToken = makeGetToken();
  const getDelOrder = makeGetDelOrder();

  const { content, confirm } = selector(state, 'content', 'confirm');

  return {
    token: getToken(state),
    delOrder: getDelOrder(state),

    content,
    confirm,

    initialValues: {
      content: '',
      confirm: '',
    },
  };
};

export default connect(mapStateToProps)(ConfirmModal);
