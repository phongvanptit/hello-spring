import React from 'react';
import { Table } from 'react-bootstrap';
import { connect } from 'react-redux';

import Paging from 'components/paging';
import FormSearch from './formSearch';
import { makeGetBankGWMsgList } from 'lib/selector';
import NodataSearch from 'components/noDataSearch';
import { numberFormat } from 'utils';
import { translate } from 'react-i18next';
import PerfectScrollBar from 'react-perfect-scrollbar';

function DienNhanVe(props) {
  const [page, setPage] = React.useState(1);
  const [recordPerPage, setRecordPerPage] = React.useState(10);

  const { bankGWMsgList, t } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <PerfectScrollBar className="w-100">
        <Table bordered>
          <thead>
            <tr>
              <th>#</th>
              <th>Ngày GD</th>
              <th>Loại</th>
              <th>ID Ngân hàng</th>
              <th>Bút toán CTCK</th>
              <th>Số bút toán</th>
              <th>Tài khoản	</th>
              <th>Tên TK	</th>
              <th>Số tiền </th>
            
              <th>Trạng thái</th>
              <th>Thời gian trả	</th>
              <th>Nghiệp vụ</th>
              <th>Thông báo từ Ngân hàng</th>
             
            </tr>
          </thead>
          <tbody>
            {bankGWMsgList &&
              bankGWMsgList.map((item) => (
                <tr key={item.ROW_NUM}>
                  <td className="text-center">{item?.ROW_NUM}</td>
                  <td className="text-center">{item?.C_INSERT_TIME}</td>
                  <td className="text-center">{item?.C_TYPE_CODE}</td>
                  <td className="text-center">{item?.C_VPBANK_ID}</td>
                  <td className="text-center">{item?.C_TRANSACTION_ID}</td>
                  <td className="text-center">{item?.C_TRANSACTION_NO}</td>
                  <td className="text-center">{item?.C_ACCOUNT_CODE}</td>
                  <td className="text-center">{item?.C_ACCOUNT_NAME}</td>
                  <td className="text-right"> {numberFormat(item?.C_CASH_VALUE, 0, '0')}</td>
                  <td className="text-center">{item?.C_RESPONSE_CODE}</td>
                  <td className="text-center">{item?.C_RESPONSE_TIME}</td>
                  <td className="">
                    {item?.C_BUSINESS_CODE}
                  </td>
                  <td className="">{item?.C_RESPONSE_MESSAGE}</td>
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollBar>
      {(!bankGWMsgList || !bankGWMsgList.length) && (
        <NodataSearch name={'dữ liệu!'} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (bankGWMsgList &&
              !!bankGWMsgList.length &&
              bankGWMsgList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
    </div>
  );
}

const makeMapStateToProps = () => {
  const getbankGWMsgList = makeGetBankGWMsgList();

  const mapStateToProps = (state) => {
    return {
      bankGWMsgList: getbankGWMsgList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(DienNhanVe)
);
