import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';

import {
  bankGWMessageListRequest,
  bankGWMessageListSuccess,
  bankSendCompareRequest,
  bankSendCompareSuccess,
  bankGetTransRequest,
  bankGetTransSuccess
} from 'containers/bank-gw/actions';
import { change } from 'redux-form';
import { makeGetSystemInfo, makeGetToken, makeGetBusinessVsdType,makeGetbankSendCompare,makeGetBankTransStatus } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { confirmAlert } from 'react-confirm-alert';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { formatDate, stringToDate } from 'utils';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import IconExcel from 'assets/img/icon/ms-excel.png';
import IconPdf from 'assets/img/icon/ms-pdf.svg';
import { globalExportFileRequest } from 'containers/report/actions';
import { globalExportFilePdfRequest } from 'containers/report/actions';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';
import PerfectScrollBar from 'react-perfect-scrollbar';
import { Button } from 'react-bootstrap';
import { setToast } from 'containers/client/actions';
import * as _ from 'lodash';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();
  const refSubmit = useRef(null);

  const [dataSearch, setDataSearch] = React.useState(null);
  const { token, page, recordPerPage, t, _date, glBusinessVsdType, formFromDate,handleSubmit,submitting, formToDate ,bankSendCompare,bankGetTrans} =
    props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preFormFromDate = usePrevious(formFromDate);
  const preFormToDate = usePrevious(formToDate);
  const preBankSendCompare = usePrevious(bankSendCompare);
  const preGetBankTrans = usePrevious(bankGetTrans);


  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    setTimeout(() => {
      //submit();
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
    return () => {
      dispatch(bankGWMessageListSuccess(null));
    };
  }, []);

  useEffect(() => {
    if (bankSendCompare && !_.isEqual(bankSendCompare, preBankSendCompare))
      _handleToast('Request thành công', 'success');
    dispatch(bankSendCompareSuccess(null));
  }, [bankSendCompare]);

  useEffect(() => {
    if (bankGetTrans && !_.isEqual(bankGetTrans, preGetBankTrans))
      _handleToast('Query trạng thái bút toán thành công', 'success');
    dispatch(bankGetTransSuccess(null));
  }, [bankGetTrans]);

  // useEffect(() => {
  //   if (page && prePage && page !== prePage) {
  //     _handleBlur();
  //   }
  // }, [page]);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      //_handleBlur();
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      //_handleBlur();
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  useEffect(() => {
    if (
      !_.isEqual(formFromDate, preFormFromDate) ||
      !_.isEqual(formToDate, preFormToDate)
    ) {
      _handleBlur();
    }
  }, [formFromDate, formToDate]);

  function initForm() {
    dispatch(
      change('formSearch', 'formFromDate', formatDate(_date, '/', 'dmy'))
    );
    dispatch(
      change('formSearch', 'formToDate', formatDate(_date, '/', 'dmy'))
    );
    dispatch(
      change('formSearch', 'formDataDate', formatDate(_date, '/', 'dmy'))
    );
    dispatch(
      change('formSearch', 'formDataType', 'SUCCESS')
    );

  }

  const submit = () => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REPORT_BANK_GW_01',
      group: 'LIST',
      data: {
        TYPE_CODE: props?.formTypeCode,
        BUSINESS_CODE: props?.formBusinessCode,
        ACCOUNT_CODE: props?.formAccountCode,
        BANK_ID: props?.formTransId,
        RESPONSE_CODE: props?.formStatus,
        TRANSACTION_ID: props?.formTransCode,

        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);

    dispatch(bankGWMessageListRequest(params));
  };

  const _handleBlur = () => {
    if (formFromDate?.includes('_') || formToDate?.includes('_')) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REPORT_BANK_GW_01',
      group: 'LIST',
      data: {
        TYPE_CODE: props?.formTypeCode,
        BUSINESS_CODE: props?.formBusinessCode,
        ACCOUNT_CODE: props?.formAccountCode,
        BANK_ID: props?.formTransId,
        RESPONSE_CODE: props?.formStatus,
        TRANSACTION_ID: props?.formTransCode,
        
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);
    dispatch(bankGWMessageListRequest(params));
  };

  function handleOnKeyDown(e) {
    if (e.key === 'Enter') _handleBlur();
  }

  function handleExportExcel() {
    const params = dataSearch;
    params.data.PAGE = 1;
    params.data.RECORD_PER_PAGE = 1000000;
    params.data.TEMPLATE_CODE = 'SD_12';
    dispatch(globalExportFileRequest(params));
  }

  function handleExportPdf() {
    const params = dataSearch;
    params.data.PAGE = 1;
    params.data.RECORD_PER_PAGE = 1000000;
    params.data.TEMPLATE_CODE = 'SD_12';
    dispatch(globalExportFilePdfRequest(params));
  }

  function handleActionRequest() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn gửi request?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionRequest();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionGetTrans() {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui-confirm">
            <h1>{t('txt-confirm')}</h1>
            <p>Bạn muốn query trạng thái bút toán?</p>
            <button onClick={onClose}>{t('txt-cancel')}</button>
            <button
              onClick={() => {
                handleActionQuery();
                onClose();
              }}
            >
              {t('txt-confirm')}
            </button>
          </div>
        );
      },
      closeOnEscape: true,
      closeOnClickOutside: true,
      keyCodeForClose: [8, 32],
    });
  }

  function handleActionRequest() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.BANK_SEND_COMPARE',
      group: 'LIST',
      data: {
        DATA_TYPE:  props?.formDataType,
        DATA_DATE: props?.formDataDate,
      },
    };

    dispatch(bankSendCompareRequest(params));
  }

  function handleActionQuery() {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.BANK_GET_TRANS_STATUS',
      group: 'LIST',
      data: {
        TRANSACTION_ID:  props?.formTransCT
      },
    };

    dispatch(bankGetTransRequest(params));
  }

  const _handleToast = (msg, type = 'info') => {
    const toastMsg = {
      id: Math.random(),
      msg: msg,
      title: 'Thông báo',
      type,
    };
    dispatch(setToast(toastMsg));
  };

  return (
    <PerfectScrollBar className="w-100" onSubmit={handleSubmit(submit)}>
      <FormFlexCenter>
      <div className="align-items-center mr-auto">
        <div className="d-flex align-items-center mr-auto">
        <Form.Group className="mx-1" style={{ width: '240px' }}>
            <Form.Label>Loại dữ liệu</Form.Label>
            <Field
              name="formDataType"
              className="form-control w-100"
              component="select"
            >
              <option value="SUCCESS">SUCCESS</option>
              <option value="FAIL">FAIL</option>
            </Field>
          </Form.Group>
            <Form.Group className="mx-1" style={{ width: '240px' }}>
              <Form.Label className="fz-13">Ngày đối soát</Form.Label>
              <Field
                className="form-control"
                name="formDataDate"
                classParentName="w-100"
                component={RenderSelectDate}
              />
            </Form.Group>
            

            <Button
              variant="danger"
              style={{ width: '240px',height:'30px' }}
              onClick={() => {
                handleActionRequest();
              }}
              className="mx-1 mt-4 fz-13"
            >
              Send Request
            </Button>
            <Form.Group className="mx-1 ml-4" style={{ width: '240px' }}>
            <Form.Label className="fz-13">Bút toán CTCK</Form.Label>
            <Field
              name="formTransCT"
              type="text"
              className="form-control"
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>

          <Button
              variant="danger"
              style={{ width: '240px',height:'30px' }}
              onClick={() => {
                handleActionGetTrans();
              }}
              className="mx-2 mt-4 fz-12"
            >
              Query trạng thái bút toán
            </Button>
          </div>
          <div className="d-flex align-items-center mr-auto">
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Loại bút toán</Form.Label>
            <Field
              name="formTypeCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label>Nghiệp vụ</Form.Label>
            <Field
              name="formBusinessCode"
              className="form-control w-100"
              component="select"
            >
              <option value="">-- Tất cả --</option>
              <option value="TRANSFER">Chuyển tiền</option>
              <option value="QUERY">Truy vấn</option>
            </Field>
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Bút toán ngân hàng</Form.Label>
            <Field
              name="formTransId"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Tài khoản CK</Form.Label>
            <Field
              name="formAccountCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Bút toán CTCK</Form.Label>
            <Field
              name="formTransCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Trạng thái</Form.Label>
            <Field
              name="formStatus"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          {/* <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Mã lỗi</Form.Label>
            <Field
              name="formErrorCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>             */}
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
            <Field
              className="form-control"
              name="formFromDate"
              classParentName="w-100"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderSelectDate}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
            <Field
              className="form-control"
              name="formToDate"
              classParentName="w-100"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderSelectDate}
            />
          </Form.Group>
          <Form.Group className="mx-1">
          <Form.Label className="fz-13"></Form.Label>
          <Button
            ref={refSubmit}
            type="submit"
            className="btn-search"
            disabled={submitting}
            style={{ width: '150px' }}
          >
            {t('txt-search')}
          </Button>
          </Form.Group>
        </div>
        </div>
        <ExportExcel className="ml-auto">
          {/* <img src={IconExcel} alt="" onClick={() => handleExportExcel()} /> */}
          {/* <img src={IconPdf} alt="" onClick={() => handleExportPdf()} /> */}
        </ExportExcel>
      </FormFlexCenter>
    </PerfectScrollBar>
  );
}

FormSearch = reduxForm({
  form: 'formSearch',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearch');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getBusinessVsdType = makeGetBusinessVsdType();
  const getbankSendCompare = makeGetbankSendCompare();
  const getbankTrans = makeGetBankTransStatus();

  const mapStateToProps = (state) => {
    const {
      formTypeCode,
      formTransId,
      formAccountCode,
      formFromDate,
      formToDate,
      formStatus,
      formTransCode,
      formErrorCode,
      formBusinessCode,
      formDataType,
      formDataDate,
      formTransCT
    } = selector(
      state,
      'formTypeCode',
      'formTransId',
      'formAccountCode',
      'formFromDate',
      'formToDate',
      'formStatus',
      'formTransCode',
      'formErrorCode',
      'formBusinessCode',
      'formDataType',
      'formDataDate',
      'formTransCT'
    );
    const sysSystemInfo = getSystemInfo(state);
    const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
    return {
      token: getToken(state),
      glBusinessVsdType: getBusinessVsdType(state),
      bankSendCompare: getbankSendCompare(state),
      bankGetTrans: getbankTrans(state),
      formTypeCode,
      formTransId,
      formAccountCode,
      formFromDate,
      formToDate,
      formStatus,
      formTransCode,
      formErrorCode,
      formBusinessCode,
      formDataType,
      formDataDate,
      formTransCT,
      _date,
      // initialValues: {
      //   formFromDate: formatDate(_date, '/', 'dmy'),
      //   formToDate: formatDate(_date, '/', 'dmy'),
      // },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
