import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';

import {
  dataCompareListRequest,
  dataCompareListSuccess,
} from 'containers/bank-gw/actions';
import { change } from 'redux-form';
import { makeGetSystemInfo, makeGetToken } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { formatDate, stringToDate } from 'utils';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import IconExcel from 'assets/img/icon/ms-excel.png';
import IconPdf from 'assets/img/icon/ms-pdf.svg';
import { globalExportFileRequest } from 'containers/report/actions';
import { globalExportFilePdfRequest } from 'containers/report/actions';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';
import PerfectScrollBar from 'react-perfect-scrollbar';
import { Button } from 'react-bootstrap';
import * as _ from 'lodash';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();
  const refSubmit = useRef(null);

  const [dataSearch, setDataSearch] = React.useState(null);
  const { token, page, recordPerPage, t, _date, glBusinessVsdType, formFromDate,handleSubmit,submitting, formDataDate } =
    props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preFormFromDate = usePrevious(formFromDate);
  const preFormDataDate = usePrevious(formDataDate);

  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    setTimeout(() => {
      //submit();
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
    return () => {
      dispatch(dataCompareListSuccess(null));
    };
  }, []);

  // useEffect(() => {
  //   if (page && prePage && page !== prePage) {
  //     _handleBlur();
  //   }
  // }, [page]);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      //_handleBlur();
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      //_handleBlur();
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  useEffect(() => {
    if (
      !_.isEqual(formDataDate, preFormDataDate)
    ) {
      _handleBlur();
    }
  }, [formFromDate]);

  function initForm() {
    
    dispatch(
      change('formSearch', 'formDataDate', formatDate(_date, '/', 'dmy'))
    );

  }

  const submit = () => {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.BANK_GET_DATA_COMPARE',
      group: 'LIST',
      data: {
        DATA_TYPE: props?.formDataType,
        DATA_DATE: props?.formDataDate,
        TRANSACTION_ID: props?.formTransId,
        ACCOUNT_CODE: props?.formAccountCode,
        
        BANK_ID: props?.formBankID,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);

    dispatch(dataCompareListRequest(params));
  };

  const _handleBlur = () => {
    if (formDataDate?.includes('_')) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.BANK_GET_DATA_COMPARE',
      group: 'LIST',
      data: {
        DATA_TYPE: props?.formDataType,
        DATA_DATE: props?.formDataDate,
        TRANSACTION_ID: props?.formTransId,
        ACCOUNT_CODE: props?.formAccountCode,
        
        BANK_ID: props?.formBankID,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);
    dispatch(dataCompareListRequest(params));
  };

  function handleOnKeyDown(e) {
    if (e.key === 'Enter') _handleBlur();
  }

  function handleExportExcel() {
    const params = dataSearch;
    params.data.PAGE = 1;
    params.data.RECORD_PER_PAGE = 1000000;
    params.data.TEMPLATE_CODE = 'KQ_DOI_SOAT';
    dispatch(globalExportFileRequest(params));
  }

  function handleExportPdf() {
    const params = dataSearch;
    params.data.PAGE = 1;
    params.data.RECORD_PER_PAGE = 1000000;
    params.data.TEMPLATE_CODE = 'SD_12';
    dispatch(globalExportFilePdfRequest(params));
  }

  return (
    <PerfectScrollBar className="w-100" onSubmit={handleSubmit(submit)}>
      <FormFlexCenter>
        <div className="d-flex align-items-center mr-auto">
          
          <Form.Group className="mx-1" style={{ width: '150px' }}>
            <Form.Label className="fz-13">Loại dữ liệu</Form.Label>
            <Field
              name="formDataType"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '150px' }}>
            <Form.Label className="fz-13">Bút toán CTCK</Form.Label>
            <Field
              name="formTransId"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '150px' }}>
            <Form.Label className="fz-13">Số tài khoản</Form.Label>
            <Field
              name="formAccountCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '150px' }}>
            <Form.Label className="fz-13">BANK ID</Form.Label>
            <Field
              name="formBankID"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
        
          <Form.Group className="mx-1" style={{ width: '150px' }}>
            <Form.Label className="fz-13">Ngày đối soát</Form.Label>
            <Field
              className="form-control"
              name="formDataDate"
              classParentName="w-100"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderSelectDate}
            />
          </Form.Group>
          
          <Form.Group className="mx-1">
          <Form.Label className="fz-13"></Form.Label>
          <Button
            ref={refSubmit}
            type="submit"
            className="btn-search"
            disabled={submitting}
            style={{ width: '150px' }}
          >
            {t('txt-search')}
          </Button>
          </Form.Group>
        </div>
        <ExportExcel className="ml-auto">
          <img src={IconExcel} alt="" onClick={() => handleExportExcel()} />
          {/* <img src={IconPdf} alt="" onClick={() => handleExportPdf()} /> */}
        </ExportExcel>
      </FormFlexCenter>
    </PerfectScrollBar>
  );
}

FormSearch = reduxForm({
  form: 'formSearch',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearch');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  //const getBusinessVsdType = makeGetBusinessVsdType();

  const mapStateToProps = (state) => {
    const {
      formAccountCode,
      formTransId,
      
      formDataDate,
      formDataType,
      formBankID
     
    } = selector(
      state,
      'formAccountCode',
      'formTransId',
      'formDataDate',
      'formDataType',
      'formBankID'
    
    );
    const sysSystemInfo = getSystemInfo(state);
    const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
    return {
      token: getToken(state),
      //glBusinessVsdType: getBusinessVsdType(state),
      formAccountCode,
      formTransId,
      formDataDate,
      formDataType,
      formBankID,
      _date,
      // initialValues: {
      //   formFromDate: formatDate(_date, '/', 'dmy'),
      //   formToDate: formatDate(_date, '/', 'dmy'),
      // },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
