import React from 'react';
import { Table } from 'react-bootstrap';
import { connect } from 'react-redux';

import Paging from 'components/paging';
import FormSearch from './formSearch';
import { makeGetDataCompareList } from 'lib/selector';
import NodataSearch from 'components/noDataSearch';
import { numberFormat } from 'utils';
import { translate } from 'react-i18next';
import PerfectScrollBar from 'react-perfect-scrollbar';

function DienNhanVe(props) {
  const [page, setPage] = React.useState(1);
  const [recordPerPage, setRecordPerPage] = React.useState(10);

  const { dataCompareList, t } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <PerfectScrollBar className="w-100">
        <Table bordered>
          <thead>
            <tr>
              <th>#</th>
              <th>Mã dịch vụ</th>
              <th>Bút toán CTCK</th>
              <th>Mã KH tại đối tác</th>
              <th>Số tiền GD</th>
              {/* <th>Mã tiền tệ GD</th>
              <th>Số Trace hệ thống	</th> */}
              <th>Giờ khởi tạo</th>
              <th>Ngày khởi tạo GD</th>
              <th>Giờ thanh toán</th>
              <th>Ngày thanh toán</th>
              {/* <th>TK ghi nợ</th>
              <th>TK ghi có</th>
              <th>Số thẻ</th>
              <th>Mã số thiết bị chấp nhận thẻ</th> */}
              <th>KQ đối soát</th>
              {/* <th>Yêu cầu của đối tác</th>
              <th>Loại GD</th>
              <th>Thông tin bổ sung</th>
              <th>ID giao dịch</th> */}
            </tr>
          </thead>
          <tbody>
            {dataCompareList &&
              dataCompareList.map((item) => (
                <tr key={item.ROW_NUM}>
                  <td className="text-center">{item?.ROW_NUM}</td>
                  <td className="text-center">{item?.MA_DICH_VU_CHI_TIET}</td>
                  <td className="text-center">{item?.MA_HOA_DON}</td>
                  <td className="text-center">{item?.MA_KHACH_HANG_TAI_DOI_TAC}</td>
                  <td className="text-right">{numberFormat(item?.SO_TIEN_GIAO_DICH, 0, '0')}</td>
                  <td className="text-center">{item?.GIO_KHOI_TAO_GIAO_DICH}</td>
                  <td className="text-center">{item?.NGAY_KHOI_TAO_GIAO_DICH}</td>
                  <td className="text-center">{item?.GIO_THANH_TOAN_GIAO_DICH}</td>
                  <td className="text-center">{item?.NGAY_THANH_TOAN_GIAO_DICH}</td>
                  <td className="text-center">{item?.KET_QUA_DOI_SOAT}</td>
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollBar>
      {(!dataCompareList || !dataCompareList.length) && (
        <NodataSearch name={'dữ liệu!'} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (dataCompareList &&
              !!dataCompareList.length &&
              dataCompareList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
    </div>
  );
}

const makeMapStateToProps = () => {
  const getDataCompareList = makeGetDataCompareList();

  const mapStateToProps = (state) => {
    return {
      dataCompareList: getDataCompareList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(DienNhanVe)
);
