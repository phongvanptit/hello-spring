import TabHanCheUng from 'components/cash/ung-truoc-tien-ban/ma-han-che-ung';
import DienGuiDi from 'components/bank/chi-ho/gui-di';
import DienNhanVe from 'components/bank/chi-ho/nhan-ve';
import KQDoiSoat from 'components/bank/chi-ho/ket-qua-doi-soat';
import { translate } from 'react-i18next';

import { useDispatch } from 'react-redux';
function IndividualComponent(props) {
  const { subType, accRight, statusCode } = props;
  const dispatch = useDispatch();
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'dien-gui-di' && <DienGuiDi accRight={accRight} statusCode={statusCode}/>}
        {subType === 'dien-nhan-ve' && <DienNhanVe accRight={accRight} />}
        {subType === 'kq-doi-soat' && <KQDoiSoat accRight={accRight} />}
      </div>
    </>
  );
}

export default translate('translations')(IndividualComponent);
