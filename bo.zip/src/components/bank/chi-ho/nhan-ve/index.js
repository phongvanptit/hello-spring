import React from 'react';
import { Table } from 'react-bootstrap';
import { connect } from 'react-redux';

import Paging from 'components/paging';
import FormSearch from './formSearch';
import { makeGetBankGWResponseList } from 'lib/selector';
import NodataSearch from 'components/noDataSearch';
import { numberFormat } from 'utils';
import { translate } from 'react-i18next';
import PerfectScrollBar from 'react-perfect-scrollbar';

function DienNhanVe(props) {
  const [page, setPage] = React.useState(1);
  const [recordPerPage, setRecordPerPage] = React.useState(10);

  const { bankGWResponseList, t } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <PerfectScrollBar className="w-100">
        <Table bordered>
          <thead>
            <tr>
              <th>#</th>
              <th>Ngày GD</th>
              <th>Thời gian</th>
              <th>ID Ngân hàng</th>
              <th>Trạng thái</th>
              <th>Bút toán CTCK	</th>
              <th>Mô tả từ bank	</th>
              
             
            </tr>
          </thead>
          <tbody>
            {bankGWResponseList &&
              bankGWResponseList.map((item) => (
                <tr key={item.ROW_NUM}>
                  <td className="text-center">{item?.ROW_NUM}</td>
                  <td className="text-center">{item?.C_TRADING_DATE}</td>
                  <td className="text-center">{item?.C_INSERT_TIME}</td>
                  <td className="text-center">{item?.C_VPBANK_ID}</td>
                  <td className="text-center">{item?.C_RESPONSE_CODE}</td>
                  <td className="text-center">{item?.C_TRANSACTION_ID}</td>
                  <td className="text-center">{item?.C_MESSAGE}</td>
       
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollBar>
      {(!bankGWResponseList || !bankGWResponseList.length) && (
        <NodataSearch name={'dữ liệu!'} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (bankGWResponseList &&
              !!bankGWResponseList.length &&
              bankGWResponseList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
    </div>
  );
}

const makeMapStateToProps = () => {
  const getbankGWResponseList = makeGetBankGWResponseList();

  const mapStateToProps = (state) => {
    return {
      bankGWResponseList: getbankGWResponseList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(DienNhanVe)
);
