import DienNhanVe from 'components/bank/thu-ho/nhan-ve';
import { translate } from 'react-i18next';

import { useDispatch } from 'react-redux';
function THuHoComponent(props) {
  const { subType, accRight, statusCode } = props;
  const dispatch = useDispatch();
  return (
    <>
      <div className="custom-tabs-content my-3">
        {subType === 'dien-nhan-ve' && <DienNhanVe accRight={accRight} statusCode={statusCode}/>}
        {/* {subType === 'han-che-ung' && <TabHanCheUng accRight={accRight} />} */}
      </div>
    </>
  );
}

export default translate('translations')(THuHoComponent);
