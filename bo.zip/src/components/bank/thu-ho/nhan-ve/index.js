import React from 'react';
import { Table } from 'react-bootstrap';
import { connect } from 'react-redux';

import Paging from 'components/paging';
import FormSearch from './formSearch';
import { makeGetBankMsgList, makeGetMainListFinra } from 'lib/selector';
import NodataSearch from 'components/noDataSearch';
import { numberFormat } from 'utils';
import { translate } from 'react-i18next';
import PerfectScrollBar from 'react-perfect-scrollbar';

function DienNhanVe(props) {
  const [page, setPage] = React.useState(1);
  const [recordPerPage, setRecordPerPage] = React.useState(10);

  const { bankMsgList, t } = props;

  function _handleNextPage(step) {
    setPage(step);
  }

  return (
    <div className="w-100 d-flex flex-column">
      <FormSearch page={page} recordPerPage={recordPerPage} />
      <PerfectScrollBar className="w-100">
        <Table bordered>
          <thead>
            <tr>
              <th>#</th>
              <th>Ngày GD</th>
              <th>Kênh GD</th>
              <th>ID Ngân hàng</th>
              <th>Bút toán CTCK</th>
              <th>Tài khoản	</th>
              <th>Số tiền </th>
              <th>Nôi dung</th>
              <th>Trạng thái</th>
              <th>Mã lỗi</th>
              <th>Nội dung lỗi</th>
             
            </tr>
          </thead>
          <tbody>
            {bankMsgList &&
              bankMsgList.map((item) => (
                <tr key={item.ROW_NUM}>
                  <td className="text-center">{item?.ROW_NUM}</td>
                  <td className="text-center">{item?.C_CREATE_TIME}</td>
                  <td className="text-center">{item?.C_CHANNEL_NAME}</td>
                  <td className="text-center">{item?.C_BANK_TRANSACTION_ID}</td>
                  <td className="text-center">{item?.C_VPBS_TRANSACTION_NO}</td>
                  <td className="text-center">{item?.C_ACCOUNT_NO}</td>
                  <td className="text-right"> {numberFormat(item?.C_AMOUNT, 0, '0')}</td>
                  <td className="">{item?.C_DESCRIPTION}</td>
                  <td className="text-center">{item?.C_STATUS}</td>
                  <td className="text-center">
                    {item?.C_ERROR_CODE}
                  </td>
                  <td className="text-center">{item?.C_ERROR_DESCRIPTION}</td>
                </tr>
              ))}
          </tbody>
        </Table>
      </PerfectScrollBar>
      {(!bankMsgList || !bankMsgList.length) && (
        <NodataSearch name={'dữ liệu!'} />
      )}
      <div className="mt-3 d-flex justify-content-end">
        <Paging
          page={page}
          nextPage={_handleNextPage}
          recordPerPage={recordPerPage}
          setRecordPerPage={setRecordPerPage}
          total={
            (bankMsgList &&
              !!bankMsgList.length &&
              bankMsgList[0].C_TOTAL_RECORD) ||
            0
          }
        />
      </div>
    </div>
  );
}

const makeMapStateToProps = () => {
  const getbankMsgList = makeGetMainListFinra();

  const mapStateToProps = (state) => {
    return {
      bankMsgList: getbankMsgList(state),
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(DienNhanVe)
);
