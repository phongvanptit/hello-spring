import RenderSelectDate from 'components/input/renderDatePicker';
import RenderInput from 'components/input/renderInput';

import {
  bankMessageListRequest,
  bankMessageListSuccess,
} from 'containers/bank-gw/actions';
import { change } from 'redux-form';
import { makeGetSystemInfo, makeGetToken, makeGetBusinessVsdType, makeGetMainListFinra } from 'lib/selector';
import React, { useEffect, useRef } from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { formatDate, stringToDate } from 'utils';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import IconExcel from 'assets/img/icon/ms-excel.png';
import IconPdf from 'assets/img/icon/ms-pdf.svg';
import { globalExportFileRequest } from 'containers/report/actions';
import { globalExportFilePdfRequest } from 'containers/report/actions';
import { ExportExcel, FormFlexCenter } from 'utils/styledComponent';
import PerfectScrollBar from 'react-perfect-scrollbar';
import { Button } from 'react-bootstrap';
import * as _ from 'lodash';
import { mainListFinraRequesting, mainListFinraSuccess } from '../../../../containers/finra/actions';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const dispatch = useDispatch();
  const refSubmit = useRef(null);

  const [dataSearch, setDataSearch] = React.useState(null);
  const { token, page, recordPerPage, t, _date, glBusinessVsdType, formFromDate,handleSubmit,submitting, formToDate } =
    props;

  const prePage = usePrevious(page);
  const preRecordPerPage = usePrevious(recordPerPage);
  const preFormFromDate = usePrevious(formFromDate);
  const preFormToDate = usePrevious(formToDate);

  useEffect(() => {
    initForm();
    return () => {
      props.reset();
    };
  }, []);

  useEffect(() => {
    setTimeout(() => {
      //submit();
      if (refSubmit.current) refSubmit.current.click();
    }, 200);
    return () => {
      dispatch(bankMessageListSuccess(null));
      dispatch(mainListFinraSuccess(null))
    };
  }, []);

  // useEffect(() => {
  //   if (page && prePage && page !== prePage) {
  //     _handleBlur();
  //   }
  // }, [page]);

  useEffect(() => {
    if (page && prePage && page !== prePage) {
      //_handleBlur();
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [page]);

  useEffect(() => {
    if (
      recordPerPage &&
      preRecordPerPage &&
      recordPerPage !== preRecordPerPage
    ) {
      //_handleBlur();
      if (refSubmit.current) refSubmit.current.click();
    }
  }, [recordPerPage]);

  useEffect(() => {
    if (
      !_.isEqual(formFromDate, preFormFromDate) ||
      !_.isEqual(formToDate, preFormToDate)
    ) {
      _handleBlur();
    }
  }, [formFromDate, formToDate]);

  function initForm() {
    dispatch(
      change('formSearch', 'formFromDate', formatDate(_date, '/', 'dmy'))
    );
    dispatch(
      change('formSearch', 'formToDate', formatDate(_date, '/', 'dmy'))
    );

  }

  // const submit = () => {
  //   const params = {
  //     user: token?.USER_NAME,
  //     session: token?.SESSION_ID,
  //     cmd: 'BACK.GET_ALL_RESPONSE_VSD',
  //     group: 'LIST',
  //     data: {
  //       FROM_DATE: formatDate(_date, '/', 'dmy'),
  //       TO_DATE: formatDate(_date, '/', 'dmy'),
  //       PAGE: page || 1,
  //       RECORD_PER_PAGE: recordPerPage || 10,
  //     },
  //   };
  //   setDataSearch(params);

  //   dispatch(responseMsgListRequest(params));
  // };

  const submit = () => {
    console.log('submit');

    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REPORT_BANK_GW_03',
      group: 'LIST',
      data: {
        TRANSACTION_TYPE: props?.formTransType,
        TRANSACTION_ID: props?.formTransId,
        ACCOUNT_CODE: props?.formAccountCode,
        STATUS: props?.formStatus,
        TRANSACTION_CODE: props?.formTransCode,
        ERROR_CODE: props?.formErrorCode,
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);

    dispatch(mainListFinraRequesting(params));
  };

  const _handleBlur = () => {
    if (formFromDate?.includes('_') || formToDate?.includes('_')) return;
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'BACK.REPORT_BANK_GW_03',
      group: 'LIST',
      data: {
        TRANSACTION_TYPE: props?.formTransType,
        TRANSACTION_ID: props?.formTransId,
        ACCOUNT_CODE: props?.formAccountCode,
        STATUS: props?.formStatus,
        TRANSACTION_CODE: props?.formTransCode,
        ERROR_CODE: props?.formErrorCode,
        FROM_DATE: props?.formFromDate,
        TO_DATE: props?.formToDate,

        PAGE: page || 1,
        RECORD_PER_PAGE: recordPerPage || 10,
      },
    };
    setDataSearch(params);
    dispatch(mainListFinraRequesting(params));
  };

  function handleOnKeyDown(e) {
    if (e.key === 'Enter') _handleBlur();
  }

  function handleExportExcel() {
    const params = dataSearch;
    params.data.PAGE = 1;
    params.data.RECORD_PER_PAGE = 1000000;
    params.data.TEMPLATE_CODE = 'SD_12';
    dispatch(globalExportFileRequest(params));
  }

  function handleExportPdf() {
    const params = dataSearch;
    params.data.PAGE = 1;
    params.data.RECORD_PER_PAGE = 1000000;
    params.data.TEMPLATE_CODE = 'SD_12';
    dispatch(globalExportFilePdfRequest(params));
  }

  return (
    <PerfectScrollBar className="w-100" onSubmit={handleSubmit(submit)}>
      <FormFlexCenter>
        <div className="d-flex align-items-center mr-auto">
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Loại bút toán</Form.Label>
            <Field
              name="formTransType"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Bút toán ngân hàng</Form.Label>
            <Field
              name="formTransId"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Tài khoản CK</Form.Label>
            <Field
              name="formAccountCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Trạng thái</Form.Label>
            <Field
              name="formStatus"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Bút toán CTCK</Form.Label>
            <Field
              name="formTransCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">Mã lỗi</Form.Label>
            <Field
              name="formErrorCode"
              type="text"
              className="form-control"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderInput}
            />
          </Form.Group>            
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">{t('txt-from-date')}</Form.Label>
            <Field
              className="form-control"
              name="formFromDate"
              classParentName="w-100"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderSelectDate}
            />
          </Form.Group>
          <Form.Group className="mx-1" style={{ width: '120px' }}>
            <Form.Label className="fz-13">{t('txt-to-date')}</Form.Label>
            <Field
              className="form-control"
              name="formToDate"
              classParentName="w-100"
              onBlur={_handleBlur}
              onKeyDown={handleOnKeyDown}
              component={RenderSelectDate}
            />
          </Form.Group>
          <Form.Group className="mx-1">
          <Form.Label className="fz-13"></Form.Label>
          <Button
            ref={refSubmit}
            type="submit"
            className="btn-search"
            disabled={submitting}
            style={{ width: '150px' }}
          >
            {t('txt-search')}
          </Button>
          </Form.Group>
        </div>
        <ExportExcel className="ml-auto">
          {/* <img src={IconExcel} alt="" onClick={() => handleExportExcel()} /> */}
          {/* <img src={IconPdf} alt="" onClick={() => handleExportPdf()} /> */}
        </ExportExcel>
      </FormFlexCenter>
    </PerfectScrollBar>
  );
}

FormSearch = reduxForm({
  form: 'formSearch',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearch');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();
  const getSystemInfo = makeGetSystemInfo();
  const getBusinessVsdType = makeGetBusinessVsdType();

  const mapStateToProps = (state) => {
    const {
      formTransType,
      formTransId,
      formAccountCode,
      formFromDate,
      formToDate,
      formStatus,
      formTransCode,
      formErrorCode,
    } = selector(
      state,
      'formTransType',
      'formTransId',
      'formAccountCode',
      'formFromDate',
      'formToDate',
      'formStatus',
      'formTransCode',
      'formErrorCode',
    );
    const sysSystemInfo = getSystemInfo(state);
    const _date = stringToDate(sysSystemInfo?.C_T_DATE, 'dmy');
    return {
      token: getToken(state),
      glBusinessVsdType: getBusinessVsdType(state),
      formTransType,
      formTransId,
      formAccountCode,
      formFromDate,
      formToDate,
      formStatus,
      formTransCode,
      formErrorCode,
      _date,
      // initialValues: {
      //   formFromDate: formatDate(_date, '/', 'dmy'),
      //   formToDate: formatDate(_date, '/', 'dmy'),
      // },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
