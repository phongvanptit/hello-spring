import React from 'react';

const RenderInput2 = ({
  input,
  type = 'text',
  className,
  placeholder,
  autoFocus = false,
  disabled,
  meta: { touched, error },
}) => (
  <input
    {...input}
    type={type}
    className={className}
    placeholder={placeholder}
    autoComplete="off"
    autoFocus={autoFocus}
    disabled={disabled}
    style={{
      borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
    }}
  />
);

export default RenderInput2;
