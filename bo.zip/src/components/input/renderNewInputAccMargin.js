import React from 'react';
import styled from 'styled-components';

import { BsPlus } from 'react-icons/bs';
import { ReactComponent as IconDown } from 'assets/img/_ic-down.svg';
import { makeGetToken } from 'lib/selector';
import { connect } from 'react-redux';
import * as _ from 'lodash';
import PerfectScrollbar from 'react-perfect-scrollbar';

const appUrl = `${process.env.REACT_APP_API_URL}`;

const DivGroup = styled.div`
  position: relative;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: ${(props) => (props.index ? props.index : 1)};

  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
  }
`;

const InputGroup = styled.div`
  display: flex;

  input[type='text'] {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
`;

const ButtonDropDown = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  border-left: 1px solid #c6cbd2;
  // background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  &:hover {
    background-color: #e0e0e0;
  }

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #3b3c3f;
  }
`;

const ButtonAdd = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #2ca01c;
  background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  svg {
    margin: auto;
    font-size: 23px;
  }
`;
const FormShow = styled.div`
  padding: 10px 0;
  min-width: 300px;
  min-height: 100px;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);
  position: absolute;
  top: calc(100% + 3px);
  max-height: 300px;
  overflow: hidden;

  ul li {
    display: grid;
    grid-template-columns: 65px auto;
    gap: 5px;
    font-size: 13px;
    padding: 5px;
  }
  ul li:first-of-type {
    background: #e6e3dc;
    font-weight: 600;
    text-align: center;
  }
  ul li:not(:first-of-type) b {
    text-align: center;
  }

  ul li:not(:first-of-type):nth-child(odd) {
    background: #f9f9f9;
  }
  ul li:not(:first-of-type).active {
    color: #fff;
    background-color: #2ca01c;
  }

  .scrollbar-container {
    max-height: 275px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function RenderNewInputAccount(props) {
  const abortController = new AbortController();
  const wrapperRef = React.useRef(null);
  const inputRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);
  const [textSearch, setTextSearch] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [suggestions, setSuggestions] = React.useState([]);

  const [indexActive, setIndexActive] = React.useState(0);
  const [selected, setSelected] = React.useState(false);
  const {
    token,
    index,
    input,
    disabled,
    actionAdd,
    fnAddCallback,
    className,
    placeholder,
    custID,
    anyAcc,
    meta: { touched, error, visited },
    status,
    custStatus,
  } = props;

  const preInputValue = usePrevious(input?.value);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  React.useEffect(() => {
    if (
      input?.value &&
      !preInputValue &&
      !_.isEqual(input?.value, preInputValue) &&
      input?.value.length > 2
    ) {
      setSelected(true);
      setTextSearch(input?.value);
      getSuggestions(input?.value);
    }
  }, [input?.value]);

  React.useEffect(() => {
    if (selected) return;
    // remove old data
    if (textSearch && textSearch.length > 2 && !!textSearch.trim().length) {
      setShowModal(true);
      getSuggestions(textSearch);
    } else {
      setSuggestions([]);
      setShowModal(false);
      setIndexActive(-1);
    }
  }, [textSearch]);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      handleSetInput();
      setShowModal(false);
      setSelected(false);
    }
  }

  function _handleShow() {
    if (disabled) return;
    inputRef && inputRef.current.focus();
    setShowModal(true);
    getSuggestions(textSearch);
  }

  function handleKeyDown(event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      if (indexActive < 0 || indexActive > suggestions.length) return;
      setSelected(true);
      const _record = suggestions[indexActive - 1];
      setShowModal(false);
      input.onChange(_record?.C_ACCOUNT_CODE);
      setTextSearch(_record.C_ACCOUNT_CODE);
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (indexActive < suggestions.length) setIndexActive(indexActive + 1);
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (indexActive > 1) setIndexActive(indexActive - 1);
    }
    if (event.key === 'Tab') {
      handleSetInput();
      setShowModal(false);
    }
  }

  function handleSelect(record) {
    setShowModal(false);
    setSelected(true);
    input.onChange(record?.C_ACCOUNT_CODE);
    setTextSearch(record?.C_ACCOUNT_CODE);
  }

  function getSuggestions(value) {
    setLoading(true);
    setIndexActive(-1);
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'MM.GET_ALL_ACCOUNT_BY_CUSTOMER',
      group: 'LIST',
      data: {
        CUSTOMER_CODE: custID,

        PAGE: 1,
        RECORD_PER_PAGE: 1000,
      },
    };

        const storedToken = localStorage.getItem('tokenBO');
    let bearerToken = '';
    if (storedToken) {
      const tokenObj = JSON.parse(storedToken);
      bearerToken = tokenObj?.ACCESS_TOKEN || tokenObj?.token?.accessToken || '';
    }


    const url = `${appUrl}/backServices`;
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': `Bearer ${bearerToken}`,
      },
      body: JSON.stringify(params),
      signal: abortController.signal,
    })
      .then((response) => response.json())
      .then((res) => {
        setLoading(false);
        if (res?.code > 0) {
          if (status) {
            const filter = _.filter(res?.data, (o) => o.C_STATUS !== status);
            setSuggestions(filter);
          } else setSuggestions(res?.data);
        } else {
          setSuggestions([]);
        }
      })
      .catch((error) => {
        setLoading(false);
        console.log(error);
      });
  }

  function handleSetInput() {
    if (
      (suggestions &&
        suggestions.length &&
        _.find(suggestions, (o) => o.C_ACCOUNT_CODE === textSearch)) ||
      anyAcc
    ) {
      input.onChange(textSearch);
    } else {
      input.onChange('');
      setTextSearch('');
    }
  }

  return (
    <>
      <DivGroup
        {...input}
        ref={wrapperRef}
        hasErr={(visited || touched) && error}
        index={index}
        // onBlur={handleBlur}
      >
        <InputGroup>
          <input
            disabled={disabled}
            ref={inputRef}
            value={textSearch}
            onChange={(e) => {
              setSelected(false);
              setTextSearch(e.target.value);
            }}
            type={'text'}
            placeholder={placeholder}
            className={className}
            autoComplete="off"
            onKeyDown={handleKeyDown}
            onFocus={(e) => e.target.select()}
          />
          {actionAdd && !disabled && (
            <ButtonAdd onClick={() => (fnAddCallback ? fnAddCallback() : {})}>
              <BsPlus />
            </ButtonAdd>
          )}
          <ButtonDropDown onClick={_handleShow} disabled={disabled}>
            <IconDown />
          </ButtonDropDown>
        </InputGroup>
        {showModal && (
          <FormShow>
            <PerfectScrollbar style={{ padding: '0 10px' }}>
              <ul>
                <li>
                  <span>Mã KH</span>
                  <span>Tên KH</span>
                </li>
                {suggestions &&
                  !!suggestions.length &&
                  suggestions.map((item, index) => (
                    <li
                      key={item.ROW_NUM}
                      className={indexActive - 1 === index ? 'active' : ''}
                      onClick={() => handleSelect(item)}
                    >
                      <b>{item.C_ACCOUNT_CODE}</b>
                      <span>{item.C_ACCOUNT_NAME}</span>
                    </li>
                  ))}
              </ul>
              {(!suggestions || !suggestions.length) && (
                <p className="text-center fz-13">Không có dữ liệu</p>
              )}
            </PerfectScrollbar>
          </FormShow>
        )}
      </DivGroup>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  return {
    token: getToken(state),
  };
};
export default connect(mapStateToProps)(RenderNewInputAccount);
