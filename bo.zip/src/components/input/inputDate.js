import React from 'react';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import 'react-datepicker/dist/react-datepicker.css';
import { stringToDate } from 'utils';
import { Portal } from 'react-overlays';

const CalendarContainer = ({ children }) => {
  const el = document.getElementById('calendar-portal');

  return <Portal container={el}>{children}</Portal>;
};

const RenderDatePicker = ({
  input,
  placeholder,
  className,
  startDate,
  minDate,
  meta: { touched, error },
}) => {
  // if (!startDate) return null;

  const buildClassNames = (touched, isInvalid) =>
    (className || 'form-input') + (touched && isInvalid ? ' is-invalid' : '');

  return (
    <DatePicker
      // {...input}
      className={buildClassNames(touched, !!error)}
      selected={
        input.value
          ? stringToDate(input.value, 'dmy')
          : stringToDate(startDate, 'dmy')
      }
      dateFormat="dd/MM/yyyy"
      onChange={(date) => {
        date && input.onChange(moment(date).format('DD/MM/YYYY'));
      }}
      selectsStart
      // startDate={stringToDate(startDate, 'dmy')}
      // endDate={stringToDate(endDate, 'dmy')}
      placeholder={placeholder || 'Nhập ngày'}
      minDate={minDate || null}
      popperContainer={CalendarContainer}
    />
  );
};

export default RenderDatePicker;
