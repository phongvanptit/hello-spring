import React from 'react';
import styled from 'styled-components';
import { makeGetToken } from 'lib/selector';
import { connect } from 'react-redux';
import * as _ from 'lodash';
import { ReactComponent as IconDown } from 'assets/img/_ic-down.svg';
import PerfectScrollbar from 'react-perfect-scrollbar';

const DivGroup = styled.div`
  position: relative;
  outline: none !important;
  z-index: ${(props) => (props.index ? props.index : 1)};
`;

const InputGroup = styled.div`
  display: flex;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')} !important;
  background-color: ${(props) =>
    props.disabled ? '#e9ecef' : '#fff'} !important;
  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    border: none;
  }
  div {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
  }
`;

const ButtonDropDown = styled.div`
  display: flex;
  margin-left: auto;
  align-items: center;
  cursor: pointer;

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #3b3c3f;
  }
`;

const FormShow = styled.div`
  padding: 10px 0;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);
  position: absolute;
  top: calc(100% + 3px);
  max-height: 300px;
  overflow: hidden;
  width: -webkit-fill-available;
  border: 1px solid #ced4da;

  ul li {
    font-size: 13px;
    padding: 5px;
    color: #5e646a;
    cursor: pointer;
  }

  ul li.active {
    color: #fff;
    background-color: #2ca01c;
  }

  .scrollbar-container {
    max-height: 275px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function RenderNormalSelect(props) {
  const wrapperRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);
  const [textSearch, setTextSearch] = React.useState('');
  const [indexActive, setIndexActive] = React.useState(0);
  const {
    input,
    disabled,
    index,
    opts,
    required,
    className,
    meta: { touched, error, visited },
  } = props;
  const preInputValue = usePrevious(input?.value);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => {
      window.removeEventListener('mousedown', handleClickOutside);
    };
  });

  React.useEffect(() => {
    if (input?.value && !_.isEqual(input?.value, preInputValue)) {
      const find = _.find(opts, (o) => o.value === input?.value);
      setTextSearch(find?.label || '');
      const findIndex = _.findIndex(opts, (o) => o.value === input.value);
      setIndexActive(findIndex + 1);
    } else {
      setTextSearch('-- Tất cả --');
      input.onChange('');
      setIndexActive(0);
    }
  }, [input?.value]);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    if (disabled) return;
    // inputRef && inputRef.current.focus();
    setShowModal(!showModal);
  }

  function handleKeyDown(event) {
    if (indexActive < 0) return;
    if (event?.key === 'Enter') {
      if (indexActive === 0) {
        input.onChange('');
        setTextSearch('-- Tất cả --');
      } else {
        event.preventDefault();
        const _record = opts[indexActive - 1];
        input.onChange(_record.value);
        setTextSearch(_record.label);
      }
      setShowModal(false);
    }
    if (event?.key === 'ArrowDown') {
      event.preventDefault();
      if (indexActive < opts.length && showModal)
        setIndexActive(indexActive + 1);
      setShowModal(true);
    }
    if (event?.key === 'ArrowUp') {
      event.preventDefault();
      if (indexActive > 0) setIndexActive(indexActive - 1);
    }
  }

  function handleSelect(record) {
    setShowModal(false);
    input.onChange(record?.value || '');
    setTextSearch(record?.label || '-- Tất cả --');
  }

  function handleMouseOver(record) {
    const findIndex = _.findIndex(opts, (o) => o.value === record.value);
    setIndexActive(findIndex + 1);
  }

  return (
    <>
      <DivGroup
        {...input}
        index={index}
        ref={wrapperRef}
        onKeyDown={handleKeyDown}
        tabIndex={0}
      >
        <InputGroup
          onClick={_handleShow}
          className={className}
          hasErr={(visited || touched) && error}
          disabled={disabled}
        >
          <div>{textSearch}</div>
          {!disabled && (
            <ButtonDropDown onClick={_handleShow} disabled={disabled}>
              {showModal ? (
                <IconDown />
              ) : (
                <IconDown style={{ transform: 'rotate(180deg)' }} />
              )}
            </ButtonDropDown>
          )}
        </InputGroup>

        {showModal && (
          <FormShow>
            <ul>
              <PerfectScrollbar style={{ padding: '0 10px' }}>
                {!required && (
                  <li
                    className={indexActive - 1 < 0 ? 'active' : ''}
                    onClick={() => handleSelect('')}
                  >
                    {'-- Tất cả --'}
                  </li>
                )}
                {opts &&
                  !!opts.length &&
                  opts.map((item, index) => (
                    <li
                      key={index}
                      className={indexActive - 1 === index ? 'active' : ''}
                      onClick={() => handleSelect(item)}
                      onMouseOver={() => handleMouseOver(item)}
                    >
                      {item.label}
                    </li>
                  ))}
              </PerfectScrollbar>
            </ul>
          </FormShow>
        )}
      </DivGroup>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  return {
    token: getToken(state),
  };
};
export default connect(mapStateToProps)(RenderNormalSelect);
