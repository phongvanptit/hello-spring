import React, { memo, useEffect, useState } from 'react';

import styled from 'styled-components';

import IcAngleDown from 'assets/img/icon/icAngleDown.svg';

import PerfectScrollbar from 'react-perfect-scrollbar';
import * as _ from 'lodash';
import FloatingDiv from './floating/FloatingDiv';
import calcPosition from './floating/calcPosition';

const FormSelect = styled.div`
  position: relative;
  z-index: 1;
  border: 1px solid
    ${(props) => (props.hasErr === true ? '#FF0000' : '#c6cbd2')};
  border-radius: 5px;
`;

const FormText = styled.div`
  padding: 6px 20px 4px 8px;
  font-size: 13px;

  background-image: url(${IcAngleDown});
  background-repeat: no-repeat;
  background-position: right 5px center;
  background-size: 9px;
  height: 28px;
  overflow: hidden;
  white-space: nowrap;
`;

const FormShow = styled.div`
  position: absolute;
  //top: 100%;
  //left: 0;
  padding: 10px 10px;
  min-width: 250px;
  height: 300px;
  border-radius: 8px;
  background: #fafafa;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  display: flex;
  flex-direction: column;
  overflow: hidden;

  .scrollbar-container {
    margin-top: 10px;
  }

  ul {
    li {
      font-size: 14px;
      padding: 5px 10px;
      background: #ffffff;
      text-align: left;
    }
    li:nth-child(2n + 1) {
      background: #fafafa;
    }
    li:not(:last-of-type) {
      border-bottom: 1px solid #ececec;
    }

    li span:first-of-type {
      font-weight: 600;
    }
  }
`;

function escapeRegexCharacters(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function RenderSelectBank({
  input,
  className,
  disabled,
  opts,
  meta: { touched, error },
}) {
  const [showModal, setShowModal] = React.useState(false);
  const [showText, setShowText] = React.useState('-- Chọn --');
  const [textChange, setTextChange] = React.useState('');
  const [suggestions, setSuggestions] = React.useState([]);
  const [positionFloatingDiv, setPositionFloatingDiv] = useState({
    top: 0,
    left: 0,
  });

  const wrapperRef = React.useRef(null);
  const inputRef = React.useRef(null);
  const floatingDivRef = React.useRef(null);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  React.useEffect(() => {
    setSuggestions(getSuggestions(textChange));
  }, [textChange]);

  React.useEffect(() => {
    if (input?.value) {
      const _bank = _.find(opts, (o) => o.C_BANK_CODE === input?.value);
      setShowText(_bank?.C_BANK_NAME);
    }
  }, [input?.value]);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      floatingDivRef &&
      wrapperRef.current &&
      floatingDivRef.current &&
      (!wrapperRef.current.contains(event.target) && !floatingDivRef.current.contains(event.target))
    ) {
      setShowModal(false);
    }
  }

  function _handleShow() {
    setShowModal(true);
  }

  function getSuggestions(value) {
    if (!value) return opts;
    const escapedValue = escapeRegexCharacters(value.trim());

    if (escapedValue === '') {
      return opts;
    }

    const regex = new RegExp('^' + escapedValue, 'i');

    return opts.filter(
      (item) => regex.test(item.C_BANK_CODE) || regex.test(item.C_BANK_NAME)
    );
  }

  function _handleClickItem(item) {
    setShowModal(false);
    setShowText(item.C_BANK_NAME);
    setSuggestions(opts);
    setTextChange('');

    input?.onChange && input?.onChange(item.C_BANK_CODE);
  }

  useEffect(() => {
    const position = calcPosition(floatingDivRef, inputRef, {top: 3})
    setPositionFloatingDiv(position)
  }, [showModal, floatingDivRef.current?.getBoundingClientRect().height]);

  return (
    <FormSelect
      {...input}
      ref={wrapperRef}
      hasErr={touched && error ? true : false}
    >
      <FormText
        onClick={_handleShow}
        ref={inputRef}
      >
        {showText}
      </FormText>
      {showModal && (
        <FloatingDiv>
          <FormShow
            style={{
              position: 'fixed',
              top: positionFloatingDiv.top,
              left: positionFloatingDiv.left,
              opacity: (positionFloatingDiv.top === 0 && positionFloatingDiv.left === 0) ? 0 : 1,
              zIndex: 9999999
            }}
            ref={floatingDivRef}
          >
            <span className="fz-13">Nhập để tìm kiếm</span>
            <input
              type={'text'}
              className="form-control"
              placeholder="Nhập mã"
              value={textChange}
              onFocus={(e) => e.target.select()}
              onChange={(e) => setTextChange(e.target.value)}
            />
            <PerfectScrollbar>
              <ul>
                {suggestions &&
                  suggestions.map((item, index) => (
                    <li key={index} onClick={() => _handleClickItem(item)}>
                      <span>{item.C_BANK_CODE}</span> -
                      <span>{item.C_BANK_NAME}</span>
                    </li>
                  ))}
              </ul>
            </PerfectScrollbar>
          </FormShow>
        </FloatingDiv>
      )}
    </FormSelect>
  );
}

export default memo(RenderSelectBank);
