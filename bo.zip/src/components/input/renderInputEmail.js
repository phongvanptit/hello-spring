import React from 'react';

import TextMask from 'react-text-mask';
import emailMask from 'text-mask-addons/dist/emailMask';

export default function RenderInputEmail(props) {
  const {
    input,
    meta: { touched, error },
  } = props;

  return (
    <div>
      <TextMask
        {...input}
        mask={emailMask}
        className="form-control text-right fz_14"
        placeholder="john@smith.com"
        style={{
          borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
        }}
      />
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}
