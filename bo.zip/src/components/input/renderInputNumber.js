import React from 'react';

const RenderInputNumber = ({
  input,
  type = 'text',
  className,
  classParent,
  placeholder,
  autoFocus = false,
  onKeyDown,
  disabled,
  space,
  meta,
}) => {
  const { touched, error, warning } = meta;
  return (
    <div className={classParent || ''}>
      <input
        {...input}
        type={type}
        className={className}
        placeholder={placeholder}
        autoComplete="off"
        autoFocus={autoFocus}
        disabled={disabled}
        onKeyDown={onKeyDown ? onKeyDown : () => {}}
        onKeyPress={(event) => {
          if (!/[0-9]/.test(event.key)) {
            event.preventDefault();
          }
        }}
        onFocus={(e) => e.target.select()}
        style={{
          borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
        }}
        onChange={(e) =>
          space
            ? input.onChange(e.target.value.trim())
            : input.onChange(e.target.value)
        }
      />
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
      {touched && warning && !!warning.length && (
        <ul
          className="text-left text-primary"
          style={{
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {warning.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default RenderInputNumber;
