import React from 'react';
import * as _ from 'lodash';
import styled from 'styled-components';

const ListFunc = styled.ul`
  grid-column: 1/5;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px;

  li {
    font-size: 13px;

    input {
      margin-right: 5px;
    }
  }
`;

function RenderCheckBox(props) {
  const [checkAll, setCheckAll] = React.useState(false);
  const [orderCheck, setOrderCheck] = React.useState([]);

  const { opts, input, disabledAll } = props;

  React.useEffect(() => {
    if (input?.value) {
      setOrderCheck(input?.value.sort());

      const allFunc = _.map(opts, 'C_CODE').sort();
      if (_.isEqual(input?.value, allFunc)) {
        setCheckAll(true);
      } else {
        setCheckAll(false);
      }
    } else {
      setCheckAll(false);
      setOrderCheck([]);
    }
  }, [input?.value]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    // console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
    input.onChange(xxx);
  }

  function handleCheckAll(e) {
    const { checked } = e.target;
    setCheckAll(checked);

    if (checked) {
      const allFunc = _.map(opts, 'C_CODE');
      setOrderCheck(allFunc);
      input.onChange(allFunc);
    } else {
      setOrderCheck([]);
      input.onChange([]);
    }
  }

  return (
    <ListFunc>
      {!disabledAll && (
        <li>
          <label>
            <input
              type={'checkbox'}
              checked={checkAll}
              onChange={handleCheckAll}
            />
            Tất cả
          </label>
        </li>
      )}

      {opts &&
        opts.map((item, index) => (
          <li key={index}>
            <label>
              <input
                name={item.C_CODE}
                type={'checkbox'}
                checked={_.some(orderCheck, (o) => o === item.C_CODE)}
                onChange={_handleChange}
              />
              {item.C_NAME}
            </label>
          </li>
        ))}
    </ListFunc>
  );
}

export default RenderCheckBox;
