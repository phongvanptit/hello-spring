import React, { forwardRef, useEffect, useState } from 'react';
import TextMask from 'react-text-mask';
import DatePicker from 'react-datepicker';
import IgDate from 'assets/img/icon/date.png';
import { range } from 'lodash';
import * as _ from 'lodash';
import { stringToDate } from 'utils';
import moment from 'moment';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { toDate } from 'utils';
import { _diff2Date } from 'utils';

const InputGroup = styled.div`
  display: flex;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: ${(props) => (props.index ? props.index : 1)};
  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
  }
  input[type='text'] {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }

  .react-datepicker-wrapper {
    display: flex;
    .btn-date {
      display: flex;
      width: 100%;
      height: 100%;
      justify-content: center;
      align-items: center;
      cursor: pointer;
    }
  }
`;

const ButtonDropDown = styled.div`
  width: 35px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const monthVns = [
  'Tháng 1',
  'Tháng 2',
  'Tháng 3',
  'Tháng 4',
  'Tháng 5',
  'Tháng 6',
  'Tháng 7',
  'Tháng 8',
  'Tháng 9',
  'Tháng 10',
  'Tháng 11',
  'Tháng 12',
];

const monthEns = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const dayEns = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const dayVns = ['Cn', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];

const vnf_regex =
  /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}
function RenderInputDate(props) {
  const {
    input,
    className,
    onCalendarOpen,
    onCalendarClose,
    disabled,
    meta,
    setting: { lang },
    minDate,
    maxDate,
  } = props;
  const inputRef = React.useRef(null);

  const [startDate, setStartDate] = useState(new Date());
  const preInputValue = usePrevious(input?.value);
  const preMinDate = usePrevious(minDate);

  const years = range(1950, new Date().getFullYear() + 40, 1);
  const locale = {
    localize: {
      day: (n) => (lang === 'vi' ? dayVns[n] : dayEns[n]),
      month: (n) => (lang === 'vi' ? monthVns[n] : monthEns[n]),
    },
    formatLong: {
      date: () => 'mm/dd/yyyy',
    },
  };

  const months = lang === 'vi' ? monthVns : monthEns;

  useEffect(() => {
    if (
      input?.value &&
      vnf_regex.test(input?.value) &&
      !_.isEqual(input?.value, preInputValue)
    ) {
      setStartDate(stringToDate(input?.value, 'dmy'));
    }
  }, [input?.value]);

  useEffect(() => {
    if (minDate && !_.isEqual(minDate, preMinDate)) {
      setStartDate(stringToDate(minDate, 'dmy'));
    }
  }, [minDate]);

  const ExampleCustomInput = forwardRef((props, ref) => (
    <div className="btn-date" onClick={props.onClick}>
      <img src={IgDate} alt="" />
    </div>
  ));

  function handleCalendarOpen() {
    onCalendarOpen && onCalendarOpen();
  }
  function handleCalendarClose() {
    onCalendarClose && onCalendarClose();
  }

  return (
    <>
      <InputGroup
        style={{
          borderColor: `${
            meta?.touched && meta?.error ? '#ff5555' : '#c6cbd2'
          }`,
        }}
      >
        <TextMask
          id={inputRef}
          {...input}
          mask={[/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/]}
          className={className + ' form-control fz-13'}
          type="text"
          placeholder="dd/mm/yyyy"
          disabled={disabled}
        />
        {!disabled && (
          <ButtonDropDown>
            <DatePicker
              selected={startDate}
              minDate={minDate ? toDate(minDate) : null}
              maxDate={maxDate ? toDate(maxDate) : null}
              locale={locale}
              onChange={(date) => {
                input.onChange(moment(date).format('DD/MM/YYYY'));
              }}
              portalId="root-portal"
              customInput={<ExampleCustomInput />}
              onCalendarOpen={handleCalendarOpen}
              onCalendarClose={handleCalendarClose}
              disabled={disabled}
              renderCustomHeader={({
                date,
                changeYear,
                changeMonth,
                decreaseMonth,
                increaseMonth,
                prevMonthButtonDisabled,
                nextMonthButtonDisabled,
              }) => (
                <div
                  style={{
                    margin: 10,
                    display: 'flex',
                    justifyContent: 'center',
                  }}
                >
                  <button
                    onClick={decreaseMonth}
                    disabled={prevMonthButtonDisabled}
                    className="btn px-2 py-0"
                  >
                    {'<'}
                  </button>
                  <select
                    value={date.getFullYear()}
                    onChange={({ target: { value } }) => changeYear(value)}
                  >
                    {years.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>

                  <select
                    value={months[date.getMonth()]}
                    onChange={({ target: { value } }) =>
                      changeMonth(months.indexOf(value))
                    }
                  >
                    {months.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={increaseMonth}
                    disabled={nextMonthButtonDisabled}
                    className="btn px-2 py-0"
                  >
                    {'>'}
                  </button>
                </div>
              )}
            />
          </ButtonDropDown>
        )}
      </InputGroup>
      {meta?.touched && meta?.error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {meta?.error}
        </div>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  return { setting: state.client.setting };
};

export default connect(mapStateToProps)(RenderInputDate);
