import React, { useEffect } from 'react';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import { Portal } from 'react-overlays';
import { range } from 'lodash';
import { stringToDate } from 'utils';
import { connect } from 'react-redux';
import { translate } from 'react-i18next';
const monthVns = [
  'Tháng 1',
  'Tháng 2',
  'Tháng 3',
  'Tháng 4',
  'Tháng 5',
  'Tháng 6',
  'Tháng 7',
  'Tháng 8',
  'Tháng 9',
  'Tháng 10',
  'Tháng 11',
  'Tháng 12',
];

const monthEns = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const dayEns = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const dayVns = ['Cn', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];

const CalendarContainer = ({ children }) => {
  const el = document.getElementById('calendar-portal');

  return <Portal container={el}>{children}</Portal>;
};

const RenderSelectDate = (props) => {
  const {
    input,
    placeholder,
    className,
    startDate,
    minDate,
    disabled,
    meta,
    onCalendarOpen,
    onCalendarClose,
    setting: { lang },
  } = props;
  const years = range(1950, new Date().getFullYear() + 40, 1);

  const locale = {
    localize: {
      day: (n) => (lang === 'vi' ? dayVns[n] : dayEns[n]),
    },
    formatLong: {
      date: () => 'mm/dd/yyyy',
    },
  };

  const months = lang === 'vi' ? monthVns : monthEns;

  function handleCalendarOpen() {
    // console.log('Calendar open')
    onCalendarOpen && onCalendarOpen();
  }
  function handleCalendarClose() {
    // console.log('Calendar close')
    onCalendarClose && onCalendarClose();
  }

  return (
    <div>
      <DatePicker
        // {...input}
        onCalendarOpen={handleCalendarOpen}
        onCalendarClose={handleCalendarClose}
        placeholderText="DD/MM/YYYY"
        locale={locale}
        renderCustomHeader={({
          date,
          changeYear,
          changeMonth,
          decreaseMonth,
          increaseMonth,
          prevMonthButtonDisabled,
          nextMonthButtonDisabled,
        }) => (
          <div
            style={{
              margin: 10,
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <button
              onClick={decreaseMonth}
              disabled={prevMonthButtonDisabled}
              className="btn px-2 py-0"
            >
              {'<'}
            </button>
            <select
              value={date.getFullYear()}
              onChange={({ target: { value } }) => changeYear(value)}
            >
              {years.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>

            <select
              value={months[date.getMonth()]}
              onChange={({ target: { value } }) =>
                changeMonth(months.indexOf(value))
              }
            >
              {months.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>

            <button
              onClick={increaseMonth}
              disabled={nextMonthButtonDisabled}
              className="btn px-2 py-0"
            >
              {'>'}
            </button>
          </div>
        )}
        className={
          (className || '') + (meta?.invalid && meta?.error ? ' hasError' : '')
        }
        selected={
          input.value
            ? stringToDate(input.value, 'dmy')
            : stringToDate(startDate, 'dmy')
        }
        dateFormat="dd/MM/yyyy"
        onChange={(date) => {
          date && input.onChange(moment(date).format('DD/MM/YYYY'));
        }}
        selectsStart
        // startDate={stringToDate(startDate, 'dmy')}
        // endDate={stringToDate(endDate, 'dmy')}
        placeholder={placeholder || 'Nhập ngày'}
        minDate={minDate || null}
        popperContainer={CalendarContainer}
        disabled={disabled}
      />
      {meta?.invalid && meta?.error && (
        <div
          className="text-left"
          style={{
            color: 'rgb(255, 85, 85)',
            margin: '0px 0px 10px',
            fontSize: '0.75rem',
          }}
        >
          {meta?.error}
        </div>
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  return { setting: state.client.setting };
};

export default connect(mapStateToProps)(RenderSelectDate);
