import React, { useEffect } from 'react';
import * as _ from 'lodash';

const RenderFileInput = ({
  input: { value, onChange, ...inputProps },
  opts,
  meta,
  ...props
}) => {
  const handleChange = (event) => {
    const _find = _.find(value, (o) => o === event.target.value);
    if (_find) {
      onChange(_.remove(value, (o) => o !== event.target.value));
    } else {
      onChange([event.target.value, ...value]);
    }
  };
  const { touched, error } = meta;

  return (
    <>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
            gridColumn: '1/4'
          }}
        >
          {error}
        </div>
      )}

      {opts &&
        opts.map((item, index) => (
          <label style={{ paddingTop: '10px', alignSelf: 'end' }} key={index}>
            <input
              value={item.value}
              type="checkbox"
              onChange={handleChange}
              checked={_.some(value, (o) => o === item.value)}
              {...props.input}
              {...props}
            />{' '}
            {item.label}
          </label>
        ))
      }
    </>

  );
};

export default RenderFileInput;
