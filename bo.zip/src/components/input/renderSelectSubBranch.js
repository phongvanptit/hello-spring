import React from 'react';

import * as _ from 'lodash';

function RenderNormalSelect({
  input,
  className,
  disabled,
  opts,
  gwCode,
  bankCode,
  provinceCode,
  meta: { touched, error },
}) {
  console.log(gwCode, bankCode, provinceCode);

  const optToShow = bankCode
    ? _.filter(
      opts,
      (o) =>
        o.C_BANK_CODE === bankCode &&
        (gwCode ? o.C_BANK_GW_CODE === gwCode : true) &&
        (provinceCode ? o.C_PROVINCE_CODE === provinceCode : true)
    )
    : [];
  // console.log(opts)
  return (
    <>
      <select
        {...input}
        className={className}
        style={{
          borderColor: `${touched && error ? '#FF0000' : '#c6cbd2'}`,
        }}
        disabled={disabled}
      >
        <option value={''}>-- Chọn --</option>
        {optToShow &&
          !!optToShow.length &&
          optToShow.map((item, index) => (
            <option key={index} value={item.C_SUB_BRANCH_CODE}>
              {item.C_SUB_BRANCH_NAME}
            </option>
          ))}
      </select>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </>


  );
}

export default RenderNormalSelect;
