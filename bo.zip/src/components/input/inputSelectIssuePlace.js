import React, { useEffect } from 'react';
import styled from 'styled-components';

import { makeGetToken } from 'lib/selector';
import { BsPlus } from 'react-icons/bs';
import { connect } from 'react-redux';

const appUrl = `${process.env.REACT_APP_API_URL}`;

const DivGroup = styled.div`
  position: relative;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: ${(props) => (props.index ? props.index : 1)};
  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
  }
`;

const InputGroup = styled.div`
  display: flex;

  select {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
`;

const ButtonAdd = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #2ca01c;
  border-left: 1px solid #c6cbd2;
  svg {
    margin: auto;
    font-size: 23px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function RenderSelectIssuePlaceInput(props) {
  const wrapperRef = React.useRef(null);

  const {
    input,
    disabled,
    actionAdd,
    fnAddCallback,
    className,
    index,
    opts,
    meta: { touched, error, visited },
  } = props;

  return (
    <>
      <DivGroup
        ref={wrapperRef}
        hasErr={(visited || touched) && error}
        index={index}
      >
        <InputGroup>
          <select
            {...input}
            className={className}
            style={{
              borderColor: `${touched && error ? '#FF0000' : '#c6cbd2'}`,
            }}
            disabled={disabled}
          >
            {opts &&
              !!opts.length &&
              opts.map((item, index) => (
                <option key={index} value={item.value}>
                  {item.label}
                </option>
              ))}
          </select>
          {actionAdd && !disabled && (
            <ButtonAdd onClick={() => (fnAddCallback ? fnAddCallback() : {})}>
              <BsPlus />
            </ButtonAdd>
          )}
        </InputGroup>
      </DivGroup>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  return {
    token: getToken(state),
  };
};
export default connect(mapStateToProps)(RenderSelectIssuePlaceInput);
