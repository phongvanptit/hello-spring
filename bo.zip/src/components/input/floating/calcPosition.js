const calcPosition = (currentRef, targetRef, offSet) => {
  if (!currentRef.current || !targetRef.current) {
    return {
      top: 0,
      left: 0
    }
  }

  if (currentRef.current?.clientHeight === 0) {
    return {
      top: 0,
      left: 0,
    }
  }

  const heightScreen = window.innerHeight
  const widthScreen = window.innerWidth

  const floatingDivPosition = currentRef.current.getBoundingClientRect()
  const inputPosition = targetRef.current.getBoundingClientRect();

  // calc
  let top = inputPosition.top + inputPosition.height + offSet.top
  let left = inputPosition.left

  if (top + currentRef.current.clientHeight > heightScreen) {
    top = top - floatingDivPosition.height - inputPosition.height - 6
  }

  if (left + currentRef.current.clientWidth > widthScreen) {
    left = left - (floatingDivPosition.width - inputPosition.width)
  }

  return {
    top: top,
    left: left,
  }
}

export default calcPosition