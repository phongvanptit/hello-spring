import React, { useEffect, useRef, useState } from 'react';
import styled from 'styled-components';
import { BsPlus } from 'react-icons/bs';
import { ReactComponent as IconDown } from 'assets/img/_ic-down.svg';
import { makeGetListProductCodeFinra, makeGetToken } from 'lib/selector';
import { connect, useDispatch } from 'react-redux';
import * as _ from 'lodash';
import PerfectScrollbar from 'react-perfect-scrollbar';
import FloatingDiv from '../FloatingDiv';
import calcPosition from '../calcPosition';
import { getListProductCodeRequesting } from '../../../../containers/finra/actions';

const appUrl = `${process.env.REACT_APP_API_URL}`;

const DivGroup = styled.div`
  position: relative;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: ${(props) => (props.index ? props.index : 1)};

  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    z-index: ${(props) => (props.index ? props.index : 99)};
  }
`;

const InputGroup = styled.div`
  display: flex;

  input[type='text'] {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
`;

const ButtonDropDown = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  border-left: 1px solid #c6cbd2;
  // background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  &:hover {
    background-color: #e0e0e0;
  }

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #3b3c3f;
  }
`;

const ButtonAdd = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #2ca01c;
  background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  svg {
    margin: auto;
    font-size: 23px;
  }
`;
const FormShow = styled.div`
  min-width: 300px;
  max-width: 450px;
  min-height: 100px;
  padding: 10px 0;
  //animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  // left: -50px;
  //top: calc(100% + 3px);

  ul li {
    display: grid;
    grid-template-columns: auto auto;
    gap: 5px;
    font-size: 13px;
    padding: 5px;
  }
  ul li:first-of-type {
    background: #e6e3dc;
    font-weight: 600;
    text-align: center;
  }
  ul li:not(:first-of-type) b {
    text-align: left;
  }

  ul li:not(:first-of-type):nth-child(odd) {
    background: #f9f9f9;
  }
  ul li:not(:first-of-type).active {
    color: #fff;
    background-color: #2ca01c;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function RenderListProductCode(props) {
  const wrapperRef = useRef(null);
  const inputRef = useRef(null);
  const floatingDivRef = useRef(null);
  const dispatch = useDispatch();

  const [showModal, setShowModal] = useState(false);
  const [list, setList] = useState([]);

  const [positionFloatingDiv, setPositionFloatingDiv] = useState({
    top: 0,
    left: 0,
  });

  const {token, input, disabled, actionAdd, fnAddCallback, className, placeholder, index, meta: { touched, error }} = props;

  useEffect(() => {
    getSuggestions()
  }, []);

  useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (input.value && showModal) {
        getSuggestions(input.value)
      } else {
        getSuggestions()
      }
    }, 150)

    return () => {
      clearTimeout(timeout);
    }
  }, [input.value]);

  useEffect(() => {
    setList(props.listProductCode)
  }, [props.listProductCode]);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      floatingDivRef &&
      wrapperRef.current &&
      floatingDivRef.current &&
      (!wrapperRef.current.contains(event.target) && !floatingDivRef.current.contains(event.target))
    ) {
      handleSetInput();
      setShowModal(false);
    }
  }

  function handleSetInput() {
    if (list === undefined || list === null) {
      input.onChange('');
      return
    }

    if (list.length === 0) {
      input.onChange('');
      return
    }

    const find = list.find((e) => {
      return e.C_PRODUCT_CODE === input.value
    })

    if (!find) {
      input.onChange('');
    }
  }

  function handleSelect(record) {
    setShowModal(false);
    input.onChange(record.C_PRODUCT_CODE);
  }

  function getSuggestions(value) {
    const params = {
      user: token?.USER_NAME,
      session: token?.SESSION_ID,
      cmd: 'MM.GET_ALL_FEE_RATE_SELECT',
      group: 'LIST',
      data: {
        PRODUCT_CODE: value
      },
    };
    dispatch(getListProductCodeRequesting(params))
  }

  const handleShowModel = () => {
    setShowModal(true);
    getSuggestions()
  }

  useEffect(() => {
    const position = calcPosition(floatingDivRef, inputRef, {top: 3})
    setPositionFloatingDiv(position)
  }, [showModal, floatingDivRef.current?.getBoundingClientRect().height]);

  return (
    <>
      <DivGroup
        {...input}
        ref={wrapperRef}
        hasErr={touched && error}
        index={index}
      >
        <InputGroup>
          <input
            disabled={disabled}
            ref={inputRef}
            value={input.value}
            onChange={input.onChange}
            onClick={handleShowModel}
            type={'text'}
            placeholder={placeholder}
            className={className}
            autoComplete="off"
          />
          {actionAdd && !disabled && (
            <ButtonAdd onClick={() => (fnAddCallback ? fnAddCallback() : {})}>
              <BsPlus />
            </ButtonAdd>
          )}
          <ButtonDropDown onClick={handleShowModel} disabled={disabled}>
            <IconDown />
          </ButtonDropDown>
        </InputGroup>
        {showModal && (
          <FloatingDiv portalId={'render-chose-array-floating'}>
            <FormShow
              style={{
                position: 'fixed',
                top: positionFloatingDiv.top,
                left: positionFloatingDiv.left,
                opacity: (positionFloatingDiv.top === 0 && positionFloatingDiv.left === 0) ? 0 : 1,
                zIndex: 9999999
              }}
              ref={floatingDivRef}
            >
              <PerfectScrollbar style={{ maxHeight: '250px', padding: '0 10px' }}>
                <ul>
                  <li>
                    <span>Mã SP</span>
                    <span>Tên SP</span>
                  </li>
                  {props.listProductCode &&
                    !!props.listProductCode.length &&
                    props.listProductCode.map((item, index) => (
                      <li
                        key={index}
                        onClick={() => handleSelect(item)}
                      >
                        <b>{item.C_PRODUCT_CODE}</b>
                        <span>{item.C_PRODUCT_NAME}</span>
                      </li>
                    ))}
                </ul>
                {(!props.listProductCode || !props.listProductCode.length) && (
                  <p className="text-center fz-13">Không có dữ liệu</p>
                )}
              </PerfectScrollbar>
            </FormShow>
          </FloatingDiv>
        )}
      </DivGroup>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  return {
    token: getToken(state),
    listProductCode: makeGetListProductCodeFinra()(state),
  };
};
export default connect(mapStateToProps)(RenderListProductCode);
