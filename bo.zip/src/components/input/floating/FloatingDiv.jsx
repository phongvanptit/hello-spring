import { createPortal } from 'react-dom';
import { useEffect, useState } from 'react';

const FloatingDiv = (props) => {
  const [el, setEl] = useState(document.createElement('div'));

  // Mount element -> create div portal
  useEffect(() => {
    const element = document.createElement('div');
    element.setAttribute('id', props.portalId ? props.portalId : 'floating-div-portal');

    element.style.top = '0';
    element.style.left = '0';

    element.style.height = '100%';
    element.style.width = '100%';

    element.style.position = 'absolute';

    element.addEventListener('mousedown', (e) => {
      if (typeof props.onClose == 'function') {
        if (element === e.target) {
          props.onClose()
        }
      }
    })

    window.addEventListener('keydown', (e) => {
      if (e.code === 'Escape' ) {
        if (typeof props.onClose == 'function') {
          props.onClose()
        }
      }
    })

    if (!bodyHasElement(props.portalId)) {
      document.body.appendChild(element);
    }

    setEl(element);

    // Unmount
    return () => {
      // Remove all element in portal
      el.replaceChildren();

      // Remove portal
      document.body.removeChild(element);
    }
  }, []);

  // Check hash element in body document
  const bodyHasElement = (idElement) => {
    const element = document.getElementById(idElement);
    return !!element;
  }

  return createPortal(props.children, el)
}

export default FloatingDiv