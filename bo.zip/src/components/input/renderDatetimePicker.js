import React from 'react';
import 'react-datetime/css/react-datetime.css';
import Datetime from 'react-datetime';
import moment from 'moment';
import { Portal } from 'react-overlays';

const CalendarContainer = ({ children }) => {
  const el = document.getElementById('calendar-portal');

  return <Portal container={el}>{children}</Portal>;
};

const RenderDatePicker = ({ input, className, meta: { touched, error } }) => {
  // if (!startDate) return null;

  const buildClassNames = (touched, isInvalid) =>
    (className || 'form-input') + (touched && isInvalid ? ' is-invalid' : '');

  return (
    <div>
      <Datetime
        // {...input}
        className={buildClassNames(touched, !!error)}
        timeFormat={false}
        locale="vi-VN"
        dateFormat="DD/MM/YYYY"
        placeholderText="DD/MM/YYYY"
        onChange={(date) => {
          date && input.onChange(moment(date).format('DD/MM/YYYY'));
        }}
      />
    </div>
  );
};

export default RenderDatePicker;
