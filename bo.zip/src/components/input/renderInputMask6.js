import React from 'react';

import TextMask from 'react-text-mask';
import createNumberMask from 'text-mask-addons/dist/createNumberMask';

let pattern = /^0/;

const RenderInputMask = ({
  input,
  className,
  placeholder,
  disabled,
  allowNegative,
  allowDecimal,
  decimalLimit,
  meta: { touched, error },
}) => (
  <div>
    <TextMask
      {...input}
      maxLength="25"
      mask={createNumberMask({
        prefix: '',
        // suffix: ' đồng',
        allowNegative: allowNegative || false,
        allowDecimal: allowDecimal || true,
        decimalLimit: decimalLimit || 6,
      })}
      placeholder={placeholder || ''}
      autoComplete="off"
      className={className}
      onFocus={(e) => e.currentTarget.select()}
      disabled={disabled}
      style={{
        borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
        textAlign: 'right',
      }}
      // onChange={(e) => input?.onChange(e.target.value.replace(/^0/, ''))}
    />
    {touched && error && (
      <div
        className="text-left"
        style={{
          color: '#ff5555',
          margin: '0 0 10px',
          fontSize: '0.75rem',
        }}
      >
        {error}
      </div>
    )}
  </div>
);

export default RenderInputMask;
