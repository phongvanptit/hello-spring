import React from 'react';
import TextMask from 'react-text-mask';

export default function InputPhoneNumber(props) {
  const {
    input,
    meta: { touched, error },
  } = props;

  return (
    <div>
      <TextMask
        {...input}
        mask={[
          /[0-9]/,
          /\d/,
          /\d/,
          /\d/,
          ' ',
          /\d/,
          /\d/,
          /\d/,
          ' ',
          /\d/,
          /\d/,
          /\d/,
        ]}
        className="form-control text-right fz-13"
        type="text"
        placeholder="0988 888 888"
        style={{
          borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
        }}
      />
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}
