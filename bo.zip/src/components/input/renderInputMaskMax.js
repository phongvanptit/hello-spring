import React, { Fragment, useEffect, useState } from 'react';

import TextMask from 'react-text-mask';
import styled from 'styled-components';
import createNumberMask from 'text-mask-addons/dist/createNumberMask';

let pattern = /^0/;

const DivGroup = styled.div`
  position: relative;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: ${(props) => (props.index ? props.index : 1)};

  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
  }
`;

const InputGroup = styled.div`
  display: flex;

  input[type='text'] {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
`;

const ButtonDropDown = styled.div`
  width: 35px;
  max-width: 35px;
  min-width: 35px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border-right: 1px solid #c6cbd2;
  background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  //&:hover {
  //  background-color: #e0e0e0;
  //}

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #3b3c3f;
  }
`;

const RenderInputMaskMax = ({
  input,
  className,
  placeholder,
  disabled,
  allowNegative,
  allowDecimal,
  decimalLimit,
  meta: { touched, error },
}) => {
  const [valueCheckbox, setValueCheckbox] = useState(false);

  useEffect(() => {

    console.log(input.value);
    if (input) {
      setValueCheckbox(input.value === '-1')
    }

  }, [input.value]);

  const handleChangeValueCheckbox = (e) => {
    input.onChange(e.target.checked ? '-1' : '0')
  }

  return (
    <Fragment>
      <DivGroup
        hasErr={touched && error}
      >
        <InputGroup>
          <ButtonDropDown onChange={handleChangeValueCheckbox} disabled={disabled}>
            <input
              type={'checkbox'}
              checked={valueCheckbox}
              onChange={handleChangeValueCheckbox}
              disabled={disabled}
            />
          </ButtonDropDown>
          {input.value === '-1' && (
            <input
              className={className}
              type={'text'}
              value={'Không giới hạn'}
              disabled={true}
            />
          )}
          {input.value !== '-1' && (
            <Fragment>
              <TextMask
                {...input}
                maxLength="26"
                mask={createNumberMask({
                  prefix: '',
                  // suffix: ' đồng',
                  allowNegative: allowNegative || false,
                  allowDecimal: allowDecimal || false,
                  decimalLimit: decimalLimit || 4
                })}
                placeholder={placeholder || ''}
                autoComplete="off"
                className={className}
                onFocus={(e) => e.currentTarget.select()}
                disabled={disabled}
                style={{
                  // borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
                  borderColor: 'none',
                  border: 'none',
                  textAlign: 'right',
                  boxShadow: 'none !important',
                  outline: 'none',
                  height: 26
                }}
                // onChange={(e) => input?.onChange(e.target.value.replace(/^0/, ''))}
              />
            </Fragment>
          )}
        </InputGroup>
      </DivGroup>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem'
          }}
        >
          {error}
        </div>
      )}
    </Fragment>
  );
};

export default RenderInputMaskMax;
