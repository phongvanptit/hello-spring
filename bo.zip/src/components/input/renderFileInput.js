import React, { useEffect } from 'react';

import { usePrevious } from 'lib/useHook';

const adaptFileEventToValue = (delegate) => (e) => delegate(e.target.files[0]);

const RenderFileInput = ({
  input: { value, onChange, onBlur, ...inputProps },
  // meta: {omitMeta, touched, error},
  meta: omitMeta,
  ...props
}) => {
  const _ref = React.useRef(null);

  const preValue = usePrevious(value);

  // console.log(value, preValue)

  // console.log(omitMeta)

  useEffect(() => {
    if (!value && preValue) {
      _ref.current.value = '';
    }
  }, [value]);

  return (
    <input
      ref={_ref}
      onChange={adaptFileEventToValue(onChange)}
      onBlur={adaptFileEventToValue(onBlur)}
      type="file"
      style={{
        border: `${
          omitMeta?.touched && omitMeta?.error ? '1px solid #ff5555' : '0'
        }`,
      }}
      {...props.input}
      {...props}
    />
  );
};

export default RenderFileInput;
