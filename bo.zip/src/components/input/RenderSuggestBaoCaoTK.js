import React from 'react';
import styled from 'styled-components';

import { BsPlus } from 'react-icons/bs';
import { ReactComponent as IconDown } from 'assets/img/_ic-down.svg';
import { makeGetToken } from 'lib/selector';
import { connect } from 'react-redux';
import * as _ from 'lodash';
import { arrBaoCao } from 'utils/const';

import PerfectScrollbar from 'react-perfect-scrollbar';

const DivGroup = styled.div`
  position: relative;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: 2;

  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
  }
`;

const InputGroup = styled.div`
  display: flex;

  input[type='text'] {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
`;

const ButtonDropDown = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  border-left: 1px solid #c6cbd2;
  // background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  &:hover {
    background-color: #e0e0e0;
  }

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #3b3c3f;
  }
`;

const ButtonAdd = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #2ca01c;
  background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  svg {
    margin: auto;
    font-size: 23px;
  }
`;
const FormShow = styled.div`
  min-width: 300px;
  min-height: 100px;
  padding: 10px 0;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  top: calc(100% + 3px);
  max-height: 300px;
  overflow: hidden;

  ul li {
    font-size: 13px;
    padding: 5px;
  }
  ul li:first-of-type {
    background: #e6e3dc;
    font-weight: 600;
    text-align: center;
  }
  ul li:not(:first-of-type) b {
    text-align: center;
  }

  ul li:not(:first-of-type):nth-child(odd) {
    background: #f9f9f9;
  }
  ul li:not(:first-of-type).active {
    color: #fff;
    background-color: #2ca01c;
  }

  .scrollbar-container {
    max-height: 275px;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function escapeRegexCharacters(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function RenderNewInput(props) {
  const abortController = new AbortController();
  const wrapperRef = React.useRef(null);
  const inputRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);
  const [textSearch, setTextSearch] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [suggestions, setSuggestions] = React.useState([]);

  const [indexActive, setIndexActive] = React.useState(0);
  const [selected, setSelected] = React.useState(false);
  const {
    token,
    input,
    disabled,
    actionAdd,
    fnAddCallback,
    className,
    placeholder,
    meta: { touched, error, visited },
  } = props;

  const preInputValue = usePrevious(input?.value);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  React.useEffect(() => {
    // console.log(input?.value)
    if (input?.value && !_.isEqual(input?.value, preInputValue)) {
      setSelected(true);
      //setTextSearch(input?.value);
      getSuggestions(textSearch);
    }
  }, [input?.value]);

  React.useEffect(() => {
    if (selected) return;

    // remove old data
    input.onChange('');
    if (textSearch && !!textSearch.trim().length) {
      setShowModal(true);
      getSuggestions(textSearch);
    } else {
      setSuggestions([]);
      setShowModal(false);
      setIndexActive(-1);
    }
  }, [textSearch]);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      handleSetInput();
      setShowModal(false);
      setSelected(false);
    }
  }

  function _handleShow() {
    if (disabled) return;
    inputRef && inputRef.current.focus();
    setShowModal(true);
    getSuggestions('');
  }

  function handleSetInput() {
    const find = _.find(suggestions, (o) => o.LABEL === textSearch);
    if (suggestions && suggestions.length && find) {
      input.onChange(find?.VALUE);
    } else {
      input.onChange('');
      setTextSearch('');
    }
  }

  function handleKeyDown(event) {
    console.log(event.key);
    if (event.key === 'Enter') {
      event.preventDefault();
      if (indexActive < 0 || indexActive > suggestions.length) return;
      setSelected(true);

      const _record = suggestions[indexActive - 1];
      setShowModal(false);
      input.onChange(_record.VALUE);
      setTextSearch(_record.LABEL);
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (indexActive < suggestions.length) setIndexActive(indexActive + 1);
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (indexActive > 1) setIndexActive(indexActive - 1);
    }
    if (event.key === 'Tab') {
      handleSetInput();
      setShowModal(false);
    }
  }

  function handleSelect(record) {
    setSelected(true);
    setShowModal(false);
    input.onChange(record.VALUE);
    setTextSearch(record.LABEL);
  }

  function getSuggestions(value) {
    const escapedValue = escapeRegexCharacters(value.trim());
    if (escapedValue === '') {
      return setSuggestions(arrBaoCao);
    }

    // const regex = new RegExp(escapedValue, 'img');
    setLoading(true);
    setIndexActive(-1);
    setSuggestions(
      arrBaoCao?.filter((item) =>
        item.LABEL?.toLowerCase().includes(escapedValue?.toLowerCase())
      )
    );
  }

  return (
    <>
      <DivGroup
        {...input}
        ref={wrapperRef}
        hasErr={(visited || touched) && error}
      >
        <InputGroup>
          <input
            disabled={disabled}
            ref={inputRef}
            value={textSearch}
            onChange={(e) => {
              setSelected(false);
              setTextSearch(e.target.value);
            }}
            type={'text'}
            placeholder={placeholder}
            className={className}
            autoComplete="off"
            onKeyDown={handleKeyDown}
            onFocus={(e) => e.target.select()}
          />
          {actionAdd && !disabled && (
            <ButtonAdd onClick={() => (fnAddCallback ? fnAddCallback() : {})}>
              <BsPlus />
            </ButtonAdd>
          )}
          <ButtonDropDown onClick={_handleShow} disabled={disabled}>
            <IconDown />
          </ButtonDropDown>
        </InputGroup>
        {showModal && (
          <FormShow>
            <PerfectScrollbar style={{ padding: '0 10px' }}>
              <ul>
                <li>
                  <span>Tên Báo cáo</span>
                </li>
                {suggestions &&
                  !!suggestions.length &&
                  suggestions.map((item, index) => (
                    <li
                      key={index}
                      className={indexActive - 1 === index ? 'active' : ''}
                      onClick={() => handleSelect(item)}
                    >
                      <span>{item.LABEL}</span>
                    </li>
                  ))}
              </ul>
              {(!suggestions || !suggestions.length) && (
                <p className="text-center fz-13">Không có dữ liệu</p>
              )}
            </PerfectScrollbar>
          </FormShow>
        )}
      </DivGroup>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  const getToken = makeGetToken();

  return {
    token: getToken(state),
  };
};
export default connect(mapStateToProps)(RenderNewInput);
