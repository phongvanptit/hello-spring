import React from 'react';
import { BsInfoCircle } from 'react-icons/bs';
import _ from 'lodash';
import { some, remove } from 'lodash';
import styled from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';

const LiContent = styled.li`
  display: grid;
  grid-template-columns: 15px auto;
  gap: 10px;
  align-items: center;
  user-select: none;

  input[type='checkbox'] {
    height: 12px;
    width: 12px;
  }
`;

const FormShow = styled.div`
  min-height: 250px;
  padding: 10px 0;
  border: 1px solid #ffa31a;
  border-radius: 5px;
`;

function RenderMultipleSelect({ input, disabled, opts, meta, handleDetailGr }) {
  const [arrChecked, setArrChecked] = React.useState([]);

  // keep local state in sync with value from redux-form
  React.useEffect(() => {
    let value = input?.value;
    if (typeof value === 'string') {
      value = value ? value.split(',') : [];
    }
    if (!_.isEqual(value, arrChecked)) {
      setArrChecked(Array.isArray(value) ? value : []);
    }
  }, [input?.value]);

  const handleChange = (event) => {
    const { name, checked } = event.target;
    let newArr = [];
    if (checked) {
      newArr = [...arrChecked, ...[name]];
    } else {
      const _cloneArr = [...arrChecked];
      remove(_cloneArr, (o) => o === name);
      newArr = [..._cloneArr];
    }
    setArrChecked(newArr);
    input.onChange(newArr);
  };

  return (
    <FormShow>
      <PerfectScrollbar style={{ maxHeight: '250px', padding: '0 10px' }}>
        <ul>
          {opts &&
            !!opts.length &&
            opts.map((item, index) => (
              <LiContent key={index}>
                <input
                  type={'checkbox'}
                  checked={some(arrChecked, (o) => o === item.value)}
                  name={item.value}
                  onChange={handleChange}
                  disabled={disabled}
                  id={item.value}
                />
                <span>
                  <label htmlFor={item.value}>{item.label}</label>
                  <BsInfoCircle
                    className="ml-2"
                    style={{ fontSize: '13px', cursor: 'pointer' }}
                    onClick={() => {}}
                  />
                </span>
              </LiContent>
            ))}
        </ul>
      </PerfectScrollbar>
    </FormShow>
  );
}

export default RenderMultipleSelect;
