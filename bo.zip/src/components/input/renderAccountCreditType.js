import React from 'react';
import * as _ from 'lodash';
import styled from 'styled-components';

const ListFunc = styled.ul`
  grid-column: 2/5;
  display: grid;
  // grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px;
  margin-left: 20px;

  li {
    font-size: 13px;

    input {
      margin-right: 5px;
    }
  }
`;

function RenderAccountCreditType(props) {
  const [orderCheck, setOrderCheck] = React.useState([]);

  const { opts, input } = props;

  React.useEffect(() => {
    // console.log(input?.value)
    if (input?.value) {
      // const _func = input?.value.split(',').sort();
      setOrderCheck(input?.value.sort());
    } else {
      setOrderCheck([]);
    }
  }, [input?.value]);

  function _handleChange(e) {
    const { checked, name } = e.target;
    // console.log(checked, name);
    let xxx = [...orderCheck];

    if (checked) {
      xxx.push(name);
    } else {
      _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
    input.onChange(xxx);
  }

  console.log(opts);

  return (
    <ListFunc>
      {opts &&
        opts.map((item, index) => (
          <li key={index}>
            <label>
              <input
                name={item.value}
                type={'checkbox'}
                checked={_.some(orderCheck, (o) => o === item.value)}
                onChange={_handleChange}
              />
              {item.label}
            </label>
          </li>
        ))}
    </ListFunc>
  );
}

export default RenderAccountCreditType;
