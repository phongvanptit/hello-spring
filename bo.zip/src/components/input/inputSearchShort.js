import React from 'react';
import styled from 'styled-components';
import * as _ from 'lodash';
import { FiSearch } from 'react-icons/fi';

const InputGroup = styled.div`
  display: flex;

  input[type='text'] {
    border: 0;
    height: 26px;
    border-radius: unset;
    border-top-left-radius: 0.25rem;
    border-bottom-left-radius: 0.25rem;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
  svg {
    width: 25%;
    background-color: #ffffff;
    height: 26px;
    border-top-right-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
    padding: 4px;
    cursor: pointer;
    color: #64748b;
  }
`;

function RenderSearchShort(props) {
  const {
    input,
    type = 'text',
    className,
    placeholder,
    autoFocus = false,
    disabled,
    clickSearch,
    meta: { touched, error },
  } = props;

  function handleKeyDown(event) {
    if (event.key === 'Enter') {
      clickSearch();
    }
  }

  return (
    <InputGroup>
      <input
        {...input}
        type={type}
        className={className}
        placeholder={placeholder}
        autoComplete="off"
        autoFocus={autoFocus}
        disabled={disabled}
        onKeyDown={handleKeyDown}
        onFocus={(e) => e.target.select()}
        style={{
          borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
        }}
      />
      <FiSearch onClick={clickSearch} />
    </InputGroup>
  );
}

export default RenderSearchShort;
