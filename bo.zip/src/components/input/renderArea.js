import React from 'react';

const RenderArea = ({
  input,
  type,
  className,
  rows,
  disabled,
  meta: { touched, error },
}) => (
  <>
    <textarea
      {...input}
      type={type}
      className={className}
      rows={rows}
      disabled={disabled}
      style={{
        borderColor: `${touched && error ? '#ff5555' : '#c6cbd2'}`,
      }}
    />
    {touched && error && (
      <div
        className="text-left"
        style={{
          color: '#ff5555',
          margin: '0 0 10px',
          fontSize: '0.75rem',
        }}
      >
        {error}
      </div>
    )}
  </>
);

export default RenderArea;
