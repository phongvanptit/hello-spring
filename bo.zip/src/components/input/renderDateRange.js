import React from 'react';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import { stringToDate } from 'utils';
import { Portal } from 'react-overlays';

const CalendarContainer = ({ children }) => {
  const el = document.getElementById('calendar-portal');

  return <Portal container={el}>{children}</Portal>;
};

const RenderDateRange = ({
  input,
  placeholder,
  className,
  containerClassName,
  type,
  startDate,
  endDate,
  maxDate,
  minDate,
  meta: { touched, error },
}) => {
  //   if (!startDate || !endDate) return null;

  const buildClassNames = (touched, isInvalid) =>
    (className || 'form-input') + (touched && isInvalid ? ' is-invalid' : '');

  return (
    <>
      {type === 'start' ? (
        <DatePicker
          // {...input}
          className={buildClassNames(touched, !!error)}
          placeholderText="DD/MM/YYYY"
          selected={
            input.value
              ? stringToDate(input.value, 'dmy')
              : startDate
              ? stringToDate(startDate, 'dmy')
              : null
          }
          dateFormat="dd/MM/yyyy"
          onChange={(date) => {
            date && input.onChange(moment(date).format('DD/MM/YYYY'));
          }}
          selectsStart
          startDate={stringToDate(startDate, 'dmy')}
          endDate={stringToDate(endDate, 'dmy')}
          placeholder={placeholder || 'Nhập ngày'}
          minDate={minDate || null}
          popperContainer={CalendarContainer}
          showYearDropdown
          todayButton="Today"
          autoComplete="off"
        />
      ) : (
        <DatePicker
          {...input}
          className={buildClassNames(touched, !!error)}
          selected={
            input.value
              ? stringToDate(input.value, 'dmy')
              : endDate
              ? stringToDate(endDate, 'dmy')
              : null
          }
          dateFormat="dd/MM/yyyy"
          onChange={(date) => {
            date && input.onChange(moment(date).format('DD/MM/YYYY'));
          }}
          selectsEnd
          startDate={stringToDate(startDate, 'dmy')}
          endDate={stringToDate(endDate, 'dmy')}
          minDate={stringToDate(startDate, 'dmy')}
          placeholder={placeholder || 'Nhập ngày'}
          maxDate={maxDate || null}
          popperClassName={containerClassName || ''}
          popperContainer={CalendarContainer}
          showYearDropdown
          todayButton="Today"
          autoComplete="off"
        />
      )}
    </>
  );
};

export default RenderDateRange;
