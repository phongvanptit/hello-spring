import React from 'react';
function RenderNormalSelect(props) {
  const {
    input,
    className,
    disabled,
    opts,
    required = false,
    meta: { touched, error },
    placeholder,
    classParent,
    onChange,
  } = props;

  const handleChange = (e) => {
    // Call redux-form's onChange first to update form state
    input.onChange(e);
    // Then call custom onChange if provided
    if (onChange) {
      onChange(e);
    }
  };

  return (
    <div className={classParent}>
      <select
        {...input}
        onChange={handleChange}
        className={className}
        style={{
          borderColor: `${touched && error ? '#FF0000' : '#c6cbd2'}`,
        }}
        disabled={disabled}
      >
        {!required && (
          <option value={''}>{placeholder ? placeholder : '-- Chọn --'}</option>
        )}
        {opts &&
          !!opts.length &&
          opts.map((item, index) => (
            <option key={index} value={item.value}>
              {item.label}
            </option>
          ))}
      </select>
      {touched && error && (
        <div
          className="text-left"
          style={{
            color: '#ff5555',
            margin: '0 0 10px',
            fontSize: '0.75rem',
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}

export default RenderNormalSelect;
