import React, { useState } from 'react';
import styled from 'styled-components';
import PerfectScrollbar from 'react-perfect-scrollbar';

import { BsPlus } from 'react-icons/bs';
import { ReactComponent as IconDown } from 'assets/img/_ic-down.svg';
import { makeGetToken } from 'lib/selector';
import { connect } from 'react-redux';
import * as _ from 'lodash';

const DivGroup = styled.div`
  position: relative;
  border: 1px solid ${(props) => (props.hasErr ? '#ff5555' : '#c6cbd2')};
  border-radius: 0.25rem;
  z-index: ${(props) => (props.index ? props.index : 1)};

  &:focus-within,
  :active {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
  }
`;

const InputGroup = styled.div`
  display: flex;

  input[type='text'] {
    border: 0;
    border-radius: 0.25rem;
    height: 26px;

    &:active,
    :focus {
      border: none;
      outline: none;
      box-shadow: none;
    }
  }
`;

const ButtonDropDown = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  border-left: 1px solid #c6cbd2;
  // background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  &:hover {
    background-color: #e0e0e0;
  }

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #3b3c3f;
  }
`;

const ButtonAdd = styled.div`
  width: 46px;
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #2ca01c;
  background: ${(props) => (props.disabled ? '#e9ecef' : '#fff')};

  svg {
    margin: auto;
    font-size: 23px;
  }
`;
const FormShow = styled.div`
  min-width: 300px;
  min-height: 100px;
  padding: 10px 0;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  left: -50px;
  top: calc(100% + 3px);

  ul li {
    display: grid;
    grid-template-columns: 30px 90px auto;
    gap: 5px;
    font-size: 13px;
    padding: 5px;
  }
  ul li:first-of-type {
    background: #e6e3dc;
    font-weight: 600;
    text-align: center;
  }
  ul li:not(:first-of-type) b {
    text-align: center;
  }

  ul li:not(:first-of-type):nth-child(odd) {
    background: #f9f9f9;
  }
  ul li:not(:first-of-type).active {
    color: #fff;
    background-color: #2ca01c;
  }
`;

function usePrevious(value) {
  const ref = React.useRef();

  React.useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function RenderNormalSelect(props) {
  const {
    token,
    input,
    disabled,
    className,
    placeholder,
    index,
    opts,
    meta: { touched, error },
  } = props;
  const wrapperRef = React.useRef(null);
  const inputRef = React.useRef(null);

  const [showModal, setShowModal] = React.useState(false);
  const [textSearch, setTextSearch] = React.useState('');
  const [orderCheck, setOrderCheck] = useState([]);
  const preShowModal = usePrevious(showModal);
  const preInputValue = usePrevious(input?.value);

  React.useEffect(() => {
    if (!_.isEqual(input?.value, preInputValue)) {
      // support both string (comma separated) and array
      if (typeof input?.value === 'string') {
        setTextSearch(input?.value);
        input?.value && setOrderCheck(input?.value.split(','));
      } else if (Array.isArray(input?.value)) {
        setOrderCheck(input.value);
        setTextSearch(input.value.join(','));
      } else {
        setOrderCheck([]);
        setTextSearch('');
      }
    }
  }, [input?.value]);

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);
    // See note below
    return () => window.removeEventListener('mousedown', handleClickOutside);
  });

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShowModal(false);
    }
  }

  // React.useEffect(() => {
  //   if (showModal && !_.isEqual(showModal, preShowModal)) {
  //     setOrderCheck([]);
  //   }
  // }, [showModal]);

  function _handleShow() {
    if (disabled) return;
    setShowModal(!showModal);
  }

  function _handleChange(e) {
    // set gia tri old value
    // do not call input.onChange here; commit on add

    const { checked, name } = e.target;
    let xxx = [...orderCheck];
    if (checked) {
      xxx.push(name);
    } else {
      const rm = _.remove(xxx, (o) => o === name);
    }

    setOrderCheck(xxx);
  }

  function handleOnChange(e) {
    setTextSearch(e.target.value);
  }

  function fnAddCallback() {
    // emit as array so form values are consistent with other multi-select components
    input.onChange(orderCheck);
    setTextSearch(orderCheck.join(','));
    setShowModal(false);
  }

  return (
    <DivGroup
      ref={wrapperRef}
      hasErr={touched && error}
      index={index}
      {...input}
    >
      <InputGroup>
        <input
          ref={inputRef}
          value={textSearch}
          onChange={(e) => handleOnChange(e)}
          type={'text'}
          placeholder={placeholder}
          className={className}
          autoComplete="off"
          onFocus={(e) => e.target.select()}
          disabled={disabled}
        />
        {showModal && !disabled && (
          <ButtonAdd onClick={() => (fnAddCallback ? fnAddCallback() : {})}>
            <BsPlus />
          </ButtonAdd>
        )}
        <ButtonDropDown onClick={_handleShow} disabled={disabled}>
          <IconDown />
        </ButtonDropDown>
      </InputGroup>
      {showModal && (
        <FormShow>
          <PerfectScrollbar style={{ maxHeight: '250px', padding: '0 10px' }}>
            <ul>
              <li>
                <span>#</span>
                <span>Mã</span>
                <span>Tên</span>
              </li>
              {opts &&
                !!opts.length &&
                opts.map((item, index) => (
                  <li key={index}>
                    <input
                      type={'checkbox'}
                      name={item.value}
                      onChange={_handleChange}
                      checked={_.some(orderCheck, (o) => o === item.value)}
                      style={{ maxHeight: '19.5px' }}
                    />
                    <b>{item.value}</b>
                    <span>{item.label}</span>
                  </li>
                ))}
            </ul>
            {(!opts || !opts.length) && (
              <p className="text-center fz-13">Không có dữ liệu</p>
            )}
          </PerfectScrollbar>
        </FormShow>
      )}
    </DivGroup>
  );
}

export default RenderNormalSelect;
