import React, { Fragment } from 'react';
import { translate } from 'react-i18next';
import { connect } from 'react-redux';
import MmContract from './mm-contract/MmContract';

function GroupTabs(props) {
  return (
    <Fragment>
      {props.subType === 'list' && (
        <MmContract
          onComplete={props.onComplete}
          onSetMessageContent={props.onSetMessageContent}
          triggerChangeReloadData={props.triggerChangeReloadData}
        />
      )}
    </Fragment>
  );
}

const makeMapStateToProps = () => {

  return (state) => {
    return {

    };
  };
};

export default connect(makeMapStateToProps)(
  translate('translations')(GroupTabs)
);
