import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import NodataSearch from 'components/noDataSearch';
import Paging from 'components/paging';
import {
    makeGetAccountRight, makeGetActionDepositContract,
    makeGetMainListDepositContract,
    makeGetToken
} from 'lib/selector';
import * as _ from 'lodash';
import React, { Fragment, useEffect, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { GroupButton } from 'utils/styledComponent';
import FormSearch from './form-search/formSearch';
import { usePrevious } from '../../../../lib/useHook';
import {
    actionDepositContractRequesting,
    mainListDepositContractRequesting,
    mainListDepositContractSuccess
} from '../../../../containers/deposit-contract/actions';
import { numberFormat, numberFormatDecimal } from '../../../../utils';
import AddDepositContract from 'components/modal/deposit-contract/contract/AddDepositContract';
import DetailDepositContract from 'components/modal/deposit-contract/contract/DetailDepositContract';
import { TiDownload } from 'react-icons/ti';
import CRUDDepositContractLiquid from 'components/modal/deposit-contract/contract-liquid/CRUDDepositContractLiquid';
import { makeGetPfAccFunc } from 'lib/selector';

const configActionButton = {
    delete: {
        messageRequest: 'txt_mm_delete_deposit_contract_req',
        messageSuccess: 'txt_mm_delete_deposit_contract_success',
        cmd: 'MM.DELETE_DEPOSIT_CONTRACT'
    },
    approve: {
        messageRequest: 'txt_mm_approve_deposit_contract_req',
        messageSuccess: 'txt_mm_approve_deposit_contract_success',
        cmd: 'MM.APPROVE_ITEM_DEPOSIT_CONTRACT'
    },
    un_approve: {
        messageRequest: 'txt_mm_un_approve_deposit_contract_req',
        messageSuccess: 'txt_mm_un_approve_deposit_contract_success',
        cmd: 'MM.UN_APPROVE_ITEM_DEPOSIT_CONTRACT'
    }
}

function MmContract(props) {
    const t = props.t;

    const [page, setPage] = useState(1);
    const [recordPerPage, setRecordPerPage] = useState(10);
    const [recordDetail, setRecordDetail] = useState(undefined);
    const [dataSearch, setDataSearch] = useState(undefined);
    const [showLiquidForm, setShowLiquidForm] = useState(false);
    const [isShowBtnLiquid, setIsShowBtnLiquid] = useState(false);

    const dispatch = useDispatch();
    const preActionDepositContract = usePrevious(props.actionDepositContract);

    useEffect(() => {
        setDataSearch({
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ALL_DEPOSIT_CONTRACT',
            group: 'LIST',
            data: {
                CUSTOMER_CODE: '',
                CUSTOMER_NAME: '',
                ACCOUNT_CODE: '',
                CONTRACT_CODE: '',
                CHANNEL: '',
                STATUS: '',
                // OPEN_FROM_DATE: Date.now(),
                // OPEN_TO_DATE: Date.now(),
                // EXPIRE_FROM_DATE: Date.now(),
                // EXPIRE_TO_DATE: Date.now(),
                FLAG_DOC_BASE: '-1',
                FLAG_DOC: '-1',

                PAGE: page || 1,
                RECORD_PER_PAGE: recordPerPage || 10,
            },
        });

        return () => {
            dispatch(mainListDepositContractSuccess(undefined))
        }
    }, [])

    useEffect(() => {
        if (dataSearch) {
            callSearch()
        }
    }, [dataSearch, props.triggerChangeReloadData]);
    
    useEffect(() => {
        if (props.accRightCus) {
            setIsShowBtnLiquid(props.accRightCus.find(x => x.C_FUNCTION_CODE === '5020001'))
        }
    }, [props.accRightCus]);

    useEffect(() => {
        if (props.actionDepositContract && !_.isEqual(props.actionDepositContract, preActionDepositContract)) {
            props.onComplete()
        }
    }, [props.actionDepositContract]);

    const callSearch = () => {
        dispatch(mainListDepositContractRequesting(dataSearch))
    }

    useEffect(() => {
        if (dataSearch) {
            dataSearch.data.PAGE = page
            dataSearch.data.RECORD_PER_PAGE = recordPerPage
            setDataSearch({ ...dataSearch })
        }
    }, [page, recordPerPage]);

    function handleNextPage(step) {
        setPage(step)
    }

    function handleChangeRecordPerPage(value) {
        setRecordPerPage(value)
    }

    function onClose(pk) {
        setRecordDetail(undefined);
    }

    function handleShowItem(value) {
        setRecordDetail(value);
    }

    function handleButtonAction(pk, action) {
        if (!pk) return;
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configActionButton[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                handleAction(pk, action);
                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    function handleAction(pk, action) {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configActionButton[action].cmd,
            group: 'LIST',
            data: {
                ITEM_ID: pk
            },
        };

        props.onSetMessageContent(configActionButton[action].messageSuccess)
        dispatch(actionDepositContractRequesting(params))
    }

    const handleShowUpdateLiquid = (value) => {
        setShowLiquidForm(true);
        setRecordDetail(value);
    }

    return (
        <div className="w-100 d-flex flex-column custom-tabs-content my-3">
            <FormSearch callSearch={callSearch} dataSearch={dataSearch} setDataSearch={setDataSearch} />
            <Table bordered>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>{t('txt_deposit_contract_tb_inv_appendix_code')}</th>
                        <th>{t('txt_deposit_contract_tb_customer_code')}</th>
                        <th>{t('txt_deposit_contract_tb_customer_name')}</th>
                        <th>{t('txt_deposit_contract_tb_account_code')}</th>
                        <th>{t('txt_finra_tb_appendix_capital')}</th>
                        <th>{t('txt_finra_tb_appendix_capital_liquid')}</th>
                        <th>{t('txt_deposit_contract_tb_open_date')}</th>
                        <th>{t('txt_deposit_contract_tb_expire_date')}</th>
                        <th>{t('txt_deposit_contract_tb_content')}</th>
                        <th>{t('txt_deposit_contract_tb_status')}</th>
                        <th>{t('txt_deposit_contract_tb_create_code')}</th>
                        <th>{t('txt-action')}</th>
                    </tr>
                </thead>
                <tbody>
                    {props.allDepositContract &&
                        props.allDepositContract.map((item) => (
                            <tr key={item.ROW_NUM}>
                                <td className="text-center">{numberFormatDecimal(item.ROW_NUM)}</td>
                                <td className="text-center">{item.C_INV_APPENDIX_CODE}</td>
                                <td className="text-center">{item.C_CUSTOMER_CODE}</td>
                                <td className="text-left">{item.C_CUSTOMER_NAME}</td>
                                <td className="text-center">{item.C_ACCOUNT_CODE}</td>
                                <td className="text-right">{numberFormatDecimal(item.C_CAPITAL)}</td>
                                <td className="text-right">{numberFormatDecimal(item.C_CAPITAL_LIQUID)}</td>
                                <td className="text-center">{item.C_OPEN_DATE}</td>
                                <td className="text-center">{item.C_EXPIRE_DATE}</td>
                                <td className="text-left">{item.C_CONTENT}</td>
                                <td className={'orderStt_' + item.C_STATUS + ' text-center'}>
                                    {item.C_STATUS_NAME}
                                </td>
                                <td className="text-center">{item.C_CREATOR_CODE}</td>
                                <td className="text-center p-0">
                                    <GroupButton>
                                        {props.accRight?.C_VIEW === 1 && (
                                            <a
                                                title={t('txt-detail')}
                                                rel="noreferrer noopener"
                                                onClick={() => handleShowItem(item.PK_MM_INV_APPENDIX)}
                                            >
                                                <IconCopy />
                                            </a>
                                        )}
                                        {props.accRight?.C_APPROVE === 1 && (
                                            <a
                                                title={t('txt-appr')}
                                                className={item.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                                                rel="noreferrer noopener"
                                                onClick={() => item.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_MM_INV_APPENDIX, 'approve') : undefined}
                                            >
                                                <IconApprove />
                                            </a>
                                        )}
                                        {props.accRight?.C_UPDATE === 1 && (
                                            <a
                                                title={t('txt-del')}
                                                className={item.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                                                rel="noreferrer noopener"
                                                onClick={() => item.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_MM_INV_APPENDIX, 'delete') : undefined}
                                            >
                                                <IconTrash />
                                            </a>
                                        )}
                                        {isShowBtnLiquid?.C_UPDATE === 1 && (
                                            <a
                                                title={t('txt-liquid')}
                                                className={item?.C_STATUS === 'DA_DUYET' ? '' : 'disabled'}
                                                onClick={() => item?.C_STATUS === 'DA_DUYET' ? handleShowUpdateLiquid(item.PK_MM_INV_APPENDIX) : undefined}
                                            >
                                                <TiDownload />
                                            </a>
                                        )}
                                    </GroupButton>
                                </td>
                            </tr>
                        ))}
                </tbody>
            </Table>

            {(!props.allDepositContract || !props.allDepositContract.length) && (
                <NodataSearch name={t('lab_deposit_contract_tab_contract')} />
            )}

            <div className="mt-3 d-flex justify-content-end">
                <Paging
                    page={page}
                    nextPage={handleNextPage}
                    recordPerPage={recordPerPage}
                    setRecordPerPage={handleChangeRecordPerPage}
                    total={
                        props.allDepositContract && !!props.allDepositContract.length
                            ? props.allDepositContract[0].C_TOTAL_RECORD
                            : 0
                    }
                />
            </div>
            {recordDetail && !showLiquidForm && (
                <DetailDepositContract
                    itemId={recordDetail}
                    onClose={onClose}
                    onComplete={props.onComplete}
                    onSetMessageContent={props.onSetMessageContent}
                />
            )}
            {recordDetail && showLiquidForm && (
                <CRUDDepositContractLiquid
                    itemId={undefined}
                    depositCtID={recordDetail}
                    onClose={() => { setShowLiquidForm(false); setRecordDetail(undefined) }}
                    onComplete={props.onComplete}
                    onSetMessageContent={props.onSetMessageContent}
                    triggerChangeReloadData={props.triggerChangeReloadData}
                />
            )}
        </div>
    );
}

const makeMapStateToProps = () => {
    const getToken = makeGetToken();
    const getAccountRight = makeGetAccountRight();
    const getMainListDepositContract = makeGetMainListDepositContract();

    return (state) => {
        return {
            token: getToken(state),
            accRight: getAccountRight(state),
            accRightCus: makeGetPfAccFunc()(state),

            allDepositContract: getMainListDepositContract(state),
            actionDepositContract: makeGetActionDepositContract()(state),
        };
    };
};

export default connect(makeMapStateToProps)(
    translate('translations')(MmContract)
);
