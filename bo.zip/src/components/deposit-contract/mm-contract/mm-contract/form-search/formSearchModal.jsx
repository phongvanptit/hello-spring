import { useRef, useState, useEffect} from 'react';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import RenderSelectDate from 'components/input/renderDatePicker';
import { BtnClose, BtnSubmit } from 'utils/styledComponent';
import RenderInput from 'components/input/renderInput';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();
  const [calendarOpen, setCalendarOpen] = useState(false);

  const {
    handleSubmit,
    submitting,
    t,
    dataSearch,
    onTriggerPopover,
    onClose,
  } = props;

  useEffect(() => {
    onTriggerPopover && onTriggerPopover(calendarOpen);
  }, [calendarOpen]);

  const submit = (values) => {
    dataSearch.data.CUSTOMER_CODE = values.formCustomerCode;
    dataSearch.data.STATUS = values.formStatus;
    dataSearch.data.INV_APPENDIX_CODE = values.formAppendixNumber;
    dataSearch.data.EXPIRE_FROM_DATE = values.formExpireFromDate;
    dataSearch.data.EXPIRE_TO_DATE = values.formExpireToDate;
    props.setDataSearch(dataSearch)
    props.callSearch()
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalBLS', 'formCustomerCode', ''));
    dispatch(change('formSearchModalBLS', 'formStatus', ''));
    dispatch(change('formSearchModalBLS', 'formAppendixNumber', ''));
    dispatch(change('formSearchModalBLS', 'formExpireFromDate', ''));
    dispatch(change('formSearchModalBLS', 'formExpireToDate', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100 ">
        {/* Mã khách hàng */}
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-cust-code')}</Form.Label>
          <Field
            name={'formCustomerCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
        {/* Mã hợp đòng */}
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-contract-code')}</Form.Label>
          <Field
            name={'formAppendixNumber'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
        {/* Ngày hết hạn từ */}
        {/* <Form.Group>
          <Form.Label className="fz-13">{t('txt-expire-from-date')}</Form.Label>
          <Field
            name={'formExpireFromDate'}
            className="form-control"
            classParentName="w-100"
            component={RenderSelectDate}
            onCalendarOpen={() => setCalendarOpen(true)}
            onCalendarClose={() => setCalendarOpen(false)}
          />
        </Form.Group> */}
        {/* Ngày hết hạn đến */}
        {/* <Form.Group>
          <Form.Label className="fz-13">{t('txt-expire-to-date')}</Form.Label>
          <Field
            name={'formExpireToDate'}
            className="form-control"
            classParentName="w-100"
            component={RenderSelectDate}
            onCalendarOpen={() => setCalendarOpen(true)}
            onCalendarClose={() => setCalendarOpen(false)}
          />
        </Form.Group> */}
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalBLS',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalBLS');

const makeMapStateToProps = () => {

  const mapStateToProps = (state, props) => {
    const {
      formCustomerCode,
      formAppendixNumber,
      formStatus,
      formExpireFromDate,
      formExpireToDate,
    } = selector(
      state,
      'formCustomerCode',
      'formAppendixNumber',
      'formStatus',
      'formExpireFromDate',
      'formExpireToDate',
    );

    const { dataSearch } = props;

    return {
      formCustomerCode,
      formAppendixNumber,
      formStatus,
      formExpireFromDate,
      formExpireToDate,

      initialValues: {
        formCustomerCode: dataSearch?.data?.CUSTOMER_CODE,
        formAppendixNumber: dataSearch?.data?.INV_APPENDIX_CODE,
        formStatus: dataSearch?.data?.STATUS,
        formExpireFromDate: dataSearch?.data?.EXPIRE_FROM_DATE,
        formExpireToDate: dataSearch?.data?.EXPIRE_TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
