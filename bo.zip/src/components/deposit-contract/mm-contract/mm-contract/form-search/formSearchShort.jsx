import React, { useEffect, useRef } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import RenderSearchShort from 'components/input/inputSearchShort';
import RenderNormalSelect from 'components/input/renderNormalSelect';
import { Form } from 'react-bootstrap';
import { translate } from 'react-i18next';
import * as _ from 'lodash';
import {
  FormFlexCenter,
} from 'utils/styledComponent';
import { makeGetPublicStt } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import { makeGetCapContractStt } from 'lib/selector';

function usePrevious(value) {
  const ref = useRef();

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
}

function FormSearch(props) {
  const {
    handleSubmit,
    t,
    formStatus,
    glStatusList
  } = props;

  const submit = (values) => {
    props.dataSearch.data.CUSTOMER_CODE = values.formCustomerCode;
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.INV_APPENDIX_CODE = values.formAppendixCode;
    props.dataSearch.data.CUSTOMER_NAME = values.formCustomerName;
    props.setDataSearch(props.dataSearch);
    props.callSearch()
  };

  function _handleBlur() {
    props.dataSearch.data.CUSTOMER_CODE = props.formCustomerCode;
    props.dataSearch.data.STATUS = props.formStatus;
    props.dataSearch.data.INV_APPENDIX_CODE = props.formAppendixCode;
    props.dataSearch.data.CUSTOMER_NAME = props.formCustomerName;
    props.setDataSearch(props.dataSearch);
    props.callSearch()
  }
  useEffect(() => {
    if (props.dataSearch) {
      _handleBlur()
    }
  }, [props.formStatus, props.formCustomerCode, props.formAppendixCode, props.formCustomerName]);

  return (
    <FormFlexCenter onSubmit={handleSubmit(submit)} className="w-100">
      <div className="d-flex align-items-center mr-auto">
        {/* Trạng thái */}
        <Form.Label className="fz-13 w-fix">{t('txt-status')}</Form.Label>
        <Field
          name="formStatus"
          className="form-control w_100 ml-2 mr-3"
          component={RenderNormalSelect}
          opts={glStatusList}
          placeholder="-- Tất cả --"
        />
        {/* <Form.Label className="fz-13 mr-2">{t('txt_deposit_contract_liquid_tb_inv_appendix_code')}</Form.Label>
        <Field
          name={'formAppendixCode'}
          type="text"
          className="form-control w_125 mr-3"
          placeholder={t('txt_deposit_contract_liquid_tb_inv_appendix_code')}
          component={RenderInput}
        /> */}
        <Form.Label className="fz-13 mr-2">{t('txt_finra_tb_contract_cus_code')}</Form.Label>
        <Field
          name={'formCustomerCode'}
          type="text"
          className="form-control w_110 mr-3"
          placeholder={t('txt_finra_tb_contract_cus_code')}
          component={RenderInput}
        />
      </div>
      <Field
        name="formAppendixCode"
        type="text"
        className="form-control"
        placeholder={t('txt_deposit_contract_liquid_tb_inv_appendix_code')}
        component={RenderSearchShort}
        onBlur={_handleBlur}
        clickSearch={_handleBlur}
      />
    </FormFlexCenter>
  );
}

FormSearch = reduxForm({
  form: 'formSearchShortBLS',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchShortBLS');

const makeMapStateToProps = () => {
  const mapStateToProps = (state) => {
    const { formCustomerCode, formStatus, formAppendixCode, formCustomerName } = selector(
      state,
      'formCustomerCode',
      'formStatus',
      'formAppendixCode',
      'formCustomerName',
    );

    return {
      // glStatusList: makeGetPublicStt()(state),
      glStatusList: makeGetCapContractStt()(state),

      formCustomerCode,
      formStatus,
      formAppendixCode,
      formCustomerName,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
