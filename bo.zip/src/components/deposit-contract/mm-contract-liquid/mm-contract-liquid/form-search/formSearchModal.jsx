import React, { useRef } from 'react';
import { Form } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { Field, formValueSelector, reduxForm, change } from 'redux-form';
import { makeGetToken } from 'lib/selector';
import RenderInput from 'components/input/renderInput';
import { translate } from 'react-i18next';

import { BtnClose, BtnSubmit } from 'utils/styledComponent';

function FormSearch(props) {
  const refSubmit = useRef(null);
  const dispatch = useDispatch();

  const {
    handleSubmit,
    submitting,
    t,
    onClose,
    reset,
  } = props;

  const submit = (values) => {
    props.dataSearch.data.CUSTOMER_CODE = values.formCustomerCode;
    props.dataSearch.data.STATUS = values.formStatus;
    props.dataSearch.data.INV_APPENDIX_CODE = values.formAppendixNumber;
    props.dataSearch.data.EXPIRE_FROM_DATE = values.formExpireFromDate;
    props.dataSearch.data.EXPIRE_TO_DATE = values.formExpireToDate;

    props.setDataSearch(props.dataSearch);
    props.callSearch();
    onClose();
  };

  const handleReset = () => {
    dispatch(change('formSearchModalLiquid', 'formCustomerCode', ''));
    dispatch(change('formSearchModalLiquid', 'formStatus', ''));
    dispatch(change('formSearchModalLiquid', 'formAppendixNumber', ''));
    dispatch(change('formSearchModalLiquid', 'formExpireFromDate', ''));
    dispatch(change('formSearchModalLiquid', 'formExpireToDate', ''));
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <div className="d-grid grid-3 w-100 ">
        {/* Mã khách hàng */}
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-cust-code')}</Form.Label>
          <Field
            name={'formCustomerCode'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
        {/* Mã hợp đòng */}
        <Form.Group>
          <Form.Label className="fz-13">{t('txt-contract-code')}</Form.Label>
          <Field
            name={'formAppendixNumber'}
            type="text"
            className="form-control"
            placeholder={t('txt-cust-code')}
            component={RenderInput}
          />
        </Form.Group>
      </div>
      <hr />
      <div
        className="d-flex mt-2"
        style={{ height: '30px', whiteSpace: 'nowrap' }}
      >
        <BtnClose type="button" onClick={handleReset} className="mr-auto">
          {t('txt-del')}
        </BtnClose>
        <div className="d-flex">
          <BtnSubmit ref={refSubmit} type="submit" disabled={submitting}>
            {t('txt-filter')}
          </BtnSubmit>
        </div>
      </div>
    </form>
  );
}

FormSearch = reduxForm({
  form: 'formSearchModalLiquid',
  enableReinitialize: true,
})(FormSearch);

const selector = formValueSelector('formSearchModalLiquid');

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state, props) => {
    const {
      formCustomerCode,
      formAppendixNumber,
      formStatus,
      formExpireFromDate,
      formExpireToDate,
    } = selector(
      state,
      'formCustomerCode',
      'formAppendixNumber',
      'formStatus',
      'formExpireFromDate',
      'formExpireToDate',
    );

    const { dataSearch } = props;

    return {
      token: getToken(state),
      formCustomerCode,
      formAppendixNumber,
      formStatus,
      formExpireFromDate,
      formExpireToDate,

      initialValues: {
        formCustomerCode: dataSearch?.data?.CUSTOMER_CODE,
        formAppendixNumber: dataSearch?.data?.INV_APPENDIX_CODE,
        formStatus: dataSearch?.data?.STATUS,
        formExpireFromDate: dataSearch?.data?.EXPIRE_FROM_DATE,
        formExpireToDate: dataSearch?.data?.EXPIRE_TO_DATE,
      },
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(FormSearch)
);
