import CRUDDepositContractLiquid from "components/modal/deposit-contract/contract-liquid/CRUDDepositContractLiquid";
import NoDataSearch from "components/noDataSearch";
import { ReactComponent as IconCopy } from 'assets/img/icon/ic_copy.svg';
import { ReactComponent as IconTrash } from 'assets/img/icon/ic_trash.svg';
import { ReactComponent as IconApprove } from 'assets/img/icon/ic_approve.svg';
import Paging from 'components/paging';
import {
    mainListDepositContractRequesting,
    actionDepositContractRequesting,
    mainListDepositContractSuccess
} from "containers/deposit-contract/actions";
import {
    makeGetActionDepositContractLiquid,
    makeGetAccountRight,
    makeGetMainListDepositContractLiquid,
    makeGetToken
} from "lib/selector";
import { usePrevious } from "lib/useHook";
import { useEffect, useState } from "react";
import { confirmAlert } from "react-confirm-alert";
import { translate } from "react-i18next";
import { connect, useDispatch } from "react-redux";
import { Table } from "react-bootstrap";
import { numberFormatDecimal } from "utils";
import { GroupButton } from "utils/styledComponent";
import { makeGetMainListDepositContract } from "lib/selector";
import { makeGetActionDepositContract } from "lib/selector";
import * as _ from 'lodash';
import FormSearch from './form-search/formSearch';

const configActionButton = {
    delete: {
        messageRequest: 'txt_mm_delete_deposit_contract_req',
        messageSuccess: 'txt_mm_delete_deposit_contract_success',
        cmd: 'MM.DELETE_DEPOSIT_CONTRACT_LIQUID'
    },
    approve: {
        messageRequest: 'txt_mm_approve_deposit_contract_req',
        messageSuccess: 'txt_mm_approve_deposit_contract_success',
        cmd: 'MM.APPROVE_ITEM_DEPOSIT_CONTRACT_LIQUID'
    },
    un_approve: {
        messageRequest: 'txt_mm_un_approve_deposit_contract_req',
        messageSuccess: 'txt_mm_un_approve_deposit_contract_success',
        cmd: 'MM.UN_APPROVE_ITEM_DEPOSIT_CONTRACT_LIQUID'
    }
}

function MmContractLiquid(props) {
    const t = props.t;

    const [page, setPage] = useState(1);
    const [recordPerPage, setRecordPerPage] = useState(10);
    const [recordDetail, setRecordDetail] = useState(undefined);
    const [depositCtID, setDepositCtID] = useState(undefined);
    const [dataSearch, setDataSearch] = useState(undefined);

    const dispatch = useDispatch();
    const preActionLiquid = usePrevious(props.actionLiquid);

    useEffect(() => {
        setDataSearch({
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: 'MM.GET_ALL_DEPOSIT_CONTRACT_LIQUID',
            group: 'LIST',
            data: {
                CUSTOMER_CODE: '',
                LIQUID_TYPE: '',
                INV_APPENDIX_CODE: '',
                STATUS: '',
                // OPEN_FROM_DATE: Date.now(),
                // OPEN_TO_DATE: Date.now(),
                // EXPIRE_FROM_DATE: Date.now(),
                // EXPIRE_TO_DATE: Date.now(),
                FLAG_DOC_BASE: '-1',
                FLAG_DOC: '-1',

                PAGE: page || 1,
                RECORD_PER_PAGE: recordPerPage || 10,
            },
        });

        return () => {
            dispatch(mainListDepositContractSuccess(undefined))
        }
    }, [])

    useEffect(() => {
        if (dataSearch) {
            callSearch()
        }
    }, [dataSearch, props.triggerChangeReloadData]);

    useEffect(() => {
        if (dataSearch) {
            dataSearch.data.PAGE = page
            dataSearch.data.RECORD_PER_PAGE = recordPerPage
            setDataSearch({ ...dataSearch })
        }
    }, [page, recordPerPage]);

    useEffect(() => {
        if (props.actionLiquid && !_.isEqual(props.actionLiquid, preActionLiquid)) {
            props.onComplete()
        }
    }, [props.actionLiquid]);

    const callSearch = () => {
        dispatch(mainListDepositContractRequesting(dataSearch))
    }

    function handleNextPage(step) {
        setPage(step)
    }

    function handleChangeRecordPerPage(value) {
        setRecordPerPage(value)
    }

    function onClose(pk) {
        setRecordDetail(undefined);
    }

    function handleShowItem(value, depositCtID) {
        setRecordDetail(value);
        setDepositCtID(depositCtID);
    }

    function handleButtonAction(pk, action) {
        if (!pk) return;
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className="custom-ui-confirm">
                        <h1>{t('txt-confirm')}</h1>
                        <p>{t(configActionButton[action].messageRequest)}</p>
                        <button onClick={onClose}>{t('txt-cancel')}</button>
                        <button
                            onClick={() => {
                                handleAction(pk, action);
                                onClose();
                            }}
                        >
                            {t('txt-confirm')}
                        </button>
                    </div>
                );
            },
            closeOnEscape: true,
            closeOnClickOutside: true,
            keyCodeForClose: [8, 32],
        });
    }

    function handleAction(pk, action) {
        const params = {
            user: props.token?.USER_NAME,
            session: props.token?.SESSION_ID,
            cmd: configActionButton[action].cmd,
            group: 'LIST',
            data: {
                ITEM_ID: pk
            },
        };

        props.onSetMessageContent(configActionButton[action].messageSuccess)
        dispatch(actionDepositContractRequesting(params))
    }

    return (
        <div className="w-100 d-flex flex-column custom-tabs-content my-3">
            <FormSearch callSearch={callSearch} dataSearch={dataSearch} setDataSearch={setDataSearch} />
            <Table bordered>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>{t('txt_deposit_contract_tb_inv_appendix_code')}</th>
                        <th>{t('txt_deposit_contract_liquid_tb_customer_code')}</th>
                        <th>{t('txt_deposit_contract_liquid_tb_customer_name')}</th>
                        <th>{t('txt_finra_tb_appendix_liquid_capital')}</th>
                        <th>{t('txt_deposit_contract_liquid_tb_liquid_date')}</th>
                        <th>{t('txt_deposit_contract_liquid_tb_content')}</th>
                        <th>{t('txt_deposit_contract_liquid_tb_status')}</th>
                        <th>{t('txt_deposit_contract_liquid_tb_create_code')}</th>
                        <th>{t('txt-action')}</th>
                    </tr>
                </thead>
                <tbody>
                    {props.allLiquid &&
                        props.allLiquid.map((item) => (
                            <tr key={item.ROW_NUM}>
                                <td className="text-center">{numberFormatDecimal(item.ROW_NUM)}</td>
                                <td className="text-center">{item.C_INV_APPENDIX_CODE}</td>
                                <td className="text-center">{item.C_CUSTOMER_CODE}</td>
                                <td className="text-left">{item.C_CUSTOMER_NAME}</td>
                                <td className="text-right">{numberFormatDecimal(item.C_CAPITAL)}</td>
                                <td className="text-center">{item.C_LIQUID_DATE}</td>
                                <td className="text-left">{item.C_CONTENT}</td>
                                <td className={'orderStt_' + item.C_STATUS + ' text-center'}>
                                    {item.C_STATUS_NAME}
                                </td>
                                <td className="text-center">{item.C_CREATOR_CODE}</td>
                                <td className="text-center p-0">
                                    <GroupButton>
                                        {props.accRight?.C_VIEW === 1 && (
                                            <a
                                                title={t('txt-detail')}
                                                rel="noreferrer noopener"
                                                onClick={() => handleShowItem(item.PK_INV_APPENDIX_LIQUID, item.FK_MM_INV_APPENDIX)}
                                            >
                                                <IconCopy />
                                            </a>
                                        )}
                                        {props.accRight?.C_APPROVE === 1 && (
                                            <a
                                                title={t('txt-appr')}
                                                className={item.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                                                rel="noreferrer noopener"
                                                onClick={() => item.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_INV_APPENDIX_LIQUID, 'approve') : undefined}
                                            >
                                                <IconApprove />
                                            </a>
                                        )}
                                        {props.accRight?.C_UPDATE === 1 && (
                                            <a
                                                title={t('txt-del')}
                                                className={item?.C_STATUS === 'CHUA_DUYET' ? '' : 'disabled'}
                                                rel="noreferrer noopener"
                                                onClick={() => item?.C_STATUS === 'CHUA_DUYET' ? handleButtonAction(item.PK_INV_APPENDIX_LIQUID, 'delete') : undefined}
                                            >
                                                <IconTrash />
                                            </a>
                                        )}
                                    </GroupButton>
                                </td>
                            </tr>
                        ))}
                </tbody>
            </Table>

            {
                (!props.allLiquid || !props.allLiquid.length) && (
                    <NoDataSearch name={t('lab_deposit_contract_tab_liquid')} />
                )
            }
            <div className="mt-3 d-flex justify-content-end">
                <Paging
                    page={page}
                    nextPage={handleNextPage}
                    recordPerPage={recordPerPage}
                    setRecordPerPage={handleChangeRecordPerPage}
                    total={
                        props.allLiquid && !!props.allLiquid.length
                            ? props.allLiquid[0].C_TOTAL_RECORD
                            : 0
                    }
                />
            </div>
            {recordDetail && depositCtID && (
                <CRUDDepositContractLiquid
                    itemId={recordDetail}
                    depositCtID={depositCtID}
                    onClose={() => { setDepositCtID(undefined); setRecordDetail(undefined) }}
                    onComplete={props.onComplete}
                    onSetMessageContent={props.onSetMessageContent}
                    triggerChangeReloadData={props.triggerChangeReloadData}
                />
            )}
        </div>
    );
}

const makeMapStateToProps = () => {
    return (state) => {
        return {
            token: makeGetToken()(state),
            accRight: makeGetAccountRight()(state),

            allLiquid: makeGetMainListDepositContract()(state),
            actionLiquid: makeGetActionDepositContract()(state),
        };
    };
};

export default connect(makeMapStateToProps)(
    translate('translations')(MmContractLiquid)
);