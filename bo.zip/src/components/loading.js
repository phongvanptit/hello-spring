import React from 'react';

function Loading() {
  return (
    <div className="animated fadeIn pt-1 text-center text-primary fz-12">
      Loading...
    </div>
  );
}

export default Loading;
