import React from 'react';
import styled from 'styled-components';

import { ReactComponent as IconPlus } from 'assets/img/icon/ic-creator.svg';

const GroupButton = styled.div`
  position: relative;
  display: flex;
  margin-left: auto;
`;

const ButtonDropDown = styled.div`
  width: 46px;
  background-color: #ffa31a;
  border-radius: 0 12px 12px 0;
  display: flex;
  align-items: center;
  cursor: pointer;

  &:hover {
    background-color: #ffd34b;
  }

  svg {
    margin: auto;
    height: 6px;
  }

  svg path {
    fill: #1c1c1c;
  }

  .line {
    margin: 5px 0 5px 5px;
    width: 1px;
    height: 25px;
    background: #1c1c1c;
  }
`;

const ButtonNormal = styled.div`
  margin-left: 10px;
  color: #1c1c1c;
  background-color: #ffa31a;
  border-radius: 12px;
  font-size: 13px;
  line-height: 24px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px 16px 8px 16px;
  cursor: pointer;

  &:hover {
    background-color: #ffd34b;
  }
`;

const FormShow = styled.div`
  min-width: 250px;
  min-height: 100px;
  animation: fadeIn 1s;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 1px rgba(12, 26, 75, 0.24),
    0px 3px 8px -1px rgba(50, 50, 71, 0.05);

  position: absolute;
  right: 0;
  top: 100%;
`;

function ImportButton(props) {
  const wrapperRef = React.useRef(null);

  const { onClick } = props;


  return (
    <ButtonNormal
      onClick={onClick}
    >
      <IconPlus className="mr-3" /> Import
    </ButtonNormal> 
  );
}

export default ImportButton;
