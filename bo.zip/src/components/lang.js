import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { makeGetToken } from 'lib/selector';

import flagVi from 'assets/img/flag/vn-icon.png';
import flagEn from 'assets/img/flag/en-icon.png';
import Down from 'assets/img/icon/icDown.svg';

import { translate } from 'react-i18next';
import { setSetting } from 'containers/client/actions';
import { saveState } from 'lib/storages';

function LanguageToggle(props) {
  const wrapperRef = React.useRef();
  const [language, setLanguage] = React.useState('vi');
  const [show, setShow] = React.useState(false);
  const {
    setting,
    setting: { lang },
  } = props;
  const dispatch = useDispatch();

  React.useEffect(() => {
    window.addEventListener('mousedown', handleClickOutside);

    // See note below
    return () => {
      window.removeEventListener('mousedown', handleClickOutside);
    };
  });

  React.useEffect(() => {
    const lang = setting.lang || 'vi';
    if (lang !== 'vi') changeLangLogin(lang);
  }, []);

  React.useEffect(() => {
    if (lang) {
      changeLangLogin(lang);
    }
  }, [lang]);

  function handleClickOutside(event) {
    if (
      wrapperRef &&
      wrapperRef.current &&
      !wrapperRef.current.contains(event.target)
    ) {
      setShow(false);
    }
  }

  function changeLangLogin(curLang) {
    setLanguage(curLang);

    props.i18n.changeLanguage(curLang);
    let _setting = Object.assign({}, setting);
    _setting.lang = curLang;

    dispatch(setSetting(_setting));
    saveState('setting', _setting);
    setShow(false);
  }

  return (
    <div className="lang mx-2">
      <div
        as="span"
        id="dropdown-custom-components"
        className="d-flex flex-row align-items-center"
        style={{
          borderRadius: '30px',
          backgroundColor: ' #dee2e6',
          padding: '5px 8px',
        }}
      >
        <img
          src={language === 'vi' ? flagVi : flagEn}
          alt=""
          style={{ width: '16px', cursor: 'pointer' }}
          onClick={() => setShow(true)}
        />
        <img
          src={Down}
          alt="vi"
          style={{ width: '10px', cursor: 'pointer' }}
          className="ml-1 icon-down"
          onClick={() => setShow(true)}
        />
      </div>
      {show && (
        <ul className="select-lang-header" ref={wrapperRef}>
          <li>
            <a
              onClick={() => changeLangLogin('vi')}
              style={{ cursor: 'pointer' }}
            >
              <img src={flagVi} alt="vi" style={{ width: '15px' }} />
              <span className="fz-12 ml-2">Tiếng Việt</span>
            </a>
          </li>
          <li>
            <a
              onClick={() => changeLangLogin('en')}
              style={{ cursor: 'pointer' }}
            >
              <img src={flagEn} alt="en" style={{ width: '15px' }} />
              <span className="fz-12 ml-2">English</span>
            </a>
          </li>
        </ul>
      )}
    </div>
  );
}

const makeMapStateToProps = () => {
  const getToken = makeGetToken();

  const mapStateToProps = (state) => {
    return {
      token: getToken(state),
      setting: state.client.setting,
    };
  };
  return mapStateToProps;
};

export default connect(makeMapStateToProps)(
  translate('translations')(LanguageToggle)
);
