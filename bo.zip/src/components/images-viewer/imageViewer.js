import React from 'react';
import styled from 'styled-components';
import ArrowLeft from './icons/arrow_left';
import ArrowRight from './icons/arrow_right';
import Close from './icons/Close';

const ViewerContainer = styled.div`
  -webkit-box-pack: center;
  -webkit-box-align: center;
  align-items: center;
  box-sizing: border-box;
  display: flex;
  height: 100%;
  justify-content: center;
  left: 0px;
  padding: 10px;
  position: fixed;
  top: 0px;
  width: 100%;
  z-index: 2001;
  background: rgba(0, 0, 0, 0.8);
`;

const ViewerContent = styled.div`
  position: relative !important;
  margin-bottom: 0px;
  max-width: 1024px;
`;

const ContentHeader = styled.div`
  -webkit-box-pack: justify;
  display: flex;
  justify-content: space-between;
  height: 40px;
`;

const ButtonAct = styled.button`
  background: none;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  outline: none;
  padding: 10px;
  position: absolute;
  top: 50%;
  user-select: none;
  fill: rgb(255, 255, 255);
  height: 120px;
  margin-top: -60px;
  width: 70px;

  &.arrow-left {
    left: 10px;
  }

  &.arrow-right {
    right: 10px;
  }
`;

const ButtonClose = styled.button`
  background: none;
  border: none;
  cursor: pointer;
  outline: none;
  position: relative;
  top: 0px;
  vertical-align: bottom;
  z-index: 1;
  height: 40px;
  margin-right: -10px;
  padding: 10px;
  width: 40px;
  fill: white;
`;

const Figure = styled.figure`
  margin: 0px !important;

  img {
    cursor: pointer;
    max-height: calc(100vh - 140px);
    display: block !important;
    height: auto !important;
    margin: 0px auto !important;
    max-width: 100% !important;
    user-select: none !important;
    transition: opacity 0.3s ease 0s !important;
    opacity: 1 !important;
  }
`;

function ImagesViewer(props) {
  const { imgs, onClose } = props;

  const [curImg, setCurImg] = React.useState('');
  const [index, setIndex] = React.useState(0);

  React.useEffect(() => {
    if (imgs && !!imgs.length) {
      setCurImg(imgs[0]);
    }
  }, []);

  React.useEffect(() => {
    if (imgs && !!imgs.length && index) {
      setCurImg(imgs[index]);
    }
  }, [index]);

  function handlePrev() {
    setIndex(index - 1);
  }

  function handleNext() {
    setIndex(index + 1);
  }

  return (
    <ViewerContainer>
      <ViewerContent>
        <ContentHeader>
          <span />
          <ButtonClose onClick={onClose}>
            <span dangerouslySetInnerHTML={{ __html: Close }} />
          </ButtonClose>
        </ContentHeader>
        <Figure>
          <img src={curImg} alt="" />
        </Figure>
      </ViewerContent>
      {index > 0 && (
        <ButtonAct className="arrow-left" onClick={() => handlePrev()}>
          <span dangerouslySetInnerHTML={{ __html: ArrowLeft }} />
        </ButtonAct>
      )}
      {imgs && index < imgs.length - 1 && (
        <ButtonAct className="arrow-right" onClick={() => handleNext()}>
          <span dangerouslySetInnerHTML={{ __html: ArrowRight }} />
        </ButtonAct>
      )}
    </ViewerContainer>
  );
}

export default ImagesViewer;
