import React, { useEffect } from 'react';
import { Button, Nav } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { reduxForm, Field, formValueSelector } from 'redux-form';
import loginRequest from 'containers/login/actions';
import { usePrevious } from 'lib/useHook';
import Errors from 'notifications/Errors';
import Messages from 'notifications/Messages';
import { required } from 'utils/validation';
import RenderInput from 'components/input/renderInput';

import * as _ from 'lodash';

// import Logo from 'assets/img/logo.png';
import Logo from 'assets/img/finra/logo-horizontal.png';
import { useHistory } from 'react-router';

function FormLogin(props) {
  const dispatch = useDispatch();
  const history = useHistory();

  const {
    handleSubmit,
    login: { requesting, successful, messages, errors },
  } = props;

  const preErrors = usePrevious(errors);

  useEffect(() => {
    if (!requesting && !!errors.length && !_.isEqual(preErrors, errors)) {
      props.reset();
    }
  }, [requesting, errors]);

  function submit(values) {
    // history.push('/dashboard');
    // return;
    dispatch(loginRequest(values.username, values.password));
  }

  return (
    <>
      <form className="form-login" onSubmit={handleSubmit(submit)}>
        <div className="text-center">
          <img src={'/images/bolt-holdings.svg'} alt="" style={{ height: '35px' }} />
        </div>
        <h1 className="text-center">Đăng nhập</h1>

        <Field
          name="username"
          type="text"
          id="username"
          className="form-control"
          placeholder="SĐT/Số CMT/ CCCD"
          autoComplete="username"
          component={RenderInput}
          validate={[required]}
        />
        <Field
          name="password"
          type="password"
          id="password"
          className="form-control mt-2"
          placeholder="Password"
          autoComplete="current-password"
          component={RenderInput}
          validate={[required]}
        />
        <div className="justify-content-center">
          <Button
            type="submit"
            className="btn-login my-2 w-100"
            style={{ height: '40px', backgroundColor: '#3C3C3C' }}
          >
            Đăng nhập
          </Button>
        </div>
        <div className="auth-messages">
          {!requesting && !!errors.length && (
            <Errors message="Failure to login due to:" errors={errors} />
          )}
          {!requesting && !!messages.length && <Messages messages={messages} />}
          {requesting && <div>Logging in...</div>}
        </div>
        <div className="d-flex flex-row align-items-center justify-content-center">
          <div
            style={{
              backgroundColor: process.env.REACT_APP_PROJECT_ENV === 'uat' ? 'lightgray' : '#d5eed5',
              padding: '2px 8px',
              border: '1px solid',
              borderColor: process.env.REACT_APP_PROJECT_ENV === 'uat' ? 'gray' : 'green',
              borderRadius: '50px',
              fontSize: '12px',
            }}
          >
            MT hệ thống: {process.env.REACT_APP_PROJECT_ENV === 'uat' ? <span style={{color: 'red', fontWeight: 'bold'}}>UAT</span> : <span style={{color: 'green', fontWeight: 'bold'}}>Production</span>}
          </div>
        </div>
      </form>
    </>
  );
}

FormLogin = reduxForm({
  form: 'formLogin',
  enableReinitialize: true,
})(FormLogin);

const selector = formValueSelector('formLogin');

const mapStateToProps = (state) => {
  const { username, password } = selector(state, 'username', 'password');

  return {
    login: state.login,

    username,
    password,

    initialValues: {
      username: '',
      password: '',
    },
  };
};

export default connect(mapStateToProps)(FormLogin);
