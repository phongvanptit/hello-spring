import React, { useEffect } from 'react';
import { Button, Row } from 'react-bootstrap';
import { connect, useDispatch } from 'react-redux';
import { reduxForm, Field, formValueSelector } from 'redux-form';
// import { makeGetChangePass } from 'lib/selector';
import { renderParams } from 'utils';
import { required, minLength } from 'utils/validation';
import RenderInput from 'components/input/renderInput';

import { toast as notify } from 'react-toastify';

import * as _ from 'lodash';
import { usePrevious } from 'lib/useHook';

import Logo from 'assets/img/logo-gls.png';
// import Logo from 'assets/img/logo.png';

const minLength8 = minLength(8);

function FormChangePass(props) {
  const dispatch = useDispatch();

  const { handleSubmit, pristine, submitting, tempToken, changePass } = props;

  const preChangePass = usePrevious(changePass);

  useEffect(() => {
    if (changePass && !_.isEqual(changePass, preChangePass)) {
      if (changePass.success) {
        notify.success(
          'Đổi mật khẩu thành công. Quý khách cần đang nhập lại để tiếp tục'
        );
        props.reset();
        dispatch({ type: 'CLIENT_UNSET' });
        dispatch({ type: 'CLEAR_CHANGE_PASS' });
        props.setCode(1);
      } else if (!changePass.success && !!changePass.error.length) {
        notify.error(changePass.error[0]);
      }
    }
  }, [changePass]);

  function submit(values) {
    console.log(values);
    const { oldPass, newPass, confirmPass } = values;

    if (newPass && confirmPass && !_.isEqual(newPass, confirmPass)) {
      notify.warning('Mật khẩu mới và nhập lại mật khẩu mới không trùng nhau');
      return;
    }

    const _data = {
      cmd: 'UPDATE_PASSWORD',
      param: {
        C_USER: tempToken.USER_NAME,
        C_PASSWORD_OLD: oldPass,
        C_PASSWORD_NEW: newPass,
      },
    };

    const _params = renderParams(_data, tempToken);

    // dispatch(changePassRequest(_params));
  }

  return (
    <>
      <form className="form-login" onSubmit={handleSubmit(submit)}>
        <div className="text-center">
          <img src={Logo} alt="" style={{ height: '35px' }} />
        </div>
        <h1 className="text-center">Đổi mật khẩu</h1>

        <div className="info">
          <label className="form-label fz-13">Mật khẩu cũ</label>
          <Field
            name="oldPass"
            type="password"
            className="form-control"
            component={RenderInput}
            validate={[required]}
          />

          <label className="form-label fz-13 mt-2">Mật khẩu mới</label>
          <Field
            name="newPass"
            type="password"
            className="form-control"
            component={RenderInput}
            validate={[required, minLength8]}
          />

          <label className="form-label fz-13 mt-2">Nhập lại mật khẩu</label>
          <Field
            name="confirmPass"
            type="password"
            className="form-control"
            component={RenderInput}
            validate={[required, minLength8]}
          />
        </div>

        <Row className="justify-content-center">
          <Button
            type="submit"
            className="btn-login my-2"
            style={{ whiteSpace: 'nowrap' }}
            disabled={pristine || submitting}
          >
            Cập nhật
          </Button>
        </Row>
      </form>
      {/* <div className="auth-messages">
        {!requesting && !!errors.length && (
          <Errors message="Failure to login due to:" errors={errors} />
        )}
        {!requesting && !!messages.length && <Messages messages={messages} />}
        {requesting && <div>Logging in...</div>}
      </div> */}
    </>
  );
}

FormChangePass = reduxForm({
  form: 'fromChangePass',
  enableReinitialize: true,
})(FormChangePass);

const selector = formValueSelector('fromChangePass');

const mapStateToProps = (state) => {
  // const getChangePass = makeGetChangePass();

  const { oldPass, newPass, confirmPass } = selector(
    state,
    'oldPass',
    'newPass',
    'confirmPass'
  );

  return {
    // changePass: getChangePass(state),

    oldPass,
    newPass,
    confirmPass,

    initialValues: {
      oldPass: '',
      newPass: '',
      confirmPass: '',
    },
  };
};

export default connect(mapStateToProps)(FormChangePass);
